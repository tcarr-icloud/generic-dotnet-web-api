CREATE PROCEDURE [metrc].[usp_tag_type_count]
	@id_location INT
AS
	SELECT t.tag_type
			, COUNT(*) AS available_count
	FROM metrc.tag t
	/* check for tag use in existing package. */
	LEFT JOIN (
		SELECT b.*
		FROM inventory.batch b
		JOIN inventory.inventory i ON i.id_batch=b.id_batch
		JOIN inventory.area a ON a.id_area=i.id_area AND a.id_location=@id_location
	) b ON b.metrc_package_label=t.tag AND t.tag_type like '%package%'

	/* check for tag use in plant. */
	LEFT JOIN (
		SELECT p.*
		FROM grow.plant p
		JOIN inventory.area a ON a.id_area=p.id_area AND a.id_location=@id_location
	) p ON p.metrc_label=t.tag AND t.tag_type like '%plant%'
	WHERE t.id_location = @id_location AND t.is_available = 1 AND b.metrc_package_label IS NULL AND p.metrc_label IS NULL
	GROUP BY t.tag_type
go

