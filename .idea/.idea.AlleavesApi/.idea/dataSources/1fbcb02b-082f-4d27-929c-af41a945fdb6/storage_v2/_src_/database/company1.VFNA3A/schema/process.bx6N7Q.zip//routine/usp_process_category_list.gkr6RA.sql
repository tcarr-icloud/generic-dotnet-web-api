CREATE PROCEDURE [process].[usp_process_category_list]
AS
	SET NOCOUNT ON

	SELECT id_process_category
			, guid_process_category
			, name AS process_category
			, sequence
			, deleted
	FROM process.process_category
	WHERE deleted=0
	ORDER BY sequence
go

