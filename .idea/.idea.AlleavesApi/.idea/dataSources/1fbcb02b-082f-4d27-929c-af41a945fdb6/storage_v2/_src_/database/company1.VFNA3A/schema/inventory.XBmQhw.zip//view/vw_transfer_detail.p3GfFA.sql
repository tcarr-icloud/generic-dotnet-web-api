CREATE VIEW [inventory].[vw_transfer_detail]
	AS 
SELECT t.id_transfer
		, ii.id_item
		, ISNULL(e.id_batch, ti.id_batch) AS id_batch
		, t.date_created
		, ii.item
		, ISNULL(e.batch, b.name) AS batch
		, ti.quantity
		, COALESCE(b.cost_of_good, eb.cost_of_good, ii.cost_of_good, 0) AS cog_per_item
		, ti.quantity * COALESCE(b.cost_of_good, eb.cost_of_good, ii.cost_of_good, 0) AS cog_transferred
		, ISNULL(lt.name, vt.name) AS ship_to
		, ISNULL(lf.name, vf.name) AS ship_from
		, ts.status
		, ts.date_verified AS status_date
FROM inventory.transfer t
JOIN inventory.transfer_item ti ON ti.id_transfer=t.id_transfer
LEFT JOIN inventory.batch b ON b.id_batch=ti.id_batch
JOIN inventory.item i ON i.id_item=ti.id_item OR i.id_item=b.id_item
JOIN inventory.vw_item_list ii ON ii.id_item=i.id_item
LEFT JOIN base.location lf ON lf.id_location=t.id_location_source
LEFT JOIN inventory.vendor vf ON vf.id_vendor=t.id_vendor_source
LEFT JOIN base.location lt ON lt.id_location=t.id_location_destination
LEFT JOIN inventory.vendor vt ON vt.id_vendor=t.id_vendor_destination
LEFT JOIN [log].vw_event_list e ON e.id_item=ii.id_item AND ti.quantity_received=e.adjustment AND e.event='transfer_receive' AND RIGHT(e.notes, 4)=CAST(t.id_transfer as varchar(10))
LEFT JOIN inventory.batch eb ON eb.id_batch=e.id_batch
JOIN (
	SELECT h.id_transfer
			, s.name AS status
			, h.date_verified
	FROM (
		SELECT id_transfer
				, MAX(date_verified) as date_verified
		FROM inventory.transfer_status_history 
		GROUP BY id_transfer
	) h1
	JOIN inventory.transfer_status_history h ON h.id_transfer=h1.id_transfer AND h.date_verified=h1.date_verified		
	JOIN inventory.transfer_status s ON s.id_transfer_status=h.id_transfer_status
)
ts ON ts.id_transfer=t.id_transfer
go

