CREATE PROCEDURE [inventory].[usp_cycle_count_fetch]
	@id_cycle_count INT
AS
	SELECT cc.id_cycle_count
		, cc.id_user
		, cc.id_location
		, l.name AS location
		, ar.name AS adjust_reason_name
		, cc.adjust_reason_note
		, u.FirstName + ' ' + u.LastName as user_name
		, cc.start_date
        , cc.end_date
        , cc.in_progress
        , cc.completed
        , cc.cancelled
		, ISNULL((SELECT cci.id_inventory_item
						, cci.id_area
						, cci.id_batch
						, cci.id_item
						, i.category_path
						, i.item
						, i.sku
						, b.name AS batch
						, a.path AS area_path
						, cci.expected_count
						, cci.actual_count
				  FROM inventory.cycle_count_item cci
				  LEFT JOIN inventory.vw_item_list i ON i.id_item=cci.id_inventory_item
				  LEFT JOIN inventory.batch b ON b.id_batch=cci.id_batch
				  LEFT JOIN inventory.vw_area_list a ON a.id_area=cci.id_area
				  WHERE cci.id_cycle_count=cc.id_cycle_count
				  FOR JSON PATH, INCLUDE_NULL_VALUES
		), '[]') AS item_list
	FROM inventory.cycle_count cc
	JOIN base.[user] u on u.id_user = cc.id_user
	JOIN base.location l on l.id_location = cc.id_location
	LEFT JOIN [inventory].adjust_reason ar ON ar.id_adjust_reason = cc.id_adjust_reason
	WHERE cc.id_cycle_count=@id_cycle_count
go

