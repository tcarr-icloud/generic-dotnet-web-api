CREATE        view  powerbi.Powerbi_table_employee as
(select (select u.FirstName + ' ' + u.LastName from base.[user] u where u.id_user=o.created_by) AS 'employee_name',
        o.created_by as employee_id,
       (select address from base.location where id_location= o.id_location) as location,
       CONVERT( varchar,  dbo.fn_utc_to_local(o.date_created,o.id_location)  , 101) as date_created,
       count(distinct o.id_order)   as "Number of Tickets",
       (select count(case when [order].returns < 0 then 1 else null end)from [order].[order] where [order].created_by = o.created_by) as total_returns,
       (select count(case [order].void when 1 then 1 else null end)from [order].[order] where [order].created_by = o.created_by) as total_voids,
       cast(COUNT(oi.id_inventory_item) as float) / cast(count(distinct o.id_order)  as float)         as UPT,
       sum(oi.price_post_tax)                                     as "Sales Total",
       sum(oi.price_post_tax) / count(distinct o.id_order)      as ATP,
       COUNT(oi.id_inventory_item) as "Number of items"
from [order].[order] o
INNER JOIN [order].[item] oi on oi.id_order = o.id_order
group by o.created_by,CONVERT( varchar,  dbo.fn_utc_to_local(o.date_created,o.id_location)  , 101),o.id_location)
go

