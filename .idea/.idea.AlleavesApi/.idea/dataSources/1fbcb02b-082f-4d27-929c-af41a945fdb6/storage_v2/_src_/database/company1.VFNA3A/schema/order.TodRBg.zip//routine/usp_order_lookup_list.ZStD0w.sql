


CREATE PROCEDURE [order].[usp_order_lookup_list]
	@id_order_lookup INT = NULL
AS
	SELECT 
			  o.id_order_lookup
			, o.location
			, cu.id_customer
			, cu.id_customer_biotrack
			, cu.id_user_online
			, cu.patient_number
			, cu.name_first
			, cu.name_last
			, cu.email
			, o.id_order_online
			, o.id_checkin
			, o.ticket
			, o.source
			, o.sale_type
			, o.status
			, CAST(o.order_date AS VARCHAR(32)) AS order_date
			, CONVERT(VARCHAR(32), o.order_date, 0) AS order_date_display
			, o.pickup_time
			, o.verified
			, o.scheduled
			, o.packed
			, o.id_user_working
			, CASE WHEN u.FirstName IS NOT NULL THEN u.FirstName + ' ' + u.LastName ELSE null END AS user_working
			, o.id_onfleet
			, m.id_manifest
			, CONVERT(VARCHAR(32), CAST(CAST(o.date_received AS DATETIME2(0)) AT TIME ZONE 'UTC' as DATETIME), 120) AS date_received_utc
			, CONVERT(VARCHAR(32), CAST(CAST(o.date_received AS DATETIME2(0)) AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows as DATETIME), 120) AS date_received
			, CONVERT(VARCHAR(20), CAST(CAST(o.date_received AS DATETIME2(0)) AT TIME ZONE 'UTC' as DATETIME), 0) AS date_received_display_utc
			, CONVERT(VARCHAR(20), CAST(CAST(o.date_received AS DATETIME2(0)) AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows as DATETIME), 0) AS date_received_display
        FROM [order].order_lookup o
        LEFT JOIN [base].[user] u ON u.id_user=o.id_user_working
		LEFT JOIN dbo.tz_lookup tz on tz.tz_iana = 'America/New_York'
		LEFT JOIN [order].manifest m ON m.id_order_lookup=o.id_order_lookup
		LEFT JOIN [order].customer cu 
			ON cu.id_customer = o.id_customer
        WHERE (@id_order_lookup IS NULL AND (
					(o.status NOT IN ('completed', 'cancelled') AND o.deleted=0) OR 
					(o.status IN ('completed', 'cancelled') AND o.date_updated>=DATEADD(dd, -4, getutcdate()))
				)
			  )
			  OR
			  (@id_order_lookup IS NOT NULL AND o.id_order_lookup=@id_order_lookup)
go

