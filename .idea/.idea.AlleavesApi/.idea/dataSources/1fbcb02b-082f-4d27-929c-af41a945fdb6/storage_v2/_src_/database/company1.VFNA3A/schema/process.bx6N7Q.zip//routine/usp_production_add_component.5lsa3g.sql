CREATE PROCEDURE [process].[usp_production_add_component]
	@id_production INT,
	@id_batch INT,
	@id_area INT,
	@quantity DECIMAL(18,4),
	@waste DECIMAL(18,4) = 0,
	@id_user INT = NULL
AS
	SET NOCOUNT ON;

	IF(@waste IS NULL)
		SET @waste=0

	DECLARE @quantity_neg DECIMAL(18,4)

	/* insert component and add to event log. */
	INSERT INTO process.production_component (id_production, id_batch, quantity, id_production_component_type, updated_by) VALUES
		(@id_production, @id_batch, @quantity, 1, @id_user)

	SET @quantity_neg = -@quantity
	EXEC [log].usp_event_create 'production_input', @id_batch, @id_area, @quantity_neg, NULL, @id_user

	IF(@waste > 0)
	BEGIN
		/* insert waste and add to event log. */
		INSERT INTO process.production_component (id_production, id_batch, quantity, id_production_component_type, updated_by) VALUES
		(@id_production, @id_batch, @waste, 2, @id_user)
		
		SET @quantity_neg = -@waste		
		EXEC [log].usp_event_create 'production_input_waste', @id_batch, @id_area, @quantity_neg, NULL, @id_user
	END

	
	/* add batch history. */
	DECLARE @id_batch_product BIGINT
	SET @id_batch_product = (SELECT id_batch FROM process.production WHERE id_production=@id_production)

	IF NOT EXISTS (SELECT * FROM inventory.batch_history WHERE id_batch=@id_batch_product AND id_batch_parent=@id_batch)
		INSERT INTO inventory.batch_history (id_batch, id_batch_parent) VALUES (@id_batch_product, @id_batch)

	EXEC inventory.usp_batch_inherit_plant_lineage @id_batch, @id_batch_product
go

