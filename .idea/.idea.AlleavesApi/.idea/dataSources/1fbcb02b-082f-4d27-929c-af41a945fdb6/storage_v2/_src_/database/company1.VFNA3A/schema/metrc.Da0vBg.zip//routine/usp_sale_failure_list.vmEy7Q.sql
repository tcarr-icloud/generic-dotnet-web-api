CREATE PROCEDURE [metrc].[usp_sale_failure_list]
	-- Add the parameters for the stored procedure here
	@id_order INT = NULL,
	@remediated BIT = 0,
	@id_location INT = null,
	@start_date datetime = null,
	@end_date datetime = null
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT sf.*,
	     usr.UserName as user_name,
	       loc.name as location
	FROM [metrc].[sale_failure] sf
	LEFT JOIN base.[user] usr on sf.created_by = usr.id_user
	LEFT JOIN [order].[order] o on o.id_order = sf.id_order
	LEFT JOIN base.location loc on o.id_location = loc.id_location
	WHERE (@id_order IS NULL OR sf.id_order=@id_order) AND (remediated=@remediated)
    AND (@id_location IS NULL OR loc.id_location = @id_location)
	AND ((@start_date IS NULL AND @end_date IS NULL) OR (sf.date_created >= @start_date AND sf.date_created <= @end_date))
END
go

