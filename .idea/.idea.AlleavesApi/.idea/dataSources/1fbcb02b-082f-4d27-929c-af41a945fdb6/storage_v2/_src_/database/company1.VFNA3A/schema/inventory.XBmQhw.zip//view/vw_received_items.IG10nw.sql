CREATE VIEW [inventory].[vw_received_items]

AS

SELECT a.id_area
	,atp.id_area_type
	,b.id_batch
	,i.id_item_group
	,i.id_item
	,c.id_category
	,lo.id_location
	,u.id_user
	,i.item AS received_item
	,c.[name] AS category 
	,b.[name] AS batch_number 
	,tl.quantity
	,um.[name] AS uom
	,atp.[name] AS area
	,lo.[name] AS 'location'
	,u.FirstName + ' ' + u.LastName AS 'user'
	,tl.date_created AS 'date'
FROM [inventory].[transfer_log] tl
LEFT JOIN [inventory].batch b ON b.id_batch = tl.id_batch
LEFT JOIN [inventory].inventory iv ON iv.id_batch = b.id_batch
LEFT JOIN [inventory].area a ON a.id_area = iv.id_area
LEFT JOIN [inventory].area_type atp ON atp.id_area_type = a.id_area_type
LEFT JOIN [inventory].vw_item_list i ON i.id_item = b.id_item
LEFT JOIN [inventory].category c ON c.id_category = i.id_category
LEFT JOIN [base].[user] u ON u.id_user = tl.id_user
LEFT JOIN [inventory].[uom] um ON um.id_uom = i.id_uom
LEFT JOIN [base].[location] lo ON lo.id_location = a.id_location
WHERE  tl.id_transfer_type=1
go

