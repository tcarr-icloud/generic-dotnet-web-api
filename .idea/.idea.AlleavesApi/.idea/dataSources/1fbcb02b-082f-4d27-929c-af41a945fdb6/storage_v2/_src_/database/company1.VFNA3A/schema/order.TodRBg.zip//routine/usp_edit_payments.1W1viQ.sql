
CREATE PROCEDURE [order].[usp_edit_payments] 
 @id_order INT
,@payments VARCHAR(MAX) 
,@date_paid DATETIME
,@id_user INT

AS 

	DECLARE @id_register INT = (SELECT TOP 1 id_register FROM [order].payment WHERE id_order = @id_order)

	SELECT 
		 @id_order as id_order
		,@id_register as id_register
		,JSON_VALUE(j.[value], '$.method') as method
		,JSON_VALUE(j.[value], '$.tendered') as tendered
		,@id_user as id_user_created
		,@id_user as id_user_updated
	INTO #payments
	FROM OPENJSON(@payments) j

	DECLARE @paid_in_full bit = 0;
	DECLARE @total_due DECIMAL(18,4) = (SELECT total FROM [order].[order] WHERE id_order = @id_order)
	DECLARE @total_payments DECIMAL(18,4) = 0
	SET @total_payments = ISNULL((SELECT SUM(CAST(ISNULL(tendered,0) as decimal(18,4))) FROM #payments WHERE method NOT IN ('Change','Tip','Terminal Charge')),0)
	
	SET @paid_in_full = CASE 
		WHEN @total_due <= 0 THEN 1 
		WHEN @total_payments >= @total_due THEN 1
		ELSE 0
	END
	
	/* Throw/Raise Error if no paid in pull here */
	if(@paid_in_full = 0)
		THROW 60000, 'Order must be paid in full', 1;

	/* Logic Here to Determine if a Credit needs to be adjusted */
	/*
		Compare Current [order].Payments to #Payment to figure adjustment if any
	*/

	/* Backup Old Payments */
	INSERT INTO [order].payment_deleted ([id_payment], [id_order], [method], [tendered], [deleted], [id_user_created], [id_user_updated], [date_created], [date_updated], [id_register], [id_user_deleted], [date_deleted])
	SELECT 
		[id_payment], [id_order], [method], [tendered], [deleted], [id_user_created], [id_user_updated], [date_created], [date_updated], [id_register], @id_user, GETUTCDATE()
	FROM [order].payment WHERE id_order = @id_order

	/* Delete Old Payments */
	DELETE FROM [order].payment WHERE id_order = @id_order		

	-- Insert Payments
	INSERT INTO [order].payment (id_order, id_register, method, tendered, id_user_created, id_user_updated)
	SELECT id_order, id_register, method, tendered, id_user_created, id_user_updated FROM #payments	

	-- Update paid fields
	UPDATE o
	SET o.date_paid = @date_paid
	FROM [order].[order] o
	WHERE id_order = @id_order
	AND @paid_in_full = 1;	

	
	--DECLARE @id_customer INT = (SELECT id_customer FROM [order].[order] WHERE id_order = @id_order); 
	--DECLARE @tendered DECIMAL(18, 2) = (SELECT SUM(CAST(tendered as decimal(18,2))) FROM #payments WHERE method = 'Store Credit')
	---- Adjust credits if needed
	--IF OBJECT_ID('tempdb..#payments') IS NOT NULL
	--BEGIN
	--	IF((SELECT SUM(cast(tendered as decimal(18,2))) FROM #payments WHERE method = 'Store Credit') > 0)
	--	BEGIN
	--		INSERT INTO [order].customer_credit_debit (id_customer, id_order, reason, amount, created_by)
	--		VALUES (
	--		@id_customer
	--		,@id_order
	--		,'Purchase'
	--		,@tendered * -1
	--		,@id_user
	--		)
	--	END
	--END
go

