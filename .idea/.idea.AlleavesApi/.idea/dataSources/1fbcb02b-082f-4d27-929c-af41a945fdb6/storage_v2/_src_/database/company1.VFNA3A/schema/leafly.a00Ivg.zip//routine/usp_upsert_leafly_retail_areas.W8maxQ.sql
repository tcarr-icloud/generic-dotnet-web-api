CREATE PROCEDURE [leafly].[usp_upsert_leafly_retail_areas]
    @id_location INT,
    @area_list VARCHAR(MAX) = '[]',
    @id_user INT
AS
    ;WITH area_list AS (
		SELECT @id_location AS id_location
				, id_area
		FROM OPENJSON(@area_list)
		WITH (
			  id_area INT
		)
	)
	MERGE [leafly].[menu_retail_area] AS mra
	USING area_list AS al
	ON al.id_location = mra.id_location AND al.id_area = mra.id_area
	WHEN MATCHED THEN
	UPDATE SET mra.updated_by=@id_user, mra.date_updated=getutcdate(), mra.active=1
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_location, id_area, active, created_by, updated_by) VALUES (al.id_location, al.id_area, 1, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND mra.id_location = @id_location THEN
	UPDATE SET mra.updated_by=@id_user, mra.date_updated=getutcdate(), mra.active=0
	;
		
	EXEC [leafly].[usp_get_leafly_retail_areas] @id_location
go

