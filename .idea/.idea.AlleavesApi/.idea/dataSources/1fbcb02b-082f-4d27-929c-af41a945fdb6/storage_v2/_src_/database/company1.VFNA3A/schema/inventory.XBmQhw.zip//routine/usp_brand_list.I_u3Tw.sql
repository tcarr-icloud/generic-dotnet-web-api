CREATE PROCEDURE [inventory].[usp_brand_list]
	@id_brand INT = NULL,
	@deleted BIT = 0
AS
	SELECT b.id_brand
		, b.[name] AS brand
		, b.deleted
	FROM [inventory].[brand] b
	WHERE b.id_brand=ISNULL(@id_brand, b.id_brand) AND b.deleted <= @deleted
	ORDER BY b.name
go

