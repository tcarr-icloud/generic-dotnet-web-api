CREATE PROCEDURE metrc.usp_get_state_adjust_reason_by_state_code
	@state VARCHAR(250)
AS
BEGIN
	SELECT * FROM metrc.state_to_adjust_reason WHERE state_code=@state
END
go

