CREATE PROCEDURE [tax].[usp_get_tax_group_list]
	@id_tax_group INT = NULL
AS
	SELECT tg.id_tax_group,
		tg.name,
		tg.active,
		tg.created_by,
		tg.updated_by,
		tg.date_created,
		tg.date_updated,
		ISNULL((
			SELECT tt.*
			FROM [tax].[group_value] tgv
			LEFT JOIN [tax].[tax] tt ON tt.id_tax = tgv.id_tax
			WHERE tgv.id_tax_group = ISNULL(@id_tax_group, tg.id_tax_group) AND tgv.active=1 AND tt.active=1
		FOR JSON PATH), '[]') as tax_list,
		ISNULL((
			SELECT DISTINCT tlg.*
			FROM [tax].[location_group] tlg
			LEFT JOIN [base].[location] bl ON bl.id_location = bl.id_location
			WHERE tlg.id_tax_group = ISNULL(@id_tax_group, tg.id_tax_group) AND tlg.active=1 AND bl.active=1
		FOR JSON PATH), '[]') as tax_location_list,
		ISNULL((
			SELECT tc.*
			FROM [tax].[category] tc
			RIGHT JOIN [tax].[category_group] tcg ON tc.id_tax_category = tcg.id_tax_category
			WHERE tcg.id_tax_group = ISNULL(@id_tax_group, tg.id_tax_group) AND tcg.active=1 AND tc.active=1
		FOR JSON PATH), '[]') as tax_category_list
	FROM [tax].[group] tg
	WHERE tg.active = 1 AND tg.id_tax_group=ISNULL(@id_tax_group, tg.id_tax_group)
	ORDER BY tg.[name]
go

