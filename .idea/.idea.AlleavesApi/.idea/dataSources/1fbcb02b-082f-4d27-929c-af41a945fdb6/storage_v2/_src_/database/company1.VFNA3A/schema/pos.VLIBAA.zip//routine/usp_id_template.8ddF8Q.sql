CREATE PROCEDURE [pos].[usp_id_template]
	@id_template INT= NULL
AS
BEGIN
	SET NOCOUNT ON;
	SELECT 
		id_template,
		id_location,
		[name],
		[path],
		deleted,
		id_user_created_by
	FROM pos.templates
	WHERE id_template = @id_template
END
go

