CREATE PROCEDURE [order].[usp_save_payments] 
 @id_order INT
,@id_register INT
,@payments AS VARCHAR(max) 
,@id_user INT
,@biotrack_receipt_id VARCHAR(64) = NULL
,@id_user_cashier INT = NULL
AS 

	-- Return if order already paid in full
	IF EXISTS(SELECT id_order FROM [order].[order] WHERE id_order = @id_order AND paid_in_full = 1) return 

	SELECT 
		 @id_order as id_order
		,@id_register as id_register
		,JSON_VALUE(j.[value], '$.method') as method
		,JSON_VALUE(j.[value], '$.tendered') as tendered
		,@id_user as id_user_created 
		,COALESCE(@id_user_cashier, @id_user) as id_user_updated 
	INTO #payments
	FROM OPENJSON(@payments) j

	-- Insert Payments
	INSERT INTO [order].payment (id_order, id_register, method, tendered, id_user_created, id_user_updated)
	SELECT id_order, id_register, method, tendered, id_user_created, id_user_updated FROM #payments
	
	DECLARE @paid_in_full bit = 0;
	DECLARE @total_due DECIMAL(18,4) = (SELECT total FROM [order].[order] WHERE id_order = @id_order)
	DECLARE @total_payments DECIMAL(18,4) = 0
	SET @total_payments = ISNULL((SELECT SUM(CAST(ISNULL(tendered,0) as decimal(18,4))) FROM #payments WHERE method NOT IN ('Change','Tip','Terminal Charge')),0)
	
	SET @paid_in_full = CASE 
		WHEN @total_due <= 0 THEN 1 
		WHEN @total_payments >= @total_due THEN 1
		ELSE 0
	END

	-- Mark order paid in full
	UPDATE o
	SET		o.id_status = (SELECT MIN(id_status) FROM [order].[status] WHERE [name] = 'Completed'),
			o.complete = 1,
			o.paid_in_full = 1,
			o.id_user_cashier = COALESCE(@id_user_cashier, @id_user),
			o.date_paid = GETUTCDATE(),
			o.biotrack_receipt_id = ISNULL(@biotrack_receipt_id, o.biotrack_receipt_id)
	FROM [order].[order] o
	INNER JOIN [order].[status] s on o.id_status = s.id_status
	WHERE id_order = @id_order
	AND @paid_in_full = 1;

	-- If order has returns adjust inventory
	DECLARE @returns VARCHAR(max) = (SELECT
		 oi.id_batch
		,oi.id_area
		,oi.quantity as adjustment
	FROM [order].[order] o 
	LEFT OUTER JOIN [order].item oi on o.id_order = oi.id_order 
	WHERE o.id_order = @id_order
	AND o.paid_in_full = 1 
	AND oi.id_item_return IS NOT NULL
	FOR JSON PATH)

	IF(@returns IS NOT NULL)
		EXEC [log].usp_event_create_bulk 'order_return', 'Payment received on return', @returns, @id_user


	DECLARE @id_customer INT = (SELECT id_customer FROM [order].[order] WHERE id_order = @id_order); 
	DECLARE @tendered DECIMAL(18, 2) = (SELECT SUM(CAST(tendered as decimal(18,2))) FROM #payments WHERE method = 'Store Credit')
	-- Adjust credits if needed
	IF OBJECT_ID('tempdb..#payments') IS NOT NULL
	BEGIN
		IF((SELECT SUM(cast(tendered as decimal(18,2))) FROM #payments WHERE method = 'Store Credit') > 0)
		BEGIN
			INSERT INTO [order].customer_credit_debit (id_customer, id_order, reason, amount, created_by)
			VALUES (
			@id_customer
			,@id_order
			,'Purchase'
			,@tendered * -1
			,@id_user
			)
		END
	END
go

