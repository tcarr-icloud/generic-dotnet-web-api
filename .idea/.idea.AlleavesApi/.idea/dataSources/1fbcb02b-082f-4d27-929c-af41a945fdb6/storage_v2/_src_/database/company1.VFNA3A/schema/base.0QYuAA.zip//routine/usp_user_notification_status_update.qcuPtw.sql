CREATE PROCEDURE base.usp_user_notification_status_update
	@id_user int = null
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE base.user_notifications
	SET
		status = 1
	WHERE id_user = @id_user
    EXEC [base].[usp_notifications_status_list] @id_user=@id_user
END
go

