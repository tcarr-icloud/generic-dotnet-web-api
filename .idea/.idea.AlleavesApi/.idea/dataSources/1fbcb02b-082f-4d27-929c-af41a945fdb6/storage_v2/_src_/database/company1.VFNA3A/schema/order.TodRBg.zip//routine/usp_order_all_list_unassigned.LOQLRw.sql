CREATE PROCEDURE [order].[usp_order_all_list_unassigned]
    @delivery_date DATE = NULL,
    @id_location INT = NULL
AS
BEGIN
SELECT o.id_order
	,o.id_customer
	,o.id_external
	,o.id_order_online
	,o.id_location
	,o.id_status
	,o.id_session
	,o.[type]
	,o.[use_type]
	,o.auto_apply_discount_exclusions
	,[order].fn_order_payment_json(o.id_order) AS payments
	,[order].fn_order_discount_json(o.id_order) AS discounts
    ,CONCAT( a.address1,',', a.address2 ) AS address
	,a.city
	,a.[state]
	,a.zip AS postal_code
	,a.delivery_date
	,a.id_driver1
	,a.id_driver2
	,a.id_vehicle
	,a.lat
	,a.long
    ,er.id_ride
    ,(  SELECT TOP 1 history.created_at
		FROM [order].ecommerce_ride_status_history history
		WHERE history.id_ride = er.id_ride
		ORDER BY history.created_at DESC
		) AS last_ride_status_createdat
FROM [order].[order] o
LEFT JOIN [order].[address] AS a ON a.id_order = o.id_order
LEFT JOIN [order].[ecommerce_ride] AS er ON er.id_order = o.id_order
WHERE o.id_order = a.id_order AND er.id_driver IS NULL AND a.delivery_date =@delivery_date AND o.verified = 1
    AND o.id_location = @id_location
END
go

