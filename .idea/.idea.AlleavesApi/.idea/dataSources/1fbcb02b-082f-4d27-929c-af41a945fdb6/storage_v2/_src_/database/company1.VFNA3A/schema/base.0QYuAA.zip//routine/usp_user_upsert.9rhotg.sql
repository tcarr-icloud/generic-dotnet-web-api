CREATE PROCEDURE [base].[usp_user_upsert]
	@id_user INT = NULL,
	@id_role INT = NULL,
	@name_first VARCHAR(128),
	@name_last VARCHAR(128),
	@username VARCHAR(128),
	@password VARCHAR(128),
	@phone VARCHAR(128),
	@pin VARCHAR(128),
	@accountDisabled BIT = 0,
	@user_location_list VARCHAR(MAX) = '[]',
	@employee_role VARCHAR(128) = null,
	@employee_department Varchar(1128) = null,
	@employee_id Varchar(128) = null,
	@internal_employee_id VARCHAR(128) = null,
	@badge_number VARchar(128) = null,
	@theme VARCHAR(250)=null,
	@birth_date DATE=null,
	@hire_date DATE=null,
	@id_user_modified_by INT = NULL
AS
	-- TODO: check email uniqueness

	/* create user. */
	IF(@id_user IS NULL)
	BEGIN
		INSERT INTO [base].[user] (id_user_modified_by, FirstName, LastName, Email, PhoneNumber, UserName, PasswordHash, PIN, PasswordReset, EmailConfirmed, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEnabled, AccessFailedCount, employee_role, employee_department, employee_id, badge_number,theme, birth_date, hire_date, internal_employee_id) 
		VALUES (@id_user_modified_by, @name_first, @name_last, @username, @phone, @username, @password, @pin, 1, 0, 0, 0, 0, 0, @employee_role, @employee_department, @employee_id, @badge_number,@theme, @birth_date, @hire_date, @internal_employee_id)
		
		SET @id_user=SCOPE_IDENTITY()
			
		EXEC [base].usp_user_insert_history @id_user, 'CREATE'
	END

	/* update user. */
	ELSE
	BEGIN
		UPDATE [base].[user]
			SET FirstName=@name_first,
			LastName=@name_last,
			UserName=@username,
			Email=@username,
			id_user_modified_by=@id_user_modified_by,
			PhoneNumber=@phone,
			PasswordHash=ISNULL(@password, PasswordHash),
			PIN=ISNULL(@pin, PIN),
			accountDisabled=@accountDisabled,
			employee_role=@employee_role,
			employee_department=@employee_department,
			employee_id=@employee_id,
			birth_date=@birth_date,
			hire_date=@hire_date,
			badge_number=@badge_number,
			internal_employee_id=@internal_employee_id,
			theme=@theme,
			PasswordResetDate=(CASE WHEN @password IS NULL THEN PasswordResetDate ELSE DATEADD(DAY, 90, GETUTCDATE()) END)
		WHERE id_user=@id_user
			
		EXEC [base].usp_user_insert_history @id_user, 'UPDATE'
	END

	/* upsert user locations. */
	;WITH user_location_list AS (
		SELECT @id_user AS id_user
				, id_location
				, metrc_api_user_key
				, biotrack_username
				, biotrack_password
				, biotrack_employee_id
				, is_accessible
		FROM OPENJSON(@user_location_list)
		WITH (
			id_location INT,
			metrc_api_user_key VARCHAR(256),
			biotrack_username VARCHAR(256),
			biotrack_password VARCHAR(256),
			biotrack_employee_id VARCHAR(256),
			is_accessible BIT
		)
	)
	MERGE [base].[user_location] t
	USING user_location_list s
	ON t.id_user=s.id_user AND t.id_location=s.id_location
	WHEN MATCHED THEN
		UPDATE SET t.metrc_api_user_key=s.metrc_api_user_key, t.is_accessible=s.is_accessible, t.biotrack_username=s.biotrack_username, t.biotrack_password=s.biotrack_password, t.biotrack_employee_id=s.biotrack_employee_id
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_user, id_location, metrc_api_user_key, biotrack_username, biotrack_password, biotrack_employee_id, is_accessible) VALUES (s.id_user, s.id_location, s.metrc_api_user_key, s.biotrack_username, s.biotrack_password, s.biotrack_employee_id, s.is_accessible)
	WHEN NOT MATCHED BY SOURCE AND t.id_user=@id_user THEN
		DELETE;

	/* update role. */
	IF(@id_role IS NOT NULL)
	BEGIN
		DECLARE @id_ur INT = (SELECT TOP 1 id_user_role FROM acl.user_role WHERE id_user=@id_user)

		IF(@id_ur IS NULL) 
			INSERT INTO acl.user_role (id_user, id_role) VALUES (@id_user, @id_role)
		ELSE 
			UPDATE acl.user_role SET id_user=@id_user, id_role=@id_role WHERE id_user_role=@id_ur
	END

	/* return updated user. */
	EXEC base.usp_user_list @id_user, 1
go

