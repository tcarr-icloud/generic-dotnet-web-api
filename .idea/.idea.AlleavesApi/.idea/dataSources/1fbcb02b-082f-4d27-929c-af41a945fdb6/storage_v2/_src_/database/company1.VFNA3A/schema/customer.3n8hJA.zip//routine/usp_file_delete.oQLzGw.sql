CREATE PROCEDURE [customer].[usp_file_delete]
	@id_file INT
AS
	DELETE FROM [customer].[file] WHERE id_file = @id_file
go

