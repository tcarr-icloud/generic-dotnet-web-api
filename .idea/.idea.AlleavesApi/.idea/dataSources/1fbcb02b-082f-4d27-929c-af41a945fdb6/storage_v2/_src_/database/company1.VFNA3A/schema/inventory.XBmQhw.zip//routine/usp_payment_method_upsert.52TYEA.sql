CREATE PROCEDURE [inventory].[usp_payment_method_upsert]
	@id_payment_method INT = NULL,
	@name VARCHAR(512),
	@id_user INT,
	@deleted BIT = 0

AS

	IF (@id_payment_method IS NULL)
	BEGIN
		INSERT INTO [inventory].[payment_method] ([name], id_user_created, id_user_updated) VALUES (@name, @id_user, @id_user)

		SET @id_payment_method = SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		UPDATE [inventory].[payment_method]
		SET 
			[name]=@name
		  , id_user_updated = @id_user
		  , deleted = @deleted
		  , date_updated = GETUTCDATE()
		WHERE id_payment_method = @id_payment_method
	END
	
	EXEC [inventory].[usp_payment_method_list] @id_payment_method, 1
go

