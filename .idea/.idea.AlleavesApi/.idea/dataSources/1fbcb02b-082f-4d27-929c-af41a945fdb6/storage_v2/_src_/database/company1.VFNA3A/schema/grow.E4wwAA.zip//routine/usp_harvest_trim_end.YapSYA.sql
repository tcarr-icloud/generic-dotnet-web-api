CREATE PROCEDURE [grow].[usp_harvest_trim_end]
	@id_harvest INT,
	@weight_dry_waste_g DECIMAL(18, 4),
	@output_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	DECLARE @id_location INT = (SELECT id_location FROM grow.harvest WHERE id_harvest=@id_harvest)
	DECLARE @weight_wet_g DECIMAL(18,4) = (SELECT h.weight_wet_g - SUM(i.quantity) FROM grow.harvest h LEFT JOIN grow.harvest_item i ON i.id_harvest=h.id_harvest WHERE h.id_harvest=@id_harvest GROUP BY h.weight_wet_g)
	
	/* set up temp table for output items. */
	DROP TABLE IF EXISTS #output_list
	SELECT * INTO #output_list
	FROM OPENJSON(@output_list)
	WITH (
		id_item INT,
		id_area INT,
		quantity DECIMAL(18,4),
		metrc_label VARCHAR(255)
	)

	/* validation. */
	DECLARE @msg VARCHAR(MAX)

	IF (SELECT date_trim_end FROM grow.harvest WHERE id_harvest=@id_harvest) IS NOT NULL
	BEGIN
		SET @msg = 'Cannot edit a harvest that has already been completed.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END
	IF EXISTS (SELECT * FROM OPENJSON(@output_list) WITH (id_area INT) o JOIN inventory.area a ON a.id_area=o.id_area AND a.id_location<>@id_location)
	BEGIN
		SET @msg = 'Storage areas must belong to the same location as the original harvest.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END
	IF (SELECT SUM(quantity) FROM #output_list) + @weight_dry_waste_g > @weight_wet_g
	BEGIN
		SET @msg = 'Cannot package more weight than the remainder of the wet weight, ' + CAST(@weight_wet_g AS VARCHAR(32)) + ' Grams'
		RAISERROR(@msg, 11, 1)
		RETURN
	END


	/* update harvest. */
	UPDATE grow.harvest
	SET date_trim_end = GETUTCDATE()
		, date_finished = GETUTCDATE()
		, finished = 1
		, id_user_trim_end = @id_user
		, id_user_finished = @id_user
		, weight_dry_g = (SELECT SUM(quantity) FROM #output_list)
		, weight_dry_waste_g = @weight_dry_waste_g
	WHERE id_harvest=@id_harvest


	DECLARE @id_item INT,
			@id_area INT,
			@quantity DECIMAL(18,4),
			@id_batch INT,
			@notes VARCHAR(MAX),
			@metrc_label VARCHAR(255),
			@metrc_item_id BIGINT,
			@metrc_state VARCHAR(16) = (SELECT TOP 1 state FROM base.location WHERE id_location=@id_location)

	/* create output items. */
	DECLARE cur CURSOR 
	FOR SELECT id_item, id_area, quantity, metrc_label FROM #output_list
	OPEN cur
	FETCH NEXT FROM cur INTO @id_item, @id_area, @quantity, @metrc_label

	WHILE @@FETCH_STATUS = 0 BEGIN

		/* get batch and add to created batch list. */
		EXEC @id_batch=inventory.usp_batch_create @id_item

		IF @metrc_label IS NOT NULL
		BEGIN
			SET @metrc_item_id = (SELECT TOP 1 metrc_item_id FROM inventory.item_location WHERE id_item=@id_item AND id_location=@id_location)
			
			UPDATE inventory.batch 
			SET metrc_package_label=@metrc_label 
				, metrc_item_id=@metrc_item_id
				, metrc_state=@metrc_state
			WHERE id_batch=@id_batch
		END

		/* tie batch to plant list. */
		INSERT INTO grow.batch_plant (id_plant, id_batch)
		SELECT t.id_plant, @id_batch AS id_batch
		FROM (SELECT id_plant FROM grow.plant WHERE id_harvest=@id_harvest) t

		/* add batch to harvest manifest. */
		INSERT INTO grow.harvest_item (id_harvest, id_batch, id_area, quantity, is_dry)
		VALUES (@id_harvest, @id_batch, @id_area, @quantity, 1)

		/* create event and insert batch into inventory. */
		SET @notes = 'HarvestID: ' + CAST(@id_harvest AS VARCHAR(12))
		EXEC [log].usp_event_create 'harvest', @id_batch, @id_area, @quantity, @notes, @id_user

		FETCH NEXT FROM cur INTO @id_item, @id_area, @quantity, @metrc_label
	END

	CLOSE cur
	DEALLOCATE cur
	

	EXEC grow.usp_harvest_fetch @id_harvest
go

