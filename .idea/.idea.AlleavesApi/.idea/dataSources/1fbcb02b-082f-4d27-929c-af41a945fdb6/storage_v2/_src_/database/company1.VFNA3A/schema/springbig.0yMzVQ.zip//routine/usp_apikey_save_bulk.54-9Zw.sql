CREATE PROCEDURE [springbig].[usp_apikey_save_bulk]
	@keys nvarchar(max)
AS
    SET NOCOUNT ON;
	MERGE [springbig].[apikey] as t
	USING (
		SELECT id_location, [key], [email_required] FROM OPENJSON(@keys)
		WITH(
			id_location int,
			[key] varchar(512),
			[email_required] bit
		)
	) as s on t.id_location = s.id_location
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_location, [key], [email_required])
		VALUES(s.id_location, s.[key], s.[email_required])
	WHEN MATCHED THEN UPDATE
		SET [key] = s.[key], [email_required] = s.[email_required];
go

