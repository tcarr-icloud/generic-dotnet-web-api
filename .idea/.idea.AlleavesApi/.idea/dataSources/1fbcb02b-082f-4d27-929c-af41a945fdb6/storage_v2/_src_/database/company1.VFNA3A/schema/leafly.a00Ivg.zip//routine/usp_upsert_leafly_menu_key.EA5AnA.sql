CREATE PROCEDURE [leafly].[usp_upsert_leafly_menu_key]
    @id_location INT,
    @menu_integration_key VARCHAR(256),
    @id_user INT,
    @use_otd_price BIT
AS
BEGIN
    IF EXISTS (SELECT * FROM [leafly].[menu_key] WHERE id_location = @id_location)
    BEGIN
        UPDATE [leafly].[menu_key]
        SET menu_key = @menu_integration_key,
            use_otd_price = @use_otd_price
        WHERE id_location = @id_location;
    END
    ELSE
    BEGIN
        INSERT INTO [leafly].[menu_key] (id_location, menu_key, use_otd_price, created_by, updated_by)
        VALUES (@id_location, @menu_integration_key, @use_otd_price, @id_user, @id_user);
    END

    EXEC [leafly].[usp_get_leafly_menu_key] @id_location;
END
go

