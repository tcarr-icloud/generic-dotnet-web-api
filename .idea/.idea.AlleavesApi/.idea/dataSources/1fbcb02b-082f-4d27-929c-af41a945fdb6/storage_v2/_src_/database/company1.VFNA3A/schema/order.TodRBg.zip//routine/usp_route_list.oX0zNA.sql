CREATE PROCEDURE [order].usp_route_list
              @id_routes INT= NULL,
              @id_driver INT = NULL
AS
BEGIN
	SELECT
	id_routes, id_driver, id_order, delivery_date, delivery_date_time, route_index, order_priority, update_at,
	       created_at, id_ride,eta, latitude, longitude
	FROM [order].routes
	WHERE id_driver = ISNULL(@id_driver, id_driver) OR id_routes = ISNULL(@id_routes, id_routes)
END
go

