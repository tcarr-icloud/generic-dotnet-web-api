CREATE PROCEDURE terminal.usp_assignment_create
	@id_terminal INT = NULL,
    @secret VARCHAR(256)= NULL,
	@id_user_created_by INT= NULL,
	@id_user_updated_by INT = NULL
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO terminal.assignment (id_terminal,secret,id_user_created_by,id_user_updated_by)
	Values (@id_terminal,@secret,@id_user_created_by,@id_user_updated_by)
	DECLARE @id_assignment INT = SCOPE_IDENTITY()
	EXEC terminal.usp_assignment_list @id_assignment = @id_assignment
END
go

