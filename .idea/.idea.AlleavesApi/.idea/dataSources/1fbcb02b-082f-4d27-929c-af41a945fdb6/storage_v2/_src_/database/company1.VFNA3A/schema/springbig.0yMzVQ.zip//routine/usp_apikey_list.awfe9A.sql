CREATE PROCEDURE [springbig].[usp_apikey_list]
AS
    SET NOCOUNT ON;
	SELECT
		 l.id_location
		,l.[name] as [location]
		,k.[key]
		,k.[email_required]
	FROM [base].[location] l
	LEFT OUTER JOIN springbig.apikey k on k.id_location = l.id_location
	WHERE l.active = 1
go

