CREATE PROCEDURE [order].[usp_delivery_note_update]
	@id_order INT,
	@note VARCHAR(MAX),
	@id_user INT
AS
	UPDATE [order].address
	SET note=@note
		, id_user_updated=@id_user
		, date_updated=getutcdate()
	WHERE id_order=@id_order
go

