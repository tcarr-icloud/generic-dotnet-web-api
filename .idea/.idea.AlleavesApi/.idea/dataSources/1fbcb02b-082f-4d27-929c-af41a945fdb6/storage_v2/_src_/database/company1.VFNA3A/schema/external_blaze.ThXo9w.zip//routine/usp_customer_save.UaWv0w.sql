CREATE PROCEDURE [external_blaze].[usp_customer_save]
	@first_name VARCHAR(200) ,
	@last_name VARCHAR(200) ,
	@dob VARCHAR(200) ,
	@patient_number VARCHAR(200) ,
	@apt_unit VARCHAR(200) ,
	@street VARCHAR(200) ,
	@state VARCHAR(200) ,
	@city VARCHAR(200) ,
	@zip VARCHAR(200) ,
	@primary_phone VARCHAR(200) ,
	@phone VARCHAR(200) ,
	@email VARCHAR(200) ,
	@driver_license VARCHAR(200) ,
	@driver_license_state VARCHAR(200) ,
	@passport VARCHAR(200) ,
	@physician VARCHAR(200) ,
	@caregiver VARCHAR(200) ,
	@referral_method VARCHAR(200) ,
	@customer_type VARCHAR(200) ,
	@other VARCHAR(200),
	@id_member VARCHAR(200)
AS
	SET NOCOUNT ON
    IF NOT EXISTS (SELECT id_customer FROM external_blaze.customer
                   WHERE id_member=@id_member)
	BEGIN
		INSERT INTO [external_blaze].customer (first_name, last_Name, dob, patient_number, apt_unit, street,state, city, zip, primary_phone, phone, email, driver_license, drivers_license_state, passport, physician, caregiver, referral_method, customer_type, other,id_member)
        VALUES(@first_name,@last_name,@dob,@patient_number,@apt_unit,@street,@state,@city,@zip,@primary_phone,@phone,@email,@driver_license,@driver_license_state,@passport,@physician,@caregiver,@referral_method,@customer_type,@other,@id_member)
	    SELECT SCOPE_IDENTITY() AS id_customer;
	END
go

