CREATE PROCEDURE [tax].[usp_get_item_tax_category_list]
	@id_tax_category INT = NULL
AS
	SELECT 
		tcv.id_tax_category,
		tcv.id_tax,
		tc.name as tax_category,
		tt.name as tax_name,
		tt.percentage,
		tt.is_cannabis,
		tt.is_non_cannabis,
		tt.is_excise_tax,
		tt.is_state_tax,
		tt.is_local_tax,
		tt.is_adult_use,
		tt.is_medical_use,
		tt.is_arms_length,
		tt.is_gross_tax,
		tt.markup_rate,
		tt.stacking_order,
		ISNULL((
				SELECT tv.id_vendor,
					iv.name as vendor
				FROM [tax].[vendor] tv
				LEFT JOIN [inventory].[vendor] iv ON iv.id_vendor=tv.id_vendor
				WHERE tv.id_tax=tt.id_tax AND tv.active = 1
			FOR JSON PATH), '[]') as vendor_list
	FROM [tax].[category_value] tcv
	LEFT JOIN [tax].[category] tc ON tcv.id_tax_category = tc.id_tax_category
	LEFT JOIN [tax].[tax] tt ON tt.id_tax = tcv.id_tax
	WHERE tc.id_tax_category=ISNULL(@id_tax_category, tc.id_tax_category) AND tt.active=1 AND tc.active=1 AND tcv.active=1
	ORDER BY tc.id_tax_category, tt.stacking_order, tt.name
go

