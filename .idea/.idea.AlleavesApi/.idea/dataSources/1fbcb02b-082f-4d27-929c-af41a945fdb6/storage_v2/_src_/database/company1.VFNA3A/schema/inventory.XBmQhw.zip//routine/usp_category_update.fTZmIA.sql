CREATE PROCEDURE [inventory].[usp_category_update]
	@id_category INT,
	@name VARCHAR(64),
	@id_parent INT = NULL,
	@id_category_image INT = NULL,
	@id_delivery_route INT,
	@deleted BIT = 0,
	@id_user INT,
	@id_category_move INT = NULL
AS

	IF EXISTS (SELECT * FROM inventory.category WHERE deleted=0 AND name=@name AND ISNULL(@id_parent, -1) = ISNULL(id_parent, -1) AND id_category<>@id_category AND @deleted<>1)
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A category with this name under the same parent already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	UPDATE inventory.category
	SET name=@name
		, id_parent=@id_parent
		, id_category_image=@id_category_image
		, id_delivery_route=@id_delivery_route
		, deleted=@deleted
		, updated_by=@id_user
		, date_updated=getutcdate()
	WHERE id_category=@id_category

	IF(@deleted=1 AND @id_category_move IS NOT NULL)
	BEGIN
		/* update items to use other category. */
		UPDATE inventory.item_group
		SET id_category=@id_category_move
			, id_user_updated=@id_user
			, date_updated=getutcdate()
		WHERE id_category=@id_category

		/* update child categories to use new parent. */
		UPDATE inventory.category
		SET id_parent=(CASE WHEN id_category=@id_category_move AND @id_parent IS NULL THEN NULL 
							WHEN id_category=@id_category_move THEN @id_parent
							ELSE @id_category_move END)
		WHERE id_parent=@id_category
	END

	EXEC inventory.usp_category_list @id_category, 1
go

