CREATE PROCEDURE [springbig].[usp_tablet_config_save]	
     @config nvarchar(max)
    ,@id_user int
AS	
    SET NOCOUNT ON;    
    MERGE [springbig].[tablet_config] as t
	USING(
        SELECT
             [id_client_config]
            ,[logo_path]
            ,[header_message]
            ,[privacy_policy]
            ,[program_name]
            ,[opt_in_text]
        FROM OPENJSON(@config)
        WITH(
             [id_client_config] int
            ,[logo_path] varchar(512)
            ,[header_message] varchar(max)
            ,[privacy_policy] varchar(max)
            ,[program_name] varchar(256)
            ,[opt_in_text] varchar(512)
        )
    ) as s ON t.id_client_config = s.id_client_config
    WHEN NOT MATCHED THEN INSERT ([logo_path],[header_message],[privacy_policy],[program_name],[opt_in_text],updated_by)
    VALUES(s.[logo_path],s.[header_message],s.[privacy_policy],s.[program_name],s.[opt_in_text],@id_user)
    WHEN MATCHED THEN UPDATE
    SET 
         t.[logo_path] = s.[logo_path]
        ,t.[header_message] = s.[header_message]
        ,t.[privacy_policy] = s.[privacy_policy]
        ,t.[program_name] = s.[program_name]
        ,t.[opt_in_text] = s.[opt_in_text]
        ,t.[updated_by] = @id_user
        ,t.[updated_at] = GETUTCDATE();
go

