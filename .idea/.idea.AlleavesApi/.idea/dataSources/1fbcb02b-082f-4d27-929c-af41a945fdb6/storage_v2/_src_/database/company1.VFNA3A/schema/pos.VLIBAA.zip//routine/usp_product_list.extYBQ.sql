CREATE PROCEDURE [pos].[usp_product_list]
	@id_item INT = NULL,
	@id_location INT = NULL,
	@is_adult_use BIT = NULL,
	@is_medical_use BIT = NULL,
	@ready_to_sell INT = NULL,
	@id_area INT = NULL
AS
	--DECLARE @id_item INT = NULL
	--DECLARE @id_location INT = NULL
	--DECLARE @is_adult_use BIT = NULL
	--DECLARE @is_medical_use BIT = NULL
	--DECLARE @ready_to_sell INT = NULL
	--DECLARE @id_area INT = NULL

	SELECT id_item
			, id_item_group
			, id_category
			, product
			, category
			, category_path
			, price
			, description
			, item
			, sku
			, is_adult_use
			, is_medical_use
			, SUM(available) AS available
			, SUM(ready_to_sell) AS ready_to_sell
	FROM (
		SELECT i.id_item
					, i.id_item_group
					, c.id_category
					, RTRIM(CONCAT(ig.name, ' ', (
								SELECT STRING_AGG(av.name, ' ') 
								FROM inventory.item_attribute_value iav
								LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
								WHERE iav.id_item=i.id_item)
							)) AS product
					, ISNULL(c.[name], 'Uncategorized') AS category
					, ISNULL(c.path, 'Uncategorized') AS category_path
					, COALESCE(CASE WHEN @is_adult_use=0 AND @is_medical_use=0 THEN i.price_retail
								    WHEN @is_medical_use=1 THEN i.price_retail_medical_use
								    WHEN @is_adult_use=1 THEN i.price_retail_adult_use
									WHEN i.price_retail_medical_use IS NOT NULL THEN i.price_retail_medical_use
									WHEN i.price_retail_adult_use IS NOT NULL THEN i.price_retail_adult_use
								    ELSE i.price_retail
							END, i.price_retail, 0) as price
					, ig.product_description AS description
					, RTRIM(CONCAT(ig.name, ' ', (
								SELECT STRING_AGG(av.name, ' ') 
								FROM inventory.item_attribute_value iav
								LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
								WHERE iav.id_item=i.id_item)
							)) AS item
					, i.sku
					, ig.is_adult_use
					, ig.is_medical_use
					, inv.on_hand AS available
					, inv.available AS ready_to_sell
			FROM inventory.batch b
			JOIN inventory.item i ON i.id_item=b.id_item
			JOIN inventory.item_group ig ON ig.id_item_group=i.id_item_group
			LEFT OUTER JOIN inventory.vw_category_list c on ig.id_category = c.id_category
			JOIN base.location l ON l.id_location=ig.id_location
			JOIN inventory.uom u ON u.id_uom=ig.id_uom
			LEFT JOIN inventory.vw_current_inventory inv ON inv.id_batch=b.id_batch AND inv.on_hand>0 AND inv.area_type<>'scrap'
			WHERE ig.is_product=1 AND ig.deleted=0 AND i.deleted=0
				  AND (@id_location IS NULL OR l.id_location=@id_location OR ig.id_location IS NULL)
				  AND (
						 (
							(ig.is_adult_use IS NULL OR ig.is_medical_use=@is_medical_use)
						 OR (ig.is_medical_use IS NULL OR ig.is_adult_use=@is_adult_use)
						 OR (@is_medical_use IS NULL OR ig.is_adult_use=@is_adult_use)
						 OR (@is_adult_use IS NULL OR ig.is_medical_use=@is_medical_use)
						 )
						 OR 
						 (
								(ig.is_adult_use IS NULL OR ig.is_adult_use=0)
							AND (ig.is_medical_use IS NULL OR ig.is_medical_use=0)
						 )
					)
		) t
		GROUP BY id_item
			, id_item_group
			, id_category
			, product
			, category
			, category_path
			, price
			, description
			, item
			, sku
			, is_adult_use
			, is_medical_use
		ORDER BY item
go

