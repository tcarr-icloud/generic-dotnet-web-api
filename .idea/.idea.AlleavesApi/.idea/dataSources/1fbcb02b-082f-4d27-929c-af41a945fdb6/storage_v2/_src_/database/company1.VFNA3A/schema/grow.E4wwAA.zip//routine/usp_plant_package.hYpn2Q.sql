CREATE PROCEDURE [grow].[usp_plant_package]
	@id_location INT,
	@group_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	/* create list of groups. */
	SELECT *
	INTO #group_list
	FROM OPENJSON(@group_list)
	WITH (
		id_item INT,
		metrc_label VARCHAR(128),
		id_area INT,
		plant_list NVARCHAR(MAX) AS JSON
	)

	DECLARE @id_item INT,
			@metrc_label VARCHAR(128),
			@id_area INT,
			@plant_list VARCHAR(MAX)

	DECLARE @metrc_state VARCHAR(16) = (SELECT TOP 1 state FROM base.location WHERE id_location=@id_location)
	DECLARE @id_batch INT,
			@quantity INT,
			@notes VARCHAR(256)

	DECLARE cur CURSOR FAST_FORWARD FOR 
	SELECT * FROM #group_list
		
	OPEN cur
	FETCH NEXT FROM cur INTO @id_item, @metrc_label, @id_area, @plant_list
		
	WHILE(@@FETCH_STATUS = 0)
	BEGIN
		/* create batch */
		SET @quantity = (SELECT COUNT(value) FROM OPENJSON(@plant_list))
		EXEC @id_batch = inventory.usp_batch_create @id_item, NULL, NULL, @id_location, @quantity

		IF @metrc_label IS NOT NULL
			UPDATE inventory.batch 
			SET name = @metrc_label
				, metrc_package_label = @metrc_label
				, metrc_item_id = (SELECT metrc_item_id FROM inventory.item_location WHERE id_location=@id_location AND id_item=@id_item)
				, metrc_state = @metrc_state
			WHERE id_batch=@id_batch

		/* add plants to batch history. */
		INSERT INTO grow.batch_plant (id_batch, id_plant)
		SELECT @id_batch AS id_batch
				, value AS id_plant
		FROM OPENJSON(@plant_list)

		/* add to inventory. */
		EXEC [log].usp_event_create 'plant_package', @id_batch, @id_area, @quantity, NULL, @id_user

		/* set plants as packaged. */
		UPDATE grow.plant
		SET packaged = 1
			, date_updated = GETUTCDATE()
			, id_user_updated = @id_user
		WHERE id_plant IN (SELECT value FROM OPENJSON(@plant_list))
		
		/* add plant event. */
		SET @notes = CONCAT('BatchID: ', CAST(@id_batch AS VARCHAR(16)))
		DECLARE @list_create VARCHAR(MAX) = (SELECT id_plant, id_area, [row], [column], @notes AS notes FROM grow.plant WHERE id_plant IN (SELECT value FROM OPENJSON(@plant_list)) FOR JSON PATH)
		EXEC grow.usp_event_create_bulk 'package', NULL, NULL, NULL, NULL, @list_create, @id_user

		FETCH NEXT FROM cur INTO @id_item, @metrc_label, @id_area, @plant_list
	END

	CLOSE cur
	DEALLOCATE cur
go

