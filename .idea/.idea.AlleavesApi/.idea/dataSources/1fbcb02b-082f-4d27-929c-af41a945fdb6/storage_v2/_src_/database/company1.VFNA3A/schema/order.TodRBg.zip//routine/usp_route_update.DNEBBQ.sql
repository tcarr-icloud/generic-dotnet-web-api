CREATE PROCEDURE [order].usp_route_update
              @id_ride INT,
              @route_index VARCHAR(250),
              @eta VARCHAR(250),
              @latitude VARCHAR(250),
              @longitude VARCHAR(250)
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE [order].routes
	SET
		route_index= @route_index,
	    eta = @eta,
		latitude = @latitude,
	    longitude = @longitude

	WHERE id_ride = @id_ride
    EXEC [order].usp_route_list @id_ride
END
go

