CREATE FUNCTION [dbo].[fn_utc_to_local]
(
	@date DATETIME,
	@id_location INT
)
RETURNS DATETIME
AS
BEGIN
	DECLARE @tz VARCHAR(64)
	SET @tz=(SELECT timezone FROM base.location WHERE id_location=@id_location)

	IF(@tz IS NULL)
		SET @tz='UTC'

	RETURN CAST(@date AT TIME ZONE 'UTC' AT TIME ZONE dbo.fn_lookup_tz(@tz) AS DATETIME)
END
go

