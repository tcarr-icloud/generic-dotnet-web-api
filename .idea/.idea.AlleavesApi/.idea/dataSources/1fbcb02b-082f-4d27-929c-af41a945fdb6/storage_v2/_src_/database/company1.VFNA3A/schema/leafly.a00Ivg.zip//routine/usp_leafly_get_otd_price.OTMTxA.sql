CREATE PROCEDURE [leafly].[usp_leafly_get_otd_price]
	@use_otd_price BIT,
	@id_location INT
AS
	SELECT use_otd_price
	FROM [leafly].[menu_key]
	WHERE id_location = @id_location
go

