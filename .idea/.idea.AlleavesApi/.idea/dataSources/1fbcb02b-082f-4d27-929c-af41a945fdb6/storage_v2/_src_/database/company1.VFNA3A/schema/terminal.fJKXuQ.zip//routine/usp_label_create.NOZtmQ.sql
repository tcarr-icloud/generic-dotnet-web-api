CREATE PROCEDURE terminal.usp_label_create
	@name VARCHAR(256),
	@path VARCHAR(256),
	@category VARCHAR(256),
	@id_user INT
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO terminal.label ([name],[path],[category],id_user_created_by, id_user_modified_by) 
	VALUES (@name,@path,@category,@id_user,@id_user)
	DECLARE @id_label INT = SCOPE_IDENTITY()
	EXEC terminal.usp_label_list @id_label
END
go

