CREATE PROCEDURE [base].[usp_setup_test_data]
	@is_move_client BIT = 0,
	@is_metrc BIT = 0
AS

	ALTER ROLE [db_owner] ADD MEMBER [api_user]

	SET IDENTITY_INSERT [base].[user] ON 
	IF NOT EXISTS (SELECT * FROM [base].[user] WHERE id_user=1)
		INSERT INTO [base].[user] (
			[id_user],
			[giud_user],
			[id_company],
			[FirstName],
			[LastName],
			[Email],
			[EmailConfirmed],
			[PasswordHash],
			[deleted],
			[PIN],
			[PhoneNumber],
			[PhoneNumberConfirmed],
			[TwoFactorEnabled],
			[LockoutEnabled],
			[AccessFailedCount],
			[UserName],
			[PasswordReset],
			[PasswordResetDate],
			[accountDisabled],
			[theme]
		) VALUES (
			1,
			newid(),
			1000,
			N'Admin',
			N'User',
			'admin@company1.com',
			1,
			N'AHqK6SmUf+MRo24kzY8WHkY3ixn6NEHleg22NoM3ZbBe7t49CWoHlDkgws8BSD+Y9w==',
			0,
			N'$2b$10$N/mAl/mQGBNvkPLsvQWeyenKcTdR0gSeps758mSTPqVV8JjVOEIke',
			N'000-000-0000',
			1,
			0,
			0,
			0,
			N'admin@company1.com',
			0,
			N'2030-12-31 23:59:59',
			0,
			N'Alleaves'
		)
	SET IDENTITY_INSERT [base].[user] OFF
	
	SET IDENTITY_INSERT [acl].[role] ON 
	IF NOT EXISTS (SELECT * FROM acl.role WHERE id_role=1)
		INSERT INTO acl.role (id_role, name, id_user_created, id_user_updated) VALUES (1, 'Admin', -1, -1)
	SET IDENTITY_INSERT [acl].[role] OFF

	;WITH list AS (
		SELECT 1 AS id_role
				, id_permission
		FROM [acl].[permission]
	)
	MERGE [acl].[role_permission] t USING list s 
	ON t.id_role=s.id_role AND t.id_permission=s.id_permission
	WHEN MATCHED THEN 
		UPDATE SET t.allowed=1
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_role, id_permission, allowed, id_user_created, id_user_updated) 
		VALUES (s.id_role, s.id_permission, 1, -1, -1) 
	WHEN NOT MATCHED BY SOURCE AND t.id_role=1 THEN
		DELETE
	;

	IF NOT EXISTS (SELECT * FROM acl.user_role WHERE id_role = 1 AND id_user = 1)
		INSERT INTO acl.user_role (id_role, id_user) VALUES (1,1)

	ALTER ROLE [db_owner] ADD MEMBER [api_user]
go

