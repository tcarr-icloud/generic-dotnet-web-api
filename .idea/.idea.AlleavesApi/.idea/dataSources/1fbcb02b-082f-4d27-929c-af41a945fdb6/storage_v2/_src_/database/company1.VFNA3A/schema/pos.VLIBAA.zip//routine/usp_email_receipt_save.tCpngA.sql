CREATE PROCEDURE [pos].[usp_email_receipt_save]
    @id_user int,
	@id_location INT,
    @email_header nvarchar(1500),
    @email_footer nvarchar(1500),
    @email_subject nvarchar(1500),
    @email_logo varchar(256),
    @email_template varchar(256),
    @email_id_logo int,
    @email_id_template int
AS
BEGIN

	IF EXISTS(SELECT TOP 1 id_email_receipt FROM pos.email_receipt WHERE id_location = @id_location)
	BEGIN
		UPDATE pos.email_receipt
		SET 
			email_subject = @email_subject,
			email_header = @email_header,
			email_footer = @email_footer,
			email_logo = @email_logo,
			email_id_logo = @email_id_logo,
			email_template = @email_template,
			email_id_template = @email_id_template,
			id_user_created_by = @id_user,
			id_user_modified_by = @id_user
		WHERE id_location = @id_location
		DECLARE @id_email_receipt_top INT
		SELECT TOP 1 @id_email_receipt_top=id_email_receipt FROM [pos].[email_receipt] WHERE id_location = @id_location;
		EXEC pos.usp_email_receipt_list @id_email_receipt_top;
	END
	ELSE
	BEGIN
		INSERT INTO pos.email_receipt  (id_location, email_subject, email_header, email_footer,email_logo,email_id_logo,email_template,email_id_template,id_user_created_by,id_user_modified_by)
		VALUES  (@id_location, @email_subject,@email_header,@email_footer,@email_logo,@email_id_logo,@email_template,@email_id_template,@id_user,@id_user);
		
		DECLARE @id_email_receipt INT = SCOPE_IDENTITY()
		EXEC pos.usp_email_receipt_list @id_email_receipt;
	END
END
go

