CREATE PROCEDURE [pos].[usp_template_list]
	@id_template INT = NULL,
	@id_location INT = NULL
AS
BEGIN
	SET NOCOUNT ON;
SELECT 
	id_template,
	id_location,
	[name],
	[path],
	deleted,
	id_user_created_by
	FROM pos.templates
	WHERE deleted = 0 
	AND (@id_template IS NULL OR id_template = @id_template)
	AND (@id_location IS NULL OR id_location = @id_location)
END
go

