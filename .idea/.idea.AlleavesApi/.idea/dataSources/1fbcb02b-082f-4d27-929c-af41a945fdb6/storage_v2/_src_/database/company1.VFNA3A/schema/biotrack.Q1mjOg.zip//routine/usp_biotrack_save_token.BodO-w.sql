CREATE PROCEDURE [biotrack].[usp_biotrack_save_token]
	@id_location INT,
	@biotrack_access_token VARCHAR(MAX),
	@biotrack_refresh_token VARCHAR(MAX),
	@biotrack_token_expiration_date DATE
AS
	UPDATE base.[location]
	SET 
		biotrack_access_token=@biotrack_access_token,
		biotrack_refresh_token=@biotrack_refresh_token,
		biotrack_token_expiration_date=@biotrack_token_expiration_date
	WHERE id_location=@id_location
go

