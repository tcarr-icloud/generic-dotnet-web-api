CREATE   PROCEDURE [dbo].[usp_admin_user_delete]
	@id_user INT
AS
	DELETE FROM [base].[user_role]
	WHERE id_user=@id_user
	
	UPDATE [base].[user]
	SET deleted = 1
	WHERE id_user=@id_user

	SELECT id_user AS id_user
			, FirstName AS name_first
			, LastName AS name_last
			, UserName AS username
	FROM [base].[user]
	WHERE id_user=@id_user
go

