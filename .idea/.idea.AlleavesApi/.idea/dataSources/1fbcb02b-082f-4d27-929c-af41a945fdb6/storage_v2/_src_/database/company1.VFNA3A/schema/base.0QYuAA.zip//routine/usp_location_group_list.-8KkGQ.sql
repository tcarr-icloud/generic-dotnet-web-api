CREATE PROCEDURE [base].[usp_location_group_list]
	@id_location_group INT = NULL,
	@deleted BIT = 0
AS
	SELECT lg.id_location_group
			, lg.deleted
			, lg.[name] AS location_group
			, ISNULL
			(
				(
					SELECT 
						  lgv.id_location_group
						, lgv.id_location
						, l.[name] AS 'location'
					FROM [base].[location_group_value] lgv
					LEFT JOIN [base].[location] l ON l.id_location = lgv.id_location
					WHERE lgv.id_location_group = lg.id_location_group 
					FOR JSON PATH
				), 
				'[]'
			) AS location_list
	FROM [base].[location_group] lg
	WHERE lg.id_location_group=ISNULL(@id_location_group, lg.id_location_group) 
	AND lg.deleted <= @deleted
go

