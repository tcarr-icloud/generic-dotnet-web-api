CREATE PROCEDURE [process].[usp_form_update]
	@id_form INT,
	@name VARCHAR(128),
	@id_process_category INT,
	@sequence INT,
	@input_list VARCHAR(MAX) = '[]',
	@attribute_list VARCHAR(MAX) = '[]',
	@output_list VARCHAR(MAX) = '[]',
	@id_user INT,
	@deleted BIT = 0,
	@id_category_move INT = NULL,
	@id_parent_move INT = NULL
AS
	SET NOCOUNT ON

	DECLARE @orig_id_parent INT
	DECLARE @orig_id_process_category INT
	DECLARE @orig_sequence INT
	SET @orig_sequence = (SELECT sequence FROM process.form WHERE id_form=@id_form)
	
	DECLARE @sequence_min INT
	DECLARE @sequence_max INT
	SET @sequence_min=IIF(@sequence<@orig_sequence, @sequence, @orig_sequence)
	SET @sequence_max=IIF(@sequence>@orig_sequence, @sequence, @orig_sequence)

	/* get original values. */
	SELECT @orig_id_process_category=id_process_category
		, @orig_sequence=sequence
	FROM process.form
	WHERE id_form=@id_form

	/* update form. */
	UPDATE process.form
	SET name=@name
		, id_process_category=@id_process_category
		, sequence=@sequence
		, deleted=@deleted
		, updated_by=@id_user
		, date_updated=getutcdate()
	WHERE id_form=@id_form

	/* update inputs. */
	;WITH input_list AS (
		SELECT @id_form AS id_form
				, id_form_input
				, id_raw_material
		FROM OPENJSON(@input_list)
		WITH (
			id_form_input INT,
			id_raw_material INT
		)
	)
	MERGE process.form_input AS t
	USING input_list AS s 
		ON s.id_form_input=t.id_form_input AND s.id_form=t.id_form
	WHEN MATCHED AND (t.id_raw_material<>s.id_raw_material) THEN
			UPDATE SET t.id_raw_material=s.id_raw_material, t.date_updated=getutcdate()
	WHEN NOT MATCHED BY TARGET  THEN
		INSERT (id_form, id_raw_material) VALUES (s.id_form, s.id_raw_material)
	WHEN NOT MATCHED BY SOURCE AND t.id_form=@id_form THEN
		DELETE
	;
	/* update attributes. */
	;WITH attribute_list AS (
		SELECT @id_form AS id_form
				, id_form_attribute
				, name
				, input_type
		FROM OPENJSON(@attribute_list)
		WITH (
			id_form_attribute INT '$.id_form_attribute',
			name VARCHAR(128) '$.name',
			input_type VARCHAR(32) '$.input_type'
		)
	)
	MERGE process.form_attribute AS t
	USING attribute_list AS s 
		ON s.id_form_attribute=t.id_form_attribute AND s.id_form=t.id_form
	WHEN MATCHED AND ((t.name<>s.name) OR (t.input_type<>s.input_type)) THEN
			UPDATE SET t.name=s.name, t.input_type=s.input_type, t.date_updated=getutcdate()
	WHEN NOT MATCHED BY TARGET  THEN
		INSERT (id_form, name, input_type) VALUES (s.id_form, s.name, s.input_type)
	WHEN NOT MATCHED BY SOURCE AND t.id_form=@id_form THEN
		DELETE
	;
	/* update outputs. */
	;WITH output_list AS (
		SELECT @id_form AS id_form
				, id_form_output
				, id_raw_material
		FROM OPENJSON(@output_list)
		WITH (
			id_form_output INT,
			id_raw_material INT
		)
	)
	MERGE process.form_output AS t
	USING output_list AS s 
		ON s.id_form_output=t.id_form_output AND s.id_form=t.id_form
	WHEN MATCHED AND (t.id_raw_material<>s.id_raw_material) THEN
			UPDATE SET t.id_raw_material=s.id_raw_material, t.date_updated=getutcdate()
	WHEN NOT MATCHED BY TARGET  THEN
		INSERT (id_form, id_raw_material) VALUES (s.id_form, s.id_raw_material)
	WHEN NOT MATCHED BY SOURCE AND t.id_form=@id_form THEN
		DELETE
	;

	IF(@deleted=1)
	BEGIN		
		/* renumber siblings in original category. */
		;WITH resequence AS
		(
		  SELECT id_form
				, sequence
				, ROW_NUMBER() OVER (ORDER BY sequence) as new_sequence
			FROM process.form
			WHERE ISNULL(id_process_category, -1)=ISNULL(@orig_id_process_category, -1) AND 
				  deleted=0
		)
		UPDATE resequence SET sequence=new_sequence

	END
	/* if either the category or parent changed. */
	ELSE IF(@orig_id_process_category<>@id_process_category)
	BEGIN
		/* renumber siblings in original category/parent group. */
		;WITH resequence AS
		(
		  SELECT id_form
				, sequence
				, ROW_NUMBER() OVER (ORDER BY sequence) as new_sequence
			FROM process.form
			WHERE ISNULL(id_process_category, -1)=ISNULL(@orig_id_process_category, -1) AND 
				  deleted=0
		)
		UPDATE resequence SET sequence=new_sequence
		
		/* shift new siblings down by one. */
		UPDATE process.form
		SET sequence=sequence+1
		WHERE ISNULL(id_process_category, -1)=ISNULL(@id_process_category, -1) AND
			  sequence>=@sequence AND
			  id_form<>@id_form AND
			  deleted=0
	END
	/* if only the sequence changed. */
	ELSE IF(@orig_sequence<>@sequence) 
	BEGIN
		/* shift sequences up or down based on movement of process. */
		UPDATE process.form
		SET sequence=sequence+(CASE WHEN @orig_sequence-@sequence<0 THEN -1 WHEN @orig_sequence-@sequence>0 THEN 1 ELSE 0 END)
		WHERE sequence BETWEEN @sequence_min AND @sequence_max AND 
			  ISNULL(id_process_category, -1)=ISNULL(@id_process_category, -1) AND
			  id_form<>@id_form AND 
			  deleted=0
	END

	EXEC process.usp_form_list @id_form
go

