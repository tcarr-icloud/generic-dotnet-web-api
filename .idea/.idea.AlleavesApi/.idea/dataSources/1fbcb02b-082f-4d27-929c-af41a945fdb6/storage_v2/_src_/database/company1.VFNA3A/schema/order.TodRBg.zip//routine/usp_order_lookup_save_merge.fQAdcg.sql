CREATE PROCEDURE [order].[usp_order_lookup_save_merge]
	@lookups NVARCHAR(MAX)
AS
DECLARE @actions TABLE(actionname varchar(50))
BEGIN TRAN;
BEGIN TRY
	--DECLARE @lookups NVARCHAR(MAX);
	--SET @lookups = '';
	MERGE [order].[order_lookup] as t
	USING (
		SELECT
			 [id_order_lookup]
			,[location]
			,[id_customer]
			,[id_order_online]
			,[id_checkin]
			,[id_onfleet]
			,[ticket]
			,[source]
			,[sale_type]
			,[status]
			,[order_date]
			,[pickup_time]
			,[verified]
			,[scheduled]
			,[packed]
			,[id_user_working]
			,ISNULL([deleted], 0) as deleted
			,[date_received]
		FROM OPENJSON(@lookups)
			WITH (
				[id_order_lookup] [int] '$.id_order_lookup',
				[location] [varchar](128) '$.location',
				[id_customer] [int] '$.id_customer',
				[id_order_online] [int] '$.id_order_online',
				[id_checkin] [int] '$.id_checkin',
				[id_onfleet] [varchar](128) '$.id_onfleet',
				[ticket] [varchar](64) '$.ticket',
				[source] [varchar](32) '$.source',
				[sale_type] [varchar](32) '$.sale_type',
				[status] [varchar](64) '$.status',
				[order_date] [date] '$.order_date',
				[pickup_time] [varchar](32) '$.pickup_time',
				[verified] [bit] '$.verified',
				[scheduled] [bit] '$.scheduled',
				[packed] [bit] '$.packed',
				[id_user_working] [int] '$.id_user_working',
				[deleted] [bit] '$.deleted',
				[date_received] [datetime] '$.date_received'
			)
	) as s
		ON
			(s.id_order_lookup IS NOT NULL AND t.id_order_lookup = s.id_order_lookup) OR
			(s.id_order_online IS NOT NULL AND t.id_order_online = s.id_order_online)

	WHEN NOT MATCHED THEN INSERT ([location],[id_customer],[id_order_online],[id_checkin],[id_onfleet],[ticket],[source],[sale_type],[status],[order_date],[pickup_time],[date_received])
	VALUES (
		 s.[location]
		,s.[id_customer]
		,s.[id_order_online]
		,s.[id_checkin]
		,s.[id_onfleet]
		,s.[ticket]
		,s.[source]
		,s.[sale_type]
		,s.[status]
		,s.[order_date]
		,s.[pickup_time]
		,s.[date_received]
	)
	WHEN MATCHED THEN UPDATE
		SET 
			 t.[location] = s.[location]
			,t.[id_customer] = s.[id_customer]
			,t.[id_order_online] = s.[id_order_online]
			,t.[id_checkin] = s.[id_checkin]
			,t.[ticket] = s.[ticket]
			,t.[source] = s.[source]
			,t.[sale_type] = s.[sale_type]
			,t.[status] = s.[status]
			,t.[order_date] = s.[order_date]
			,t.[pickup_time] = s.[pickup_time]
			,t.[deleted] = s.[deleted]
			,t.[date_received] = s.[date_received]
			,t.[date_updated] = GETUTCDATE()
			OUTPUT $action, inserted.*;
	COMMIT TRAN;
END TRY
BEGIN CATCH
	ROLLBACK TRAN;
	SELECT ERROR_NUMBER() as Error, ERROR_MESSAGE() as [Message]
END CATCH
go

