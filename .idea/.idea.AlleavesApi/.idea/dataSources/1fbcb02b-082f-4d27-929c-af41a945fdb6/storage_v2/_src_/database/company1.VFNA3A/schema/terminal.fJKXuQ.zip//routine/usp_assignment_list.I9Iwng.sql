CREATE PROCEDURE terminal.usp_assignment_list
              @id_assignment INT = NULL
AS
BEGIN
	SELECT id_assignment,
	       id_terminal,
	       secret,
	       id_user_created_by,
	       id_user_updated_by,
	       date_created,
	       date_updated
	FROM terminal.assignment
	WHERE id_assignment = @id_assignment
END
go

