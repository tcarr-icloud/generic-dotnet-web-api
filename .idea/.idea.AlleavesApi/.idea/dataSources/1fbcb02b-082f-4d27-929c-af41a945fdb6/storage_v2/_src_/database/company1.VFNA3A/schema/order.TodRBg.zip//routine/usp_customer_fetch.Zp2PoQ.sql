CREATE PROCEDURE [order].[usp_customer_fetch]
    @id_customer INT = NULL
AS

SELECT 
      c.id_customer
    , c.deleted
    , c.is_banned
    , c.ban_reason
    , c.ban_expires
    , c.guid_customer
    , c.name_first
    , c.name_middle
    , c.name_last
    , c.gender
    , c.phone
    , c.email
    , c.PasswordHash as [password]
    , c.address1
    , c.address2
    , c.city
    , c.state
    , c.zip
    , c.id_physician
    , c.id_caregiver
    , c.is_caregiver
    , c.is_employee
    , c.id_referral_method
    , c.drivers_license
    , c.drivers_license_st
    , c.passport
    , c.expiration_date
    , r.[name] AS referral_method  
    , c.id_customer_referral
    , rc.name_first AS referral_customer_fname
    , rc.name_last AS referral_customer_lname
    , c.id_physician_referral 
	, c.referral_expiration_date
    , c.referral_date
    , p.name_first AS physician_fname
    , p.name_last AS physician_lname
    , c.referral_description
    , CAST(c.date_of_birth AS VARCHAR(16)) AS date_of_birth
    , (SELECT 
        CASE WHEN SUM(amount) IS NULL THEN 0 WHEN SUM(amount) < 0 THEN 0 ELSE SUM(amount) END
        FROM [order].customer_credit_debit
        WHERE id_customer = c.id_customer) as credit_balance
    , (SELECT 
        COUNT(id_order)
        FROM [order].[order]
        WHERE id_customer = c.id_customer
        AND void <> 1
        AND (cancel = 0 AND paid_in_full <> 1 OR (complete <> 1 AND id_status NOT IN (SELECT id_status
                                                                        FROM [order].[status]
                                                                        WHERE LOWER([name]) LIKE 'complete%')))) as open_orders
    , c.patient_number
    , c.id_user_online
    , c.id_customer_biotrack
	, c.springbig_user_code
	, c.springbig_signature_url
    , CASE WHEN q.id_queue IS NULL THEN 0 ELSE 1 END AS in_queue
    , q.time_in
    , q.time_out
    , q.id_queue
    , CAST(CAST(c.date_created AS DATE) AS VARCHAR(16)) AS customer_since
    , ISNULL(
    (
        SELECT i.id_identification
                , i.id_customer
                , i.label
                , i.value
        FROM [order].identification i
        WHERE i.id_customer = c.id_customer
        FOR JSON PATH
    ), '[]') AS id_list
    , ISNULL(
    (
        SELECT ct.id_customer_type_selected
                , ct.id_customer
                , ct.id_customer_type
                , t.[name] AS customer_type
        FROM [order].customer_type_selected ct
                    LEFT JOIN [order].customer_type t ON t.id_customer_type = ct.id_customer_type
        WHERE ct.id_customer = c.id_customer
        FOR JSON PATH
    ),'[]') AS customer_type_list
    , c.patient_id_front
    , c.patient_id_back
    , c.driver_license_front
    , c.driver_license_back
FROM [order].[customer] c
LEFT JOIN [order].queue q ON q.id_customer = c.id_customer AND q.time_out IS NULL
LEFT JOIN [order].referral_method r ON r.id_referral_method = c.id_referral_method
LEFT JOIN [order].physician p ON p.id_physician = c.id_physician_referral
LEFT JOIN [order].customer rc ON rc.id_customer = c.id_customer_referral
WHERE 
        (@id_customer IS NULL OR c.id_customer = @id_customer)
OPTION(RECOMPILE)
go

