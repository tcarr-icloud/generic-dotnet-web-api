CREATE PROCEDURE [loyalty].[usp_create_order_loyalty_entry] 
	@id_order int,
	@loyalty_vender VARCHAR(256),
	@redemption_type VARCHAR(50),
	@redemption_url VARCHAR(2048),
	@id_offer_reward VARCHAR(50),
	@amount DECIMAL(18, 2),
	@loyalty_name VARCHAR(256),
	@discount_type VARCHAR(1),
	@expiry_date DATETIME,
	@item_value INT,
	@id_user INT
AS
INSERT INTO loyalty.[order] (
	[id_order],
	[loyalty_vender],
	[loyalty_name],
	[redemption_type],
	[redemption_url],
	[id_offer_reward],
	[amount],
	[discount_type],
	[expiry_date],
	[item_value],
	[date_created], 
	[id_user_created_by]
)
VALUES (
	@id_order, 
	@loyalty_vender,
	@loyalty_name, 
	@redemption_type, 
	@redemption_url,
	@id_offer_reward, 
	@amount,
	@discount_type,
	@expiry_date,
	@item_value, 
	GETUTCDATE(), 
	@id_user
)
go

