CREATE PROCEDURE [inventory].[usp_batch_get_last_area]
	@id_batch INT,
	@id_location INT = NULL
AS
	IF @id_location IS NULL 
	BEGIN
		SELECT TOP 1 ia.id_area
		FROM [log].[event] le
		LEFT JOIN inventory.area ia ON ia.id_area = le.id_area
		WHERE le.id_batch = @id_batch
		ORDER BY le.date_created DESC, le.id_event DESC
	END
	ELSE 
	BEGIN
		SELECT TOP 1 ia.id_area
		FROM [log].[event] le
		LEFT JOIN inventory.area ia ON ia.id_area = le.id_area
		WHERE le.id_batch = @id_batch AND ia.id_location=@id_location AND le.original_quantity + le.adjustment > 0
		ORDER BY le.date_created DESC, le.id_event DESC
	END
go

