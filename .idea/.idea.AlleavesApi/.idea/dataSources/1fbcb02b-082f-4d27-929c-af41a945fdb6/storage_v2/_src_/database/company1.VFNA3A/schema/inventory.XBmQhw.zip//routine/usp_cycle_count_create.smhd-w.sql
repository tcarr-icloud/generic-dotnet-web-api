CREATE PROCEDURE [inventory].[usp_cycle_count_create]
	@id_location INT,
	@start_date DATETIME,
	@end_date DATETIME,
	@id_user INT,
	@id_adjust_reason INT,
	@adjust_reason VARCHAR(MAX),
	@list VARCHAR(MAX)
AS
	INSERT INTO inventory.cycle_count (id_location, id_user, start_date, end_date, id_adjust_reason, adjust_reason_note, in_progress, completed, deleted)
	VALUES (@id_location, @id_user, @start_date, @end_date, @id_adjust_reason, @adjust_reason, 1, 1,0)

	DECLARE @id_cycle_count INT = SCOPE_IDENTITY()

	INSERT INTO inventory.cycle_count_item (id_cycle_count, id_area, id_inventory_item, id_batch, expected_count, actual_count)
	SELECT @id_cycle_count AS id_cycle_count
			, id_area
			, id_inventory_item
			, id_batch
			, expected_count
			, actual_count
	FROM OPENJSON(@list)
	WITH (
		id_area INT,
		id_inventory_item INT,
		id_batch INT,
		expected_count DECIMAL(18,4),
		actual_count DECIMAL(18,4)
	)

	SELECT @id_cycle_count AS id_cycle_count
go

