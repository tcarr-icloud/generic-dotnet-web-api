CREATE PROCEDURE [order].[usp_sale_limit_cart_balance]
	@id_order INT

AS
	/* get lookup variables. */
	DECLARE @id_customer INT,
			@id_location INT,
			@use_type VARCHAR(64)

	SELECT @id_location=id_location	
			, @id_customer=id_customer
			, @use_type=use_type
	FROM [order].[order]
	WHERE id_order=@id_order

	DECLARE @id_state_customer INT

	SELECT @id_state_customer=bs.id_state
	FROM [order].[customer] oc
	LEFT JOIN [base].[states] bs ON bs.name=oc.state
	WHERE id_customer=@id_customer

	SELECT delivery_route, MAX(amount) as amount_in_cart, uom
	FROM (
	SELECT SUM(amount) AS amount
			, amount_limit
			, ISNULL((SELECT STRING_AGG(ISNULL(d.name, ' '), ', ')
			   FROM inventory.delivery_route d
			   JOIN [order].sale_limit_delivery_route slr ON slr.id_delivery_route=d.id_delivery_route
			   WHERE slr.id_sale_limit=t.id_sale_limit), 'All Cannabis Products') AS delivery_route
			, (amount_limit - SUM(amount)) as amount_remaining
			, uom
	FROM (	
		SELECT DISTINCT oi.id_item
				, sl.id_sale_limit
				, o.use_type
				, sl.weight_type
				, sl.timespan
				, sl.rolling_days
				, sl.residence_type
				, st.abbreviation as state
				, (CASE WHEN oi.id_item_return IS NULL THEN oi.quantity ELSE -oi.quantity END) * 
					(CASE WHEN sl.weight_type IS NULL OR sl.weight_type='net' THEN ISNULL(i.weight_useable, 0) * uc.multiplier ELSE ISNULL(i.gross_weight_useable, 0) * ucc.multiplier END) AS amount
				, sl.amount AS amount_limit
				, u.name AS uom
		FROM [order].[order] o
		JOIN [order].item oi ON oi.id_order=o.id_order
		JOIN inventory.vw_item_list i ON i.id_item=oi.id_inventory_item
		JOIN inventory.vw_delivery_route d ON d.id_delivery_route=i.id_delivery_route
		JOIN [order].sale_limit sl ON ((@use_type='adult' AND sl.is_adult=1) OR (@use_type='medical' AND sl.is_medical=1)) AND sl.deleted=0 AND ((sl.residence_type<>'out_state' AND id_state=@id_state_customer) OR (sl.residence_type='out_state' AND id_state<>@id_state_customer) OR (sl.residence_type='any_state'))
		JOIN (
			SELECT id_sale_limit, id_delivery_route
			FROM [order].sale_limit_delivery_route
			UNION ALL
			SELECT x.id_sale_limit, y.id_delivery_route
			FROM [order].sale_limit x
			CROSS JOIN inventory.delivery_route y 
			WHERE x.id_sale_limit not in (select distinct id_sale_limit FROM [order].sale_limit_delivery_route)
		) slr ON slr.id_sale_limit=sl.id_sale_limit AND (slr.id_delivery_route=d.id_delivery_route OR slr.id_delivery_route=d.id_root)
		JOIN base.location l ON l.id_location=o.id_location
		JOIN base.states st ON st.id_state=sl.id_state AND st.abbreviation=l.state
		JOIN inventory.uom u ON u.id_uom=sl.id_uom
		JOIN inventory.uom_convert uc ON uc.id_uom_from=i.id_uom_weight_useable AND uc.id_uom_to=sl.id_uom
		JOIN inventory.uom_convert ucc ON ucc.id_uom_from=i.id_uom_gross_weight_useable AND ucc.id_uom_to=sl.id_uom
		LEFT OUTER JOIN [dbo].[tz_lookup] as tl ON l.[timezone] = tl.[tz_iana]
		WHERE o.id_location=@id_location AND
				o.id_customer=@id_customer AND
				o.use_type=@use_type AND
				(@id_order IS NOT NULL AND o.id_order=@id_order)
			) t
		GROUP BY id_sale_limit, use_type, timespan, rolling_days, state, amount_limit, uom, weight_type, residence_type
	) at
	GROUP BY delivery_route, uom
go

