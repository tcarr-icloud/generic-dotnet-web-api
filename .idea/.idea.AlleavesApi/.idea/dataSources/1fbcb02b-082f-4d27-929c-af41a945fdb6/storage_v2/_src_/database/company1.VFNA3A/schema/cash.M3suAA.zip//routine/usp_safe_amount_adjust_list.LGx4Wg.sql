CREATE PROCEDURE [cash].[usp_safe_amount_adjust_list]
	@id_safe_event INT = NULL

AS

	SELECT se.id_safe_event
		, se.adjustment
		, se.id_safe
		, se.reason
		, se.reason_type
		, se.note
		, se.id_user_created
		, CAST(se.date_created AS DATE) AS 'date' 
		, se.date_created
		, s.[name] AS 'safe'
		, s.amount
		, l.id_location
		, l.[name] AS 'location'
		, u.FirstName + ' ' + u.LastName AS 'user'
	    , ISNULL(
					(
						SELECT ses.id_session
						FROM [cash].[safe_event_session] ses
						JOIN [pos].[session] sn ON sn.id_session = ses.id_session
						JOIN [pos].[register] r ON r.id_register = sn.id_register
						WHERE ses.id_safe_event = se.id_safe_event
					), NULL  
				) AS id_session
	    , ISNULL(
					(
						SELECT r.name AS register
						FROM [cash].[safe_event_session] ses
						JOIN [pos].[session] sn ON sn.id_session = ses.id_session
						JOIN [pos].[register] r ON r.id_register = sn.id_register
						WHERE ses.id_safe_event = se.id_safe_event
					), ''  
				) AS register
	    , ISNULL(
					(
						SELECT st.id_safe
						FROM [cash].[safe_transfer] st
						WHERE st.id_safe_event = se.id_safe_event AND st.is_transfer_from = 1
					), NULL  
				) AS id_safe_transfer_from
	    , ISNULL(
					(
						SELECT st.id_safe
						FROM [cash].[safe_transfer] st
						WHERE st.id_safe_event = se.id_safe_event AND st.is_transfer_from = 0
					), NULL  
				) AS id_safe_transfer_to
	    , ISNULL(
					(
						SELECT s.[name] AS safe_transfer_from
						FROM [cash].[safe_transfer] st
						JOIN [cash].[safe] s ON s.id_safe = st.id_safe
						WHERE st.id_safe_event = se.id_safe_event AND st.is_transfer_from = 1
					), NULL  
				) AS safe_transfer_from
	    , ISNULL(
					(
						SELECT s.[name] AS safe_transfer_to
						FROM [cash].[safe_transfer] st
						JOIN [cash].[safe] s ON s.id_safe = st.id_safe
						WHERE st.id_safe_event = se.id_safe_event AND st.is_transfer_from = 0
					), NULL  
				) AS safe_transfer_to
	    , ISNULL(
					(
						SELECT st.is_transfer_from
						FROM [cash].[safe_transfer] st
						WHERE st.id_safe_event = se.id_safe_event
					), NULL  
				) AS is_transfer_from
	    , ISNULL(
					(
						SELECT s.balance_ending
						FROM [pos].[session] s
						JOIN [cash].[safe_event_session] ses ON s.id_session = ses.id_session
						WHERE ses.id_safe_event = se.id_safe_event
					), NULL  
				) AS balance_ending
	    , ISNULL(
					(
						SELECT vp.id_vendor
						FROM [cash].[vendor_payment] vp
						WHERE vp.id_safe_event = se.id_safe_event
					), NULL  
				) AS id_vendor
	    , ISNULL(
					(
						SELECT v.[name] AS vendor
						FROM [cash].[vendor_payment] vp
						JOIN [inventory].[vendor] v ON v.id_vendor = vp.id_vendor
						WHERE vp.id_safe_event = se.id_safe_event
					), NULL  
				) AS vendor
				, CASE 
					WHEN se.reason = 'Deposit' AND se.reason_type = 'Closing Deposit' THEN
						(
							SELECT d.[id], d.[name], d.[location], d.[type], d.[value], d.[order_id], d.[location_id], d.[customer_id], d.[id_session]
							FROM [base].[donation] d
							INNER JOIN [cash].[safe_event_session] ses ON d.id_session = ses.id_session
							WHERE ses.id_safe_event = se.id_safe_event
							FOR JSON PATH
						)
					ELSE NULL
				END AS donations
	FROM [cash].[safe_event] se
	LEFT JOIN [cash].[safe] s ON s.id_safe=se.id_safe
	LEFT JOIN [base].[location] l ON l.id_location=s.id_location
	LEFT JOIN [base].[user] u ON u.id_user=se.id_user_created
	WHERE se.id_safe_event=ISNULL(@id_safe_event, se.id_safe_event) 
	ORDER BY se.date_created DESC
go

