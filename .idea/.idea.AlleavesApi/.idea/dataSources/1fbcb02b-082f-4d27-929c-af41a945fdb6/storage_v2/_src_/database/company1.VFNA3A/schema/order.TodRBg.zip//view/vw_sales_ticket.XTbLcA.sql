
CREATE VIEW [order].[vw_sales_ticket]

AS

WITH order_CTE as (
SELECT 
     o.id_order
    ,o.date_created as 'date'
	,o.type as order_type
	,l.name AS 'location'
	,u.FirstName + ' ' + u.LastName AS 'employee_name'
	,c.name_first + ' ' + c.name_last AS 'customer_name'
	,c.patient_number
	,o.total
	,r.[name] as terminal
	,r.id_register
FROM [order].[order] o 
INNER JOIN [order].[item] oi on o.id_order = oi.id_order AND oi.id_item_return IS NULL
LEFT JOIN [order].[customer] c on c.id_customer=o.id_customer
LEFT JOIN [base].[user] u ON u.id_user=o.created_by
LEFT JOIN [base].[location] l on l.id_location=o.id_location
LEFT JOIN [order].[payment] p ON p.id_order=oi.id_order
LEFT JOIN [pos].[register] r ON r.id_register=p.id_register
WHERE o.void = 0 
AND o.cancel = 0
)
SELECT
	 [date]
	,location
	,id_register
	,terminal
	,employee_name
	,id_order
	,order_type
	,customer_name
	,patient_number
	,total
FROM order_CTE
GROUP BY [date] ,employee_name ,id_order ,order_type ,customer_name ,patient_number ,location ,total ,terminal ,id_register
go

