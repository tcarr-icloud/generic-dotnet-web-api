CREATE   PROCEDURE [dbo].[usp_admin_role_delete]
	@id_role INT
AS
	SET NOCOUNT ON;

	DELETE FROM [base].[user_role]
	WHERE id_role=@id_role

	DELETE FROM [base].[role]
	WHERE id_role=@id_role
go

