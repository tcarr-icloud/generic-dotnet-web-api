CREATE PROCEDURE [log].[usp_event_create_bulk]
	@type_reference VARCHAR(128),	
	@notes VARCHAR(MAX) = NULL,
	@event_list VARCHAR(MAX) = '[]',
	@id_user INT
AS

	IF (@event_list IS NULL)
		RETURN

	DECLARE @id_batch INT,
			@id_area INT,
			@adjustment DECIMAL(18,4)

	/* set up list of events. */
	DROP TABLE IF EXISTS #event_list
	SELECT e.*
	INTO #event_list
	FROM (
		SELECT * FROM OPENJSON(@event_list)
		WITH (
			id_batch INT,
			id_area INT,
			adjustment DECIMAL(18,4)
		)	
	) e

	/* lop through event list and insert events. */
	DECLARE c CURSOR FOR SELECT id_batch, id_area, adjustment FROM #event_list
	OPEN c
	FETCH NEXT FROM c INTO @id_batch, @id_area, @adjustment
	WHILE @@FETCH_STATUS = 0 BEGIN

		/* only create event if all data is present for this row. */
		IF (@id_batch IS NOT NULL AND @id_area IS NOT NULL AND @adjustment IS NOT NULL)
		BEGIN
			EXEC [log].usp_event_create @type_reference, @id_batch, @id_area, @adjustment, @notes, @id_user
		END

		FETCH NEXT FROM c INTO @id_batch, @id_area, @adjustment
	END

	CLOSE c
	DEALLOCATE c
go

