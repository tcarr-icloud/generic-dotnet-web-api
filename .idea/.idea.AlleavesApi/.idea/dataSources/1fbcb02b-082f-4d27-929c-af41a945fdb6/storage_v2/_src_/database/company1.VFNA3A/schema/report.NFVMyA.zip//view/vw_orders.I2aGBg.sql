
----------------------------------------------------------------------------
---Orders-------------------------------------------------------------------
CREATE VIEW [report].[vw_orders]
	AS
	
SELECT
	o.[id_order]
	,o.[created_by] as 'id_created_by'
	,buc.[FirstName] + ' ' + buc.[LastName] as 'created_by'
	,o.[updated_by] as 'id_updated_by'
	,buu.[FirstName] + ' ' + buu.[LastName] as 'updated_by'
	,o.[date_created] as 'UTC_created_datetime'
	,o.[date_updated] as 'UTC_updated_datetime'
	,CASE
		WHEN o.[date_created] IS NOT NULL
		THEN CAST(o.[date_created] AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime)
		ELSE NULL
	END as 'local_created_datetime'
		,CASE
		WHEN o.[date_updated] IS NOT NULL
		THEN CAST(o.[date_updated] AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime)
		ELSE NULL
	END as 'local_updated_datetime'
    ,bl.[name] as 'location'
	,o.[type] as 'order_type'
	,o.[use_type]
	,o.[subtotal]
    ,o.[discount]
    ,o.[delivery_fee]
    ,o.[tax]
    ,o.[total]
    ,o.[paid_in_full]
    ,o.[complete]
    ,o.[void]
    ,o.[void_reason]
    ,o.[void_reason_other]

FROM [order].[order] o
	LEFT OUTER JOIN [base].[user] buu on o.[updated_by] = buu.[id_user]
	LEFT OUTER JOIN [base].[user] buc on o.[created_by] = buc.[id_user]
	LEFT OUTER JOIN  [base].[location] bl on bl.[id_location] = o.[id_location]
	LEFT OUTER JOIN  [dbo].[tz_lookup] tl ON bl.[timezone] = tl.[tz_iana]
go

