CREATE PROCEDURE [cash].[usp_safe_amount_adjust]
	@id_session INT = NULL,
	@adjustment DECIMAL(18,2), 
	@reason VARCHAR(128),
	@reason_type VARCHAR(128) = 'Other',
	@note VARCHAR(MAX) = '',   
	@id_safe INT = NULL,
	@id_user INT,
	@is_closing_deposit BIT = 0,
	@is_vendor_payment BIT = 0,   
	@is_safe_transfer BIT = 0,   
	@is_transfer_from BIT = 0,
	@id_safe_transfer_from INT = NULL,   
	@id_safe_transfer_to INT = NULL,
	@id_vendor INT = NULL,
	@balance_ending DECIMAL(18,2) = NULL,
	@id_register INT = NULL

AS

	DECLARE @previous_amount DECIMAL(18,2) = (SELECT amount FROM [cash].[safe] WHERE id_safe=@id_safe)
	DECLARE @previous_amount_from DECIMAL(18,2) = (SELECT amount FROM [cash].[safe] WHERE id_safe=@id_safe_transfer_from)
	DECLARE @previous_amount_to DECIMAL(18,2) = (SELECT amount FROM [cash].[safe] WHERE id_safe=@id_safe_transfer_to)
	DECLARE @safe_transfer_from VARCHAR(512) = (SELECT [name] FROM [cash].[safe] WHERE id_safe=@id_safe_transfer_from)
	DECLARE @safe_transfer_to VARCHAR(512) = (SELECT [name] FROM [cash].[safe] WHERE id_safe=@id_safe_transfer_to)
	DECLARE @vendor VARCHAR(128) = (SELECT [name] FROM [inventory].[vendor] WHERE id_vendor=@id_vendor)
	DECLARE @id_safe_event INT = NULL


	IF (@reason = 'Deposit' AND @id_session IS NULL AND @reason_type <> 'Manual Register Closeout')
	BEGIN
		INSERT INTO [cash].[safe_event] (adjustment, previous_amount, id_safe, reason, reason_type, note, id_user_created)
		VALUES (@adjustment, @previous_amount, @id_safe, @reason, @reason_type, @note, @id_user)
		
		SET @id_safe_event=SCOPE_IDENTITY()

		UPDATE [cash].[safe]
		SET amount = @previous_amount + @adjustment
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_safe=@id_safe

		EXEC [cash].[usp_safe_amount_adjust_list] @id_safe_event
	END

	IF (@reason = 'Deposit' AND @reason_type ='Manual Register Closeout')
	BEGIN
		SET @id_session = (SELECT TOP 1 id_session FROM [pos].[session] WHERE id_register = @id_register ORDER BY date_start DESC)
		
		EXEC pos.usp_withdrawal @id_session, @adjustment, @reason, @note, @id_safe, @id_user, @id_user, 1  

		UPDATE [pos].[session] 
		SET 
			balance_ending=@balance_ending
			,id_user_end = @id_user
			,date_end = GETUTCDATE()
		WHERE id_session = @id_session

		SET @id_session = NULL
	END

	IF ((@reason = 'Deposit' OR @reason = 'Payout' OR @reason = 'POS Safe') AND @id_session IS NOT NULL)
	BEGIN
		IF (@is_closing_deposit = 1)
		BEGIN
			SET @reason_type='Closing Deposit'
		END
		ELSE
		BEGIN
			SET @reason_type='Other'
		END
		INSERT INTO [cash].[safe_event] (adjustment, previous_amount, id_safe, reason, reason_type, note, id_user_created, is_closing_deposit)
		VALUES (@adjustment, @previous_amount, @id_safe, @reason, @reason_type, @note, @id_user, @is_closing_deposit)
		
		SET @id_safe_event=SCOPE_IDENTITY()
		
		INSERT INTO [cash].[safe_event_session] (id_safe_event, id_session, id_user_created)
		VALUES (@id_safe_event, @id_session, @id_user)

		IF (@reason = 'Deposit')
		BEGIN
			UPDATE [cash].[safe]
			SET amount = @previous_amount + @adjustment
				, id_user_updated=@id_user
				, date_updated=GETUTCDATE()
			WHERE id_safe=@id_safe
		END

		IF (@reason = 'POS Safe')
		BEGIN
			UPDATE [cash].[safe]
			SET amount = @previous_amount - @adjustment
				, id_user_updated=@id_user
				, date_updated=GETUTCDATE()
			WHERE id_safe=@id_safe
		END

		IF (@reason = 'Payout')
		BEGIN
			UPDATE [cash].[safe]
			SET amount = @previous_amount - @adjustment
				, id_user_updated=@id_user
				, date_updated=GETUTCDATE()
			WHERE id_safe=@id_safe
		END

		EXEC [cash].[usp_safe_amount_adjust_list] @id_safe_event
	END

	IF (@reason = 'Payout' AND @reason_type <> 'Vendor Payment' AND @id_session IS NULL)
	BEGIN
		INSERT INTO [cash].[safe_event] (adjustment, previous_amount, id_safe, reason, reason_type, note, id_user_created)
		VALUES (@adjustment, @previous_amount, @id_safe, @reason, @reason_type, @note, @id_user)
		
		SET @id_safe_event=SCOPE_IDENTITY()

		UPDATE [cash].[safe]
		SET amount = @previous_amount - @adjustment
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_safe=@id_safe

		EXEC [cash].[usp_safe_amount_adjust_list] @id_safe_event
	END

	IF (@reason = 'Payout' AND @reason_type='Vendor Payment' AND @id_session IS NULL)
	BEGIN
		SET @reason_type='Payment To ' + @vendor
		SET @is_vendor_payment = 1
		INSERT INTO [cash].[safe_event] (adjustment, previous_amount, id_safe, reason, reason_type, note, id_user_created, is_vendor_payment)
		VALUES (@adjustment, @previous_amount, @id_safe, @reason, @reason_type, @note, @id_user, @is_vendor_payment)
		
		SET @id_safe_event=SCOPE_IDENTITY()
		
		INSERT INTO [cash].[vendor_payment] (id_safe_event, id_vendor, payment_amount, id_user_created)
		VALUES (@id_safe_event, @id_vendor, @adjustment, @id_user) 

		UPDATE [cash].[safe]
		SET amount = @previous_amount - @adjustment
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_safe=@id_safe

		EXEC [cash].[usp_safe_amount_adjust_list] @id_safe_event
	END

	IF (@reason = 'Transfer')
	BEGIN	
		SET @reason_type=@reason + ' To ' + @safe_transfer_to
		SET @is_safe_transfer=1
		INSERT INTO [cash].[safe_event] (adjustment, previous_amount, id_safe, reason, reason_type, note, is_safe_transfer, id_user_created)
		VALUES (@adjustment, @previous_amount_from, @id_safe_transfer_from, @reason, @reason_type, @note, @is_safe_transfer, @id_user) 
			
		SET @id_safe_event=SCOPE_IDENTITY()

		SET @is_transfer_from=1
		INSERT INTO [cash].[safe_transfer] (id_safe_event, id_safe, is_transfer_from, id_user_created)
		VALUES (@id_safe_event, @id_safe_transfer_from, @is_transfer_from, @id_user) 
		
		UPDATE [cash].[safe]
		SET amount = @previous_amount_from - @adjustment
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_safe=@id_safe_transfer_from

		EXEC [cash].[usp_safe_amount_adjust_list] @id_safe_event
		
		SET @reason_type=@reason + ' From ' + @safe_transfer_from
		SET @is_safe_transfer=1
		INSERT INTO [cash].[safe_event] (adjustment, previous_amount, id_safe, reason, reason_type, note, is_safe_transfer, id_user_created)
		VALUES (@adjustment, @previous_amount_to, @id_safe_transfer_to, @reason, @reason_type, @note, @is_safe_transfer, @id_user)
		
		SET @id_safe_event=SCOPE_IDENTITY()

		SET @is_transfer_from=0
		INSERT INTO [cash].[safe_transfer] (id_safe_event, id_safe, is_transfer_from, id_user_created)
		VALUES (@id_safe_event, @id_safe_transfer_to, @is_transfer_from, @id_user) 
		  
		UPDATE [cash].[safe]
		SET amount = @previous_amount_to + @adjustment
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_safe=@id_safe_transfer_to

		EXEC [cash].[usp_safe_amount_adjust_list] @id_safe_event
	END
go

