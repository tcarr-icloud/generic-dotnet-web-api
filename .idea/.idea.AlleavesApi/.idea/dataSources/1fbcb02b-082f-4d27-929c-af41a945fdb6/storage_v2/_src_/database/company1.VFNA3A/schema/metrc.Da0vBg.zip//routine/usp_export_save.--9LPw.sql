CREATE PROCEDURE [metrc].[usp_export_save]
	@id_export INT,
	@id_location_source INT,
	@id_location_destination INT,
	@id_vendor_destination INT,
	@source_use_address_on_file BIT = 1,
	@source_address VARCHAR(512),
	@source_city VARCHAR(512),
	@source_state VARCHAR(512),
	@source_postal_code VARCHAR(512),
	@recipient VARCHAR(512),
	@destination_use_address_on_file VARCHAR(512),
	@destination_address VARCHAR(512),
	@destination_city VARCHAR(512),
	@destination_state VARCHAR(512),
	@destination_postal_code VARCHAR(512),
	@destination_facility_license VARCHAR(512),
	@transfer_type VARCHAR(512),
	@id_driver INT,
	@id_driver_2 INT,
	@id_vehicle INT,
	@phone VARCHAR(32),
	@planned_route VARCHAR(MAX),
	@datetime_depart DATETIME,
	@datetime_arrive DATETIME,
	@tracking_number VARCHAR(128),
	@internal_reference VARCHAR(128),
	@notes VARCHAR(MAX),
	@batch_list VARCHAR(MAX) = '[]',
	@stops VARCHAR(MAX) = '[]',
	@id_user INT,
	@biotrack_barcode_id VARCHAR(512) = NULL,
	@biotrack_barcode_pickup_id VARCHAR(512) = NULL
AS
	DECLARE @source_facility_license VARCHAR(128) = (SELECT COALESCE(metrc_facility_license_number, biotrack_license_number) FROM base.location WHERE id_location = @id_location_source)

	/* create new. */
	IF NOT EXISTS (SELECT * FROM metrc.export WHERE id_export=@id_export)
	BEGIN
		
		INSERT INTO metrc.export (
			id_location_source,
			id_location_destination,
			id_vendor_destination,
			source_use_address_on_file,
			source_address,
			source_city,
			source_state,
			source_postal_code,
			source_facility_license,
			recipient,
			destination_use_address_on_file,
			destination_address,
			destination_city,
			destination_state,
			destination_postal_code,
			destination_facility_license,
			transfer_type,
			id_driver,
			id_driver_2,
			id_vehicle,
			phone,
			planned_route,
			datetime_depart,
			datetime_arrive,
			tracking_number,
			internal_reference,
			notes,
			id_user_created,
			id_user_updated,
			biotrack_barcode_pickup_id,
			biotrack_barcode_id
			)
		VALUES (
			@id_location_source,
			@id_location_destination,
			@id_vendor_destination,
			@source_use_address_on_file,
			@source_address,
			@source_city,
			@source_state,
			@source_postal_code,
			@source_facility_license,
			@recipient,
			@destination_use_address_on_file,
			@destination_address,
			@destination_city,
			@destination_state,
			@destination_postal_code,
			@destination_facility_license,
			@transfer_type,
			@id_driver,
			@id_driver_2,
			@id_vehicle,
			@phone,
			@planned_route,
			@datetime_depart,
			@datetime_arrive,
			@tracking_number,
			@internal_reference,
			@notes,
			@id_user,
			@id_user,
			@biotrack_barcode_pickup_id,
			@biotrack_barcode_id)

		SET @id_export = SCOPE_IDENTITY();

	END
	/* update. */
	ELSE
		UPDATE metrc.export
		SET id_location_source = @id_location_source
			, id_location_destination = @id_location_destination
			, id_vendor_destination = @id_vendor_destination
			, source_use_address_on_file = @source_use_address_on_file
			, source_address = @source_address
			, source_city = @source_city
			, source_state = @source_state
			, source_postal_code = @source_postal_code
			, source_facility_license = @source_facility_license
			, recipient = @recipient
			, destination_use_address_on_file = @destination_use_address_on_file
			, destination_address = @destination_address
			, destination_city = @destination_city
			, destination_state = @destination_state
			, destination_postal_code = @destination_postal_code
			, destination_facility_license = @destination_facility_license
			, transfer_type = @transfer_type
			, id_driver = @id_driver
			, id_driver_2 = @id_driver_2
			, id_vehicle = @id_vehicle
			, phone = @phone
			, planned_route = @planned_route
			, datetime_depart = @datetime_depart
			, datetime_arrive = @datetime_arrive
			, tracking_number = @tracking_number
			, internal_reference = @internal_reference
			, notes = @notes
			, date_updated = GETUTCDATE()
			, id_user_updated = @id_user
		WHERE id_export = @id_export

	IF @biotrack_barcode_id IS NOT NULL OR @biotrack_barcode_pickup_id IS NOT NULL
	BEGIN
		SELECT *
		INTO #stops
		FROM OPENJSON(@stops)
		WITH (
			[stop_number] INT,
			[id_location_source] VARCHAR(528),
			[id_location_destination] VARCHAR(528),
			[id_vendor_destination] VARCHAR(528),
			[source_use_address_on_file] BIT,
			[source_address] VARCHAR(528),
			[source_city] VARCHAR(256),
			[source_state] VARCHAR(256),
			[source_postal_code] VARCHAR(32),
			[source_facility_license] VARCHAR(255),
			[destination_use_address_on_file] BIT,
			[destination_address] VARCHAR(528),
			[destination_city] VARCHAR(256),
			[destination_state] VARCHAR(256),
			[destination_postal_code] VARCHAR(32),
			[destination_facility_license] VARCHAR(255),
			[planned_route] VARCHAR(MAX),
			[datetime_depart] DATETIME,
			[datetime_arrive] DATETIME,
			[recipient] VARCHAR(528),
			[id_invoice] VARCHAR(528)
		)

		DECLARE @stop_number INT, 
				@stop_id_location_source VARCHAR(528), 
				@stop_id_location_destination VARCHAR(528), 
				@stop_id_vendor_destination VARCHAR(528), 
				@stop_source_use_address_on_file BIT, 
				@stop_source_address VARCHAR(528), 
				@stop_source_city VARCHAR(256), 
				@stop_source_state VARCHAR(256), 
				@stop_source_postal_code VARCHAR(32),
				@stop_source_facility_license VARCHAR(255), 
				@stop_destination_use_address_on_file BIT, 
				@stop_destination_address VARCHAR(528), 
				@stop_destination_city VARCHAR(256), 
				@stop_destination_state VARCHAR(256), 
				@stop_destination_postal_code VARCHAR(32),
				@stop_destination_facility_license VARCHAR(255), 
				@stop_planned_route VARCHAR(MAX), 
				@stop_datetime_depart DATETIME, 
				@stop_datetime_arrive DATETIME,
				@stop_recipient VARCHAR(528),
				@stop_id_invoice VARCHAR(528)

		DECLARE add_stops_cursor CURSOR FAST_FORWARD FOR
		SELECT stop_number, 
			   id_location_source, 
			   id_location_destination, 
			   id_vendor_destination, 
			   source_use_address_on_file, 
			   source_address, 
			   source_city, 
			   source_state, 
			   source_postal_code,
			   source_facility_license, 
			   destination_use_address_on_file, 
			   destination_address, 
			   destination_city, 
			   destination_state, 
			   destination_postal_code,
			   destination_facility_license, 
			   planned_route, 
			   datetime_depart, 
			   datetime_arrive,
			   recipient,
			   id_invoice
		FROM #stops

		OPEN add_stops_cursor

		FETCH NEXT FROM add_stops_cursor INTO @stop_number, @stop_id_location_source, @stop_id_location_destination, @stop_id_vendor_destination, @stop_source_use_address_on_file, @stop_source_address, @stop_source_city, @stop_source_state, @stop_source_postal_code,
		@stop_source_facility_license, @stop_destination_use_address_on_file, @stop_destination_address, @stop_destination_city, @stop_destination_state, @stop_destination_postal_code,
		@stop_destination_facility_license, @stop_planned_route, @stop_datetime_depart, @stop_datetime_arrive, @stop_recipient, @stop_id_invoice

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			IF NOT EXISTS (SELECT * FROM metrc.stops WHERE id_export = @id_export AND stop_number = @stop_number)
			BEGIN
				INSERT INTO metrc.stops (id_export, stop_number, id_location_source, id_location_destination, id_vendor_destination, source_use_address_on_file, source_address, source_city, source_state, source_postal_code,
				source_facility_license, destination_use_address_on_file, destination_address, destination_city, destination_state, destination_postal_code,
				destination_facility_license, planned_route, datetime_depart, datetime_arrive, recipient, id_invoice)
				VALUES(@id_export, @stop_number, @stop_id_location_source, @stop_id_location_destination, @stop_id_vendor_destination, @stop_source_use_address_on_file, @stop_source_address, @stop_source_city, @stop_source_state, @stop_source_postal_code,
				@stop_source_facility_license, @stop_destination_use_address_on_file, @stop_destination_address, @stop_destination_city, @stop_destination_state, @stop_destination_postal_code,
				@stop_destination_facility_license, @stop_planned_route, @stop_datetime_depart, @stop_datetime_arrive, @stop_recipient, @stop_id_invoice)
			END
			FETCH NEXT FROM add_stops_cursor INTO @stop_number, @stop_id_location_source, @stop_id_location_destination, @stop_id_vendor_destination, @stop_source_use_address_on_file, @stop_source_address, @stop_source_city, @stop_source_state, @stop_source_postal_code,
			@stop_source_facility_license, @stop_destination_use_address_on_file, @stop_destination_address, @stop_destination_city, @stop_destination_state, @stop_destination_postal_code,
			@stop_destination_facility_license, @stop_planned_route, @stop_datetime_depart, @stop_datetime_arrive, @stop_recipient, @stop_id_invoice
		END

		CLOSE add_stops_cursor
		DEALLOCATE add_stops_cursor
		END

	/* remove deleted stops from manifest. *******************************************************************/
	IF @biotrack_barcode_id IS NOT NULL OR @biotrack_barcode_pickup_id IS NOT NULL
	BEGIN
		DECLARE remove_stop_cursor CURSOR FAST_FORWARD FOR 
		SELECT stop_number FROM metrc.stops
		WHERE id_export=@id_export AND stop_number NOT IN (SELECT stop_number FROM #stops)

		OPEN remove_stop_cursor
		FETCH NEXT FROM remove_stop_cursor INTO @stop_number
		
		WHILE(@@FETCH_STATUS = 0)
		BEGIN
			/* remove inventory from export manifest. */
			DELETE FROM metrc.stops
			WHERE id_export = @id_export AND stop_number = @stop_number
		
			FETCH NEXT FROM remove_stop_cursor INTO @stop_number
		END

		CLOSE remove_stop_cursor
		DEALLOCATE remove_stop_cursor
	END

	/* prepare list of batches. */
	SELECT *
	INTO #batch_list
	FROM OPENJSON(@batch_list)
	WITH (
		id_batch INT,
		[stop] INT,
		price DECIMAL
	)

	DECLARE @id_batch INT,
			@batch_stop_number INT,
			@price DECIMAL,
			@event_list VARCHAR(MAX),
			@event_notes VARCHAR(128) = CONCAT('Metrc ExportID: ', @id_export)

	/* insert new batches into manifest. ************************************************************************/
	DECLARE add_cursor CURSOR FAST_FORWARD FOR 
	SELECT id_batch, [stop], price FROM #batch_list
		
	OPEN add_cursor
	FETCH NEXT FROM add_cursor INTO @id_batch, @batch_stop_number, @price
		
	WHILE(@@FETCH_STATUS = 0)
	BEGIN

		IF NOT EXISTS (SELECT * FROM metrc.export_item WHERE id_export = @id_export AND id_batch = @id_batch)
		BEGIN
			/* insert inventory into export manifest. */
			INSERT INTO metrc.export_item (id_export, id_batch, id_area, [stop], price, quantity)
			SELECT @id_export AS id_export
					, id_batch
					, inv.id_area
					, @batch_stop_number AS [stop]
					, @price
					, quantity
			FROM inventory.inventory inv
			JOIN inventory.area a ON a.id_area=inv.id_area AND a.id_location=@id_location_source
			WHERE id_batch = @id_batch AND quantity > 0

			/* remove quantities from Alleaves inventory */
			SET @event_list = (
				SELECT id_batch, id_area, -quantity AS adjustment
				FROM metrc.export_item 
				WHERE id_export=@id_export AND id_batch=@id_batch 
				FOR JSON PATH
			)
			EXEC [log].usp_event_create_bulk 'transfer_manifest_add', @event_notes, @event_list, @id_user
		END
		
		FETCH NEXT FROM add_cursor INTO @id_batch, @batch_stop_number, @price
	END

	CLOSE add_cursor
	DEALLOCATE add_cursor


	/* remove deleted batches from manifest. *******************************************************************/
	DECLARE remove_cursor CURSOR FAST_FORWARD FOR 
	SELECT id_batch FROM metrc.export_item 
	WHERE id_export=@id_export AND id_batch NOT IN (SELECT id_batch FROM #batch_list)
		
	OPEN remove_cursor
	FETCH NEXT FROM remove_cursor INTO @id_batch
		
	WHILE(@@FETCH_STATUS = 0)
	BEGIN
		/* replace quantities into Alleaves inventory */
		SET @event_list = (
			SELECT id_batch, id_area, quantity AS adjustment
			FROM metrc.export_item 
			WHERE id_export=@id_export AND id_batch=@id_batch 
			FOR JSON PATH
		)
		EXEC [log].usp_event_create_bulk 'transfer_manifest_remove', @event_notes, @event_list, @id_user

		/* remove inventory from export manifest. */
		DELETE FROM metrc.export_item
		WHERE id_export = @id_export AND id_batch = @id_batch
		
		FETCH NEXT FROM remove_cursor INTO @id_batch
	END

	CLOSE remove_cursor
	DEALLOCATE remove_cursor


	/* return updated export object. */
	EXEC metrc.usp_export_fetch @id_export
go

