CREATE PROCEDURE [grow].[usp_strain_list]
	@id_strain INT = NULL,
	@id_location INT = NULL,
	@deleted BIT = 0
AS
	SELECT s.id_strain
			, s.id_strain_type
			, (SELECT sm.id_strain_mood, sm.[name] as strain_mood FROM [grow].strain_mood sm INNER JOIN [grow].strain_mood_assoc sma on sm.id_strain_mood = sma.id_strain_mood WHERE id_strain = s.id_strain FOR JSON PATH) as mood_list
			, s.name AS strain
			, st.name AS strain_type
			, s.lineage
			, s.percent_thc
			, s.percent_cbd
			, s.percent_indica
			, s.percent_sativa
			, s.days_seedling
			, s.days_germination
			, s.days_vegetative
			, s.days_preflower
			, s.days_flower
			, sl.metrc_id
			, ISNULL((SELECT sl.id_strain
							, sl.id_location
							, l.name AS location
							, sl.metrc_id
							, sl.metrc_name
					  FROM grow.strain_location sl
					  JOIN base.location l ON l.id_location=sl.id_location
					  WHERE sl.id_strain=s.id_strain
					  FOR JSON PATH
			), '[]') AS location_list
			, ISNULL((SELECT n.id_strain_note
							, n.id_strain
							, n.topic
							, n.note
							, n.date_created
							, n.date_updated
							, CONCAT(uc.FirstName, ' ', uc.LastName) AS created_by
							, CONCAT(uu.FirstName, ' ', uu.LastName) AS updated_by
				      FROM grow.strain_note n
					  JOIN base.[user] uc ON uc.id_user=n.created_by
					  JOIN base.[user] uu ON uu.id_user=n.updated_by
					  WHERE n.id_strain=s.id_strain AND n.deleted=0
					  ORDER BY n.date_created DESC
					  FOR JSON PATH
			), '[]') AS note_list
			, CAST((CASE WHEN pa.id_strain IS NOT NULL OR ia.id_strain IS NOT NULL THEN 1 ELSE 0 END) AS BIT) AS active
	FROM grow.strain s
	JOIN grow.strain_type st ON st.id_strain_type=s.id_strain_type	
	LEFT JOIN grow.strain_location sl ON sl.id_strain=s.id_strain AND sl.id_location=@id_location
	LEFT JOIN (
		SELECT DISTINCT id_strain
		FROM grow.plant
		WHERE harvested=0 AND destroyed=0
	) pa ON pa.id_strain = s.id_strain
	LEFT JOIN (
		SELECT DISTINCT ig.id_strain
		FROM inventory.vw_current_inventory inv
		JOIN inventory.item i ON inv.id_item=i.id_item
		JOIN inventory.item_group ig ON ig.id_item_group=i.id_item_group
		WHERE inv.on_hand>0 AND ig.id_strain IS NOT NULL
	) ia ON ia.id_strain = s.id_strain
	WHERE s.id_strain=ISNULL(@id_strain, s.id_strain) AND
		  s.deleted<=@deleted
	ORDER BY s.name
go

