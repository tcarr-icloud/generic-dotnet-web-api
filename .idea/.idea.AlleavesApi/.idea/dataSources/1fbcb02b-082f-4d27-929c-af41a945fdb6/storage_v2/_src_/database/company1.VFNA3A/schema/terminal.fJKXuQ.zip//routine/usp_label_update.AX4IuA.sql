CREATE PROCEDURE terminal.usp_label_update
        @id_label INT,
		@name VARCHAR(256),
	    @path VARCHAR(256),
		@category VARCHAR(256),
	    @id_user INT
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE terminal.label 
	SET 
		[name] = ISNULL(@name, [name]),
		[path] = ISNULL(@path, [path]), 
		[category] = @category,
		id_user_modified_by = @id_user 
	WHERE id_label = @id_label
    EXEC terminal.usp_label_list @id_label
END
go

