CREATE PROCEDURE [inventory].[usp_batch_save_metrc_fields]
	@id_batch INT,
	@metrc_package_label VARCHAR(255),
	@metrc_item_id INT,
	@metrc_state VARCHAR(16),
	@metrc_uom VARCHAR(64)
AS
	DECLARE @id_uom INT = (SELECT TOP 1 id_uom FROM inventory.uom WHERE name=@metrc_uom)

	UPDATE inventory.batch
	SET metrc_package_label=@metrc_package_label
		, metrc_item_id=@metrc_item_id
		, metrc_state=@metrc_state
		, id_uom_metrc=@id_uom
	WHERE id_batch=@id_batch
go

