

CREATE VIEW [grow].[vw_harvest_tracker] as
SELECT l.name AS location
		, h.date_harvest
		, s.name AS strain
		, h.harvest_batch
		, a.path AS area
		, a.canopy_sqft
		, p.num_plants
		, h.net_weight_wet_packaged_g
		, h.net_weight_to_be_dried_g
		, h.net_weight_to_be_dried_g * 0.00220462 AS net_weight_to_be_dried_lb
		, h.weight_after_drying_g
		, h.weight_after_drying_g * 0.00220462 AS weight_after_drying_lb
		, waste_g
		, waste_g * 0.00220462 AS waste_lb
		, CASE WHEN weight_after_drying_g > 0 THEN waste_g / weight_after_drying_g ELSE NULL END AS waste_percent 
		, CASE WHEN net_weight_to_be_dried_g > 0 THEN weight_after_drying_g / net_weight_to_be_dried_g ELSE NULL END AS wet_dry_ratio
		, NULL AS thc_percent
		, (weight_after_drying_g - waste_g) * 0.00220462 AS usable_dried_biomass_lb
		, (h.net_weight_wet_packaged_g * 0.2) + (h.weight_after_drying_g * 0.85) AS ttl_harvest_converted_g
		, ((h.net_weight_wet_packaged_g * 0.2) + (h.weight_after_drying_g * 0.85)) / a.canopy_sqft AS usable_g_sq_ft
FROM (
	SELECT h.id_harvest
			, h.id_location
			, h.date_harvest
			, h.name AS harvest_batch
			, h.id_strain
			, h.id_area_dry
			, (h.weight_wet_g - o.weight_wet_package - o.weight_waste_package) AS net_weight_to_be_dried_g
			, o.weight_wet_package + o.weight_waste_package AS net_weight_wet_packaged_g
			, h.weight_dry_g + h.weight_dry_waste_g AS weight_after_drying_g
			, h.weight_dry_waste_g AS waste_g
	FROM grow.harvest h
	JOIN (
		SELECT id_harvest
				, SUM(CASE WHEN is_wet=1 THEN quantity ELSE 0 END) AS weight_wet_package
				, SUM(CASE WHEN is_waste=1 THEN quantity ELSE 0 END) AS weight_waste_package
				, SUM(CASE WHEN is_dry=1 THEN quantity ELSE 0 END) AS weight_dry_package
		FROM grow.harvest_item
		GROUP BY id_harvest
	) o ON o.id_harvest=h.id_harvest
	WHERE h.finished=1
) h
JOIN (
	SELECT id_harvest, COUNT(*) AS num_plants
	FROM grow.plant
	WHERE harvested=1
	GROUP BY id_harvest
) p ON p.id_harvest=h.id_harvest
JOIN grow.strain s ON s.id_strain=h.id_strain
JOIN inventory.vw_area_list a ON a.id_area=h.id_area_dry
JOIN base.location l ON l.id_location=h.id_location
go

