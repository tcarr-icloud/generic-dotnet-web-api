CREATE PROCEDURE discount.[usp_global_stack_settings_update]
    @stacking BIT = NULL,
    @product VARCHAR(250)=NULL,
    @cart VARCHAR(250)=NULL
AS
	IF EXISTS (SELECT TOP 1 * FROM discount.global_stack_settings)
    UPDATE discount.global_stack_settings SET stacking = isnull(@stacking,stacking),
                                              product= isnull(@product, product),
                                              cart = isnull(@cart, cart)
	ELSE 
	INSERT discount.global_stack_settings (stacking, product, cart)
	VALUES (@stacking, @product, @cart)
go

