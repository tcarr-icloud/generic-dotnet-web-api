CREATE PROCEDURE [base].usp_user_profile_image
	@id_user INT,
	@profile_img VARCHAR(256)
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE base.[user] SET profile_img = @profile_img
	WHERE id_user = @id_user
	EXEC base.usp_user_list @id_user=@id_user
END
go

