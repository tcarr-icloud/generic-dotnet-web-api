CREATE PROCEDURE [dbo].[usp_user_lookup_add]
	@email VARCHAR(MAX),
	@id_company INT
AS
	/* check to see if user already exists for any company. */
	IF EXISTS (SELECT * FROM dbo.user_lookup u JOIN dbo.company c ON c.id_company=u.id_company WHERE u.active=1 AND c.active=1 AND LOWER(u.email)=LOWER(@email))
	BEGIN
		RAISERROR(N'This email is already in use. Please try again or use another email address.', 10, 1);
		RETURN
	END

	/* add new user or reactivate existing user. */
	MERGE dbo.user_lookup t
	USING (
		SELECT @email AS email, @id_company AS id_company
	) s
	ON LOWER(t.email)=LOWER(s.email) AND t.id_company=s.id_company
	WHEN MATCHED THEN
		UPDATE SET t.active=1, t.date_updated=GETUTCDATE()
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (email, id_company) VALUES (s.email, s.id_company)
	;
go

