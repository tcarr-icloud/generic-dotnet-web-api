CREATE PROCEDURE [grow].[usp_raw_material_config_delete]
	@id_raw_material_config INT,
	@id_user INT
AS
	UPDATE grow.raw_material_config
	SET deleted=1
		, date_updated=GETUTCDATE()
		, id_user_updated=@id_user
	WHERE id_raw_material_config=@id_raw_material_config
go

