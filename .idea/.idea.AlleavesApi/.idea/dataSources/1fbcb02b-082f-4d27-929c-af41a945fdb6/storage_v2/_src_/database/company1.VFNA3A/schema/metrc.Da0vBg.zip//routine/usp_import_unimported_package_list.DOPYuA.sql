CREATE PROCEDURE [metrc].[usp_import_unimported_package_list]
	@id_location INT = NULL,
	@package_list VARCHAR(MAX) = NULL,
	@manifest_list VARCHAR(MAX) = NULL,
	@include_imported BIT = 0,
	@start_row INT = 0,
	@end_row INT = 100,
	@filter_clause VARCHAR(max) = NULL
AS
	SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
		SELECT p.id_location
				, p.package
				, p.manifest_number
				, p.transfer_quantity
				, p.transfer_cost
				, m.package_count AS transfer_package_count
				, m.shipper
				, m.shipper_facility
				, m.date_received
		FROM metrc.crawler_package p
		LEFT JOIN metrc.crawler_manifest m ON m.manifest_number=p.manifest_number
		LEFT JOIN (
			SELECT DISTINCT b.metrc_package_label
					, a.id_location
			FROM inventory.batch b
			JOIN inventory.inventory inv ON inv.id_batch=b.id_batch
			JOIN inventory.area a ON a.id_area=inv.id_area
			WHERE b.metrc_package_label IS NOT NULL AND inv.quantity > 0
		) b ON b.metrc_package_label=p.package AND b.id_location=p.id_location
		WHERE b.metrc_package_label IS NULL AND imported=' + CAST(ISNULL(@include_imported, 0) AS VARCHAR(1)) + ' AND is_open=1
	) package'

	SET @where = 'WHERE id_location = '+ ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location')
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)
	IF (@package_list IS NOT NULL)
		SET @where = @where + ' AND package IN ' + @package_list
	IF (@manifest_list IS NOT NULL)
		SET @where = @where + ' AND manifest_number IN ' + @manifest_list

	SET @order = 'ORDER BY package'
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

