
CREATE VIEW [log].[vw_event_list]
	AS 
SELECT e.id_event
		, e.id_type
		, i.id_item
		, e.id_batch
		, e.id_area
		, e.id_user_created
		, t.reference AS event
		, e.original_quantity
		, e.adjustment
		, e.original_quantity + e.adjustment AS new_quantity
		, eu.name AS uom
		, i.item
		, e.item AS item_historical
		, e.category AS category_historical
		, b.name AS batch
		, base.fn_barcode_human_readable(b.name) AS batch_split
		, l.name AS location
		, a.name AS area
		, a.path AS area_path
		, CONCAT(u.FirstName, ' ', u.LastName) AS user_created
		, e.date_created
		,CAST(e.date_created AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as local_datetime_created
		, e.notes
		, t.description
FROM (
	SELECT * FROM [log].event
	UNION ALL
	SELECT * FROM [log].[event_archive]
)e
LEFT JOIN [log].type t ON t.id_type=e.id_type
LEFT JOIN base.[user] u ON u.id_user=e.id_user_created
LEFT JOIN inventory.vw_area_list a ON a.id_area=e.id_area
LEFT JOIN inventory.batch b ON b.id_batch=e.id_batch
LEFT JOIN inventory.vw_item_list i ON i.id_item=b.id_item
LEFT JOIN inventory.uom eu ON eu.id_uom=e.id_uom
LEFT JOIN base.location l ON l.id_location=a.id_location
LEFT OUTER JOIN [dbo].[tz_lookup] as tl ON l.[timezone] = tl.[tz_iana]
go

