CREATE PROCEDURE [order].[usp_delivery_route_upsert]
	@id_delivery_route INT,
	@id_driver INT = null
AS
    IF @id_driver is not null
        BEGIN
	        UPDATE [order].[delivery_route]
	        SET id_driver=@id_driver
	        WHERE id_delivery_route=@id_delivery_route	        
            UPDATE [order].ecommerce_ride SET id_driver = @id_driver
            WHERE id_ride IN (SELECT rdr.id_ride FROM [order].delivery_route dr
	        LEFT JOIN [order].ride_delivery_route rdr
	        ON dr.id_delivery_route = rdr.id_delivery_route
            WHERE dr.id_delivery_route=@id_delivery_route)
			IF EXISTS(select id_ride_transfer_delivery_route from [order].ride_transfer_delivery_route where id_delivery_route=@id_delivery_route)
			BEGIN
			UPDATE [inventory].[transfer] set id_driver1=@id_driver
			WHERE id_transfer IN(SELECT tdr.id_transfer FROM [order].delivery_route dr
	        LEFT JOIN [order].ride_transfer_delivery_route tdr
	        ON dr.id_delivery_route = tdr.id_delivery_route
            WHERE dr.id_delivery_route=@id_delivery_route)
			END
        END
	else
	 BEGIN
	        UPDATE [order].[delivery_route]
	        SET id_driver=null
	        WHERE id_delivery_route=@id_delivery_route
	        
            UPDATE [order].ecommerce_ride SET id_driver = null
            WHERE id_ride IN (SELECT rdr.id_ride FROM [order].delivery_route dr
	        LEFT JOIN [order].ride_delivery_route rdr
	        ON dr.id_delivery_route = rdr.id_delivery_route
            WHERE dr.id_delivery_route=@id_delivery_route)
			IF EXISTS(select id_ride_transfer_delivery_route from [order].ride_transfer_delivery_route where id_delivery_route=@id_delivery_route)
			BEGIN
			UPDATE [inventory].[transfer] set id_driver1=null
			WHERE id_transfer IN(SELECT tdr.id_transfer FROM [order].delivery_route dr
	        LEFT JOIN [order].ride_transfer_delivery_route tdr
	        ON dr.id_delivery_route = tdr.id_delivery_route
            WHERE dr.id_delivery_route=@id_delivery_route)
			END
        END
	EXEC [order].usp_delivery_route_list @id_delivery_route
go

