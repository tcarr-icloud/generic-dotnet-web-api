CREATE PROCEDURE [order].usp_get_metrc_delivery
@id_order int = null
AS 
BEGIN 
	SELECT * FROM [order].[delivery_metrc] where id_order =@id_order 
END
go

