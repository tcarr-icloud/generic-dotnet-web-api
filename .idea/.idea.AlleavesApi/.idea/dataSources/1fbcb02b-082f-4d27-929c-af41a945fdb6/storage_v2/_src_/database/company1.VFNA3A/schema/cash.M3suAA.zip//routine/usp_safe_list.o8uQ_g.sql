CREATE PROCEDURE [cash].[usp_safe_list]
	@id_location INT = NULL,
	@id_safe INT = NULL,
	@deleted BIT = 0,
	@allow_amount_update BIT = 0

AS 

	SELECT id_safe
	, id_location
	, [name] AS 'safe'
	, amount  
	, deleted
	, allow_amount_update
	FROM [cash].[safe] 
	WHERE id_location=ISNULL(@id_location, id_location) AND 
		id_safe=ISNULL(@id_safe, id_safe) AND deleted<=@deleted
go

