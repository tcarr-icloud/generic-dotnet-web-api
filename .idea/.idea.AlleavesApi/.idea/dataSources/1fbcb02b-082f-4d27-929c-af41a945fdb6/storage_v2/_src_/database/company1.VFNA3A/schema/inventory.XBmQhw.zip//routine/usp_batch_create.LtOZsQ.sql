CREATE PROCEDURE [inventory].[usp_batch_create]
	@id_item INT,
	@id_strain INT = NULL,
	@actual_weight_useable_g DECIMAL(18,4) = NULL,
	@id_location INT = NULL,
	@initial_quantity DECIMAL(18,4) = NULL,
	@cost DECIMAL(18,2) = NULL,
	@batch_label VARCHAR(128) = NULL,
	@cost_of_good_price DECIMAL(18,8) = NULL,
	@biotrack_barcode_id VARCHAR(256) = NULL,
	@biotrack_inventory_type_id INT = NULL,
	@date_use_by DATE = NULL,
    @date_expire DATE = NULL,
	@created_by INT = -1
AS
	SET NOCOUNT ON;

	DECLARE @id_batch INT,
			@cost_of_good DECIMAL(18,8) = CASE WHEN @cost IS NOT NULL AND @initial_quantity IS NOT NULL THEN @cost / @initial_quantity ELSE NULL END

	IF (@cost_of_good_price IS NOT NULL)
	BEGIN
		SET @cost_of_good = @cost_of_good_price
	END

	/* if no batch is required, find or create NULL batch. */
	IF((SELECT batch_required FROM inventory.vw_item_list WHERE id_item=@id_item) = 0)
	BEGIN
		SET @id_batch = (SELECT id_batch FROM inventory.batch WHERE id_item=@id_item AND name IS NULL)
		IF(@id_batch IS NULL)
		BEGIN
			INSERT INTO inventory.batch (id_item, name, created_by, updated_by, biotrack_barcode_id, biotrack_inventory_type_id) VALUES (@id_item, NULL, @created_by, @created_by, @biotrack_barcode_id, @biotrack_inventory_type_id)
			SET @id_batch=SCOPE_IDENTITY()
		END
	END
	/* otherwise create new batch. */
	ELSE
	BEGIN
		IF (@batch_label IS NULL)
		BEGIN
			SET @batch_label = inventory.fn_generate_batch_num(@id_item, @id_location)
		END

		SET @id_batch = (SELECT TOP 1 id_batch FROM inventory.batch WHERE name=@batch_label)
		IF (@id_batch IS NULL)
		BEGIN
			INSERT INTO inventory.batch (id_item, name, id_strain, date_production, actual_weight_useable_g, initial_quantity, cost_of_good, biotrack_barcode_id, biotrack_inventory_type_id, created_by, updated_by, date_use_by, date_expire) VALUES 
				(@id_item, @batch_label, @id_strain, CAST(dbo.fn_utc_to_local(getutcdate(), @id_location) AS DATE), @actual_weight_useable_g, @initial_quantity, @cost_of_good, @biotrack_barcode_id, @biotrack_inventory_type_id, @created_by, @created_by, @date_use_by, @date_expire)

			SET @id_batch=SCOPE_IDENTITY()
		END
		ELSE
		BEGIN
			DECLARE @msg VARCHAR(MAX) = 'Batch name must be unique.'
			RAISERROR(@msg, 11, 1)
		END
	END
	
	/* return batch id. */
	RETURN @id_batch
go

