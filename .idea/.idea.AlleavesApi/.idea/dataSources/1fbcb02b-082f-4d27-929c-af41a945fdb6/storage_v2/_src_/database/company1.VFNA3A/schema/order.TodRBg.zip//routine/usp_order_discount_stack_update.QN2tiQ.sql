CREATE PROCEDURE [order].[usp_order_discount_stack_update]
    @id_order INT,
    @discount_stack_order varchar(max) = null
AS
    UPDATE [order].[order] SET discount_stack_order = isnull(@discount_stack_order,discount_stack_order)
    WHERE [order].id_order = @id_order
go

