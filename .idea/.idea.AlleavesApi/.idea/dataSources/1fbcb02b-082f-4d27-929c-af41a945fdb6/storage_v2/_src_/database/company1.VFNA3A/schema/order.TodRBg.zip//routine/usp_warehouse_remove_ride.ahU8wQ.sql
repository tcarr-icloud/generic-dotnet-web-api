CREATE PROCEDURE [order].[usp_warehouse_remove_ride]
	                    @id_warehouse INT,
	                    @id_ride INT
    AS
    BEGIN
	    DELETE [order].ride_warehouse
       		WHERE id_warehouse =@id_warehouse
       		AND id_ride = @id_ride
       
--        INSERT INTO [order].ride_warehouse (id_ride, id_warehouse) VALUES (@id_ride, @id_warehouse)
     END
go

