CREATE PROCEDURE [inventory].[usp_batch_list]
	@id_location INT = NULL,
	@id_item INT = NULL,
	@id_batch INT = NULL,
	@id_export INT = NULL,
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
	SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
		SELECT b.id_batch
				, i.id_item
				, i.id_item_group
				, b.id_status
				, RTRIM(CONCAT(ig.name, '' '', (
							SELECT STRING_AGG(av.name, '' '') 
							FROM inventory.item_attribute_value iav
							LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
							WHERE iav.id_item=i.id_item)
						)) AS item
				, b.name AS batch				
				, b.harvest_batch
				, ''api/inventory/batch/methodlabs/'' + b.harvest_batch as methodlabs_coa
				, b.vendor_batch_id
				, u.name AS uom
				, u.name_short AS uom_short
				, st.name AS status
				, b.qc_hold
				, t.coa_s3_key
				, ISNULL(CAST((SELECT TOP 1 trcp.[value]
					FROM inventory.test_result_chemical_profile trcp
					LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
					WHERE icp.id_chemical_profile=2 AND trcp.id_test_result=t.id_test_result) AS DECIMAL(18, 3)), NULL) as thc
				, ISNULL(CAST((SELECT TOP 1 trcp.[value]
					FROM inventory.test_result_chemical_profile trcp
					LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
					WHERE icp.id_chemical_profile=1 AND trcp.id_test_result=t.id_test_result) AS DECIMAL(18, 3)), NULL) as cbd
				, ISNULL(CAST((SELECT TOP 1 trcp.[value]
					FROM inventory.test_result_chemical_profile trcp
					LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
					WHERE icp.id_chemical_profile = 60 AND trcp.id_test_result=t.id_test_result) AS DECIMAL(18,3)), NULL) as thc_mg
				, ISNULL(CAST((SELECT TOP 1 trcp.[value]
					FROM inventory.test_result_chemical_profile trcp
					LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
					WHERE icp.id_chemical_profile = 61 AND trcp.id_test_result=t.id_test_result) AS DECIMAL(18,3)), NULL) as cbd_mg
				, b.extraction_method
				, b.solvent_type
				, b.activation_time
				, CAST(CASE WHEN ISNULL(inv.quantity, 0) = 0 THEN 0 ELSE 1 END AS BIT) AS has_inventory
				, ISNULL(b.cost_of_good, i.cost_of_good) AS cost_of_good
				, inv.quantity AS available
				, inv.num_areas
				, b.metrc_package_label
				, b.metrc_item_id
				, b.metrc_state
				, b.biotrack_barcode_id
				, b.biotrack_inventory_type_id
				, b.biotrack_scheduled_destroyed
				, b.biotrack_destroyed
				, ig.id_location
		FROM inventory.batch b
		JOIN inventory.item i ON i.id_item=b.id_item
		JOIN inventory.item_group ig ON ig.id_item_group=i.id_item_group
		JOIN inventory.status st ON st.id_status=b.id_status
		JOIN inventory.uom u ON u.id_uom=ig.id_uom
		LEFT JOIN inventory.test_result t ON t.id_batch=b.id_batch
		LEFT JOIN (
			SELECT inv.id_batch
					, SUM(inv.quantity) AS quantity
					, COUNT(CASE WHEN inv.quantity > 0 THEN 1 END) AS num_areas
			FROM inventory.inventory inv
			JOIN inventory.area a ON a.id_area=inv.id_area AND a.id_location = ' + ISNULL(CAST(@id_location AS VARCHAR(16)), 'a.id_location') + '
			GROUP BY inv.id_batch, a.id_location
		) inv ON inv.id_batch=b.id_batch
	) inventory'

	SET @where = 'WHERE id_item = '+ ISNULL(CAST(@id_item AS VARCHAR(16)), 'id_item')
	SET @where = @where + ' AND id_batch = '+ ISNULL(CAST(@id_batch AS VARCHAR(16)), 'id_batch')	
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'item, batch')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

