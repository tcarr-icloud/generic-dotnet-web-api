
CREATE VIEW [pos].[vw_withdrawals]
  
AS

SELECT s.id_session
    , l.name AS 'location'
	, l.id_location
	, s.id_register AS 'terminal_number'
	, r.name AS 'terminal_name'
	, s.id_user_end
	, (ue.FirstName + ' ' + ue.LastName) AS 'user_closing'
	, w.amount
	, CASE WHEN w.reason = 'Deposit' THEN w.amount END AS 'deposit_amount'
	, CASE WHEN w.reason = 'Withdrawal' OR w.reason = 'Payout' THEN w.amount END AS 'withdrawal_amount'
	, w.date_created as 'date'
	, w.reason
	, w.notes
	, w.id_safe
	,sf.[name] AS 'safe_name'
	, w.id_withdrawal
FROM [pos].[withdrawal] w
INNER JOIN [pos].session s ON w.id_session=s.id_session
JOIN [pos].register r ON r.id_register=s.id_register
JOIN [base].[location] l ON l.id_location=r.id_location
JOIN [base].[user] ue ON ue.id_user=s.id_user_end
LEFT JOIN [cash].[safe] sf ON sf.id_safe=w.id_safe AND sf.deleted <= 0
go

