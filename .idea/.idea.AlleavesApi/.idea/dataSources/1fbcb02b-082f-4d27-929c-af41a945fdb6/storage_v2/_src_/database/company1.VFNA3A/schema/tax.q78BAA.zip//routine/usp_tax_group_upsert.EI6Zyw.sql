CREATE PROCEDURE [tax].[usp_tax_group_upsert]
	@id_tax_group INT,
	@name VARCHAR(256),
    @active BIT,
	@id_user INT,
	@tax_list VARCHAR(MAX) = '[]',
	@tax_location_list VARCHAR(MAX) = '[]',
	@tax_category_list VARCHAR(MAX) = '[]'
AS

	UPDATE [tax].[group]
    SET [name] = @name,
        active = @active,
        updated_by = @id_user,
        date_updated = getutcdate()
    WHERE id_tax_group = @id_tax_group

	-- INSERT VALUES INTO THE GROUP_VALUE TABLE FOR ANY SELECTED VALUES HERE.
	;WITH tax_list AS (
		SELECT @id_tax_group AS id_tax_group
			, id_tax
		FROM OPENJSON(@tax_list)
		WITH (
			  id_tax INT
		)
	)
	MERGE [tax].[group_value] AS tgv
	USING tax_list AS taxl
	ON taxl.id_tax_group = tgv.id_tax_group AND taxl.id_tax = tgv.id_tax
	WHEN MATCHED THEN
	UPDATE SET tgv.updated_by=@id_user, tgv.date_updated=getutcdate(), tgv.active=@active
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_tax, id_tax_group, active, created_by, updated_by) VALUES(taxl.id_tax, taxl.id_tax_group, @active, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND tgv.id_tax_group = @id_tax_group THEN
	UPDATE SET tgv.active=0, tgv.updated_by=@id_user, tgv.date_updated=getutcdate()
	;

	-- INSERT VALUES INTO THE LOCATION_GROUP TABLE FOR ANY SELECTED VALUES HERE.
	;WITH tax_location_list AS (
		SELECT @id_tax_group AS id_tax_group
			, id_location
		FROM OPENJSON(@tax_location_list)
		WITH (
			  id_location INT
		)
	)
	MERGE [tax].[location_group] AS tlg
	USING tax_location_list AS ltaxl
	ON ltaxl.id_tax_group = tlg.id_tax_group AND ltaxl.id_location = tlg.id_location
	WHEN MATCHED THEN
	UPDATE SET tlg.updated_by=@id_user, tlg.date_updated=getutcdate(), tlg.active=@active
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_location, id_tax_group, active, created_by, updated_by) VALUES(ltaxl.id_location, ltaxl.id_tax_group, @active, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND tlg.id_tax_group = @id_tax_group THEN
	UPDATE SET tlg.active=0, tlg.updated_by=@id_user, tlg.date_updated=getutcdate()
	;

	-- INSERT VALUES INTO THE CATEGORY_GROUP TABLE FOR ANY SELECTED VALUES HERE.
	;WITH tax_category_list AS (
		SELECT @id_tax_group AS id_tax_group
			, id_tax_category
		FROM OPENJSON(@tax_category_list)
		WITH (
			  id_tax_category INT
		)
	)
	MERGE [tax].[category_group] AS tcg
	USING tax_category_list AS ctaxl
	ON ctaxl.id_tax_group = tcg.id_tax_group AND ctaxl.id_tax_category = tcg.id_tax_category
	WHEN MATCHED THEN
	UPDATE SET tcg.updated_by=@id_user, tcg.date_updated=getutcdate(), tcg.active=@active
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_tax_category, id_tax_group, active, created_by, updated_by) VALUES(ctaxl.id_tax_category, ctaxl.id_tax_group, @active, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND tcg.id_tax_group = @id_tax_group THEN
	UPDATE SET tcg.active=0, tcg.updated_by=@id_user, tcg.date_updated=getutcdate()
	;

	EXEC [tax].[usp_get_tax_group_list] @id_tax_group
go

