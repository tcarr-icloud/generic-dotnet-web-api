CREATE PROCEDURE [dbo].[daily_account]
AS
	SET NOCOUNT ON;

SELECT t.[name] AS Category, t.loc_name AS [Location], SUM(t.Cash) AS Cash, SUM(t.Change) AS Change, SUM(t.CanPay) AS CanPay, SUM(t.num) AS Sold, SUM(t.revenue) AS PreDiscount, SUM(t.post_discount) AS PostDiscount, SUM(t.discount) AS Discount 
FROM (
	SELECT orders.*, products.id_item_group, products.id_category, products.[name] 
	FROM (
		SELECT g.*, (g.disc_rat * g.revenue) AS post_discount, ((1 - g.disc_rat) * g.revenue) AS discount 
		FROM (
			SELECT t1.id_order, t1.id_item, t1.revenue, t1.num, t2.order_date, t2.[name] AS loc_name, t2.id_location,t2.complete, t2.disc_rat, t2.Cash, t2.Change, t2.CanPay 
			FROM (
				SELECT [id_order], id_item, SUM([price]) AS revenue, COUNT(*) AS num 
				FROM [order].[item]
				GROUP BY [id_order], id_item
			) t1
			INNER JOIN (
				SELECT orders.*,  a.tendered AS Cash, b.tendered AS CanPay, c.tendered AS Change 
				FROM (
					SELECT [order].[order].[id_order], [order].[date_created] as order_date, [order].[order].id_location, [base].[location].[name], [order].[order].complete, [order].[order].total, [order].[order].subtotal, ([order].[order].total / [order].[order].subtotal) AS disc_rat 
					FROM [order].[order]
					LEFT JOIN [base].[location] ON [order].[order].id_location = [base].[location].id_location
				) orders
				LEFT JOIN (
					SELECT [order].[payment].[id_order], [order].[payment].[method],[order].[payment].[tendered] 
					FROM [order].[payment] 
					WHERE [order].[payment].[method] = 'Cash'
				) a ON orders.[id_order] = a.[id_order]
				LEFT JOIN (
					SELECT [order].[payment].[id_order], [order].[payment].[method],[order].[payment].[tendered] 
					FROM [order].[payment] 
					WHERE [order].[payment].[method] = 'CanPay'
				) b ON orders.[id_order] = b.[id_order]
				LEFT JOIN (
					SELECT [order].[payment].[id_order], [order].[payment].[method],[order].[payment].[tendered] 
					FROM [order].[payment] 
					WHERE [order].[payment].[method] = 'Change'
				) c ON orders.[id_order] = c.[id_order]
			) t2 ON t1.id_order = t2.id_order
		) g
	) orders
	LEFT JOIN (
		SELECT prod.id_category, prod.id_item, prod.id_item_group, prod.category AS name
		FROM inventory.vw_item_list prod
	) products ON orders.id_item = products.id_item
) t
WHERE ISNULL(t.[CanPay], 0.0) + ISNULL(t.[Cash], 0.0) + ISNULL(t.[Change], 0.0) = t.[post_discount]
GROUP BY t.id_category, t.id_location, t.[name], t.loc_name
go

