CREATE VIEW [inventory].[vw_delivery_route]
	AS 
WITH	route_path AS (
			SELECT a.*, CAST(a.name AS VARCHAR(MAX)) AS path, id_delivery_route AS id_root
			FROM inventory.delivery_route a
			WHERE a.id_parent IS NULL
			AND a.route_version = 1
			UNION ALL
			SELECT b.*, CONCAT(p.path, ' > ', b.name) AS path, p.id_root AS id_root
			FROM inventory.delivery_route b
			JOIN route_path p ON p.id_delivery_route=b.id_parent
			WHERE b.route_version = 1
		)
SELECT d.id_delivery_route
		, d.name AS delivery_route
		, d.path AS delivery_route_path
		, dr.name as root
		, dr.biotrack_invtype_id
		, d.id_root
		, CASE WHEN d.id_root=d.id_delivery_route AND EXISTS (SELECT * FROM inventory.delivery_route r WHERE r.id_parent=d.id_delivery_route) THEN 1 ELSE 0 END AS has_children
FROM route_path d
JOIN inventory.delivery_route dr ON dr.id_delivery_route=d.id_root
go

