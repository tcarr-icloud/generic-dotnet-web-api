CREATE PROCEDURE [grow].[usp_plant_move]
	@id_area_from INT,
	@id_area_to INT,
	@notes VARCHAR(MAX) = NULL,
	@plant_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	SET NOCOUNT ON

	DECLARE @id_plant_move INT

	/* create move record. */
	INSERT INTO grow.plant_move (id_area_from, id_area_to, notes, id_user_created)
	VALUES (@id_area_from, @id_area_to, @notes, @id_user)

	SET @id_plant_move = SCOPE_IDENTITY()

	/* get table of available grid spaces. --------------------------------------- */
	;WITH grid ([row], [column], sequence) AS (
		SELECT b.[row], a.[column], ROW_NUMBER() OVER(ORDER BY b.[row] ASC) AS sequence
		FROM (
			SELECT [column] = number 
			FROM master..[spt_values] 
			WHERE type='P' AND number BETWEEN 1 AND (SELECT columns FROM inventory.area WHERE id_area=@id_area_to)
		) a
		CROSS JOIN (
			SELECT [row] = number 
			FROM master..[spt_values] 
			WHERE type='P' AND number BETWEEN 1 AND (SELECT rows FROM inventory.area WHERE id_area=@id_area_to)
		) b
		LEFT JOIN grow.plant p ON p.[row]=b.[row] AND 
								  p.[column]=a.[column] AND 
								  p.harvested = 0 AND
								  p.destroyed = 0 AND
								  p.id_area=@id_area_to
		WHERE p.id_plant IS NULL
	)

	/* insert plants into manifest with new grid locations. */
	INSERT INTO grow.plant_move_item (id_plant_move, id_plant, row_from, column_from, row_to, column_to, id_user_created)
	SELECT @id_plant_move AS id_plant_move
			, l.id_plant
			, l.[row] AS row_from
			, l.[column] AS column_from
			, g.[row] AS row_to
			, g.[column] AS column_to
			, @id_user AS id_user_created
	FROM (
		SELECT p.*
				, ROW_NUMBER() OVER(ORDER BY p.id_plant ASC) AS sequence
		FROM grow.plant p
		WHERE p.id_plant IN (SELECT value FROM OPENJSON(@plant_list)) AND
			 p.id_area <> @id_area_to
	) l 
	LEFT JOIN grid g ON g.sequence=l.sequence

	/* update plants with new areas. */
	UPDATE p
	SET p.id_area=@id_area_to
		, p.[row]=m.row_to
		, p.[column]=m.column_to
		, p.id_user_updated=@id_user
		, p.date_updated=GETUTCDATE()
	FROM grow.plant p
	JOIN grow.plant_move_item m ON m.id_plant=p.id_plant AND m.id_plant_move=@id_plant_move

	/* add log events. */
	DECLARE @list VARCHAR(MAX) = (
			SELECT id_plant
					, id_area
					, [row]
					, [column]
			FROM grow.plant p
			WHERE p.id_plant in (SELECT value FROM OPENJSON(@plant_list))
			FOR JSON PATH),
			@move_notes VARCHAR(128) = CONCAT('MoveID: ', @id_plant_move)

	EXEC grow.usp_event_create_bulk 'move', @id_area_to, NULL, NULL, @move_notes, @list, @id_user

	/* return changed plants. */
	EXEC grow.usp_plant_list NULL, NULL, NULL, NULL, NULL, NULL, @plant_list
go

