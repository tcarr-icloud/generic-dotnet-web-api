CREATE   PROCEDURE [dbo].[usp_admin_user_update]
	@id_user INT,
	@name_first VARCHAR(128),
	@name_last VARCHAR(128),
	@username VARCHAR(128),
	@phone VARCHAR(128),
	@password VARCHAR(128) = NULL,
	@pin VARCHAR(128) = NULL,
	@accountDisabled BIT = 0
AS
	SET NOCOUNT ON;
	
	UPDATE [base].[user]
	SET FirstName=@name_first,
		LastName=@name_last,
		UserName=@username,
		Email=@username,
		PhoneNumber=@phone,
		PasswordHash=ISNULL(@password, Passwordhash),
		PIN=ISNULL(@pin, PIN),
		accountDisabled=@accountDisabled
	WHERE id_user=@id_user

	SELECT id_user
			, FirstName AS name_first
			, LastName AS name_last
			, UserName AS username
	FROM [base].[user]
	WHERE id_user=@id_user
go

