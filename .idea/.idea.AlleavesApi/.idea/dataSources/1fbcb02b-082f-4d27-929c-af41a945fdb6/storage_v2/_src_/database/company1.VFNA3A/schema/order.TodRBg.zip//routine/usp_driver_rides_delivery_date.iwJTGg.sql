CREATE PROCEDURE [order].[usp_driver_rides_delivery_date]
       @delivery_date DATE =NULL,
       @id_location INT = NULL
AS
SELECT ride.id_ride
	,ride.id_driver
	,ride.id_order
	,ride.id_area
	,ride.id_driver2
	,ride.signature
	,a.delivery_date
	,driver_user.FirstName + ' ' + driver_user.LastName AS driver1_name
	,o.date_created
	,o.type
	,c.name_first + ' ' + c.name_last AS recipient_name
    ,c.phone
    ,c.phone2
	,a.address1 + ISNULL(', ' + NULLIF(REPLACE(a.address2, ' ' ,''), ''), '') AS address
	,a.city
	,a.state
	,a.zip AS postal_code
    ,a.lat
    ,a.long
	,location.name AS sender_name
	,location.address AS sender_address
	,location.city AS sender_city
	,location.STATE AS sender_state
	,location.postal_code AS sender_postal_code
    ,(
		SELECT TOP 1 ers.driver_message
		FROM [order].ecommerce_ride_status_history history
		JOIN [order].ecommerce_ride_status ers ON ers.id_status = history.id_ride_status
		WHERE ride.id_ride = history.id_ride
		ORDER BY history.created_at DESC
		) AS last_ride_status
	,(
		SELECT TOP 1 history.created_at
		FROM [order].ecommerce_ride_status_history history
		WHERE history.id_ride = ride.id_ride
		ORDER BY history.created_at DESC
		) AS last_ride_status_createdat
	,es.driver_message
	,(
		SELECT TOP 1 history.cancellation_note 
		FROM [order].ecommerce_ride_status_history history
		WHERE history.id_ride = ride.id_ride
		ORDER BY history.created_at DESC
		) AS cancellation_note
FROM [order].ecommerce_ride ride
JOIN [order].[order] o ON o.id_order = ride.id_order
JOIN [order].customer c ON c.id_customer = o.id_customer
LEFT JOIN [order].[address] a ON o.id_order = a.id_order
JOIN [order].driver d ON d.id_driver = ride.id_driver
LEFT JOIN base.[user] driver_user ON d.id_user = driver_user.id_user
LEFT JOIN inventory.area ON ride.id_area = area.id_area
LEFT JOIN base.location ON area.id_location = location.id_location
CROSS APPLY (
	SELECT TOP 1 * FROM [order].[ecommerce_ride_status_history] where id_ride = ride.id_ride ORDER BY created_at DESC
)  eh
JOIN [order].[ecommerce_ride_status] es ON es.id_status = eh.id_ride_status
WHERE a.delivery_date = @delivery_date 
AND es.driver_message  = 'Aborted' 
AND o.id_location = @id_location
go

