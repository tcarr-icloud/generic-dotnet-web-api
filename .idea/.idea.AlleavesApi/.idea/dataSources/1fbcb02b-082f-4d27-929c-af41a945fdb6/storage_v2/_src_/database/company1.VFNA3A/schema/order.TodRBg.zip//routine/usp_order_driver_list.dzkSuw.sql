CREATE PROCEDURE [order].[usp_order_driver_list]
	@id_order INT = NULL
AS
	SELECT distinct u.id_user AS id_user_alleaves
			, d.id_driver
			, u.FirstName AS name_first
			, u.LastName AS name_last
			, u.Email
			, d.license
	FROM [order].[address] a
	LEFT JOIN [order].driver d ON d.id_driver=a.id_driver1
	LEFT JOIN base.[user] u ON u.id_user = d.id_user
	WHERE (a.id_order=ISNULL(@id_order, a.id_order) AND 
			u.id_user<>-1 AND
			u.Email NOT LIKE 'TERM-%')
	ORDER BY u.LastName
go

