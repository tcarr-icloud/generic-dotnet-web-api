CREATE PROCEDURE [inventory].[usp_item_save_bulk]
	@id_category INT = NULL,
	@id_tax_category INT = NULL,
	@id_uom INT = NULL,
	@id_uom_receiving INT = NULL,
	@id_uom_weight_useable INT = NULL,
	@id_preset_tiered_pricing INT = NULL,
	@id_brand INT = NULL,
	@id_vendor INT = NULL,
	@id_strain INT = NULL,
	@threshold_low_quantity DECIMAL(18,4) = NULL,
	@is_tax_exempt BIT = NULL,
	@is_cannabis BIT = NULL,
	@is_adult_use BIT = NULL,
	@is_medical_use BIT = NULL,
	@id_delivery_route INT = NULL,
	@is_low_thc BIT = NULL,
	@is_medicated BIT = NULL,
	@is_smoking BIT = NULL,
	@is_low_thc_and_medical BIT = NULL,
	@id_ommu_form INT = NULL,
	@is_ommu_delivery_device BIT = NULL,
	@tiered_pricing_option VARCHAR(64) = NULL,
	@use_tiered_pricing INT = NULL,
	@item_group_list VARCHAR(MAX) = '[]',
	@item_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	UPDATE inventory.item_group
	SET id_category = ISNULL(@id_category, id_category),
		id_tax_category = ISNULL(@id_tax_category, id_tax_category),
		id_uom = ISNULL(@id_uom, id_uom),
		id_uom_receiving = ISNULL(@id_uom_receiving, id_uom_receiving),
		id_uom_weight_useable = ISNULL(@id_uom_weight_useable, id_uom_weight_useable),
		id_brand = ISNULL(@id_brand, id_brand),
		id_vendor = ISNULL(@id_vendor, id_vendor),
		id_strain = ISNULL(@id_strain, id_strain),
		threshold_low_quantity = ISNULL(@threshold_low_quantity, threshold_low_quantity),
		is_tax_exempt = ISNULL(@is_tax_exempt, is_tax_exempt),
		is_cannabis = ISNULL(@is_cannabis, is_cannabis),
		is_adult_use = ISNULL(@is_adult_use, is_adult_use),
		is_medical_use = ISNULL(@is_medical_use, is_medical_use),
		id_delivery_route = ISNULL(@id_delivery_route, id_delivery_route),
		is_low_thc = ISNULL(@is_low_thc, is_low_thc),
		is_medicated = ISNULL(@is_medicated, is_medicated),
		is_smoking = ISNULL(@is_smoking, is_smoking),
		is_low_thc_and_medical = ISNULL(@is_low_thc_and_medical, is_low_thc_and_medical),
		id_ommu_form = ISNULL(@id_ommu_form, id_ommu_form),
		is_ommu_delivery_device = ISNULL(@is_ommu_delivery_device, is_ommu_delivery_device),
		id_user_updated = @id_user,
		date_updated = GETUTCDATE()
	WHERE id_item_group IN (SELECT value as id_item_group FROM OPENJSON(@item_group_list))
	BEGIN
    UPDATE inventory.item
    SET 
	id_preset_tiered_pricing = ISNULL(@id_preset_tiered_pricing,id_preset_tiered_pricing),
	use_tiered_pricing = ISNULL(@use_tiered_pricing, use_tiered_pricing),
	tiered_pricing_option    = ISNULL(@tiered_pricing_option, tiered_pricing_option)
    WHERE id_item IN (SELECT value as id_item FROM OPENJSON(@item_list))
END
	SELECT *
	FROM inventory.vw_item_list
	WHERE id_item_group IN (SELECT value as id_item_group FROM OPENJSON(@item_group_list))
go

