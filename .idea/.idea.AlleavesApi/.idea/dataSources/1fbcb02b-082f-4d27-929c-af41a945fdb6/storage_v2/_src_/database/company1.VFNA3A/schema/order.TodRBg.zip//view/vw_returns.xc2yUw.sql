CREATE VIEW [order].[vw_returns]

AS

SELECT oi.id_order
	, oi.id_item
	, cd.reason
	, l.id_location
	, u.id_user
	, c.id_customer
	, oi.date_updated AS 'date'
	, l.name AS 'location'
	, u.FirstName + ' ' + u.LastName AS 'employee_name'
	, c.name_first + ' ' + c.name_last AS 'customer_name'
	, c.patient_number
	, r.name AS 'terminal'
	, r.id_register
	, pr.item as product_name
	, o.total
	, cd.id_customer_credit_debit
	, COUNT(oi.id_order)as number_returned_items
	, SUM(oi.price - oi.discount) as price_post_discount
	, SUM(o.total) as ticket_total
FROM [order].[item] oi
LEFT JOIN [order].[order] o ON o.id_order=oi.id_order
LEFT JOIN [order].[customer_credit_debit] cd ON cd.id_order=oi.id_order 
LEFT JOIN [order].[payment] p ON p.id_order=oi.id_order
LEFT JOIN [order].[customer] c ON c.id_customer=o.id_customer
LEFT JOIN [base].[user] u ON u.id_user=oi.updated_by
LEFT JOIN [pos].[register] r ON r.id_register=p.id_register
LEFT JOIN [base].[location] l ON l.id_location=r.id_location
LEFT JOIN inventory.vw_item_list pr ON pr.id_item=oi.id_inventory_item
WHERE id_item_return IS NOT NULL
group by oi.id_order
	, cd.reason
	, oi.date_updated 
	, l.name 
	, u.FirstName 
	, u.LastName 
	, c.name_first 
	, c.name_last
	, c.patient_number
	, r.name 
	, r.id_register
	, pr.item 
	, o.total
	, cd.id_customer_credit_debit
	, oi.id_item
	, l.id_location
	, u.id_user
	, c.id_customer
go

