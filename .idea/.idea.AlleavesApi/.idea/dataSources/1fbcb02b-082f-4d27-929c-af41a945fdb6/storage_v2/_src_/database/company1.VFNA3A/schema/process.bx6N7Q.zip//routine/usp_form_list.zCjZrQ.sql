CREATE PROCEDURE [process].[usp_form_list]
	@id_form INT = NULL,
	@id_location INT = NULL
AS
	SELECT pf.id_form
			, pc.id_process_category
			, pf.name AS form
			, pf.sequence
			, COALESCE(pc.name, 'Misc') AS category
			, COALESCE(pc.sequence, 10000) AS category_sequence		
			, ISNULL((SELECT fi.id_form_input
							, fi.id_form
							, fi.id_raw_material
							, fii.name AS raw_material
					  FROM process.form_input fi
					  JOIN inventory.raw_material fii ON fii.id_raw_material=fi.id_raw_material
					  WHERE fi.id_form=pf.id_form
					  FOR JSON PATH
			), '[]') AS input_list
			, ISNULL((SELECT fo.id_form_output
							, fo.id_form
							, fo.id_raw_material
							, foi.name AS raw_material
					  FROM process.form_output fo
					  JOIN inventory.raw_material foi ON foi.id_raw_material=fo.id_raw_material
					  WHERE fo.id_form=pf.id_form
					  FOR JSON PATH
			), '[]') AS output_list
			, ISNULL((SELECT fa.id_form_attribute
							, fa.id_form
							, fa.name AS attribute
							, fa.input_type
					  FROM process.form_attribute fa
					  WHERE fa.id_form=pf.id_form
					  FOR JSON PATH
			), '[]') AS attribute_list
			, ISNULL((SELECT p.id_process
							, l.id_location
							, l.name AS location
							, dbo.fn_utc_to_local(p.process_start, l.id_location) AS process_start
							, u.FirstName AS name_first
							, u.LastName AS name_last
					  FROM process.process p
					  JOIN base.location l ON l.id_location=p.id_location AND l.id_location=ISNULL(@id_location, l.id_location)
					  LEFT JOIN base.[user] u ON u.id_user=p.created_by
					  WHERE p.id_form=pf.id_form AND p.complete=0 AND p.cancelled=0
					  FOR JSON PATH
			), '[]') AS current_process_list
	FROM process.form pf
	LEFT JOIN process.process_category pc ON pc.id_process_category=pf.id_process_category
	WHERE pf.id_form=ISNULL(@id_form, pf.id_form) AND
		  pf.deleted=(CASE WHEN @id_form IS NOT NULL THEN pf.deleted ELSE 0 END)
	ORDER BY category_sequence, pf.sequence
go

