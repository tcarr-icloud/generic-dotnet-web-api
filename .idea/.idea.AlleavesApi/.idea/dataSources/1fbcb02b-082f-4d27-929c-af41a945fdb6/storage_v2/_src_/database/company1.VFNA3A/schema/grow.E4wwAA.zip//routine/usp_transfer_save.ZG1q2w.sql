CREATE PROCEDURE [grow].[usp_transfer_save]
	@id_transfer INT = NULL,
	/* participant information. */
	@id_location_source INT = NULL,
	@id_vendor_source INT = NULL,
	@id_location_destination INT = NULL,
	@id_vendor_destination INT = NULL,
	/* source details. */
	@source_use_address_on_file BIT = 0,
	@source_address VARCHAR(512) = NULL,
	@source_city VARCHAR(512) = NULL,
	@source_state VARCHAR(128) = NULL,
	@source_postal_code VARCHAR(32) = NULL,
	/* destination information. */
	@recipient VARCHAR(512) = NULL,
	@destination_use_address_on_file BIT = 0,
	@destination_address VARCHAR(512) = NULL,
	@destination_city VARCHAR(512) = NULL,
	@destination_state VARCHAR(128) = NULL,
	@destination_postal_code VARCHAR(32) = NULL,
	/* shipment information. */
	@id_driver1 INT = NULL,
	@id_driver2 INT = NULL,
	@id_vehicle INT = NULL,
	@tracking_number VARCHAR(128) = NULL,
	@internal_reference VARCHAR(128) = NULL,
	@notes VARCHAR(MAX) = NULL,
	/* manifests. */
	@plant_list VARCHAR(MAX) = '[]',
	@strain_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	/* create new transfer. */
	IF(@id_transfer IS NULL)
	BEGIN
		INSERT INTO grow.transfer (
			id_location_source, 
			id_vendor_source, 
			id_location_destination, 
			id_vendor_destination,
			source_use_address_on_file,
			source_address,
			source_city,
			source_state,
			source_postal_code,
			recipient,
			destination_use_address_on_file,
			destination_address,
			destination_city,
			destination_state,
			destination_postal_code,
			id_driver1,
			id_driver2,
			id_vehicle,
			tracking_number,
			internal_reference,
			notes,
			id_user_created,
			id_user_updated)
		VALUES (
			@id_location_source, 
			@id_vendor_source, 
			@id_location_destination, 
			@id_vendor_destination,
			@source_use_address_on_file,
			@source_address,
			@source_city,
			@source_state,
			@source_postal_code,
			@recipient,
			@destination_use_address_on_file,
			@destination_address,
			@destination_city,
			@destination_state,
			@destination_postal_code,
			@id_driver1,
			@id_driver2,
			@id_vehicle,
			@tracking_number,
			@internal_reference,
			@notes,
			-1,
			-1)

		SET @id_transfer = SCOPE_IDENTITY()

		INSERT INTO grow.transfer_status_history (id_transfer, id_transfer_status, id_user_verified)
		VALUES (@id_transfer, 1, @id_user)
	END
	/* update existing transfer. */
	ELSE
	BEGIN
		UPDATE grow.transfer
		SET id_location_source=@id_location_source,
			id_vendor_source=@id_vendor_source,
			id_location_destination=@id_location_destination,
			id_vendor_destination=@id_vendor_destination,
			source_use_address_on_file=@source_use_address_on_file,
			source_address=@source_address,
			source_city=@source_city,
			source_state=@source_state,
			source_postal_code=@source_postal_code,
			recipient=@recipient,
			destination_use_address_on_file=@destination_use_address_on_file,
			destination_address=@destination_address,
			destination_city=@destination_city,
			destination_state=@destination_state,
			destination_postal_code=@destination_postal_code,
			id_driver1=@id_driver1,
			id_driver2=@id_driver2,
			id_vehicle=@id_vehicle,
			tracking_number=@tracking_number,
			internal_reference=@internal_reference,
			notes=@notes,
			date_updated=GETUTCDATE(),
			id_user_updated=@id_user
		WHERE id_transfer=@id_transfer
	END


	/* create plant list temp table. ------------------------------------------------------------------------------------------ */

	DROP TABLE IF EXISTS #pick_list
	SELECT l.*
			, ISNULL(t.id_transfer_plant, NULL) AS id_transfer_item_orig
			, t.id_plant AS id_plant_orig
			, t.id_area_source AS id_area_source_orig
			, t.source_row AS source_row_orig
			, t.source_column AS source_column_orig
			, CASE WHEN (l.id_transfer_plant IS NULL AND t.id_transfer_plant IS NOT NULL) THEN 1 ELSE 0 END AS removed
			, CASE WHEN (l.id_transfer_plant IS NULL AND t.id_transfer_plant IS NULL) THEN 1 ELSE 0 END AS added
	INTO #pick_list
	FROM (
		SELECT @id_transfer AS id_transfer
				, *
		FROM OPENJSON(@plant_list)
		WITH (
			id_transfer_plant INT,
			id_plant INT,
			id_area_source INT,
			source_row INT,
			source_column INT
		)
	) l
	FULL OUTER JOIN grow.transfer_plant t ON t.id_transfer_plant=l.id_transfer_plant
	LEFT JOIN inventory.area a1 ON a1.id_area=l.id_area_source
	LEFT JOIN inventory.area a2 ON a2.id_area=t.id_area_source
	WHERE ISNULL(t.id_transfer, @id_transfer)=@id_transfer


	/* adjust plants and add log events. ------------------------------------------------------------------------------------------ */	

	DECLARE @return_list VARCHAR(MAX) = (SELECT id_plant_orig as id_plant
												, id_area_source_orig AS id_area
												, source_row_orig AS [row]
												, source_column_orig AS [column]
												, CONCAT('TransferID: ', @id_transfer) AS notes 
									     FROM #pick_list WHERE removed=1 FOR JSON PATH), 
			@add_list VARCHAR(MAX) = (SELECT id_plant
												, id_area_source AS id_area
												, source_row AS [row]
												, source_column AS [column]
												, CONCAT('TransferID: ', @id_transfer) AS notes 
									  FROM #pick_list WHERE added=1 FOR JSON PATH)
			
	/* add log events and update inventory. */
	EXEC grow.usp_event_create_bulk 'transfer_manifest_remove', NULL, NULL, NULL, NULL, @return_list, @id_user
	EXEC grow.usp_event_create_bulk 'transfer_manifest_add', NULL, NULL, NULL, NULL, @add_list, @id_user

	DELETE FROM #pick_list WHERE removed=1

	/* upsert plants. */
	MERGE grow.transfer_plant t
	USING #pick_list s
	ON t.id_transfer_plant=s.id_transfer_plant
	WHEN MATCHED THEN 
		UPDATE SET t.id_area_source=s.id_area_source, t.source_row=s.source_row, t.source_column=s.source_column
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_transfer, id_plant, id_area_source, source_row, source_column) VALUES (s.id_transfer, s.id_plant, s.id_area_source, s.source_row, s.source_column)
	WHEN NOT MATCHED BY SOURCE AND t.id_transfer=@id_transfer THEN DELETE
	;


	/* adjust strains. ------------------------------------------------------------------------------------------ */	

	MERGE grow.transfer_strain t
	USING (SELECT *
			FROM OPENJSON(@strain_list)
			WITH (
				id_transfer_strain INT,
				id_strain INT,
				quantity INT
			)
	) s
	ON t.id_transfer_strain=s.id_transfer_strain
	WHEN MATCHED THEN 
		UPDATE SET t.id_strain=s.id_strain, t.quantity=s.quantity
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_transfer, id_strain, quantity) VALUES (@id_transfer, s.id_strain, s.quantity)
	WHEN NOT MATCHED BY SOURCE AND t.id_transfer=@id_transfer THEN DELETE
	;


	EXEC grow.usp_transfer_fetch @id_transfer
go

