CREATE PROCEDURE terminal.usp_label_list
              @id_label INT = NULL
			  --DECLARE @id_label INT = NULL
AS
BEGIN
	SELECT id_label,
	       [name] AS label,
	       [path],
		   [category],
	       id_user_created_by
	FROM terminal.label
	WHERE id_label = ISNULL(@id_label, id_label)
	ORDER BY name
END
go

