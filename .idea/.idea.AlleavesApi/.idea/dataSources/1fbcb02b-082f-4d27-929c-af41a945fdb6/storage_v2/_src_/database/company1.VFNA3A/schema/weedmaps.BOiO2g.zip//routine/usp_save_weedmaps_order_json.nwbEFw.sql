CREATE PROCEDURE [weedmaps].[usp_save_weedmaps_order_json]
	@json varchar(max)
AS
	INSERT INTO weedmaps.[orders] (requestJSON)
	SELECT @json
go

