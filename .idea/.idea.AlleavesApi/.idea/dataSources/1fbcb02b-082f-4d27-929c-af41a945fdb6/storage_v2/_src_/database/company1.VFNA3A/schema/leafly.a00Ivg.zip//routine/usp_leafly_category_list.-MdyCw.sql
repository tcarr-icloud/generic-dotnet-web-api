CREATE PROCEDURE [leafly].[usp_leafly_category_list]
AS
	SELECT c.id_category,
        c.name,
        c.path,
		lc.[leafly_type]
	FROM inventory.vw_category_list c
	LEFT JOIN [leafly].[category] lc ON lc.id_category = c.id_category
	WHERE c.deleted = 0
go

