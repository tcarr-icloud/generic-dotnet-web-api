CREATE PROCEDURE [order].[usp_driver_upsert]
	@id_driver INT = NULL,
	@id_user_alleaves INT,
	@id_location INT,
	@license VARCHAR(128)
AS
	IF(@id_driver IS NULL)
	BEGIN
		INSERT INTO [order].driver (id_user, id_location, license) VALUES (@id_user_alleaves, @id_location, UPPER(@license))

		SET @id_driver=SCOPE_IDENTITY()
	END
	ELSE
		UPDATE [order].driver SET license=UPPER(@license), id_location=@id_location WHERE id_driver=@id_driver

	EXEC [order].usp_driver_list @id_driver
go

