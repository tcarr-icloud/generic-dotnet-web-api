CREATE PROCEDURE [process].[usp_process_category_update]
	@id_process_category INT,
	@name VARCHAR(64),
	@sequence INT,
	@deleted BIT = 0,
	@id_user INT,
	@id_category_move INT = NULL
AS
	SET NOCOUNT ON

	DECLARE @orig_sequence INT
	DECLARE @sequence_min INT
	DECLARE @sequence_max INT
	
	SET @orig_sequence = (SELECT sequence FROM process.process_category WHERE id_process_category=@id_process_category)
	SET @sequence_min=IIF(@sequence<@orig_sequence, @sequence, @orig_sequence)
	SET @sequence_max=IIF(@sequence>@orig_sequence, @sequence, @orig_sequence)

	/* updated category. */
	UPDATE process.process_category
	SET name=@name
		, sequence=@sequence
		, deleted=@deleted
		, updated_by=@id_user
		, date_updated=getutcdate()
	WHERE id_process_category=@id_process_category

	/* update affected category sequences based on direction of movement by updated category. */
	UPDATE process.process_category
	SET sequence=sequence+(CASE WHEN @orig_sequence-@sequence<0 THEN -1 WHEN @orig_sequence-@sequence>0 THEN 1 ELSE 0 END)
	WHERE sequence BETWEEN @sequence_min AND @sequence_max AND 
		  id_process_category<>@id_process_category AND deleted=0

	/* renumber sequences. */
	;WITH resequence AS
	(
	  SELECT id_process_category
			, sequence
			, ROW_NUMBER() OVER (ORDER BY sequence) as new_sequence
		FROM process.process_category
		WHERE deleted=0
	)
	UPDATE resequence SET sequence=new_sequence

	SELECT id_process_category
			, guid_process_category
			, name AS process_category
			, sequence
			, deleted
	FROM process.process_category
	WHERE id_process_category=@id_process_category
go

