


----------------------------------------------------------------------------
---Event Log----------------------------------------------------------------
CREATE VIEW [report].[vw_log_event]
	AS
	
SELECT  
	le.[id_event] as 'id_log_event'
	,le.[id_user_created]
	,bu.[FirstName] + ' ' + bu.[LastName] as 'user_name'
	,le.[date_created] as 'UTC_created_datetime'
	,CASE
		WHEN le.[date_created] IS NOT NULL
		THEN CAST(le.[date_created] AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime)
		ELSE NULL
	END as 'local_created_datetime'
	,le.[id_batch]
	,le.[original_quantity]
	,le.[adjustment]
	,le.[notes]
	,bl.[name] as 'location'
    ,lt.[reference] as 'event_reference'
    ,lt.[description] as 'event_description'
	,ia.[name] as 'area_name'
	,iat.[name] as 'area_type'
	,ib.[id_strain]
    ,ib.[name] as 'strain_name'
	,ib.[metrc_package_label]
	,ii.[metrc_item_id]
    ,ii.[metrc_category]
	,iig.[name] as 'item_group_name'
	,iig.[is_adult_use]
    ,iig.[is_medical_use]


FROM [log].[event] le
	LEFT OUTER JOIN [base].[user] bu ON le.[id_user_created] = bu.[id_user]
	LEFT OUTER JOIN [log].[type] lt ON le.[id_type] = lt.[id_type]
	LEFT OUTER JOIN [inventory].[area] ia ON le.[id_area] = ia.[id_area]
	LEFT OUTER JOIN [inventory].[area_type] iat ON ia.[id_area_type] = iat.[id_area_type]
	LEFT OUTER JOIN [inventory].[batch] ib ON le.[id_batch] = ib.[id_batch]
	LEFT OUTER JOIN [inventory].[item] ii ON ib.[id_item] = ii.[id_item]
	LEFT OUTER JOIN [inventory].[item_group] iig ON ii.[id_item_group] = iig.[id_item_group]
	LEFT OUTER JOIN [base].[location] bl on ia.[id_location] = bl.[id_location]
	LEFT OUTER JOIN [dbo].[tz_lookup] tl ON bl.[timezone] = tl.[tz_iana]
go

