CREATE PROCEDURE [metrc].[usp_tag_import]
	@id_location INT,
	@list VARCHAR(MAX) = '[]'
AS
	;WITH list AS (
		SELECT @id_location AS id_location
				, l.tag
				, l.tag_type
				, CAST((CASE WHEN p.metrc_label IS NOT NULL THEN 0
					   WHEN b.metrc_package_label IS NOT NULL THEN 0
					   ELSE 1 END) AS BIT) AS is_available
				, CASE WHEN b.metrc_package_label IS NOT NULL THEN b.date_created
					   WHEN p.metrc_label IS NOT NULL THEN COALESCE(p.date_vegetative, p.date_preflower, p.date_flower, GETUTCDATE())
					   ELSE NULL END AS date_used
		FROM OPENJSON(@list) 
		WITH (
			tag VARCHAR(128),
			tag_type VARCHAR(64)
		) l

		/* check for tag use in existing package. */
		LEFT JOIN (
			SELECT b.*
			FROM inventory.batch b
			JOIN inventory.inventory i ON i.id_batch=b.id_batch
			JOIN inventory.area a ON a.id_area=i.id_area AND a.id_location=@id_location
		) b ON b.metrc_package_label=l.tag AND l.tag_type like '%package%'

		/* check for tag use in plant. */
		LEFT JOIN (
			SELECT p.*
			FROM grow.plant p
			JOIN inventory.area a ON a.id_area=p.id_area AND a.id_location=@id_location
		) p ON p.metrc_label=l.tag AND l.tag_type like '%plant%'
	)
	MERGE metrc.tag t
	USING list s
	ON t.id_location=s.id_location AND t.tag=s.tag
	-- add new tag
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_location, tag, tag_type, is_available, date_used) VALUES (s.id_location, s.tag, s.tag_type, s.is_available, CASE WHEN s.is_available=0 THEN ISNULL(s.date_used, GETUTCDATE()) ELSE NULL END)
	-- update existing tag with updated data
	WHEN MATCHED THEN
		UPDATE SET t.is_available=s.is_available
				   , t.date_used=CASE WHEN t.date_used IS NULL AND s.is_available=0 THEN s.date_used ELSE t.date_used END
	-- set tag not in list to 'used'
	WHEN NOT MATCHED BY SOURCE AND t.id_location=@id_location THEN 
		UPDATE SET t.is_available=0
				   , t.date_used=CASE WHEN t.date_used IS NULL THEN GETUTCDATE() ELSE t.date_used END
	;
go

