CREATE PROCEDURE [order].[usp_delivery_route_create]
    @ride_list VARCHAR(MAX) = NULL,
    @transfer_list VARCHAR(MAX) = NULL,
    @start_time VARCHAR(MAX),
	@start_date VARCHAR(MAX)=null,
    @delivery_end_eta VARCHAR(MAX),
    @list_eta VARCHAR(MAX)
AS
BEGIN
    INSERT INTO [order].delivery_route (id_driver, status, delivery_start_time,delivery_start_date, delivery_end_eta)
    VALUES (NULL, NULL, @start_time,@start_date, @delivery_end_eta)

    DECLARE @order_count INT = 0
    DECLARE @id_delivery_route INT
    SET @id_delivery_route = SCOPE_IDENTITY()
    
    IF (@ride_list IS NOT NULL)
    BEGIN
	    INSERT INTO [order].ride_delivery_route (id_ride, id_delivery_route, position, eta)
	    SELECT
	        ride_list.value AS id_ride,
	        @id_delivery_route,
	        ride_list.position,
	        ride_eta.value AS eta
	    FROM
	        (
	            SELECT
	                value,
	                ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS position
	            FROM
	                STRING_SPLIT(@ride_list, ',')
	        ) AS ride_list
	    JOIN
	        (
	            SELECT
	                value,
	                ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS position
	            FROM
	                STRING_SPLIT(@list_eta, ',')
	        ) AS ride_eta ON ride_eta.position = ride_list.position
	    SET @order_count=@@ROWCOUNT+@order_count
    END
    
    IF (@transfer_list IS NOT NULL)
    BEGIN
	   	INSERT INTO [order].ride_transfer_delivery_route(id_transfer, id_delivery_route, position, eta)
	    SELECT
	        transfer_list.value AS id_transfer,
	        @id_delivery_route,
	        transfer_list.position,
	        ride_eta.value AS eta
	    FROM
	        (
	            SELECT
	                value,
	                @order_count+ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS position
	            FROM
	                STRING_SPLIT(@transfer_list, ',')
	        ) AS transfer_list
	    JOIN
	        (
	            SELECT
	                value,
	                ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS position
	            FROM
	                STRING_SPLIT(@list_eta, ',')
	        ) AS ride_eta ON ride_eta.position = transfer_list.position
	    SET @order_count=@@ROWCOUNT+@order_count
	END
    SELECT @id_delivery_route AS route_id
END
go

