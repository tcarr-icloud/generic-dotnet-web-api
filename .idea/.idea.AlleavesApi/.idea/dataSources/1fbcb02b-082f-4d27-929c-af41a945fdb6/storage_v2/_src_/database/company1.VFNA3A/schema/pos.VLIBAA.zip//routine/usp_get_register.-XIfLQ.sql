
CREATE PROCEDURE [pos].[usp_get_register]
@mac nvarchar(25),
@id_register int,
@id_session int
AS 

if(@id_session IS NOT NULL AND @id_register IS NULL)
	SELECT TOP 1 @id_register = id_register FROM [pos].[session] WHERE @id_session = id_session

SELECT id_register, id_location, [name], mac, tf_RegisterID, tf_AuthKey, gift_card_register_id, gift_card_auth_key, receipt_header, receipt_footer FROM pos.register 
WHERE 
	(@mac IS NOT NULL OR @id_register IS NOT NULL OR @id_session IS NOT NULL ) AND
	(@mac IS NULL OR mac = @mac) AND
	(@id_register IS NULL OR id_register = @id_register)
go

