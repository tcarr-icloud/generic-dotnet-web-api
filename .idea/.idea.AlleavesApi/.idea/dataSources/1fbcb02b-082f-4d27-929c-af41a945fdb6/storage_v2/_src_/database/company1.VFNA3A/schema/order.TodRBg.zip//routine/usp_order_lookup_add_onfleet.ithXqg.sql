CREATE   PROCEDURE [order].[usp_order_lookup_add_onfleet]
	@id_order_online INT,
	@id_onfleet VARCHAR(128)
AS
	SET NOCOUNT ON;

	UPDATE [order].[order_lookup] 
	SET id_onfleet=@id_onfleet
	WHERE id_order_online=@id_order_online AND deleted=0
	
	DECLARE @id_order_lookup INT = (SELECT TOP 1 id_order_lookup FROM [order].[order_lookup] WHERE id_order_online=@id_order_online AND deleted=0)	
	EXEC [order].usp_order_lookup_list @id_order_lookup
go

