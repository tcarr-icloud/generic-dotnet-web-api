CREATE PROCEDURE [biotrack].[usp_biotrack_sync_sales]
	@sales VARCHAR(MAX) = '[]'
AS
	SELECT *
	INTO #sales
	FROM OPENJSON(@sales)
	WITH(
		[biotrack_receipt_id] VARCHAR(528),
		[id_order] INT
	)
	DECLARE @biotrack_receipt_id VARCHAR(528),
			@id_order INT

	DECLARE sales_cursor CURSOR FAST_FORWARD FOR
	SELECT 
		biotrack_receipt_id,
		id_order
	FROM #sales

	OPEN sales_cursor

	FETCH NEXT FROM sales_cursor INTO @biotrack_receipt_id, @id_order

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		UPDATE [order].[order]
		SET biotrack_receipt_id=@biotrack_receipt_id
		WHERE id_order=@id_order
		FETCH NEXT FROM sales_cursor INTO @biotrack_receipt_id, @id_order
	END

	CLOSE sales_cursor
	DEALLOCATE sales_cursor
go

