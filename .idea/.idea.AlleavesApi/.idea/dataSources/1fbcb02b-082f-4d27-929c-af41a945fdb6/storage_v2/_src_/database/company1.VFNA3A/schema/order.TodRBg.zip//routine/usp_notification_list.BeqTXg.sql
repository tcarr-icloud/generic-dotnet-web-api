CREATE PROCEDURE [order].usp_notification_list
              @id_notification INT = NULL
AS
BEGIN
	SELECT id_notification,
	       notification_text,
	       id_user,
	       status
	FROM [order].notification_schedule
	WHERE id_notification = ISNULL(@id_notification, id_notification)
END
go

