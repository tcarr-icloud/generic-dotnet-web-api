CREATE PROCEDURE [order].[usp_physician_update]
	@id_physician INT, 
	@name_first VARCHAR(128),
	@name_last VARCHAR(128),
	@phone VARCHAR(20),
	@email VARCHAR(263),
	@address1 VARCHAR(255),
	@address2 VARCHAR(255),
	@city VARCHAR(150),
	@state VARCHAR(150),
	@zip VARCHAR(15),
	@license_number VARCHAR(50),
	@dea VARCHAR(50),
	@npi VARCHAR(50),
	@id_user INT,
	@deleted BIT = 0
AS
	UPDATE [order].physician
	SET name_first=@name_first
		, name_last=@name_last
		, phone=@phone
		, email=@email
		, address1=@address1
		, address2=@address2
		, city=@city
		, state=@state
		, zip=@zip
		, license_number=@license_number
		, dea=@dea
		, npi=@npi
		, updated_by=@id_user
		, date_updated=getutcdate()
		, deleted=@deleted
	WHERE id_physician=@id_physician

	EXEC [order].usp_physician_list @id_physician, 1
go

