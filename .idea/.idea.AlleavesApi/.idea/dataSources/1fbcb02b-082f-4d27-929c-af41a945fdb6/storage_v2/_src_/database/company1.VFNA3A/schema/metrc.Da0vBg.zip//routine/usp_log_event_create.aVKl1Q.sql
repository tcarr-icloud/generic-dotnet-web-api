CREATE PROCEDURE [metrc].[usp_log_event_create]
	@type_reference VARCHAR(128),
	@id_location INT,
	@metrc_facility_license_number VARCHAR(128),
	@metrc_api_user_key VARCHAR(256),
	@metrc_request VARCHAR(MAX) = NULL,
	@metrc_response VARCHAR(MAX) = NULL,
	@notes VARCHAR(MAX),
	@id_user INT
AS
	/* get type id from supplied reference. */
	DECLARE @id_type INT = (SELECT id_type FROM [metrc].[log_type] WHERE reference=@type_reference)

	/* throw error if log event type is not found. */
	IF (@id_type IS NULL)
	BEGIN
		DECLARE @msg VARCHAR(MAX) = CONCAT('Not a valid log event type reference: "', ISNULL(@type_reference, 'NULL'), '"')
		RAISERROR(@msg, 11, 1)
	END

	/* insert log event. */
	INSERT INTO [metrc].[log_event] (id_type, id_location, metrc_facility_license_number, metrc_api_user_key, metrc_request, metrc_response, notes, id_user)
	VALUES (@id_type, @id_location, @metrc_facility_license_number, @metrc_api_user_key, @metrc_request, @metrc_response, @notes, @id_user)
go

