CREATE PROCEDURE [leafly].[usp_upsert_leafly_category]
	@category_list VARCHAR(MAX) = '[]',
	@id_user INT
AS

	;WITH category_list AS (
		SELECT *
		FROM OPENJSON(@category_list)
		WITH (
			  id_category INT,
			  leafly_type VARCHAR(512)
		)
	)
	MERGE [leafly].[category] AS lc
	USING category_list AS cl
	ON cl.id_category = lc.id_category
	WHEN MATCHED THEN
	UPDATE SET lc.updated_by=@id_user, lc.date_updated=getutcdate(), lc.leafly_type=cl.leafly_type
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_category, leafly_type, created_by, updated_by) VALUES (cl.id_category, cl.leafly_type, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND lc.id_category = id_category THEN
	DELETE
	;

	EXEC [leafly].[usp_leafly_category_list]
go

