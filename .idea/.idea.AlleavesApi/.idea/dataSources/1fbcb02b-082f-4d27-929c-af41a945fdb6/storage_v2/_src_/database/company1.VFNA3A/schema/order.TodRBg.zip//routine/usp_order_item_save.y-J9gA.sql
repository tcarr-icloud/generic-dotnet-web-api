CREATE PROCEDURE [order].[usp_order_item_save]
	 @items VARCHAR(max)
	,@id_order INT
	,@id_user INT
	,@force BIT = 0
AS
	SET NOCOUNT ON
	--DROP TABLE IF EXISTS #items_t

	--DECLARE 
	--	 @items VARCHAR(max) = N'[
	--		{"id_inventory_item":1000,"id_brand":1001,"brand":"Test Brand","id_inventory_item_category":1003,"id_batch":1000,"id_area":1000,"id_vendor":1161,"id_strain":1000,"item":"Generic Pre-Roll","cost_of_good":null,"is_tax_exempt":false,"is_cannabis":true,"is_medicated":false,"is_adult_use":true,"is_medical_use":true,"id_tax_category":null,"id_delivery_route2":3,"id_uom_weight_useable":2,"id_uom_weight_net":null,"id_uom_gross_weight_useable":2,"uom":"Each","weight_useable":1,"weight_useable_uom":"Grams","weight_net":null,"gross_weight_useable":null,"thc":null,"thc_mg":null,"cbd":null,"cbd_mg":null,"item_thc":null,"item_thc_mg":null,"item_cbd":null,"item_cbd_mg":null,"ommu_form_name":null,"biotrack_form_name":null,"ommu_order_type_name":null,"is_low_thc_and_medical":false,"is_ommu_delivery_device":false,"sku":"SBTEST","discounts":[{"id_rule":1032,"amount":2}],"loyalties":[],"quantity":1,"rounded_quantity":null,"price":5,"pk":0,"discount":2,"taxable_discount":0,"price_post_item_discount":3,"price_post_item_loyalty":3,"loyalty":0,"price_post_order_discount":3,"price_post_order_loyalty":3,"price_post_all_adjustments":3,"taxes":null,"price_post_tax":3,"item_state_excise_tax_percentage":0,"item_local_excise_tax_percentage":0,"item_state_sales_tax_percentage":0,"item_local_sales_tax_percentage":0,"item_state_category_tax_percentage":0,"item_local_category_tax_percentage":0,"price_post_round":3},
	--		{"id_item":349201,"id_inventory_item":1000,"id_inventory_item_category":1003,"id_delivery_route2":3,"delivery_route2":"Whole Flower","item_group":"Generic Pre-Roll","item":"Generic Pre-Roll","inventory_category_path":"Whole Flower > Pre-Roll","uom":"Each","uom_short":"ea","weight_useable_uom":"Grams","weight_useable_uom_short":"g","id_batch":1000,"id_area":1000,"area":"Main Retail Area","batch":"B2022062200000001","manufactured_by":null,"metrc_package_label":null,"batch_split":"B2022062200000001","biotrack_barcode_id":null,"biotrack_inventory_type_id":null,"id_item_return":null,"discount":2,"taxable_discount":null,"sku":"SBTEST","loyalty":0,
	--		"quantity":3,"rounded_quantity":null,"price":5,"cost_of_good":null,"price_override":null,"price_override_otd":null,"price_override_reason":null,"price_post_item_discount":3,"price_post_item_loyalty":3,"price_post_order_discount":3,"price_post_order_loyalty":3,"price_post_round":3,"price_post_all_adjustments":3,"price_post_tax":3,"item_state_excise_tax_percentage":0,"item_local_excise_tax_percentage":0,"item_state_sales_tax_percentage":0,"item_local_sales_tax_percentage":0,"item_state_category_tax_percentage":0,"item_local_category_tax_percentage":0,"is_tax_exempt":false,"is_cannabis":true,"is_adult_use":true,"is_medical_use":true,"taxes":null,"id_tax_category":null,"id_strain":1000,"strain":"Good Strain","inventory_category":"Pre-Roll","inventory_brand":"Test Brand","returned":false,"discounts":[],"loyalties":[],"thc":null,"cbd":null,"thc_mg":null,"cbd_mg":null,"item_thc":null,"item_cbd":null,"item_thc_mg":null,"item_cbd_mg":null,"id_brand":1001,"brand":"Test Brand","id_vendor":1161,"inventory_vendor":"SKYTIDE LLC","weight_useable":1,"id_uom_weight_useable":2,"weight_net":null,"id_uom_weight_net":null,"gross_weight_useable":null,"id_uom_gross_weight_useable":2,"inventory_uom_type":"count","id_delivery_route":4,"delivery_route":"Pre-Roll","is_low_thc":false,"is_medicated":false,"is_smoking":false,"is_low_thc_and_medical":false,"id_ommu_form":null,"is_ommu_delivery_device":false,"ommu_form_name":null,"ommu_order_type_name":null,"biotrack_form_name":null,"item_barcode":"I0000100020220622","date_expire":"2032-11-13"}
	--	]'
	
	--	,@id_order INT = 179508
	--	,@id_user INT = 1
	--	,@force BIT = 0

	CREATE TABLE #items_t (
		 id INT PRIMARY KEY IDENTITY(1,1)
		,[id_item] INT
		,[id_order] INT
		,id_inventory_item INT
		,id_inventory_item_category INT
		,[id_batch] INT
		,[id_area] INT
		,[id_item_return] INT
		,[quantity] DECIMAL(18,4)
		,[rounded_quantity] DECIMAL(18,4)
		,[use_scale] BIT
		,uom VARCHAR(50)
		,weight_useable DECIMAL(18,4)
		,weight_useable_uom VARCHAR(50)
		,[price] DECIMAL(18,5)
		,[price_override] DECIMAL(18,2)
		,[price_override_otd] DECIMAL(18,2)
		,[price_override_reason] VARCHAR(max)
		,[price_post_item_discount] DECIMAL(18,5)
		,[price_post_item_loyalty] DECIMAL(18,5)
		,[price_post_order_discount] DECIMAL(18,5)
		,[price_post_order_loyalty] DECIMAL(18,5)
		,[price_post_round] DECIMAL(18,5)
		,[price_post_all_adjustments] DECIMAL(18,5)
		,[price_post_tax] DECIMAL(18,5)
		,[item_state_excise_tax_percentage] DECIMAL(18,5)
		,[item_local_excise_tax_percentage] DECIMAL(18,5)
		,[item_state_sales_tax_percentage] DECIMAL(18,5)
		,[item_local_sales_tax_percentage] DECIMAL(18,5)
		,[item_state_category_tax_percentage] DECIMAL(18,3)
		,[item_local_category_tax_percentage] DECIMAL(18,3)
		,[discount] DECIMAL(18,2)
		,[discount_overrides] VARCHAR(max)
		,[taxable_discount] DECIMAL(18, 2)
		,[loyalty] DECIMAL(18,2)
		,[is_tax_exempt] BIT
		,[is_medicated] BIT
		,[thc] DECIMAL(6,3)
		,[thc_mg] DECIMAL(18,3)
		,[cbd] DECIMAL(6,3)
		,[cbd_mg] DECIMAL(18,3)
		,[item_thc] DECIMAL(6,3)
		,[item_thc_mg] DECIMAL(18,3)
		,[item_cbd] DECIMAL(6,3)
		,[item_cbd_mg] DECIMAL(18,3)
		,[ommu_order_type_name] varchar(128)
		,[ommu_form_name] varchar(128)
		,[strain] VARCHAR(255)
		,discounts VARCHAR(max)
		,taxes VARCHAR(max)
		,[id_tax_category] INT
		,item_index INT
		,sku VARCHAR(255)
		,inventory_category varchar(255)
		,inventory_brand varchar(255)
		,inventory_vendor varchar(255)
		,inventory_uom_type varchar(50)
	)
	INSERT INTO #items_t
	SELECT 
		 i.id_item		
		, @id_order
		, i.id_inventory_item
		, i.id_inventory_item_category
		, i.id_batch
		, i.id_area
		, i.id_item_return
		, i.quantity
		, i.rounded_quantity
		, i.use_scale
		, i.uom
		, i.weight_useable
		, i.weight_useable_uom
		, i.price
		, i.price_override
		, i.price_override_otd
		, i.price_override_reason
		, i.price_post_item_discount
		, i.price_post_item_loyalty
		, i.price_post_order_discount
		, i.price_post_order_loyalty
		, i.price_post_round
		, i.price_post_all_adjustments
		, i.price_post_tax
		, i.item_state_excise_tax_percentage
		, i.item_local_excise_tax_percentage
		, i.item_state_sales_tax_percentage
		, i.item_local_sales_tax_percentage
		, i.item_state_category_tax_percentage
		, i.item_local_category_tax_percentage
		, i.discount
		, i.discount_overrides
		, i.taxable_discount
		, i.loyalty
		, i.is_tax_exempt
		, i.is_medicated
		, i.thc
		, i.thc_mg
		, i.cbd
		, i.cbd_mg
		, i.item_thc
		, i.item_thc_mg
		, i.item_cbd
		, i.item_cbd_mg
		, i.ommu_order_type_name
		, i.ommu_form_name
		, i.strain
		, i.discounts
		, i.taxes
		, i.id_tax_category
		, ROW_NUMBER() OVER(ORDER BY i.id_item) as item_index
		, i.sku
		, c.[name] as inventory_category
		, b.[name] as inventory_brand
		, v.[name] as inventory_vendor
		, iu.[quantity_type] as inventory_uom_type
	FROM OPENJSON(@items)	
	WITH (
		id_item INT '$.id_item',
		id_inventory_item INT '$.id_inventory_item',
		id_inventory_item_category INT '$.id_inventory_item_category',
		id_batch INT '$.id_batch',
		id_area INT '$.id_area',
		id_item_return INT '$.id_item_return',
		quantity DECIMAL(18,4) '$.quantity',
		rounded_quantity DECIMAL(18,4) '$.rounded_quantity',
		use_scale BIT '$.use_scale',
		uom VARCHAR(50) '$.uom',
		weight_useable DECIMAL(18,5) '$.weight_useable',
		weight_useable_uom VARCHAR(50) '$.weight_useable_uom',
		price DECIMAL(18,5) '$.price',
		price_override DECIMAL(18,2) '$.price_override',
		price_override_otd DECIMAL(18,2) '$.price_override_otd',
		price_override_reason VARCHAR(MAX) '$.price_override_reason',
		price_post_item_discount DECIMAL(18,5)'$.price_post_item_discount',
		price_post_item_loyalty DECIMAL(18,5)'$.price_post_item_loyalty',
		price_post_order_discount DECIMAL(18,5)'$.price_post_order_discount',
		price_post_order_loyalty DECIMAL(18,5)'$.price_post_order_loyalty',
		price_post_round DECIMAL(18,5)'$.price_post_round',
		price_post_all_adjustments DECIMAL(18,5)'$.price_post_all_adjustments',
		price_post_tax DECIMAL(18,5)'$.price_post_tax',
		item_state_excise_tax_percentage DECIMAL(18,5)'$.item_state_excise_tax_percentage',
		item_local_excise_tax_percentage DECIMAL(18,5)'$.item_local_excise_tax_percentage',
		item_state_sales_tax_percentage DECIMAL(18,5)'$.item_state_sales_tax_percentage',
		item_local_sales_tax_percentage DECIMAL(18,5)'$.item_local_sales_tax_percentage',
		item_state_category_tax_percentage DECIMAL(18,5)'$.item_state_category_tax_percentage',
		item_local_category_tax_percentage DECIMAL(18,5)'$.item_local_category_tax_percentage',
		discount DECIMAL(18,2) '$.discount',
		discount_overrides NVARCHAR(MAX) AS JSON,
		taxable_discount DECIMAL(18, 2) '$.taxable_discount',
		loyalty DECIMAL(18,2) '$.loyalty',
		is_tax_exempt BIT '$.is_tax_exempt',
		is_medicated BIT '$.is_medicated',
		thc DECIMAL(6,3) '$.thc',
		thc_mg DECIMAL(18,3) '$.thc_mg',
		cbd DECIMAL(6,3)'$.cbd',
		cbd_mg DECIMAL(18,3) '$.cbd_mg',
		item_thc DECIMAL(6,3) '$.item_thc',
		item_thc_mg DECIMAL(18,3) '$.item_thc_mg',
		item_cbd DECIMAL(6,3)'$.item_cbd',
		item_cbd_mg DECIMAL(18,3) '$.item_cbd_mg',
		ommu_order_type_name VARCHAR(128) '$.ommu_order_type_name',
		ommu_form_name VARCHAR(128) '$.ommu_form_name',
		strain VARCHAR(255) '$.strain',
		id_item_return INT '$.id_item_return',
		discounts NVARCHAR(MAX) AS JSON,
		taxes NVARCHAR(MAX) AS JSON,
		id_tax_category INT '$.id_tax_category',
		sku VARCHAR(255) '$.sku'
	) as i
	LEFT OUTER JOIN inventory.category c on i.id_inventory_item_category = c.id_category
	LEFT OUTER JOIN inventory.item it on it.id_item = i.id_inventory_item
	LEFT OUTER JOIN inventory.item_group ig on ig.id_item_group = it.id_item_group
	LEFT OUTER JOIN inventory.uom iu on iu.id_uom = ig.id_uom
	LEFT OUTER JOIN inventory.brand b on b.id_brand = ig.id_brand
	LEFT OUTER JOIN inventory.vendor v on v.id_vendor = ig.id_vendor
	
	/* Inventory Check */
	IF((SELECT COUNT(*) FROM #items_t WHERE id_item_return IS NULL) > 0 AND @force = 0)
	BEGIN
		IF EXISTS (			
			SELECT
				 i.id_batch
				,i.id_area
				,MIN(inv.quantity) as CurrentRemaining
				,SUM(oi.quantity) as Ordered
				,SUM(i.quantity) as Requested
				,MIN(inv.quantity) + SUM(oi.quantity) -	SUM(i.quantity) as AfterSale
			FROM #items_t i 
			LEFT OUTER JOIN [order].item oi on oi.id_item = i.id_item
			LEFT OUTER JOIN inventory.inventory inv on inv.id_batch = i.id_batch AND inv.id_area = i.id_area
			GROUP BY i.id_batch, i.id_area
			HAVING MIN(inv.quantity) + SUM(oi.quantity) - SUM(i.quantity) < 0
		)
			THROW 60000, 'Insufficent inventory',1;
	END

	DECLARE @output TABLE(
	  [action] varchar(20)
	, id_item_inserted INT
	, id_batch_inserted INT
	, id_area_inserted INT
	, id_item_return_inserted INT
	, quantity_inserted DECIMAL(18,4)
	, id_item_deleted INT
	, id_batch_deleted INT
	, id_area_deleted INT
	, id_item_return_deleted INT
	, quantity_deleted DECIMAL(18,4)
	)

	DECLARE @item_index INT = (SELECT MIN(item_index) FROM #items_t WHERE id_item IS NULL)
	
	/* Insert new items so we can capture PK */
	WHILE(EXISTS (SELECT * FROM #items_t WHERE item_index = @item_index))
	BEGIN
		INSERT INTO [order].item (
			id_order
			,id_inventory_item
			,id_inventory_item_category
			,id_batch
			,id_area
			,id_item_return
			,quantity
			,rounded_quantity
			,use_scale
			,uom
			,weight_useable
			,weight_useable_uom
			,price
			,price_override
			,price_override_reason
			,price_post_item_discount
			,price_post_item_loyalty
			,price_post_order_discount
			,price_post_order_loyalty
			,price_post_round
			,price_post_all_adjustments
			,price_post_tax
			,item_state_excise_tax_percentage
			,item_local_excise_tax_percentage
			,item_state_sales_tax_percentage
			,item_local_sales_tax_percentage
			,item_state_category_tax_percentage
			,item_local_category_tax_percentage
			,discount
			,discount_overrides
			,loyalty
			,is_tax_exempt
			,is_medicated
			,thc
			,thc_mg
			,cbd
			,cbd_mg
			,item_thc
			,item_thc_mg
			,item_cbd
			,item_cbd_mg
			,ommu_order_type_name
			,ommu_form_name
			,strain
			,taxes
			,id_tax_category
			,created_by
			,updated_by
			,sku
			,inventory_category
			,inventory_brand
			,inventory_vendor
			,inventory_uom_type
		) 
		SELECT 
			 @id_order
			,id_inventory_item
			,id_inventory_item_category
			,id_batch
			,id_area
			,id_item_return
			,quantity
			,rounded_quantity
			,use_scale
			,uom
			,weight_useable
			,weight_useable_uom
			,price
			,price_override
			,price_override_reason
			,price_post_item_discount
			,price_post_item_loyalty
			,price_post_order_discount
			,price_post_order_loyalty
			,price_post_round
			,price_post_all_adjustments
			,price_post_tax
			,item_state_excise_tax_percentage
			,item_local_excise_tax_percentage
			,item_state_sales_tax_percentage
			,item_local_sales_tax_percentage
			,item_state_category_tax_percentage
			,item_local_category_tax_percentage
			,discount
			,discount_overrides
			,loyalty
			,ISNULL(is_tax_exempt,0)
			,is_medicated
			,thc
			,thc_mg
			,cbd
			,cbd_mg
			,item_thc
			,item_thc_mg
			,item_cbd
			,item_cbd_mg
			,ommu_order_type_name
			,ommu_form_name
			,strain
			,taxes
			,id_tax_category
			,@id_user
			,@id_user
			,sku
			,inventory_category
			,inventory_brand
			,inventory_vendor
			,inventory_uom_type
		FROM #items_t WHERE item_index = @item_index
		
		DECLARE @id_item INT = SCOPE_IDENTITY();

		UPDATE #items_t 
		SET id_item = @id_item
		WHERE item_index = @item_index
		SET @item_index = (SELECT MIN(item_index) FROM #items_t WHERE id_item IS NULL AND item_index > @item_index)
		
		DECLARE @id_item_return INT = (SELECT id_item_return FROM #items_t WHERE id_item = @id_item)

		/* Return logging will be hanlded on order cash out*/
		IF(@id_item_return IS NOT NULL) CONTINUE
		
		DECLARE @id_batch INT = (SELECT id_batch FROM #items_t WHERE id_item = @id_item)
		DECLARE @id_area INT = (SELECT id_area FROM #items_t WHERE id_item = @id_item)
		DECLARE @quantity DECIMAL(18,4) = (SELECT quantity FROM #items_t WHERE id_item = @id_item)*-1
		DECLARE @add_note varchar(50) = CONCAT('OrderID: ', @id_order)

		EXEC [log].usp_event_create  'order_add',@id_batch=@id_batch, @id_area=@id_area, @adjustment=@quantity, @notes = @add_note, @id_user=@id_user
	END
	
	/* UPDATE */
	UPDATE t
	SET 
		t.quantity=s.quantity,
			t.rounded_quantity=s.rounded_quantity,
			t.use_scale = s.use_scale,
			t.uom=s.uom,
			t.weight_useable=s.weight_useable,
			t.weight_useable_uom=s.weight_useable_uom,
			t.price=s.price,
			t.price_override=s.price_override,
			t.price_override_reason=s.price_override_reason,
			t.price_post_item_discount=s.price_post_item_discount,
			t.price_post_item_loyalty=s.price_post_item_loyalty,
			t.price_post_order_discount=s.price_post_order_discount,
			t.price_post_order_loyalty=s.price_post_order_loyalty,
			t.price_post_round=s.price_post_round,
			t.price_post_all_adjustments=s.price_post_all_adjustments,
			t.price_post_tax=s.price_post_tax,
			t.item_state_excise_tax_percentage=s.item_state_excise_tax_percentage,
			t.item_local_excise_tax_percentage=s.item_local_excise_tax_percentage,
			t.item_state_sales_tax_percentage=s.item_state_sales_tax_percentage,
			t.item_local_sales_tax_percentage=s.item_local_sales_tax_percentage,
			t.item_state_category_tax_percentage=s.item_state_category_tax_percentage,
			t.item_local_category_tax_percentage=s.item_local_category_tax_percentage,
			t.discount=s.discount,
			t.discount_overrides=s.discount_overrides,
			t.loyalty=s.loyalty,
			t.taxes=s.taxes,
			t.id_tax_category=s.id_tax_category,
			t.ommu_order_type_name=s.ommu_order_type_name,
			t.ommu_form_name=s.ommu_form_name,
			t.thc_mg=s.thc_mg,
			t.cbd_mg=s.cbd_mg,
			t.thc=s.thc,
			t.cbd=s.cbd,
			t.item_thc_mg=s.item_thc_mg,
			t.item_cbd_mg=s.item_cbd_mg,
			t.item_thc=s.item_thc,
			t.item_cbd=s.item_cbd,
			t.updated_by=@id_user,
			t.date_updated=getutcdate(),	
			t.sku=s.sku	
	OUTPUT 
		'UPDATE' as [action],
		inserted.id_item,
		inserted.id_batch,
		inserted.id_area,
		inserted.id_item_return,
		inserted.quantity,
		deleted.id_item,
		deleted.id_batch,
		deleted.id_area,
		deleted.id_item_return,
		deleted.quantity
	INTO @output
	FROM [order].item t
	INNER JOIN #items_t s ON s.id_item = t.id_item
	WHERE 
		(
			(ISNULL(t.quantity, 0)<>ISNULL(s.quantity, 0)) OR
			(ISNULL(t.rounded_quantity, 0)<>ISNULL(s.rounded_quantity, 0)) OR
			(ISNULL(t.uom, '')<>ISNULL(s.uom, '')) OR
			(ISNULL(t.weight_useable, 0)<>ISNULL(s.weight_useable, 0)) OR
			(ISNULL(t.weight_useable_uom, '')<>ISNULL(s.weight_useable_uom, '')) OR
			(ISNULL(t.price, 0)<>ISNULL(s.price, 0)) OR
			(ISNULL(t.discount, 0)<>ISNULL(s.discount, 0)) OR
			(ISNULL(t.loyalty, 0)<>ISNULL(s.loyalty, 0)) OR
			(ISNULL(t.price_override, 0) <> ISNULL(s.price_override, 0)) OR
			(ISNULL(t.price_override_reason, '') <> ISNULL(s.price_override_reason,'')) OR 
			(ISNULL(t.price_post_item_discount, 0)<>ISNULL(s.price_post_item_discount, 0)) OR
			(ISNULL(t.price_post_item_loyalty, 0)<>ISNULL(s.price_post_item_loyalty, 0)) OR
			(ISNULL(t.price_post_order_discount, 0)<>ISNULL(s.price_post_order_discount, 0)) OR
			(ISNULL(t.price_post_order_loyalty, 0)<>ISNULL(s.price_post_order_loyalty, 0)) OR
			(ISNULL(t.price_post_round, 0)<>ISNULL(s.price_post_round, 0)) OR
			(ISNULL(t.price_post_all_adjustments, 0)<>ISNULL(s.price_post_all_adjustments, 0)) OR
			(ISNULL(t.price_post_tax, 0)<>ISNULL(s.price_post_tax, 0)) OR
			(ISNULL(t.item_state_excise_tax_percentage, 0)<>ISNULL(s.item_state_excise_tax_percentage, 0)) OR
			(ISNULL(t.item_local_excise_tax_percentage, 0)<>ISNULL(s.item_local_excise_tax_percentage, 0)) OR
			(ISNULL(t.item_state_sales_tax_percentage, 0)<>ISNULL(s.item_state_sales_tax_percentage, 0)) OR
			(ISNULL(t.item_local_sales_tax_percentage, 0)<>ISNULL(s.item_local_sales_tax_percentage, 0)) OR
			(ISNULL(t.item_state_category_tax_percentage, 0)<>ISNULL(s.item_state_category_tax_percentage, 0)) OR
			(ISNULL(t.item_local_category_tax_percentage, 0)<>ISNULL(s.item_local_category_tax_percentage, 0)) OR
			(ISNULL(t.taxes, '')<>ISNULL(s.taxes, '')) OR
			(ISNULL(t.id_tax_category, -1)<>ISNULL(s.id_tax_category, -1)) OR
			(ISNULL(t.ommu_order_type_name, '')<>ISNULL(s.ommu_order_type_name, '')) OR
			(ISNULL(t.ommu_form_name, '')<>ISNULL(s.ommu_form_name, '')) OR
			(ISNULL(t.thc_mg, -1)<>ISNULL(s.thc_mg, -1)) OR
			(ISNULL(t.cbd_mg, -1)<>ISNULL(s.cbd_mg, -1)) OR
			(ISNULL(t.thc, -1)<>ISNULL(s.thc, -1)) OR
			(ISNULL(t.cbd, -1)<>ISNULL(s.cbd, -1)) OR
			(ISNULL(t.item_thc_mg, -1)<>ISNULL(s.item_thc_mg, -1)) OR
			(ISNULL(t.item_cbd_mg, -1)<>ISNULL(s.item_cbd_mg, -1)) OR
			(ISNULL(t.item_thc, -1)<>ISNULL(s.item_thc, -1)) OR
			(ISNULL(t.item_cbd, -1)<>ISNULL(s.item_cbd, -1)) OR
			(ISNULL(t.sku, '')<>ISNULL(s.sku, '')) OR
			(ISNULL(t.discount_overrides, '')<>ISNULL(s.discount_overrides, ''))
		)
		AND t.id_order = @id_order;

	DECLARE @add_modify VARCHAR(max) = (SELECT 
		id_batch_inserted as id_batch, 
		id_area_inserted as id_area, 
		CASE WHEN id_item_return_inserted IS NULL 
			THEN (quantity_inserted-ISNULL(quantity_deleted,0))*-1 
			ELSE (quantity_inserted-ISNULL(quantity_deleted,0))
		END as adjustment
	FROM @output WHERE [action] IN ('INSERT','UPDATE')
	AND CASE WHEN id_item_return_inserted IS NULL 
			THEN (quantity_inserted-ISNULL(quantity_deleted,0))*-1 
			ELSE (quantity_inserted-ISNULL(quantity_deleted,0))
		END <> 0 
	FOR JSON PATH)

	/* DELETE */
	DELETE t
	OUTPUT 
		'DELETE' as [action],
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		deleted.id_item,
		deleted.id_batch,
		deleted.id_area,
		deleted.id_item_return,
		deleted.quantity
	INTO @output
	FROM [order].item t
	WHERE NOT EXISTS (
		SELECT 1
		FROM #items_t s
		WHERE s.id_item = t.id_item
	)
	AND t.id_order = @id_order;

	DECLARE @remove VARCHAR(MAX) = (SELECT 
		id_batch_deleted as id_batch, 
		id_area_deleted as id_area, 
		CASE WHEN id_item_return_deleted IS NULL THEN quantity_deleted ELSE quantity_deleted*-1 END as adjustment 
	FROM @output WHERE [action] = 'DELETE'
	FOR JSON PATH)

	/* add adjustments and events. */
	DECLARE @note varchar(50) = CONCAT('OrderID: ', @id_order)
	EXEC [log].usp_event_create_bulk 'order_add', @note, @add_modify, @id_user
	EXEC [log].usp_event_create_bulk 'order_remove', @note, @remove, @id_user

	/* Update Discounts */
	MERGE [order].[item_discount] as t
	USING (SELECT
		 i.id_item
		,d.id_item_discount
		,d.id_discount
		,d.id_rule
		,d.amount
		,d.line_item_discount
	FROM #items_t i
	CROSS APPLY (
		SELECT * FROM OPENJSON((
		SELECT 
			discounts 
		FROM #items_t 
		WHERE id_item = i.id_item)) 
		WITH (
			id_item_discount INT '$.id_item_discount', 
			id_discount INT '$.id_discount', 
			id_rule INT '$.id_rule', 
			amount DECIMAL(18,2) '$.amount',
			line_item_discount BIT '$.line_item_discount'
		)
	) d(id_item_discount, id_discount, id_rule, amount, line_item_discount)) as s
	ON t.id_item_discount = s.id_item_discount
	WHEN MATCHED AND ISNULL(s.amount, 0) <> ISNULL(t.amount,0) OR s.line_item_discount <> t.line_item_discount	THEN UPDATE
	SET 
		t.amount = s.amount,
		t.line_item_discount = s.line_item_discount
	WHEN NOT MATCHED BY TARGET THEN INSERT (id_order, id_item, id_discount, id_rule, amount, line_item_discount)
	VALUES(@id_order, s.id_item, s.id_discount, s.id_rule, s.amount, s.line_item_discount)
	WHEN NOT MATCHED BY SOURCE AND t.id_order = @id_order THEN DELETE;
go

