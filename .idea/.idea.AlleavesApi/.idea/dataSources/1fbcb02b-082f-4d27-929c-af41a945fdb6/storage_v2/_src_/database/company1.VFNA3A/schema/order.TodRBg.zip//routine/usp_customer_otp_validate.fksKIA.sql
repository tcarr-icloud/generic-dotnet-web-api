CREATE 
 PROCEDURE [order].[usp_customer_otp_validate] @id_customer int,
                                                    @otp varchar(10)
AS

select *
from [order].customer_otp
where otp = @otp
  and id_customer = @id_customer
  and expiry_date > getutcdate()
go

