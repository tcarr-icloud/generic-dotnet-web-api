CREATE PROCEDURE [order].[usp_delivery_route_position_update]
                    @id_delivery_route INT,
                    @ride_list VARCHAR(MAX),
                    @start_time VARCHAR(MAX),
					@list_eta VARCHAR(MAX),
					@delivery_end_eta VARCHAR(MAX)
AS
    BEGIN
        DECLARE @ride_list_table TABLE(rideId INT)
		DECLARE @list_eta_table TABLE(eta_value VARCHAR(MAX))
        DECLARE @id_ride INT
        DECLARE @position INT = 1

        INSERT @ride_list_table(rideId)
        SELECT value FROM STRING_SPLIT(@ride_list, ',')

		INSERT INTO @list_eta_table(eta_value)
		SELECT value FROM STRING_SPLIT(@list_eta, ',')
        
        UPDATE [order].[delivery_route]
	    SET delivery_start_time=@start_time,delivery_end_eta=@delivery_end_eta
        WHERE id_delivery_route=@id_delivery_route

        WHILE(1 = 1)
            BEGIN
                SET @id_ride = NULL
                SELECT TOP(1) @id_ride = rideId
                FROM @ride_list_table

                IF @id_ride IS NULL
                BREAK

				DECLARE @eta_value VARCHAR(MAX)
				SELECT TOP(1) @eta_value = eta_value
				FROM @list_eta_table

                  UPDATE [order].[ride_delivery_route]
	              SET position=@position,eta = @eta_value
	              WHERE id_delivery_route=@id_delivery_route
                  AND id_ride = @id_ride
                  SET @position = @position + 1
                DELETE TOP(1) FROM @ride_list_table
                WHERE rideId = @id_ride

				DELETE TOP(1) FROM @list_eta_table
				WHERE eta_value = @eta_value
            END
    END
go

