CREATE PROCEDURE [base].[usp_profile_update]
	@id_user INT = NULL,
	@email_update VARCHAR(256) = NULL,
	@email_confirmed BIT = 0,
	@password VARCHAR(128) = NULL,
	@phone VARCHAR(128) = NULL,
	@pin VARCHAR(128) = NULL

AS
SET NOCOUNT ON;

	IF(@email_update IS NOT NULL AND @email_confirmed = 0)
	BEGIN
		UPDATE [base].[user]
	    SET EmailUpdate=@email_update,
			EmailConfirmed=@email_confirmed
		WHERE id_user=@id_user
	END
	
	IF(@phone IS NOT NULL)
	BEGIN
		UPDATE [base].[user]
		SET PhoneNumber = @phone
		WHERE id_user=@id_user
	END
	
	IF(@pin IS NOT NULL)
	BEGIN
		UPDATE [base].[user]
		SET PIN=ISNULL(@pin, PIN)
		WHERE id_user=@id_user
	END
	
	IF(@password IS NOT NULL)
	BEGIN
		UPDATE [base].[user]
		SET PasswordHash=ISNULL(@password, PasswordHash),
			PasswordResetDate=dateadd(DD, 90, getutcdate())
		WHERE id_user=@id_user
	END

	/* return updated user. */
	EXEC base.usp_user_list @id_user, 1
go

