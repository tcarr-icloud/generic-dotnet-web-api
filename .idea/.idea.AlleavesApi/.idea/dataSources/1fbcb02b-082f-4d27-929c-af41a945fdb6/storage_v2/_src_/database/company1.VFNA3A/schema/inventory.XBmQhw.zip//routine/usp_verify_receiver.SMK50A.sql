CREATE PROCEDURE inventory.usp_verify_receiver
	@id_user INT,
	@id_location_destination INT
AS
BEGIN
	SET NOCOUNT ON;
	SELECT
		*
	FROM base.user_location 
	WHERE id_user=@id_user and id_location=@id_location_destination;
END
go

