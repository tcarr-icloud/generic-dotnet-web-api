CREATE PROCEDURE [grow].[usp_plant_salvage]
	@id_area INT,
	@plant_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	SET NOCOUNT ON
	
	;WITH grid ([row], [column], sequence) AS (
		SELECT b.[row], a.[column], ROW_NUMBER() OVER(ORDER BY b.[row] ASC) - 1 AS sequence
		FROM (
			SELECT [column] = number 
			FROM master..[spt_values] 
			WHERE type='P' AND number BETWEEN 1 AND (SELECT columns FROM inventory.area WHERE id_area=@id_area)
		) a
		CROSS JOIN (
			SELECT [row] = number 
			FROM master..[spt_values] 
			WHERE type='P' AND number BETWEEN 1 AND (SELECT rows FROM inventory.area WHERE id_area=@id_area)
		) b
		LEFT JOIN grow.plant p ON p.[row]=b.[row] AND 
								  p.[column]=a.[column] AND 
								  p.harvested = 0 AND
								  p.destroyed = 0 AND
								  p.id_area=@id_area
		WHERE p.id_plant IS NULL
	)

	/* update plant. */
	UPDATE p
	SET p.id_area=@id_area
		, p.[row]=g.[row]
		, p.[column]=g.[column]
		, p.destroyed=0
		, p.id_destroy_reason=null
		, p.date_destroyed=null
		, p.destroy_description=null
		, p.id_user_updated=@id_user
		, p.date_updated=getutcdate()
	FROM grow.plant p
	JOIN (
		SELECT value AS id_plant
				, [key] AS sequence
		FROM OPENJSON(@plant_list)
	) l ON l.id_plant=p.id_plant
	LEFT JOIN grid g ON g.sequence=l.sequence


	/* add log event. */
	DECLARE @list VARCHAR(MAX) = (
					SELECT id_plant
							, id_area
							, [row]
							, [column]
					FROM grow.plant
					WHERE id_plant IN (SELECT value AS id_plant FROM OPENJSON(@plant_list))
					FOR JSON PATH)

	EXEC grow.usp_event_create_bulk 'salvage', NULL, NULL, NULL, NULL, @list, @id_user
go

