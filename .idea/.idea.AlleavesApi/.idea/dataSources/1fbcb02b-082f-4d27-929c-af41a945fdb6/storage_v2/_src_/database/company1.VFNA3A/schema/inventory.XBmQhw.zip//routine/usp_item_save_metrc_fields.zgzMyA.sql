CREATE PROCEDURE [inventory].[usp_item_save_metrc_fields]
	@id_item INT,
	@id_location INT,
	@metrc_item_id INT,
	@metrc_category VARCHAR(255),
	@metrc_name VARCHAR(255),
	@metrc_brand VARCHAR(255),
	@id_user INT
AS
	UPDATE inventory.item
	SET metrc_category = @metrc_category
		, metrc_item_id = @metrc_item_id
		, id_user_updated = @id_user
		, date_updated = GETUTCDATE()
	WHERE id_item = @id_item

	IF EXISTS (SELECT * FROM inventory.item_location WHERE id_item=@id_item AND id_location=@id_location)
	BEGIN
		UPDATE inventory.item_location
		SET metrc_item_id = @metrc_item_id
			, metrc_category = @metrc_category
			, metrc_name = @metrc_name
			, metrc_brand = @metrc_brand
			, id_user_updated = @id_user
			, date_updated = GETUTCDATE()
		WHERE id_item=@id_item AND id_location=@id_location
	END
	ELSE
	BEGIN
		INSERT INTO inventory.item_location (id_location, id_item, metrc_item_id, metrc_category, metrc_name, metrc_brand, id_user_created, id_user_updated)
		VALUES (@id_location, @id_item, @metrc_item_id, @metrc_category, @metrc_name, @metrc_brand, @id_user, @id_user)
	END
go

