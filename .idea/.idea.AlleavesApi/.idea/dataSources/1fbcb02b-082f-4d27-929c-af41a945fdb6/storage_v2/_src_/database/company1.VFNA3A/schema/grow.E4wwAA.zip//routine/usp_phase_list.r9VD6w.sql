CREATE PROCEDURE [grow].[usp_phase_list]
AS
	SELECT p.id_phase
			, p.name AS phase
			, p.sequence
	FROM grow.phase p
	ORDER BY p.sequence
go

