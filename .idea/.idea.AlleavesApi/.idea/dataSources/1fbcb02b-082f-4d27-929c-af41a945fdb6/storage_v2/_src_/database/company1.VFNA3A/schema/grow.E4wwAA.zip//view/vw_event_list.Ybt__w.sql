CREATE VIEW [grow].[vw_event_list]
	AS 
SELECT e.id_event
		, e.id_type
		, e.id_plant
		, a.id_location
		, e.id_area
		, e.[row]
		, e.[column]
		, t.reference AS event_reference
		, t.label AS event
		, p.name AS plant
		, l.name AS location
		, a.path AS area
		, grow.fn_grid_label(e.[row], e.[column]) AS grid
		, e.notes
		, e.id_user_created
		, CONCAT(u.FirstName, ' ', u.LastName) AS user_created
		, e.date_created
		, CAST(e.date_created AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as local_datetime_created
FROM grow.event e
JOIN grow.event_type t ON t.id_type=e.id_type
JOIN grow.plant p ON p.id_plant=e.id_plant
JOIN inventory.vw_area_list a ON a.id_area=e.id_area
JOIN base.location l ON l.id_location=a.id_location
JOIN base.[user] u ON u.id_user=e.id_user_created
LEFT OUTER JOIN [dbo].[tz_lookup] as tl ON l.[timezone] = tl.[tz_iana]
go

