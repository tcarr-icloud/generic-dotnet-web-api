/**
 * File: usp_customer_id_path.sql
 * -----
 * Created Date: Tuesday March 14th 2023
 * Author: Vineetha
 * -----
 * Last Modified: Tue Mar 14 2023
 * Modified By: Vineetha
 * @packageDocumentation
 */

CREATE PROCEDURE [order].[usp_customer_id_path]
	@id_customer INT = NULL,
	@driver_license_front VARCHAR(200) = NULL,
	@driver_license_back VARCHAR(200) = NULL,
	@patient_id_front VARCHAR(200) = NULL,
	@patient_id_back VARCHAR(200) = NULL
AS 
BEGIN
	SET NOCOUNT ON;
	UPDATE [order].customer
	SET
	driver_license_front = @driver_license_front,
	driver_license_back = @driver_license_back,
	patient_id_front = @patient_id_front,
	patient_id_back = @patient_id_back
	WHERE id_customer =  @id_customer
END
go

