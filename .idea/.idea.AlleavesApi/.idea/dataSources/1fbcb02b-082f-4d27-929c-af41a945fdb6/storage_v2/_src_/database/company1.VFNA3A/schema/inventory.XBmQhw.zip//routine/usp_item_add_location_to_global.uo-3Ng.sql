CREATE PROCEDURE [inventory].[usp_item_add_location_to_global]
	@id_location INT,
	@id_user INT
AS
	INSERT INTO inventory.item_location (id_item, id_location, id_user_created, id_user_updated)
	SELECT i.id_item 
		, @id_location AS id_location
		, @id_user AS id_user_created
		, @id_user AS id_user_updated
	FROM inventory.item_group g
	JOIN inventory.item i ON i.id_item_group=g.id_item_group
	LEFT JOIN inventory.item_location l ON l.id_item=i.id_item AND l.id_location=@id_location
	WHERE g.is_global=1 AND l.id_location IS NULL
go

