CREATE   PROCEDURE [dbo].[usp_admin_user_create]
	@name_first VARCHAR(128),
	@name_last VARCHAR(128),
	@username VARCHAR(128),
	@password VARCHAR(128),
	@phone VARCHAR(128),
	@pin VARCHAR(128)
AS
	SET NOCOUNT ON;

	INSERT INTO [base].[user] (FirstName, LastName, Email, PhoneNumber, UserName, PasswordHash, PIN, PasswordReset, EmailConfirmed, PhoneNumberConfirmed, TwoFactorEnabled, LockoutEnabled, AccessFailedCount) 
	VALUES
		(@name_first, @name_last, @username, @phone, @username, @password, @pin, 1, 0, 0, 0, 0, 0)

	SELECT id_user AS id_user
			, FirstName AS name_first
			, LastName AS name_last
			, UserName AS username
	FROM [base].[user]
	WHERE id_user=SCOPE_IDENTITY()
go

