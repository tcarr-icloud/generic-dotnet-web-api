
CREATE PROCEDURE [customer].[usp_customer_list] @page INT = 1
	,@page_size INT = 100
	,@sort VARCHAR(max) = NULL
	,@filter VARCHAR(max) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	/*
		This code cleans up any duplicates that may have occured from customer profile merges
	*/
	;WITH DuplicateRecords
	AS (
		SELECT id_customer_merge
			,ROW_NUMBER() OVER (
				PARTITION BY id_customer
				,id_merging_customer ORDER BY date_created
				) AS RowNumber
		FROM [order].customer_merge
		WHERE deleted_merge = 0
		)
	DELETE
	FROM [order].customer_merge
	WHERE id_customer_merge IN (
			SELECT id_customer_merge
			FROM DuplicateRecords
			WHERE RowNumber > 1
			);

	/*
		End clean up code
	*/

	DECLARE @select NVARCHAR(MAX)

	SET @select = 'SELECT * FROM (
		SELECT
			 c.id_customer
			,c.weedmaps_id
			,c.dispense_id
			,c.iheartjane_id
			,c.name_first
			,c.name_middle
			,c.name_last
			,c.name_preferred
			,ISNULL(c.name_first, '''') + '' '' + ISNULL(c.name_last, '''') as customer_name  
			,c.gender   
			,c.date_of_birth
			,c.patient_number
			,c.expiration_date
			,c.referral_date
			,c.id_file_patient
			,c.phone
			,c.phone2
			,c.email
			,c.drivers_license
			,c.address1
			,c.address2
			,c.city
			,c.state
			,c.zip
			,c.id_user_online
			,c.deleted
			,c.is_caregiver
			,c.caregiver_license_number
			,c.is_employee
			,c.is_banned
			,c.ban_expires
			,(SELECT COUNT(1) FROM [order].[customer] c2 ' + ISNULL(' WHERE ' + NULLIF(@filter, ''), '') + ') AS total_rows
		FROM [order].[customer] c
	) records'

	DECLARE @sql NVARCHAR(max) = @select + ISNULL(' WHERE ' + NULLIF(@filter, ''), '') + ISNULL(' ORDER BY' + NULLIF(@sort, ''), ' ORDER BY id_customer')

	-- Paging
	SET @sql = @sql + ' OFFSET ' + CAST(((@page - 1) * @page_size) AS VARCHAR(10)) + ' ROWS FETCH NEXT ' + CAST((@page_size) AS VARCHAR(10)) + ' ROWS ONLY
	
	OPTION(RECOMPILE);'

	EXEC sp_executesql @sql
END
go

