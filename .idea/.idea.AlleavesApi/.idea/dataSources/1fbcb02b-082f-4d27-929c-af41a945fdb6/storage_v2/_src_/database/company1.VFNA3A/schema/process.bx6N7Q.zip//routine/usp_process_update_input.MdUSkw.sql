CREATE PROCEDURE [process].[usp_process_update_input]
	@id_process INT,
	@input_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	/* set up input list. */
	DROP TABLE IF EXISTS #input_list
	SELECT l.* 
			, ISNULL(i.id_process_input, NULL) AS id_process_input_orig
			, i.id_batch AS id_batch_orig
			, i.id_area AS id_area_orig
			, i.quantity AS quantity_orig
	INTO #input_list
	FROM (
		SELECT @id_process AS id_process
				, *
		FROM OPENJSON(@input_list)
		WITH (
			id_process_input INT,
			id_form_input INT,
			id_batch INT,
			id_area INT,
			quantity DECIMAL(18,4)
		)
		WHERE id_batch IS NOT NULL AND id_area IS NOT NULL AND quantity>0
	) l
	FULL OUTER JOIN process.process_input i ON i.id_process_input=l.id_process_input
	WHERE ISNULL(i.id_process, @id_process)=@id_process


	/* adjust inventory and add log events. ------------------------------------------------------------------------------------------ */

	/* create list of inventory return (increment) events. */
	DROP TABLE IF EXISTS #return_list
	SELECT id_batch_orig AS id_batch
			, id_area_orig AS id_area
			, CASE WHEN id_process_input IS NOT NULL AND id_batch=id_batch_orig AND id_area=id_area_orig AND quantity<>quantity_orig
				   THEN quantity_orig-quantity
				   ELSE quantity_orig END
				   AS adjustment
	INTO #return_list
	FROM #input_list
	WHERE (id_process_input IS NULL AND id_process_input_orig IS NOT NULL) OR -- deleted input
		  (id_process_input IS NOT NULL AND (id_batch<>id_batch_orig OR id_area<>id_area_orig)) OR -- batch/area changed (return original quantity)
		  (id_process_input IS NOT NULL AND id_batch=id_batch_orig AND id_area=id_area_orig AND quantity_orig-quantity>0) -- original quantity is higher than new quantity

	/* create list of inventory use (decrement) events. */
	DROP TABLE IF EXISTS #use_list
	SELECT id_batch AS id_batch
			, id_area AS id_area
			, CASE WHEN id_process_input IS NOT NULL AND id_batch=id_batch_orig AND id_area=id_area_orig AND quantity<>quantity_orig
				   THEN quantity_orig-quantity
				   ELSE -quantity END
				   AS adjustment
	INTO #use_list
	FROM #input_list
	WHERE (id_process_input IS NULL AND id_process_input_orig IS NULL) OR -- new input
		  (id_process_input IS NOT NULL AND id_batch<>id_batch_orig OR id_area<>id_area_orig) OR -- batch/area changed (add new quantity)
		  (id_process_input IS NOT NULL AND id_batch=id_batch_orig AND id_area=id_area_orig AND quantity_orig-quantity<0) -- original quantity is lower than new quantity

	DECLARE @return_list VARCHAR(MAX) = (SELECT * FROM #return_list FOR JSON PATH), 
			@use_list VARCHAR(MAX) = (SELECT * FROM #use_list FOR JSON PATH)
			
	/* add log events and update inventory. */
	EXEC [log].usp_event_create_bulk 'process_input_return', NULL, @return_list, @id_user
	EXEC [log].usp_event_create_bulk 'process_input_use', NULL, @use_list, @id_user

	
	/* merge input table. ------------------------------------------------------------------------------------------ */

	DELETE FROM #input_list WHERE id_process_input IS NULL AND id_process_input_orig IS NOT NULL

	MERGE process.process_input t
	USING #input_list s
	ON t.id_process_input=s.id_process_input
	WHEN MATCHED THEN 
		UPDATE SET t.id_batch=s.id_batch, t.id_area=s.id_area, t.quantity=s.quantity, t.updated_by=@id_user, t.date_updated=getutcdate()
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_process, id_form_input, id_batch, id_area, quantity, created_by, updated_by) VALUES (s.id_process, s.id_form_input, s.id_batch, s.id_area, s.quantity, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND t.id_process=@id_process THEN DELETE
	;


	/* return updated process. */
	EXEC process.usp_process_list @id_process
go

