CREATE PROCEDURE[acl].[usp_role_list] 
	@id_role int = NULL ,
	@include_deleted BIT = 0
AS
	SET NOCOUNT ON;

	SELECT r.id_role
			, r.name AS role
			, ISNULL((SELECT rp.id_role_permission						
								, p.id_permission
								, p.id_parent
								, m.id_module
								, ISNULL(m.name, 'Uncategorized') AS module
								, p.reference
								, p.label 
								, ISNULL(rp.allowed, 0) AS allowed
					  FROM acl.permission p
					  LEFT JOIN (SELECT t.* FROM acl.role_permission t WHERE t.id_role=r.id_role) rp ON rp.id_permission=p.id_permission
					  LEFT JOIN acl.module m ON m.id_module=p.id_module
					  FOR JSON PATH
			), '[]') AS permission_list
	FROM acl.role r
	WHERE r.id_role=ISNULL(@id_role, r.id_role) AND 
		  r.deleted<=@include_deleted
go

