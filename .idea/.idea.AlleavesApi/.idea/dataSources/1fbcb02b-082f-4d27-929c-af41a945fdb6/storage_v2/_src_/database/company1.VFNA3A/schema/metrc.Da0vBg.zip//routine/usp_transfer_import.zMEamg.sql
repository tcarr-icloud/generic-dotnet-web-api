CREATE PROCEDURE [metrc].[usp_transfer_import]
	@id_location INT,
	@id_area INT,
	@transfer_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	DECLARE @id_transfer_import INT,
			@id_transfer INT,

			/* manifest variables. */
			@manifest_number VARCHAR(255),
			@manifest_vendor VARCHAR(512),
			@date_received DATETIME,
			@package_count INT,
			@item_list VARCHAR(MAX),

			/* item variables. */
			@is_new_item BIT,
			@metrc_item_id BIGINT,
			@item VARCHAR(512),
			@metrc_uom VARCHAR(64),
			@uom VARCHAR(64),
			@weight_useable DECIMAL(18,4),
			@weight_useable_uom VARCHAR(64),
			@gross_weight_useable DECIMAL(18,4),
			@gross_weight_useable_uom VARCHAR(64),
			@id_delivery_route INT,
			@vendor VARCHAR(512),
			@brand VARCHAR(512),
			@metrc_category VARCHAR(512),
			@metrc_name VARCHAR(512),
			@category VARCHAR(512),
			@strain VARCHAR(512),
			@is_adult_use BIT,
			@is_medical_use BIT,
			@cost_of_good DECIMAL(18,4),
			@price_retail_medical_use DECIMAL(18,4),
			@price_retail_adult_use DECIMAL(18,4),
			@tax_category VARCHAR(512),
			@metrc_package_label VARCHAR(255),
			@quantity DECIMAL(18,4),
			@date_harvest DATETIME,
			@test_lab VARCHAR(512),
			@test_date DATETIME,
			@date_expire DATETIME,
			@cost DECIMAL(18,4),
			@thc VARCHAR(64),
			@thc_mg VARCHAR(64),
			@cbd VARCHAR(64),
			@cbd_mg VARCHAR(64),
			@cbg VARCHAR(64),
			@cbn VARCHAR(64),
			@cbc VARCHAR(64),
			@product_description VARCHAR(MAX),
			@vendor_batch_id VARCHAR(255),

			/* item ids. */
			@id_uom INT,
			@id_uom_metrc INT,
			@id_item INT,
			@id_item_group INT,
			@id_batch INT,
			@notes VARCHAR(64),
	        @id_brand int,
            @id_category int,
	        @id_strain int,
	        @id_tax_category int,
	        @id_vendor int,
	        @id_uom_weight_useable int,
	        @id_uom_gross_weight_useable int,
			@id_test_result INT,
			@metrc_state VARCHAR(16) = (SELECT TOP 1 state FROM base.location WHERE id_location=@id_location)


	/* create new import. */
	INSERT INTO metrc.transfer_import (id_user_created) VALUES (@id_user)
	SET @id_transfer_import=SCOPE_IDENTITY()


	/* loop through transfers. */
	DECLARE c CURSOR FOR (
		SELECT * FROM OPENJSON(@transfer_list)
		WITH (
			manifest_number VARCHAR(255),
			vendor VARCHAR(512),
			date_received DATETIME,
			package_count INT,
			item_list NVARCHAR(MAX) AS JSON
		)
	)
	OPEN c
	FETCH NEXT FROM c INTO @manifest_number, @manifest_vendor, @date_received, @package_count, @item_list

	WHILE @@FETCH_STATUS = 0 BEGIN

		/* get or create metrc transfer. */
		SET @id_transfer=(SELECT TOP 1 id_transfer FROM metrc.transfer WHERE manifest_number=@manifest_number)
		IF (@id_transfer IS NULL)
		BEGIN
			INSERT INTO metrc.transfer (id_location, manifest_number, vendor, package_count, date_received)
			VALUES (@id_location, @manifest_number, @manifest_vendor, @package_count, @date_received)

			SET @id_transfer=SCOPE_IDENTITY()
		END

		/* loop through packages. */
		DECLARE d CURSOR FOR (
			SELECT * FROM OPENJSON(@item_list)
			WITH (
				is_new_item BIT,
				id_item INT,
				metrc_item_id BIGINT,
				item VARCHAR(512),
				metrc_uom VARCHAR(64),
				uom VARCHAR(64),
				weight_useable DECIMAL(18,4),
				weight_useable_uom VARCHAR(64),
				gross_weight_useable DECIMAL(18,4),
				gross_weight_useable_uom VARCHAR(64),
				id_delivery_route INT,
				vendor VARCHAR(512),
				brand VARCHAR(512),
				metrc_category VARCHAR(512),
				metrc_name VARCHAR(512),
				category VARCHAR(512),
				strain VARCHAR(512),
				is_adult_use BIT,
				is_medical_use BIT,
				cost_of_good DECIMAL(18,4),
				price_retail_medical_use DECIMAL(18,4),
				price_retail_adult_use DECIMAL(18,4),
				tax_category VARCHAR(512),
				metrc_package_label VARCHAR(255),
				quantity DECIMAL(18,4),
				date_harvest DATETIME,
				test_lab VARCHAR(512),
				test_date DATETIME,
				date_expire DATETIME,
				cost DECIMAL(18,4),
				thc VARCHAR(64),
				thc_mg VARCHAR(64),
				cbd VARCHAR(64),
				cbd_mg VARCHAR(64),
				cbg VARCHAR(64),
				cbn VARCHAR(64),
				cbc VARCHAR(64),
				product_description VARCHAR(MAX),
				vendor_batch_id VARCHAR(255)
			)
		)
		OPEN d
		FETCH NEXT FROM d INTO @is_new_item, @id_item, @metrc_item_id, @item, @metrc_uom, @uom, @weight_useable, @weight_useable_uom, @gross_weight_useable, @gross_weight_useable_uom, @id_delivery_route, @vendor, @brand, @metrc_category, @metrc_name, @category, @strain,
							   @is_adult_use, @is_medical_use, @cost_of_good, @price_retail_medical_use, @price_retail_adult_use, @tax_category, @metrc_package_label, @quantity, @date_harvest, @test_lab, @test_date, @date_expire, @cost, @thc, @thc_mg, @cbd, @cbd_mg, @cbg, @cbn, @cbc, @product_description, @vendor_batch_id
		WHILE @@FETCH_STATUS = 0 BEGIN

			/* get ids. */
			-- SET @id_item=(
			-- 	SELECT TOP 1 id_item FROM inventory.item_location 
			-- 	WHERE metrc_item_id=@metrc_item_id 
			-- 	AND id_location IN 
			-- 		(
			-- 			SELECT id_location FROM [base].[location] 
			-- 			WHERE [state] = (SELECT [state] FROM [base].[location] WHERE id_location = @id_location)
			-- 		)
			-- 	)
			SET @id_brand=(SELECT TOP 1 id_brand FROM inventory.brand WHERE name = @brand)
			SET @id_category=(SELECT TOP 1 id_category from inventory.category where name = @category)
			SET @id_strain=(SELECT TOP 1 id_strain from grow.strain where name = @strain)
			SET @id_tax_category=(SELECT TOP 1 id_tax_category from tax.category where name = @tax_category)
			SET @id_vendor=(SELECT TOP 1 id_vendor from inventory.vendor where name = @vendor)
			SET @id_uom=(SELECT TOP 1 id_uom FROM inventory.uom WHERE name=@uom)
			SET @id_uom_weight_useable=(SELECT TOP 1 id_uom from inventory.uom where name=@weight_useable_uom)
			SET @id_uom_gross_weight_useable=(SELECT TOP 1 id_uom from inventory.uom where name=@gross_weight_useable_uom)
			SET @id_uom_metrc=(SELECT TOP 1 id_uom from inventory.uom where name=@metrc_uom)

			/* create or update item. */
			IF (@id_item IS NULL)
			BEGIN
				/* create item group. */
				INSERT INTO inventory.item_group (name, id_location, is_global, id_uom, id_uom_receiving, id_uom_weight_useable,
													units_per_received, batch_required, is_product, is_cannabis, id_delivery_route, 
													is_adult_use, is_medical_use, id_user_created, id_user_updated,
													id_category, id_brand, id_tax_category, id_strain, id_vendor, product_description)
				VALUES (@item, @id_location, 0, @id_uom, @id_uom, @id_uom_weight_useable,
						1, 1, 1, 1, @id_delivery_route,
						@is_adult_use, @is_medical_use, @id_user, @id_user,
						@id_category, @id_brand, @id_tax_category, @id_strain, @id_vendor, @product_description)

				SET @id_item_group=SCOPE_IDENTITY()

				/* create item. */
				INSERT INTO inventory.item (id_item_group, cost_of_good, price_retail_adult_use, price_retail_medical_use, weight_useable, gross_weight_useable, id_uom_gross_weight_useable, id_user_created, id_user_updated)
				VALUES (@id_item_group, @cost_of_good, @price_retail_adult_use, @price_retail_medical_use, @weight_useable, @gross_weight_useable, @id_uom_gross_weight_useable, @id_user, @id_user)

				SET @id_item=SCOPE_IDENTITY()

				/* add location to current item. */
				INSERT INTO inventory.item_location (id_item, id_location, cost_of_good, price_retail_adult_use, price_retail_medical_use, metrc_item_id, metrc_name, metrc_category, id_user_created, id_user_updated)
				VALUES (@id_item, @id_location, @cost_of_good, @price_retail_adult_use, @price_retail_medical_use, @metrc_item_id, @metrc_name, @metrc_category, @id_user, @id_user)
			END
			ELSE
			BEGIN
				/* update item. */
				SET @id_item_group=(SELECT TOP 1 id_item_group FROM inventory.item WHERE id_item=@id_item)

				UPDATE inventory.item_group 
				SET name=@item
					, id_category=@id_category
					, id_uom=@id_uom
					, id_uom_receiving=@id_uom
					, id_uom_weight_useable=@id_uom_weight_useable
					, id_brand=@id_brand
					, is_adult_use=@is_adult_use
					, is_medical_use=@is_medical_use
					, id_tax_category=@id_tax_category
					, id_strain=@id_strain
					, id_vendor=@id_vendor 
					, id_user_updated=@id_user
					, date_updated = GETUTCDATE()
				WHERE id_item_group = @id_item_group

				UPDATE inventory.item 
				SET cost_of_good=@cost_of_good
					, price_retail_adult_use=@price_retail_adult_use
					, price_retail_medical_use=@price_retail_medical_use
					, weight_useable=@weight_useable 
					, id_user_updated = @id_user
					, date_updated = GETUTCDATE()
				WHERE id_item = @id_item

				/* add location to item if needed. */
				IF NOT EXISTS (SELECT 1 FROM inventory.item_location WHERE id_location = @id_location AND id_item=@id_item)
				BEGIN
					INSERT INTO inventory.item_location (id_item, id_location, metrc_item_id, metrc_name, metrc_category, id_user_created, id_user_updated)
					VALUES (@id_item, @id_location, @metrc_item_id, @metrc_name, @metrc_category, @id_user, @id_user)
				END
				/* update location prices if necessary. */
				ELSE
					UPDATE inventory.item_location
					SET cost_of_good=@cost_of_good
						, price_retail_adult_use=@price_retail_adult_use
						, price_retail_medical_use=@price_retail_medical_use
						, id_user_updated=@id_user
						, date_updated=GETUTCDATE()
					WHERE id_item=@id_item AND id_location=@id_location

			END

			/* find or create batch. */
			SET @id_batch=(SELECT TOP 1 id_batch FROM inventory.batch WHERE metrc_package_label=@metrc_package_label)
			IF (@id_batch IS NULL)
			BEGIN
				SET @id_uom=(SELECT TOP 1 id_uom FROM inventory.uom WHERE name=@uom)

				/* create batch. */
				INSERT INTO inventory.batch (id_item, name, initial_quantity,date_harvest, date_expire, metrc_package_label, metrc_item_id, metrc_state, vendor_batch_id, id_uom_metrc, created_by, updated_by, cost_of_good)
				VALUES (@id_item, @metrc_package_label, @quantity, @date_harvest, @date_expire, @metrc_package_label, @metrc_item_id, @metrc_state, @vendor_batch_id, @id_uom_metrc, @id_user, @id_user, CASE WHEN @cost IS NULL OR @quantity=0 OR @quantity IS NULL THEN NULL ELSE @cost / @quantity END)

				SET @id_batch=SCOPE_IDENTITY()
			END
			-- TODO: recalculate cost of good cost if batch exists?

			/* add test results. */
			IF (@thc IS NOT NULL OR @thc_mg IS NOT NULL OR @cbd IS NOT NULL OR @cbd_mg IS NOT NULL OR @cbg IS NOT NULL OR @cbn IS NOT NULL OR @cbc IS NOT NULL)
			BEGIN
				SET @id_test_result = (SELECT TOP 1 id_test_result FROM inventory.test_result WHERE id_batch=@id_batch)

				IF @id_test_result IS NULL
					INSERT INTO inventory.test_result (id_batch,test_lab, test_date, created_by, updated_by) VALUES (@id_batch, @test_lab, @test_date, @id_user, @id_user)

					SET @id_test_result = (SELECT TOP 1 id_test_result FROM inventory.test_result WHERE id_batch=@id_batch)

					--THC %
					IF (@thc IS NOT NULL)
						INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
						VALUES (2, @id_test_result, @thc, 0, @id_user, @id_user)

					--THC mg
					IF (@thc_mg IS NOT NULL)
						INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
						VALUES (60, @id_test_result, @thc_mg, 0, @id_user, @id_user)

					--CBD %
					IF (@cbd IS NOT NULL)
						INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
						VALUES (1, @id_test_result, @cbd, 0, @id_user, @id_user)

					--CBD mg
					IF (@cbd_mg IS NOT NULL)
						INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
						VALUES (61, @id_test_result, @cbd_mg, 0, @id_user, @id_user)

					--CBG
					IF (@cbg IS NOT NULL)
						INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
						VALUES (10, @id_test_result, @cbg, 0, @id_user, @id_user)
					
					--CBN
					IF (@cbn IS NOT NULL)
						INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
						VALUES (14, @id_test_result, @cbn, 0, @id_user, @id_user)
					
					--CBC
					IF (@cbc IS NOT NULL)
						INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
						VALUES (3, @id_test_result, @cbc, 0, @id_user, @id_user)

				ELSE
						UPDATE inventory.test_result SET test_lab=@test_lab, test_date=@test_date, date_updated=GETUTCDATE(), updated_by=@id_user WHERE id_test_result=@id_test_result

					--THC %
					IF (@thc IS NOT NULL)
					BEGIN
						IF (SELECT TOP 1 id_test_result_chemical_profile FROM inventory.test_result_chemical_profile WHERE id_chemical_profile=2 AND id_test_result=@id_test_result) IS NOT NULL
							UPDATE inventory.test_result_chemical_profile SET [value]=@thc WHERE id_chemical_profile=2 AND id_test_result=@id_test_result
						ELSE
							INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
							VALUES (2, @id_test_result, @thc, 0, @id_user, @id_user)
					END

					--THC mg
					IF (@thc_mg IS NOT NULL)
					BEGIN
						IF (SELECT TOP 1 id_test_result_chemical_profile FROM inventory.test_result_chemical_profile WHERE id_chemical_profile=60 AND id_test_result=@id_test_result) IS NOT NULL
							UPDATE inventory.test_result_chemical_profile SET [value]=@thc_mg WHERE id_chemical_profile=60 AND id_test_result=@id_test_result
						ELSE
							INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
							VALUES (60, @id_test_result, @thc_mg, 0, @id_user, @id_user)
					END

					--CBD %
					IF (@cbd IS NOT NULL)
					BEGIN
						IF (SELECT TOP 1 id_test_result_chemical_profile FROM inventory.test_result_chemical_profile WHERE id_chemical_profile=1 AND id_test_result=@id_test_result) IS NOT NULL
							UPDATE inventory.test_result_chemical_profile SET [value]=@cbd WHERE id_chemical_profile=1 AND id_test_result=@id_test_result
						ELSE
							INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
							VALUES (1, @id_test_result, @cbd, 0, @id_user, @id_user)
					END

					--CBD mg
					IF (@cbd_mg IS NOT NULL)
					BEGIN
						IF (SELECT TOP 1 id_test_result_chemical_profile FROM inventory.test_result_chemical_profile WHERE id_chemical_profile=61 AND id_test_result=@id_test_result) IS NOT NULL
							UPDATE inventory.test_result_chemical_profile SET [value]=@cbd_mg WHERE id_chemical_profile=61 AND id_test_result=@id_test_result
						ELSE
							INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
							VALUES (61, @id_test_result, @cbd_mg, 0, @id_user, @id_user)
					END

					--CBG
					IF (@cbg IS NOT NULL)
					BEGIN
						IF (SELECT TOP 1 id_test_result_chemical_profile FROM inventory.test_result_chemical_profile WHERE id_chemical_profile=10 AND id_test_result=@id_test_result) IS NOT NULL
							UPDATE inventory.test_result_chemical_profile SET [value]=@cbg WHERE id_chemical_profile=10 AND id_test_result=@id_test_result
						ELSE
							INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
							VALUES (10, @id_test_result, @cbg, 0, @id_user, @id_user)
					END

					--CBN
					IF (@cbn IS NOT NULL)
					BEGIN
						IF (SELECT TOP 1 id_test_result_chemical_profile FROM inventory.test_result_chemical_profile WHERE id_chemical_profile=14 AND id_test_result=@id_test_result) IS NOT NULL
							UPDATE inventory.test_result_chemical_profile SET [value]=@cbn WHERE id_chemical_profile=14 AND id_test_result=@id_test_result
						ELSE
							INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
							VALUES (14, @id_test_result, @cbn, 0, @id_user, @id_user)
					END

					--CBC
					IF (@cbc IS NOT NULL)
					BEGIN
						IF (SELECT TOP 1 id_test_result_chemical_profile FROM inventory.test_result_chemical_profile WHERE id_chemical_profile=3 AND id_test_result=@id_test_result) IS NOT NULL
							UPDATE inventory.test_result_chemical_profile SET [value]=@cbc WHERE id_chemical_profile=3 AND id_test_result=@id_test_result
						ELSE
							INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, deleted, id_user_created, id_user_updated)
							VALUES (3, @id_test_result, @cbc, 0, @id_user, @id_user)
					END
			END

			/* add item to inventory. */
			SET @notes=CONCAT('TransferImportID: ', @id_transfer_import)
			EXEC [log].usp_event_create 'metrc_transfer_import', @id_batch, @id_area, @quantity, @notes, @id_user

			/* create row for transfer_item. */
			INSERT INTO metrc.transfer_item (id_transfer, id_transfer_import, id_batch, item, package_label, vendor_batch_id, quantity, uom, cost, is_new_item)
			VALUES (@id_transfer, @id_transfer_import, @id_batch, @item, @metrc_package_label, @vendor_batch_id, @quantity, @uom, @cost, @is_new_item)


			FETCH NEXT FROM d INTO @is_new_item, @id_item, @metrc_item_id, @item, @metrc_uom, @uom, @weight_useable, @weight_useable_uom, @gross_weight_useable, @gross_weight_useable_uom, @id_delivery_route, @vendor, @brand, @metrc_category, @metrc_name, @category, @strain,
								   @is_adult_use, @is_medical_use, @cost_of_good, @price_retail_medical_use, @price_retail_adult_use, @tax_category, @metrc_package_label, @quantity, @date_harvest, @test_lab, @test_date, @date_expire, @cost, @thc, @thc_mg, @cbd, @cbd_mg, @cbg, @cbn, @cbc, @product_description, @vendor_batch_id
		END

		CLOSE d
		DEALLOCATE d


		FETCH NEXT FROM c INTO @manifest_number, @manifest_vendor, @date_received, @package_count, @item_list
	END

	CLOSE c
	DEALLOCATE c

	SELECT @id_transfer_import AS id_transfer_import
go

