CREATE PROCEDURE [grow].[usp_plant_destroy]
	@id_destroy_reason INT,
	@destroy_description VARCHAR(MAX),
	@plant_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	UPDATE grow.plant
	SET id_destroy_reason=@id_destroy_reason
		, destroy_description=@destroy_description
		, destroyed=1
		, date_destroyed=GETUTCDATE()
		, date_updated=GETUTCDATE()
		, id_user_updated=@id_user
	WHERE id_plant IN (SELECT value FROM OPENJSON(@plant_list))

	/* add log event. */
	DECLARE @list VARCHAR(MAX) = (
					SELECT id_plant
							, id_area
							, [row]
							, [column]
					FROM grow.plant
					WHERE id_plant IN (SELECT value AS id_plant FROM OPENJSON(@plant_list))
					FOR JSON PATH),
			@notes VARCHAR(MAX) = CONCAT(
						(SELECT name FROM grow.destroy_reason WHERE id_destroy_reason=@id_destroy_reason),
						CASE WHEN @destroy_description IS NOT NULL THEN CONCAT('; ', @destroy_description) ELSE '' END)

	EXEC grow.usp_event_create_bulk 'destroy', NULL, NULL, NULL, @notes, @list, @id_user

	/* return destroyed plants. */
	EXEC grow.usp_plant_list NULL, NULL, NULL, NULL, NULL, NULL, @plant_list
go

