CREATE PROCEDURE [metrc].[usp_tag_list]
	@id_location INT = NULL,
	@only_available BIT = 0,
	@tag_type VARCHAR(64) = NULL,
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
    SET NOCOUNT ON;
	
	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = '	
	SELECT *
	FROM (
		SELECT t.id_location
				, l.name AS location
				, t.tag
				, t.tag_type
				, CAST((CASE WHEN b.metrc_package_label IS NOT NULL THEN 0
					   WHEN p.metrc_label IS NOT NULL THEN 0
					   ELSE t.is_available END) AS BIT) AS is_available
				, t.date_loaded
				, CASE WHEN t.date_used IS NULL AND b.metrc_package_label IS NOT NULL THEN b.date_created
					   WHEN t.date_used IS NULL AND p.metrc_label IS NOT NULL THEN COALESCE(p.date_vegetative, p.date_preflower, p.date_flower, NULL)
					   ELSE t.date_used END AS date_used
				, b.id_batch
				, p.id_plant
		FROM metrc.tag t
		JOIN base.location l ON l.id_location = t.id_location

		/* check for tag use in existing package. */
		LEFT JOIN (
			SELECT b.*
			FROM inventory.batch b
			JOIN inventory.inventory i ON i.id_batch=b.id_batch
			JOIN inventory.area a ON a.id_area=i.id_area AND a.id_location=' + CAST(@id_location AS VARCHAR(16)) + '
		) b ON b.metrc_package_label=t.tag AND t.tag_type like ''%package%''

		/* check for tag use in plant. */
		LEFT JOIN (
			SELECT p.*
			FROM grow.plant p
			JOIN inventory.area a ON a.id_area=p.id_area AND a.id_location=' + CAST(@id_location AS VARCHAR(16)) + '
		) p ON p.metrc_label=t.tag AND t.tag_type like ''%plant%''
	) inventory'

	SET @where = 'WHERE id_location = '+ ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location')	
	SET @where = @where + ' AND [tag_type] = ' + CASE WHEN @tag_type IS NOT NULL THEN CONCAT('''', @tag_type, '''') ELSE '[tag_type]' END
	IF (@only_available IS NOT NULL AND @only_available = 1)
		SET @where = @where + ' AND is_available = 1'
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'tag')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order


	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

