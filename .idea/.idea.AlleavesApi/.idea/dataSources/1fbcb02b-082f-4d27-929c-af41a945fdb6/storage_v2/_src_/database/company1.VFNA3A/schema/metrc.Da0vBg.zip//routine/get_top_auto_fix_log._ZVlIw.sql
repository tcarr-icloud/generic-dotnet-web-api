CREATE PROCEDURE [metrc].[get_top_auto_fix_log]
    @id_order INT
AS
    SELECT TOP 1 id_log FROM metrc.auto_fix_log WHERE id_order=@id_order
    ORDER BY created_at DESC
go

