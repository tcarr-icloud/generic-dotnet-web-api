CREATE PROCEDURE [metrc].[usp_export_save_metrc_fields]
	@id_export INT,
	@metrc_id INT,
	@metrc_name VARCHAR(512),
	@id_user INT
AS
	UPDATE metrc.export
	SET metrc_id = @metrc_id
		, metrc_name = @metrc_name
	WHERE id_export = @id_export

	EXEC metrc.usp_export_fetch @id_export
go

