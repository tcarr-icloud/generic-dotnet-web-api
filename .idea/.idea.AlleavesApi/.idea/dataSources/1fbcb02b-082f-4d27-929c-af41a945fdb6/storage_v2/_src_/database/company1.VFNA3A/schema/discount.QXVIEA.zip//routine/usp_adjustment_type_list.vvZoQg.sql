CREATE PROCEDURE [discount].[usp_adjustment_type_list]
AS
	SELECT id_adjustment_type
			, name AS adjustment_type
			, reference AS adjustment_type_reference
	FROM discount.adjustment_type
go

