CREATE PROCEDURE [inventory].[usp_uom_create]
	@name VARCHAR(64),
	@name_short VARCHAR(64) = NULL,
	@id_user INT
AS
	SET NOCOUNT ON;

	INSERT INTO inventory.uom (name, name_short, id_user_created, id_user_updated) VALUES
		(@name, ISNULL(@name_short, @name), @id_user, @id_user)

	SELECT u.id_uom
			, u.name AS uom
			, u.name_short AS uom_short
			, deleted
	FROM inventory.uom u
	WHERE u.id_uom=SCOPE_IDENTITY()
go

