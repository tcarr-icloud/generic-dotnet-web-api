CREATE PROCEDURE [inventory].[usp_inventory_fetch]
	@id_location INT = NULL,
    @id_area INT = NULL,
    @id_item INT = NULL,
    @id_batch INT = NULL,
    @is_adult_use BIT = NULL,
    @is_medical_use BIT = NULL,
    @include_scrap BIT = 0,
	@include_zero BIT = 0,
	@include_closed BIT = 0
AS
    SET NOCOUNT ON;

/* Stop Parameter Sniffing */
DECLARE @id_location_L INT
DECLARE @id_area_L INT
DECLARE @id_item_L INT
DECLARE @id_batch_L INT
DECLARE @is_adult_use_L BIT
DECLARE @is_medical_use_L BIT
DECLARE @include_scrap_L BIT

SELECT @id_location_L = @id_location
SELECT @id_area_L = @id_area
SELECT @id_item_L = @id_item
SELECT @id_batch_L = @id_batch
SELECT @is_adult_use_L = @is_adult_use
SELECT @is_medical_use_L = @is_medical_use
SELECT @include_scrap_L = @include_scrap

SELECT 
    l.id_location
    , c.id_category
    , ig.id_tax_category
    , a.id_area
    , i.id_item_group
    , i.id_item
    , b.id_batch
    , ig.id_brand
    , s.id_strain
    , tr.id_test_result
    , l.name AS location
    , c.name AS category
    , c.path AS category_path
    , tc.name AS tax_category
    , RTRIM(CONCAT(ig.name, ' ', (
			    SELECT STRING_AGG(av.name, ' ') 
			    FROM inventory.item_attribute_value iav
			    LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
			    WHERE iav.id_item=i.id_item)
		    )) AS item
    , i.barcode item_barcode
    , i.sku
    , b.name AS batch
    , base.fn_barcode_human_readable(b.name) AS batch_split
    , ISNULL(CAST((SELECT TOP 1 trcp.[value]
		FROM inventory.test_result_chemical_profile trcp
		LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
		WHERE icp.id_chemical_profile=2 AND trcp.id_test_result=tr.id_test_result) / 100.0 AS DECIMAL(6, 5)), NULL) as thc
	, ISNULL(CAST((SELECT TOP 1 trcp.[value]
		FROM inventory.test_result_chemical_profile trcp
		LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
		WHERE icp.id_chemical_profile=1 AND trcp.id_test_result=tr.id_test_result) / 100.0 AS DECIMAL(6, 5)), NULL) as cbd
	, ISNULL(CAST((SELECT TOP 1 trcp.[value]
		FROM inventory.test_result_chemical_profile trcp
		LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
		WHERE icp.id_chemical_profile = 60 AND trcp.id_test_result=tr.id_test_result) AS DECIMAL(18,3)), NULL) as thc_mg
	, ISNULL(CAST((SELECT TOP 1 trcp.[value]
		FROM inventory.test_result_chemical_profile trcp
		LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
		WHERE icp.id_chemical_profile = 61 AND trcp.id_test_result=tr.id_test_result) AS DECIMAL(18,3)), NULL) as cbd_mg
    , b.vendor_batch_id
    , tr.coa_s3_key
    , bs.name AS batch_status
    , s.name AS strain
    , a.name AS area
    , a.path AS area_path
    , atp.name AS area_type
    , atp.reference AS area_type_reference
    , ast.name AS area_status
    , inv.quantity
    , cinv.ordered as sold
    , cinv.on_hand
    , inv.quantity as available
    , CASE WHEN atp.reference = 'retail' THEN inv.quantity ELSE 0 END as ready_to_sell
    , u.name AS uom
    , u.name_short AS uom_short
    , ig.threshold_low_quantity
    , ig.threshold_low_quantity_selected
	, ig.is_tax_exempt
    , ig.is_cannabis
    , CAST(
        CASE
            WHEN ISNULL(ig.is_adult_use, 0) = 1 THEN 1
            WHEN ISNULL(ig.is_medical_use, 0) = 1 THEN 1
            ELSE 0
        END as bit) as is_medicated
    , ISNULL(ig.is_adult_use, 0) as is_adult_use
    , ISNULL(ig.is_medical_use, 0) as is_medical_use
    , i.external_id
    , i.metrc_item_id
    , i.metrc_category
    , i.biotrack_barcode_id
    , i.biotrack_inventory_type_id
    , biot.name as biotrack_inventory_type_name
	, biot.requires_weighing as biotrack_requires_weighing
    , ig.is_product
    , br.[name] as brand
    , ISNULL(ilp.location_price_of_good, i.cost_of_good) as cost_of_good
    , ISNULL(ilp.location_retail_price, i.price_retail) as price_retail
	, CONVERT(VARCHAR(32), b.date_created, 127) AS date_received
    , CAST(b.date_production AS VARCHAR(16)) AS date_production
    , CASE WHEN ig.has_shelf_life=1 THEN CAST(ISNULL(b.date_expire, DATEADD(day, ig.shelf_life_days, b.date_production)) AS VARCHAR(16)) ELSE NULL END AS date_expire
    , (SELECT MIN(pp.date_started)
    FROM grow.batch_plant bp
    JOIN grow.plant p ON p.id_plant=bp.id_plant
    JOIN grow.plant_phase pp ON pp.id_plant=p.id_plant
       WHERE bp.id_batch=b.id_batch AND p.harvested=1 AND pp.id_phase=6) as date_harvest
    , CASE WHEN b.name IS NOT NULL THEN b.date_created ELSE NULL END AS date_received
    , ISNULL(
    (SELECT 
        id_media,
        content,
        [type]
    FROM inventory.item_media
    WHERE item_media.id_item_group = i.id_item_group
    FOR JSON PATH
    ),
    '[]') as media_list
	, ig.allergens
	, ig.ingredients_list
	, ig.nutritional_information
    --, ISNULL((SELECT p.id_plant
    -- , p.id_strain
    -- , s.id_strain_type
    -- , p.name AS plant
    -- , s.name AS strain
    -- , st.name AS strain_type
    -- , (SELECT pp.id_phase
    -- , ph.name AS phase
    -- , pp.date_started
    -- FROM grow.plant_phase pp
    -- JOIN grow.phase ph ON ph.id_phase=pp.id_phase
    -- WHERE pp.id_plant=p.id_plant
    -- ORDER BY ph.sequence
    -- FOR JSON PATH
    -- ) AS phase_list
    -- FROM grow.batch_plant bp
    -- JOIN grow.plant p ON p.id_plant=bp.id_plant
    -- JOIN grow.strain s ON s.id_strain=p.id_strain
    -- JOIN grow.strain_type st ON st.id_strain_type=s.id_strain_type
    -- WHERE bp.id_batch=b.id_batch
    -- FOR JSON PATH
    -- ), '[]') AS plant_list
FROM inventory.item i
LEFT OUTER JOIN inventory.item_group ig on i.id_item_group = ig.id_item_group
LEFT OUTER JOIN inventory.batch b on i.id_item = b.id_item
INNER JOIN inventory.inventory inv on inv.id_batch = b.id_batch
INNER JOIN inventory.vw_area_list a ON a.id_area=inv.id_area
LEFT OUTER JOIN base.[location] l on l.id_location = a.id_location
LEFT OUTER JOIN inventory.vw_category_list c ON c.id_category=ISNULL(ig.id_category, (SELECT TOP 1 id_category FROM inventory.category WHERE LOWER([name]) = 'uncategorized'))
LEFT OUTER JOIN tax.category tc ON tc.id_tax_category=ig.id_tax_category
INNER JOIN inventory.uom u ON u.id_uom=ig.id_uom
LEFT OUTER JOIN inventory.test_result tr on tr.id_batch = b.id_batch
LEFT OUTER JOIN inventory.area_type atp ON atp.id_area_type=a.id_area_type
LEFT OUTER JOIN inventory.status bs ON bs.id_status=b.id_status
LEFT OUTER JOIN inventory.status ast ON ast.id_status=a.id_status
LEFT OUTER JOIN grow.strain s ON s.id_strain=b.id_strain
LEFT OUTER JOIN inventory.brand br on br.id_brand = ig.id_brand
LEFT OUTER JOIN biotrack.inventory_type biot ON biot.id_inventory_type=i.biotrack_inventory_type_id
LEFT JOIN inventory.item_location_price ilp ON
i.id_item=ilp.id_inventory_item AND l.id_location=ilp.id_location
AND (
(
(ig.is_adult_use IS NULL OR ig.is_medical_use=@is_medical_use_L)
OR (ig.is_medical_use IS NULL OR ig.is_adult_use=@is_adult_use_L)
OR (@is_medical_use_L IS NULL OR ig.is_adult_use=@is_adult_use_L)
OR (@is_adult_use_L IS NULL OR ig.is_medical_use=@is_medical_use_L)
)
OR (
(ig.is_adult_use IS NULL OR ig.is_adult_use=0)
AND (ig.is_medical_use IS NULL OR ig.is_medical_use=0)
)
)
AND ((ilp.is_adult_use=ISNULL(@is_adult_use_L, 0) AND ilp.is_medical_use=ISNULL(@is_medical_use_L, 0))
OR (ilp.is_adult_use=0 AND ilp.is_medical_use=0))
LEFT OUTER JOIN inventory.vw_current_inventory as cinv on cinv.id_area = a.id_area and cinv.id_batch = b.id_batch
    WHERE (@id_item_L IS NULL OR i.id_item=@id_item_L) AND
 (@id_location_L IS NULL OR l.id_location=@id_location_L) AND
 (@id_area_L IS NULL OR a.id_area=@id_area_L) AND
 (@id_batch_L IS NULL OR b.id_batch=@id_batch_L) AND
 (@include_closed=1 OR (@include_closed=0 AND b.id_status=1)) AND
 (@include_zero=1 OR (@include_zero=0 AND cinv.on_hand>0)) AND
 (@include_scrap_L = 0 OR atp.reference = 'scrap')
go

