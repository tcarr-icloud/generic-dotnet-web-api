CREATE PROCEDURE [inventory].[usp_brand_upsert]
	@id_brand INT = NULL,
    @name VARCHAR (128),
	@deleted BIT = 0,
	@id_user INT

AS
	IF EXISTS (SELECT * FROM inventory.brand WHERE deleted=0 AND @deleted<>1 AND name=@name AND (@id_brand IS NULL OR id_brand <> @id_brand))
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A brand with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	IF (@id_brand IS NULL)
	BEGIN
		INSERT INTO [inventory].[brand] ([name], id_user_created, id_user_updated)
		VALUES (@name, @id_user, @id_user)

		SET @id_brand=SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		UPDATE [inventory].[brand]
		SET [name] = @name
			, deleted = @deleted
			, id_user_updated = @id_user
			, date_updated=GETUTCDATE()
		WHERE id_brand = @id_brand
	END

	EXEC [inventory].[usp_brand_list] @id_brand, 1
go

