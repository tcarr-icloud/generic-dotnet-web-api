CREATE PROCEDURE external_blaze.usp_blaze_id_list
                                         @id_order_blaze VARCHAR(200),
                                         @order_type VARCHAR(255),
                                         @date DATE,
                                         @discount_total DECIMAL(18, 2),
                                         @sub_total DECIMAL(18, 2),
                                         @total DECIMAL(18, 2),
                                         @tender_type VARCHAR(255),
                                         @store_address VARCHAR(200)
AS
BEGIN
	SELECT id_order_blaze,id_order
	FROM external_blaze.[order]
    WHERE id_order_blaze=@id_order_blaze AND order_type = @order_type AND date = @date AND discount_total =@discount_total
    AND sub_total = @sub_total AND total = @total AND tender_type = @tender_type AND store_address = @store_address
END
go

