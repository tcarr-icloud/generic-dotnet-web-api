CREATE PROCEDURE [process].[usp_update_bom]
	@id_bom_group INT,
	@id_item INT,
	@quantity DECIMAL(18,4),
	@item_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	SET NOCOUNT ON;

	/* upsert bom group. */
	;WITH bom_group AS (
		SELECT @id_bom_group AS id_bom_group
				, @id_item AS id_item
				, @quantity AS quantity
	)
	MERGE process.bom_group t
	USING bom_group s
	ON s.id_bom_group=t.id_bom_group
	WHEN MATCHED THEN UPDATE SET t.id_item=s.id_item, t.quantity=s.quantity
	WHEN NOT MATCHED BY TARGET THEN INSERT (id_item, quantity) VALUES (s.id_item, s.quantity)
	WHEN NOT MATCHED BY SOURCE AND t.id_bom_group=@id_bom_group THEN UPDATE SET t.deleted=1
	;

	IF(@id_bom_group IS NULL)
		SET @id_bom_group=SCOPE_IDENTITY();

	/* upsert bom items. */
	;WITH item_list AS (
		SELECT id_bom_item
				, @id_bom_group AS id_bom_group
				, id_item
		FROM OPENJSON(@item_list)
		WITH (
			id_bom_item INT '$.id_bom_item',
			id_item INT '$.id_item'
		)
	)
	MERGE process.bom_item t
	USING item_list s
	ON t.id_bom_item=s.id_bom_item
	WHEN MATCHED THEN UPDATE SET t.id_item=s.id_item
	WHEN NOT MATCHED BY TARGET THEN INSERT (id_bom_group, id_item) VALUES (s.id_bom_group, s.id_item)
	WHEN NOT MATCHED BY SOURCE AND t.id_bom_group=@id_bom_group THEN UPDATE SET t.deleted=1
	;
go

