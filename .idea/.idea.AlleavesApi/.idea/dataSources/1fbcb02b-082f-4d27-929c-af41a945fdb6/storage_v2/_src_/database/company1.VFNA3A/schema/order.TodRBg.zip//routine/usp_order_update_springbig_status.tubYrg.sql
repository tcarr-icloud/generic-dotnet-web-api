
create procedure [order].[usp_order_update_springbig_status]
    @id_order int
as
    update [order].[order]
set springbig_points_allocated = 1
where id_order = @id_order
go

