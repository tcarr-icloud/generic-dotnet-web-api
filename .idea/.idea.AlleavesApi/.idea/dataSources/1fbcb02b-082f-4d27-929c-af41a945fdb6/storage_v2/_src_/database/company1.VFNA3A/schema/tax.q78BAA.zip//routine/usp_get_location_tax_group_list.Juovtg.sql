CREATE PROCEDURE [tax].[usp_get_location_tax_group_list]
	@id_location INT = NULL
AS
	SELECT tlg.id_location,
		bl.[name] as location,
		tlg.id_tax_group,
		tg.[name] as tax_group,
		ISNULL((
			SELECT
				tt.[name] as tax_name,
				tt.percentage,
				tt.is_cannabis,
				tt.is_non_cannabis,
				tt.is_excise_tax,
				tt.is_state_tax,
				tt.is_local_tax,
				tt.is_adult_use,
				tt.is_medical_use,
				tt.is_arms_length,
				tt.is_gross_tax,
				tt.markup_rate,
				tt.stacking_order,
				ISNULL((
					SELECT tv.id_vendor,
						iv.name as vendor
					FROM [tax].[vendor] tv
					LEFT JOIN [inventory].[vendor] iv ON iv.id_vendor=tv.id_vendor
					WHERE tv.id_tax=tt.id_tax AND tv.active=1
				FOR JSON PATH), '[]') as vendor_list
			FROM [tax].[group_value] tgv
			LEFT JOIN [tax].[tax] tt ON tt.id_tax = tgv.id_tax
			WHERE tgv.id_tax_group=tlg.id_tax_group AND tgv.active = 1 AND tt.active = 1
			ORDER BY tt.stacking_order, tt.[name]
		FOR JSON PATH), '[]') as tax_list
	FROM [tax].[location_group] tlg
	LEFT JOIN [base].[location] bl ON bl.id_location = tlg.id_location
	LEFT JOIN [tax].[group] tg ON tg.id_tax_group = tlg.id_tax_group
	WHERE (@id_location IS NULL OR tlg.id_location = @id_location) AND bl.active=1 AND tlg.active=1 AND tg.active=1
	ORDER BY tlg.id_location
go

