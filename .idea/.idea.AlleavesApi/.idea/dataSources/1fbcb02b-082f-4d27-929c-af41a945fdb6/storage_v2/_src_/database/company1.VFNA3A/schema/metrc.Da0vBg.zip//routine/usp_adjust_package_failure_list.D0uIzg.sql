-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [metrc].[usp_adjust_package_failure_list]
	-- Add the parameters for the stored procedure here
	@id_batch INT = NULL,
	@id_area INT = NULL,
	@remediated BIT = 0,
	@id_location INT = null,
	@start_date datetime,
	@end_date datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT ad.*,
    ar.name as location,
	usr.UserName as user_name
	FROM metrc.adjust_package_failure ad
	LEFT JOIN inventory.area ar on ad.id_area = ar.id_area
	LEFT JOIN base.location loc on ar.id_location = loc.id_location
	LEFT JOIN base.[user] usr on ad.created_by = usr.id_user
	WHERE (@id_batch IS NULL OR id_batch=@id_batch) AND (@id_area IS NULL OR ad.id_area=@id_area) AND (remediated=@remediated)
    AND (@id_location IS NULL OR ar.id_location = @id_location)
	AND ((@start_date IS NULL AND @end_date IS NULL) OR (ad.date_created >= @start_date AND ad.date_created <= @end_date))
END
go

