CREATE     VIEW powerbi.Powerbi_labor_table
AS
SELECT (SELECT name
              FROM    base.location
              WHERE  (id_location = p.id_location)) AS location,
                 (SELECT FirstName + ' ' + LastName AS Expr1
                 FROM    base.[user] AS u
                 WHERE (id_user = p.created_by)) AS 'user', dbo.fn_utc_to_local(p.date_created,p.id_location) AS process_date, SUM(pi.quantity) AS yield,
                 (SELECT SUM(oi.price_post_tax) AS Expr1
                 FROM    process.process_session INNER JOIN
                              process.process_session_output ON process.process_session.id_process_session = process.process_session_output.id_process_session INNER JOIN
                              inventory.batch ON process.process_session_output.id_batch = inventory.batch.id_batch INNER JOIN
                              inventory.vw_item_list AS i ON i.id_item = inventory.batch.id_item INNER JOIN
                              [order].item AS oi ON oi.id_inventory_item = i.id_item
                 WHERE (process.process_session.id_process = p.id_process)) AS sales
FROM   process.process AS p INNER JOIN
             process.process_input AS pi ON p.id_process = pi.id_process
GROUP BY p.id_process, dbo.fn_utc_to_local(p.date_created,p.id_location), p.id_location, p.created_by
go

