CREATE PROCEDURE [external_blaze].[usp_order_save]
                                         @id_order_blaze VARCHAR(200),
                                         @order_type VARCHAR(255),
                                         @date DATE,
                                         @discount_total DECIMAL(18, 2),
                                         @sub_total DECIMAL(18, 2),
                                         @total DECIMAL(18, 2),
                                         @tender_type VARCHAR(255),
                                         @items VARCHAR(max),
                                         @id_customer int,
                                         @id_member VARCHAR(200),
                                         @store_address VARCHAR(200)

AS
    SET NOCOUNT ON
    DECLARE @id_order INT = NULL
        BEGIN
            INSERT INTO [external_blaze].[order] (id_order_blaze,order_type,date,tender_type,discount_total,sub_total,total,id_customer,id_member,store_address)
            VALUES (@id_order_blaze,@order_type,@date,@tender_type,@discount_total,@sub_total,@total,@id_customer,@id_member,@store_address)
            SET @id_order = SCOPE_IDENTITY()
        END

        EXEC [external_blaze].usp_order_item_save @items, @id_order
go

