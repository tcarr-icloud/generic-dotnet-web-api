CREATE PROCEDURE discount.[usp_global_stack_settings]
AS
    IF EXISTS (SELECT TOP 1 id_stack_settings,stacking,product,cart FROM discount.global_stack_settings)
		SELECT TOP 1 id_stack_settings,stacking,product,cart FROM discount.global_stack_settings
	ELSE
		SELECT null as id_stack_setting ,0 as stacking, '{"percent":false,"fixed":false,"mix":false}' as product, '{"percent":false,"fixed":false,"mix":false}' as cart
go

