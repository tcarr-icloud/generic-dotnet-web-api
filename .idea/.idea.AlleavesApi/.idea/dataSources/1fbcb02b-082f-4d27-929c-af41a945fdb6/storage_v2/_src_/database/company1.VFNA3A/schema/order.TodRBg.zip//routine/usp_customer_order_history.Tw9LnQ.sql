CREATE PROCEDURE [order].[usp_customer_order_history]
	@id_customer INT = NULL
AS
	SELECT 
		  CONCAT(usr.FirstName, ' ', usr.LastName) created_by_userName
		, ccd.id_customer_credit_debit
		, ccd.id_customer
		, ccd.id_order
		, ccd.amount
		, ccd.reason
		, ccd.notes
		, ccd.created_by
		, ccd.date_created
		, SUM(ccd.amount) OVER (PARTITION BY ccd.id_customer ORDER BY ccd.id_customer, ccd.date_created) as credit_balance
	FROM [order].[customer_credit_debit] ccd
	LEFT JOIN [base].[user] usr ON usr.id_user = ccd.created_by
	WHERE ccd.id_customer = @id_customer
go

