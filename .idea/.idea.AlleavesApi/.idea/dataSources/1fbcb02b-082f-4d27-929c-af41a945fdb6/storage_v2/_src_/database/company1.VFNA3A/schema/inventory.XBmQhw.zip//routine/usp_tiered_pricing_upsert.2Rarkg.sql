CREATE PROCEDURE [inventory].[usp_tiered_pricing_upsert]
	@id_tiered_pricing INT = null,
    @name VARCHAR (128),
	@enable_combined_tiers bit,
	@enable_cumulative_weights bit,
	@show_price_total bit,
	@id_uom INT,
	@tier varchar(MAX),
	@deleted BIT = 0,
	@id_user INT

AS
	IF (@id_tiered_pricing IS NULL)
	BEGIN
		INSERT INTO [inventory].[tiered_pricing] ([name], [tier], [enable_combined_tiers], [enable_cumulative_weights],  [show_price_total], [id_uom], [deleted],  id_user_created, id_user_updated)
		VALUES (@name, @tier, @enable_combined_tiers,  @enable_cumulative_weights, @show_price_total, @id_uom, 0, @id_user, @id_user)

		SET @id_tiered_pricing=SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		UPDATE [inventory].[tiered_pricing]
		SET [name] = @name
			, tier = @tier
			, enable_combined_tiers = @enable_combined_tiers
			, enable_cumulative_weights = @enable_cumulative_weights
			, show_price_total = @show_price_total
			, id_uom  = @id_uom 
			, deleted = @deleted
			, id_user_updated = @id_user
			, date_updated=GETUTCDATE()
		WHERE id_tiered_pricing = @id_tiered_pricing
	END

	EXEC [inventory].[usp_tiered_pricing_list] @id_tiered_pricing, 0
go

