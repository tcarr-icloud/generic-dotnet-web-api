CREATE PROCEDURE [discount].[usp_discount_list]
	@id_discount INT = NULL,
	@id_discount_include VARCHAR(MAX) = NULL,
	@only_active BIT = NULL,
	@only_auto_apply BIT = NULL,
	@include_deleted BIT = 0
AS
	
	SELECT d.id_discount
			, d.name AS discount
			, d.code
			, d.id_adjustment_type
			, d.id_sale_type
			, a.name AS adjustment_type
			, a.reference AS adjustment_type_reference
			, s.name AS sale_type
			, s.reference AS sale_type_reference
			, d.use_category_in_list
			, d.use_product_in_list
			, d.auto_apply
			, d.apply_pre_tax
			, d.apply_post_tax
			, d.can_be_combined
			, d.active
			, d.num_uses
			, CAST(d.date_valid_start AS VARCHAR(16)) AS date_valid_start
			, CAST(d.date_valid_end AS VARCHAR(16)) AS date_valid_end
			, ISNULL((
				SELECT fc.id_discount
						, fc.id_category
				FROM discount.filter_category fc
				WHERE fc.id_discount=d.id_discount
				FOR JSON PATH
			), '[]') AS filter_category_list
			, ISNULL((
				SELECT fp.id_discount
						, fp.id_item
				FROM discount.filter_product fp
				WHERE fp.id_discount=d.id_discount
				FOR JSON PATH
			), '[]') AS filter_product_list
			, ISNULL(
				CASE WHEN a.reference='bulk' THEN
					(SELECT r.id_rule, r.id_discount, r.range_min, r.range_max, r.id_type, r.value, t.reference AS type_reference
					 FROM discount.rule_bulk r 
					 JOIN discount.type t ON t.id_type=r.id_type
					 WHERE r.id_discount=d.id_discount
					 ORDER BY r.range_min
					 FOR JSON PATH)
				WHEN a.reference='bxgx' THEN
					(SELECT r.id_rule, r.id_discount, r.qty_bought, r.qty_discounted, r.id_type, r.value, t.reference AS type_reference
					 FROM discount.rule_bxgx r 
					 JOIN discount.type t ON t.id_type=r.id_type
					 WHERE r.id_discount=d.id_discount
					 FOR JSON PATH)
				ELSE
					(SELECT r.id_rule, r.id_discount, r.id_type, r.value, t.reference AS type_reference
					 FROM discount.rule_basic r 
					 JOIN discount.type t ON t.id_type=r.id_type
					 WHERE r.id_discount=d.id_discount
					 FOR JSON PATH)
				END
			, '[]') AS rule_list
	FROM discount.discount d
	JOIN discount.adjustment_type a ON a.id_adjustment_type=d.id_adjustment_type
	LEFT JOIN [order].sale_type s ON s.id_sale_type=d.id_sale_type
	WHERE	(@id_discount IS NULL OR d.id_discount=@id_discount)
	AND		(@only_active IS NULL OR d.active>= 0)
	AND		(@only_auto_apply IS NULL OR ISNULL(d.auto_apply,0) = 1)
	AND		((@id_discount_include IS NULL) OR d.id_discount IN (SELECT [value] FROM OPENJSON(@id_discount_include, '$')))
	AND		d.deleted<=@include_deleted
	ORDER BY d.name
go

