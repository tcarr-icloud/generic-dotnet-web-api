CREATE PROCEDURE [discount].[usp_discount_create]
	@name VARCHAR(128),
	@code VARCHAR(128),
	@id_adjustment_type INT,
	@id_sale_type INT,
	@use_category_in_list BIT,
	@use_product_in_list BIT,
	@auto_apply BIT,
	@apply_pre_tax BIT,
	@apply_post_tax BIT,
	@active BIT,
	@can_be_combined BIT,
	@num_uses INT,
	@date_valid_start DATE,
	@date_valid_end DATE,
	@filter_category_list VARCHAR(MAX) = '[]',
	@filter_product_list VARCHAR(MAX) = '[]',
	@rule_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	INSERT INTO [discount].[discount] (name, code, id_adjustment_type, id_sale_type, use_category_in_list, use_product_in_list, auto_apply, apply_pre_tax, apply_post_tax, active, can_be_combined, num_uses, date_valid_start, date_valid_end, created_by, updated_by) VALUES
	(@name, @code, @id_adjustment_type, @id_sale_type, @use_category_in_list, @use_product_in_list, @auto_apply, @apply_pre_tax, @apply_post_tax, @active, @can_be_combined, @num_uses, @date_valid_start, @date_valid_end, @id_user, @id_user)

	DECLARE @id_discount INT = SCOPE_IDENTITY()

	/* insert category filters. */
	INSERT INTO [discount].[filter_category] (id_discount, id_category)
	SELECT @id_discount AS id_discount
			, id_category
	FROM OPENJSON(@filter_category_list)
	WITH (
		id_category INT '$.id_category'
	)

	/* insert product filters. */
	INSERT INTO [discount].[filter_product] (id_discount, id_item)
	SELECT @id_discount AS id_discount
			, id_item
	FROM OPENJSON(@filter_product_list)
	WITH (
		id_item INT '$.id_item'
	)

	/* insert rule based on adjustment type. */
	DECLARE @reference VARCHAR(128) = (SELECT TOP 1 reference FROM discount.adjustment_type WHERE id_adjustment_type=@id_adjustment_type)

	IF (@reference = 'bulk')
	BEGIN
		INSERT INTO [discount].[rule_bulk] (id_discount, range_min, range_max, id_type, value)
		SELECT @id_discount AS id_discount
				, range_min
				, range_max
				, id_type
				, value
		FROM OPENJSON(@rule_list)
		WITH (
			range_min DECIMAL(18,4) '$.range_min',
			range_max DECIMAL(18,4) '$.range_max',
			id_type INT '$.id_type',
			value DECIMAL(18,4) '$.value'
		)
	END
	IF (@reference = 'bxgx')
	BEGIN
		INSERT INTO [discount].[rule_bxgx] (id_discount, qty_bought, qty_discounted, id_type, value)
		SELECT @id_discount AS id_discount
				, qty_bought
				, qty_discounted
				, id_type
				, value
		FROM OPENJSON(@rule_list)
		WITH (
			qty_bought INT '$.qty_bought',
			qty_discounted INT '$.qty_discounted',
			id_type INT '$.id_type',
			value DECIMAL(18,4) '$.value'
		)
	END
	ELSE
	BEGIN
		INSERT INTO [discount].[rule_basic] (id_discount, id_type, value)
		SELECT @id_discount AS id_discount
				, id_type
				, value
		FROM OPENJSON(@rule_list)
		WITH (
			id_type INT '$.id_type',
			value DECIMAL(18,4) '$.value'
		)
	END

	/* return newly created discount. */
	EXEC discount.usp_discount_list @id_discount
go

