CREATE     PROCEDURE [inventory].[usp_ride_list]
	@id_user int
AS

    declare @id_driver int = (select id_driver from [order].driver where id_user = @id_user)

    select
           id_transfer,
            t.date_created
			, t.recipient
			, ISNULL(sl.name, sv.name) AS sender_name
			, ISNULL(dl.name, dv.name) AS recipient_name
			, t.address
			, t.city
			, t.state
			, t.postal_code
			, ISNULL(sl.address, sv.shipping_address) AS sender_address
			, ISNULL(sl.city, sv.shipping_city) AS sender_city
			, ISNULL(sl.state, sv.shipping_state) AS sender_state
			, ISNULL(sl.postal_code, sv.shipping_postal_code) AS sender_postal_code
           ,(SELECT top 1  rs.name AS transfer_status
					  FROM inventory.ride_status_history rsh
					  JOIN inventory.ride_status rs ON rs.id_ride_status=rsh.id_ride_status
					  WHERE rsh.id_transfer=t.id_transfer
					  ORDER BY rsh.date_verified desc ) as last_ride_status
    from inventory.transfer t
	LEFT JOIN base.location sl ON sl.id_location=t.id_location_source
	LEFT JOIN base.location dl ON dl.id_location=t.id_location_destination
	LEFT JOIN inventory.vendor sv ON sv.id_vendor=t.id_vendor_source
	LEFT JOIN inventory.vendor dv ON dv.id_vendor=t.id_vendor_destination
    where id_driver1 = @id_driver or
          id_driver2 = @id_driver
order by t.date_created desc
go

