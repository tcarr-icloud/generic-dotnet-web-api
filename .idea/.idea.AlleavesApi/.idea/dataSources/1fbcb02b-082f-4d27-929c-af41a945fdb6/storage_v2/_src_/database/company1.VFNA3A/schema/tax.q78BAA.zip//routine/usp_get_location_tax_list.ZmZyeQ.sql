CREATE PROCEDURE [tax].[usp_get_location_tax_list]
	@id_location INT = NULL
AS
	SELECT tl.id_location,
		bl.name as location,
		tt.name as tax_name,
		tt.percentage,
		tt.is_cannabis,
		tt.is_non_cannabis,
		tt.is_excise_tax,
		tt.is_state_tax,
		tt.is_local_tax,
		tt.is_adult_use,
		tt.is_medical_use,
		tt.is_arms_length,
		tt.is_gross_tax,
		tt.markup_rate,
		tt.stacking_order,
		ISNULL((
				SELECT tv.id_vendor,
					iv.name as vendor
				FROM [tax].[vendor] tv
				LEFT JOIN [inventory].[vendor] iv ON iv.id_vendor=tv.id_vendor
				WHERE tv.id_tax=tt.id_tax AND tv.active = 1
			FOR JSON PATH), '[]') as vendor_list,
		ISNULL((
				SELECT tc.id_tax_category,
					tcv.id_tax,
					tc.name
				FROM [tax].[category_value] tcv
				LEFT JOIN [tax].[category] tc ON tc.id_tax_category = tcv.id_tax_category
				WHERE tcv.active=1 AND tc.active=1 AND tcv.id_tax=tt.id_tax
			FOR JSON PATH), '[]') as category_list
	FROM [tax].[location] tl
	LEFT JOIN [tax].[tax] tt ON tt.id_tax = tl.id_tax
	LEFT JOIN [base].[location] bl ON bl.id_location = tl.id_location
	WHERE tl.id_location=ISNULL(@id_location, tl.id_location) AND tt.active=1 AND tl.active=1
	ORDER BY tl.id_location, tt.stacking_order, tt.name
go

