CREATE PROCEDURE [order].[ecommerce_ride_fetch_failed_upsert] @id_driver INT = NULL
	,@date_delivery DATE = NULL
	,@cancellation_note VARCHAR(50) = NULL
AS
SELECT r.id_ride
FROM [order].ecommerce_ride r
LEFT JOIN [order].ecommerce_ride_status_history h ON h.id_ride = r.id_ride
LEFT JOIN [order].ecommerce_ride_status s ON s.id_status = h.id_ride_status
WHERE id_driver = @id_driver
	AND delivery_date = isnull(@date_delivery, r.delivery_date)
	AND h.id_status_history = (
		SELECT TOP 1 id_status_history
		FROM [order].[ecommerce_ride_status_history] h
		WHERE h.id_ride = r.id_ride
		ORDER BY id_status_history DESC
		)
	AND s.reference = 'failed_delivery'
go

