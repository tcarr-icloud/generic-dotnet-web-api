CREATE PROCEDURE [pos].[usp_logo_list]
	@id_logo INT = NULL,
	@id_location INT = NULL
AS
BEGIN
	SET NOCOUNT ON;
SELECT 
	id_logo,
	id_location,
	[name],
	[path],
    deleted,
	id_user_created_by
	FROM pos.logos
	WHERE deleted = 0
	AND (@id_logo IS NULL OR id_logo = @id_logo)
	AND (@id_location IS NULL OR id_location = @id_location)
END
go

