CREATE PROCEDURE [inventory].[usp_raw_material_delete]
	@id_raw_material INT,
	@id_user INT
AS
	UPDATE inventory.raw_material
	SET deleted=1
		, date_updated=GETUTCDATE()
		, id_user_updated=@id_user
	WHERE id_raw_material=@id_raw_material
go

