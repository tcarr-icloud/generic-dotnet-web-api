CREATE PROCEDURE [order].[usp_customer_queue]
	@id_customer INT,
	@id_location INT,
	@id_user INT
AS
	IF NOT EXISTS (SELECT id_customer FROM [order].[queue] WHERE id_customer = @id_customer AND time_out IS NULL AND id_location = @id_location)
		INSERT INTO [order].queue (id_customer, id_location, updated_by, created_by) VALUES (@id_customer, @id_location, @id_user, @id_user)
go

