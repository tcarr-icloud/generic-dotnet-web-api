CREATE PROCEDURE [metrc].[usp_transfer_filter_received]
	@manifest_number VARCHAR(128),
	@package_list VARCHAR(MAX)
AS
	;WITH list AS (
		SELECT * FROM OPENJSON(@package_list)
		WITH (
			package_label VARCHAR(128) '$.PackageLabel'
		)
	)

	SELECT ti.package_label
	FROM metrc.transfer t
	JOIN metrc.transfer_item ti On ti.id_transfer=t.id_transfer
	WHERE ti.package_label IN (SELECT i.package_label FROM list i)
		  AND t.manifest_number=@manifest_number
go

