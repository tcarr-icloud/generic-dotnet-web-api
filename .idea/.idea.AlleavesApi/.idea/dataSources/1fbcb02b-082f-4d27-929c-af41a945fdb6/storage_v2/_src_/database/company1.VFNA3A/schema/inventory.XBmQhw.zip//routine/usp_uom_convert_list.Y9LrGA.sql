CREATE PROCEDURE [inventory].[usp_uom_convert_list]
AS
    SET NOCOUNT ON;
SELECT uc.id_uom_to,
       uc.id_uom_from,
       ucf.name          as name_from,
       ucf.name_short    as name_from_short,
       ucf.quantity_type as quantity_from,
       uct.name          as name_to,
       uct.name_short    as name_to_short,
       uct.quantity_type as quantity_to,
       uc.multiplier
FROM inventory.uom_convert uc
         LEFT JOIN inventory.uom ucf on uc.id_uom_from = ucf.id_uom
         LEFT JOIN inventory.uom uct on uc.id_uom_to = uct.id_uom
go

