
CREATE   PROCEDURE [dbo].[usp_change_password]
@id_user INT,
@password VARCHAR(128)
AS
SET NOCOUNT ON;

UPDATE [base].[user]
SET PasswordHash=@password,
PasswordReset=0,
PasswordResetDate=dateadd(DD, 90, getutcdate())
WHERE id_user=@id_user
go

