CREATE PROCEDURE [pos].[usp_cash_in]
	@id_user INT,
	@id_register INT,
	@balance_starting decimal(18,2)

AS
INSERT INTO pos.[session] (id_user_start, id_register,  balance_starting, date_start)
VALUES(@id_user, @id_register, @balance_starting, GETUTCDATE())
go

