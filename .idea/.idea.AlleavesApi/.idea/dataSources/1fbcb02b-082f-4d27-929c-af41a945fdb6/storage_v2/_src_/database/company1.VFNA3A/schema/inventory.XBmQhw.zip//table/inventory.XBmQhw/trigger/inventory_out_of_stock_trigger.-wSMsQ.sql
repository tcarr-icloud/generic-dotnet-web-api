

CREATE TRIGGER [inventory].[inventory_out_of_stock_trigger]
ON [inventory].[inventory]
AFTER INSERT, UPDATE
AS
BEGIN
    IF UPDATE(quantity) OR EXISTS (SELECT * FROM INSERTED)
    BEGIN
        MERGE [inventory].[batch_auto_close] AS target
        USING (
            SELECT b.id_batch, it.id_item, it.id_item_group 
			FROM INSERTED i
			 JOIN [inventory].[batch] b ON i.id_batch = b.id_batch
            JOIN [inventory].[item] it ON b.id_item = it.id_item
			WHERE quantity = 0
            UNION
               SELECT id_batch, NULL, NULL 
			   FROM [inventory].[batch_auto_close]
        ) AS source
        ON target.id_batch = source.id_batch
        WHEN MATCHED AND target.id_batch IN (SELECT id_batch FROM INSERTED WHERE quantity > 0) THEN DELETE
        WHEN NOT MATCHED THEN
            INSERT (id_batch, id_item, id_item_group, date_updated, date_created)
            VALUES (source.id_batch, source.id_item, source.id_item_group, GETDATE(), GETDATE());
    END
END;
go

