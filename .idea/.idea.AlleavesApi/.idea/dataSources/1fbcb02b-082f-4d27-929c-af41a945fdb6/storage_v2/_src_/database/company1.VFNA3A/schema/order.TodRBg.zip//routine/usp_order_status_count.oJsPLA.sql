CREATE PROCEDURE [order].[usp_order_status_count]
	@per_page INT = 10
	,@page INT = 1
	,@id_location INT = NULL
	,@date_created DATETIME = NULL
AS
	SET @page = 1
	SET @per_page = 1
	select 
	   count(o.id_order) as count,s.driver_message, u.FirstName AS name_first
     , u.LastName AS name_last
	 , u.Email as email
	 , u.PhoneNumber as phone_number
	 , u.UserName as user_name
	 ,u.id_user as id_user_alleaves
	 ,r.id_driver,d.license
	 , l.name AS location
	 , d.lat
	 , d.long
	 , (select  top 1 id_delivery_route  from [order].delivery_route  where id_driver =r.id_driver order by id_delivery_route desc) as route_id
	from [order].[order] o inner join [order].[ecommerce_ride] r on o.id_order=r.id_order
	left outer join  [order].[ecommerce_ride_status_history] h on h.id_ride=r.id_ride
	left outer join  [order].[ecommerce_ride_status] s on s.id_status=h.id_ride_status 
	LEFT JOIN [order].driver d ON d.id_driver=r.id_driver
	LEFT outer JOIN base.[user] u  ON d.id_user=u.id_user
	LEFT JOIN base.location l ON l.id_location=d.id_location
	 where (@id_location IS NULL OR l.id_location = @id_location) and
	(@date_created IS NULL OR CONVERT(VARCHAR(32), CAST(CAST(o.date_created AS DATETIME2(0)) AT TIME ZONE 'UTC' as DATE), 120)
	=CONVERT(VARCHAR(32), CAST(CAST(@date_created AS DATETIME2(0)) AT TIME ZONE 'UTC' as DATE), 120)) and type ='delivery'  and 
	 h.id_status_history=
	(select top 1 id_status_history from [order].[ecommerce_ride_status_history] h where h.id_ride=r.id_ride order by id_status_history desc) 
	group by s.driver_message,r.id_driver,u.FirstName,u.LastName,u.Email,u.PhoneNumber,u.UserName,u.id_user, r.id_driver,d.license,d.lat,d.long,l.name
go

