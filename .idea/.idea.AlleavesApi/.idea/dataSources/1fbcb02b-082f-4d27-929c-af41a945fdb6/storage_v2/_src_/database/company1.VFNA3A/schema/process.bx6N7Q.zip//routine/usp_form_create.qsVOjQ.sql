CREATE PROCEDURE [process].[usp_form_create]
	@name VARCHAR(128),
	@id_process_category INT,
	@sequence INT,
	@input_list VARCHAR(MAX) = '[]',
	@attribute_list VARCHAR(MAX) = '[]',
	@output_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	SET NOCOUNT ON

	INSERT INTO process.form (name, sequence, id_process_category, created_by, updated_by) VALUES
		(@name, @sequence, @id_process_category, @id_user, @id_user)

	DECLARE @id_form INT
	SET @id_form=SCOPE_IDENTITY()

	UPDATE process.form
	SET sequence=sequence+1
	WHERE sequence>=@sequence AND 
		  id_form<>@id_form AND 
		  deleted=0
	
	/* insert inputs. */
	INSERT INTO process.form_input (id_form, id_raw_material)
	SELECT @id_form AS id_process_form
			, id_raw_material
	FROM OPENJSON(@input_list)
	WITH (
		id_raw_material INT
	)
	
	/* insert attributes. */
	INSERT INTO process.form_attribute (id_form, name, input_type)
	SELECT @id_form AS id_process_form
			, name
			, input_type
	FROM OPENJSON(@attribute_list)
	WITH (
		name VARCHAR(128) '$.name',
		input_type VARCHAR(32) '$.input_type'
	)
	
	/* insert outputs. */
	INSERT INTO process.form_output (id_form, id_raw_material)
	SELECT @id_form AS id_process_form
			, id_raw_material
	FROM OPENJSON(@output_list)
	WITH (
		id_raw_material INT
	)

	EXEC process.usp_form_list @id_form
go

