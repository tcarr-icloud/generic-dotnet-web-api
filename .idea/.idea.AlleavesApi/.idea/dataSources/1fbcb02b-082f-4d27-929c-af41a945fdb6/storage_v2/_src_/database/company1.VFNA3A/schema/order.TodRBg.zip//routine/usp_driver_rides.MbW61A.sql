CREATE PROCEDURE [order].[usp_driver_rides] 
	@id_ride INT = NULL,
	@id_user INT = NULL,
	@id_order INT = NULL,
	@id_area INT = NULL,
	@id_location INT = NULL,
	@delivery_date DATE = NULL,
	@app bit = 1
AS

--DECLARE 
--	@id_ride int = null,
--	@id_user int = 32,
--	@id_order int = null,
--	@id_area int = null,
--	@id_location int = null,
--	@delivery_date date =null

DECLARE @id_driver INT = (
		SELECT id_driver
		FROM [order].driver
		WHERE id_user = @id_user
		)

DECLARE @is_area_driver BIT = CASE 
		WHEN (
				SELECT id_area_driver
				FROM inventory.area_driver
				WHERE id_driver = @id_driver
				) IS NULL
			THEN 0
		ELSE 1
		END


SELECT ride.id_ride
	,ride.id_driver
	,ride.id_order
	,ride.id_area
	,ride.id_driver2
	,ride.[signature]
	,a.delivery_date
	,driver_user.FirstName + ' ' + driver_user.LastName AS driver1_name
	,o.date_created
	,o.[type]
	,c.name_first + ' ' + c.name_last AS recipient_name
    ,c.phone
    ,c.phone2
	,a.address1 + ISNULL(', ' + NULLIF(REPLACE(a.address2, ' ' ,''), ''), '') AS [address]
	,a.city
	,a.[state]
	,a.zip AS postal_code
    ,a.zip_four
    ,a.lat
    ,a.long
	,[location].[name] AS sender_name
	,[location].[address] AS sender_address
	,[location].city AS sender_city
	,[location].[STATE] AS sender_state
	,[location].postal_code AS sender_postal_code
	,(
		SELECT TOP 1 ers.driver_message
		FROM [order].ecommerce_ride_status_history history
		JOIN [order].ecommerce_ride_status ers ON ers.id_status = history.id_ride_status
		WHERE ride.id_ride = history.id_ride
		ORDER BY history.created_at DESC
		) AS last_ride_status
	,rdr.id_delivery_route
	,ISNULL((SELECT TOP 1 note FROM [order].[note] WHERE ID_ORDER =@id_order ORDER BY [order].[note].id_note DESC),NULL) as ordernote
	,a.note as delivery_note
	,dst.delivery_start_time
	,hca.last_ride_status_createdat
	,ISNULL(statusList.json_result, '[]') AS status_list
FROM [order].ecommerce_ride ride
JOIN [order].[order] o ON o.id_order = ride.id_order
JOIN [order].customer c ON c.id_customer = o.id_customer
left JOIN [order].[ride_delivery_route] rdr on rdr.id_ride=ride.id_ride
LEFT JOIN [order].[address] a ON o.id_order = a.id_order
JOIN [order].driver d ON d.id_driver = ride.id_driver
LEFT JOIN base.[user] driver_user ON d.id_user = driver_user.id_user
LEFT JOIN inventory.area ON ride.id_area = area.id_area
LEFT JOIN base.location ON area.id_location = [location].id_location
LEFT OUTER JOIN (
	SELECT 
		 ROW_NUMBER() OVER(PARTITION BY rdr.id_ride ORDER BY rdr.id_ride_delivery_route DESC) as id_ride_delivery_route_rank
		,rdr.id_ride
		,dr.delivery_start_time
	FROM [order].[delivery_route]  dr
	JOIN [order].[ride_delivery_route] rdr ON dr.id_delivery_route = rdr.id_delivery_route
) dst ON dst.id_ride = ride.id_ride AND dst.id_ride_delivery_route_rank = 1
LEFT OUTER JOIN (
	SELECT
		history.id_ride,
		history.created_at as last_ride_status_createdat,
		ROW_NUMBER() OVER(PARTITION BY history.id_ride ORDER BY history.created_at DESC) as create_at_index
	FROM [order].ecommerce_ride_status_history history
) hca on hca.id_ride = ride.id_ride AND hca.create_at_index = 1
OUTER APPLY (
    SELECT (
        SELECT id_status_history
            ,customer_message
            ,driver_message
            ,created_at
        FROM [order].ecommerce_ride_status_history history
        JOIN [order].ecommerce_ride_status ers ON ers.id_status = history.id_ride_status
        WHERE ride.id_ride = history.id_ride
        ORDER BY history.created_at
        FOR JSON PATH
    ) AS json_result
) AS statusList
WHERE
	ride.id_ride = ISNULL(@id_ride,ride.id_ride) AND
	(
		@id_user IS NULL
		OR ride.id_driver = @id_driver
		OR (
			ride.id_driver IS NULL
			AND @is_area_driver = 0
			)
	) AND
	ISNULL(ride.id_order, -1) = ISNULL(@id_order, ISNULL(ride.id_order, -1)) AND
	(
        (@app = 1 AND ISNULL(a.delivery_date, '1900-01-01') = ISNULL(@delivery_date, ISNULL(a.delivery_date, '1900-01-01')))
        OR
        (@app = 0 AND DATEDIFF(day, a.delivery_date, GETDATE()) <= 15)
    )AND
	ISNULL(ride.id_area, -1) = ISNULL(@id_area, ISNULL(ride.id_area, -1)) AND
	[location].id_location = ISNULL(@id_location, [location].id_location)
go

