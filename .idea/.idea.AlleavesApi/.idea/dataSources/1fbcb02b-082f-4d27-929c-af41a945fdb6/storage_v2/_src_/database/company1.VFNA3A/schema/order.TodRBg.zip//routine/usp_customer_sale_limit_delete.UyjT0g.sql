CREATE PROCEDURE [order].[usp_customer_sale_limit_delete]
	@id_sale_limit INT,
	@id_customer INT,
	@id_user INT
AS
	UPDATE [order].[customer_sale_limit]
	SET deleted=1
		, id_user_updated=@id_user
		, date_updated=GETUTCDATE()
	WHERE id_sale_limit=@id_sale_limit AND id_customer=@id_customer

	EXEC [order].[usp_customer_sale_limit_list] NULL, @id_customer, NULL, 0
go

