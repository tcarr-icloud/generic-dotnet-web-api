-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [inventory].[usp_metrc_receiving_locations_list]
AS
	SET NOCOUNT ON;

	SELECT DISTINCT
	l.id_location
	, l.[name] AS location
	, l.reference
	, l.address
	, l.city
	, l.state
	, ts.[name] AS full_state_name
	, l.postal_code
	, l.country
	, l.phone
	, l.timezone
	, l.retail
	, l.pickup
	, l.delivery
	, l.local_tax_percentage
	, l.active
	, l.custom_id
	, l.metrc_facility_license_number
	, l.is_adult_use
	, l.is_medical_use
FROM [inventory].[area] a
LEFT OUTER JOIN [base].[location] l ON l.id_location = a.id_location
LEFT OUTER JOIN [inventory].[area_type] art ON art.id_area_type = a.id_area_type
LEFT OUTER JOIN [tax].[state] ts ON l.state = ts.abbreviation
WHERE l.active = 1 AND l.metrc_facility_license_number IS NOT NULL AND l.metrc_facility_license_number<>'' AND art.reference='receiving'
ORDER BY l.[name]
go

