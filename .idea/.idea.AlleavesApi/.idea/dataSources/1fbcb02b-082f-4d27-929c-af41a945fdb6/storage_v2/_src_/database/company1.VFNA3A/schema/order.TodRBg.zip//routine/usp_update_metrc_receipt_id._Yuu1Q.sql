CREATE PROCEDURE [order].[usp_update_metrc_receipt_id]
	@id_order INT,
	@metrc_receipt_id INT = NULL,
	@id_user INT
AS
	UPDATE [order].[order] 
	SET metrc_receipt_id = @metrc_receipt_id,
		updated_by = @id_user,
		date_updated=getutcdate()
	WHERE id_order=@id_order
go

