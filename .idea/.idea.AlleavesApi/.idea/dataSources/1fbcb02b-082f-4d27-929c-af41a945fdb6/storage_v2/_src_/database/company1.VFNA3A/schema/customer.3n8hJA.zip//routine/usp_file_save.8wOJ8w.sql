CREATE PROCEDURE [customer].[usp_file_save]
	@id_file INT,
	@label INT,
	@id_user INT
AS

	DECLARE @id_customer INT = (SELECT TOP 1 id_customer FROM [customer].[file] WHERE id_file = @id_file)

	UPDATE [customer].[file]
	SET 
			[label] = @label
		,id_user_updated = @id_user
		,date_updated = GETUTCDATE()
	WHERE id_file = @id_file
	
	EXEC [customer].usp_file_list @id_customer = @id_file
go

