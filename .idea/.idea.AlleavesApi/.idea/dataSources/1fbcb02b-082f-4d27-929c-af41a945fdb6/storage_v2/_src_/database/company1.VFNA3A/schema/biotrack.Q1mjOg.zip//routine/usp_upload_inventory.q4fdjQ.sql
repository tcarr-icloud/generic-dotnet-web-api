CREATE PROCEDURE [biotrack].[usp_upload_inventory]
	@barcodes VARCHAR(MAX) = '[]'
AS
	SELECT *
	INTO #barcodes
	FROM OPENJSON(@barcodes)
	WITH(
		[ProviderBarcodeID] VARCHAR(528),
		[TraceabilityBarcodeID] VARCHAR(528),
		[biotrack_inventory_type_id] INT
	)
	DECLARE @batch_name VARCHAR(528),
			@barcode VARCHAR(528),
			@biotrack_inventory_type_id INT

	DECLARE barcode_cursor CURSOR FAST_FORWARD FOR
	SELECT 
		ProviderBarcodeID,
		TraceabilityBarcodeID,
		biotrack_inventory_type_id
	FROM #barcodes

	OPEN barcode_cursor

	FETCH NEXT FROM barcode_cursor INTO @batch_name, @barcode, @biotrack_inventory_type_id

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		UPDATE inventory.batch
		SET biotrack_barcode_id=@barcode,
			biotrack_inventory_type_id=@biotrack_inventory_type_id
		WHERE [name]=@batch_name
		FETCH NEXT FROM barcode_cursor INTO @batch_name, @barcode, @biotrack_inventory_type_id
	END

	CLOSE barcode_cursor
	DEALLOCATE barcode_cursor
go

