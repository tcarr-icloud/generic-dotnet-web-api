CREATE PROCEDURE [ommu].[usp_upsert_delivery_device]
	@ommu_delivery_device_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	/* upsert user locations. */
	;WITH delivery_device_list AS (
		SELECT @id_user AS id_user
			, DeliveryDeviceId
			, OrderTypeId
			, FormId
			, DeliveryDevicesName
		FROM OPENJSON(@ommu_delivery_device_list)
		WITH (
			DeliveryDeviceId INT,
			OrderTypeId INT,
			FormId INT,
			DeliveryDevicesName VARCHAR(256)
		)
	)
	MERGE [ommu].[delivery_device] t
	USING delivery_device_list s
	ON t.id_delivery_device=s.DeliveryDeviceId
	WHEN MATCHED THEN
		UPDATE SET t.id_order_type=s.OrderTypeId, t.[name]=s.DeliveryDevicesName, t.id_form=s.FormId, t.updated_by=s.id_user, t.date_updated=getutcdate()
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_delivery_device, [name], id_order_type, id_form, created_by, updated_by) VALUES (s.DeliveryDeviceId, s.DeliveryDevicesName, s.OrderTypeId, s.FormId, s.id_user, s.id_user)
	WHEN NOT MATCHED BY SOURCE THEN
		DELETE
	;

	/* return ommu delivery device list. */
	EXEC ommu.usp_delivery_device_list
go

