CREATE PROCEDURE [grow].[usp_raw_material_config_list]
	@id_raw_material_config INT = NULL,
	@include_deleted BIT = 0
AS
	SELECT rc.id_raw_material_config
			, rc.id_raw_material
			, r.name AS raw_material
			, ISNULL(c.path, 'Uncategorized') AS category
			, u.name AS uom
			, rc.item_name
			, rc.id_category
			, rc.id_uom
			, rc.id_uom_receiving
			, rc.units_per_received
			, rc.threshold_low_quantity
			, rc.has_expiration
			, rc.shelf_life_days
			, rc.id_uom_weight_useable
			, rc.weight_useable
			, rc.weight_net
			, rc.id_uom_weight_net
			, rc.id_uom_gross_weight_useable
			, rc.gross_weight_useable
			, rc.cost_of_good
	FROM grow.raw_material_config rc
	JOIN  inventory.raw_material r ON r.id_raw_material=rc.id_raw_material
	LEFT JOIN inventory.vw_category_list c ON c.id_category=rc.id_category
	JOIN inventory.uom u ON u.id_uom=rc.id_uom
	WHERE (@id_raw_material_config IS NULL OR rc.id_raw_material_config=@id_raw_material_config) AND
			rc.deleted<=@include_deleted
	ORDER BY r.name, rc.item_name
go

