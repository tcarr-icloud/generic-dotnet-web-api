CREATE PROCEDURE [springbig].[usp_apikey_fetch]
	@id_location int
AS
    SET NOCOUNT ON;
	SELECT id_location, [key], [email_required] FROM [springbig].[apikey] WHERE id_location = @id_location
go

