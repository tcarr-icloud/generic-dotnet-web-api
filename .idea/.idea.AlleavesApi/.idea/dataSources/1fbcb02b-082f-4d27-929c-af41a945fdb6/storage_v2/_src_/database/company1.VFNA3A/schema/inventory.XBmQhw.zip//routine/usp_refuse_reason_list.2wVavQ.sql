CREATE PROCEDURE [inventory].[usp_refuse_reason_list]
AS
	SELECT id_refuse_reason
			, name AS refuse_reason
			, system
	FROM inventory.refuse_reason
go

