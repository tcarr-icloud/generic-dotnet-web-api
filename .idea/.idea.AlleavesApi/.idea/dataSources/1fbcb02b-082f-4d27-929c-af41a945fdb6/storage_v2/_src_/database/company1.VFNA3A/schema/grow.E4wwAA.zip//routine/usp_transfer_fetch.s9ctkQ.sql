CREATE PROCEDURE [grow].[usp_transfer_fetch]
	@id_transfer INT
AS
	SELECT t.id_transfer
			/* participant information. */
			, t.id_location_source
			, t.id_vendor_source
			, t.id_location_destination
			, t.id_vendor_destination
			, ISNULL(sl.name, sv.name) AS source_name
			, ISNULL(dl.name, dv.name) AS destination_name
			/* source details. */
			, t.source_use_address_on_file
			, t.source_address
			, t.source_city
			, t.source_state
			, t.source_postal_code
			/* destination details. */
			, t.recipient
			, t.destination_use_address_on_file
			, t.destination_address
			, t.destination_city
			, t.destination_state
			, t.destination_postal_code
			/* status. */
			, t.received
			, t.date_received
			, t.cancelled
			, t.date_cancelled
			/* shipment information. */
			, t.id_driver1
			, t.id_driver2
			, CASE WHEN t.id_driver1 IS NULL THEN NULL ELSE CONCAT(d1u.FirstName, ' ', d1u.LastName) END AS driver1_name
			, CASE WHEN t.id_driver2 IS NULL THEN NULL ELSE CONCAT(d2u.FirstName, ' ', d2u.LastName) END AS driver2_name
			, d1.license AS driver1_license
			, d2.license AS driver2_license
			, t.id_vehicle
			, v.name AS vehicle
			, v.company AS vehicle_company
			, v.phone AS vehicle_phone
			, v.make AS vehicle_make
			, v.model AS vehicle_model
			, v.color AS vehicle_color
			, v.license AS vehicle_license
			, t.tracking_number
			, t.internal_reference
			, t.notes
			/* plant list. */
			, ISNULL((SELECT tp.id_transfer_plant
								, tp.id_plant
								, p.name AS plant
								, st.name AS strain
								, ph.phase_current
								, tp.id_area_source
								, sa.path AS area_source
								, tp.source_row
								, tp.source_column
								, grow.fn_grid_label(tp.source_row, tp.source_column) AS source_grid								
								, tp.id_area_destination
								, da.path AS area_destination
								, tp.destination_row
								, tp.destination_column
								, grow.fn_grid_label(tp.destination_row, tp.destination_column) AS destination_grid	
					  FROM grow.transfer_plant tp
					  LEFT JOIN inventory.vw_area_list sa ON sa.id_area=tp.id_area_source
					  LEFT JOIN inventory.vw_area_list da ON da.id_area=tp.id_area_destination
					  JOIN grow.plant p ON p.id_plant=tp.id_plant
					  JOIN grow.strain st ON st.id_strain=p.id_strain
					  JOIN (
							SELECT id_plant
									, CASE WHEN harvested = 1 THEN 'Harvested'
											WHEN destroyed = 1 THEN 'Destroyed'
											WHEN date_flower IS NOT NULL THEN 'Flowering'
											WHEN date_preflower IS NOT NULL THEN 'Pre-Flowering'
											WHEN date_vegetative IS NOT NULL THEN 'Vegetative'
											WHEN date_germination IS NOT NULL THEN 'Germination'
											WHEN date_seedling IS NOT NULL THEN 'Seedling'
											ELSE NULL END AS phase_current
									, CASE WHEN harvested = 1 THEN NULL
											ELSE COALESCE(date_flower, date_preflower, date_vegetative, date_germination, date_seedling) END 
										AS phase_current_date
									, COALESCE(date_seedling, date_germination, date_vegetative, date_preflower, date_flower) AS date_birth
							FROM grow.plant
						) ph ON ph.id_plant=p.id_plant
					  WHERE tp.id_transfer=t.id_transfer
					  FOR JSON PATH
			), '[]') AS plant_list
			/* strain list. */
			, ISNULL((SELECT ts.id_transfer_strain
								, ts.id_strain
								, tss.name AS strain
								, ts.quantity
					  FROM grow.transfer_strain ts
					  JOIN grow.strain tss ON tss.id_strain=ts.id_strain
					  WHERE ts.id_transfer=t.id_transfer
					  FOR JSON PATH
			), '[]') AS strain_list
			/* strain receipt list. */
			, ISNULL((SELECT ts.id_transfer_strain_receipt
							, ts.id_plant
							, p.name AS plant
							, st.name AS strain
							, ph.phase_current
							, ts.id_area_destination
							, da.path AS area_destination
							, ts.destination_row
							, ts.destination_column
							, grow.fn_grid_label(ts.destination_row, ts.destination_column) AS destination_grid	
					  FROM grow.transfer_strain_receipt ts
					  LEFT JOIN inventory.vw_area_list da ON da.id_area=ts.id_area_destination
					  JOIN grow.plant p ON p.id_plant=ts.id_plant
					  JOIN grow.strain st ON st.id_strain=p.id_strain
					  JOIN (
							SELECT id_plant
									, CASE WHEN harvested = 1 THEN 'Harvested'
											WHEN destroyed = 1 THEN 'Destroyed'
											WHEN date_flower IS NOT NULL THEN 'Flowering'
											WHEN date_preflower IS NOT NULL THEN 'Pre-Flowering'
											WHEN date_vegetative IS NOT NULL THEN 'Vegetative'
											WHEN date_germination IS NOT NULL THEN 'Germination'
											WHEN date_seedling IS NOT NULL THEN 'Seedling'
											ELSE NULL END AS phase_current
									, CASE WHEN harvested = 1 THEN NULL
											ELSE COALESCE(date_flower, date_preflower, date_vegetative, date_germination, date_seedling) END 
										AS phase_current_date
									, COALESCE(date_seedling, date_germination, date_vegetative, date_preflower, date_flower) AS date_birth
							FROM grow.plant
						) ph ON ph.id_plant=p.id_plant
					  WHERE ts.id_transfer=t.id_transfer
					  FOR JSON PATH
			), '[]') AS strain_receipt_list
			/* status list. */
			, ISNULL((SELECT tsh.id_transfer_status
							, tsh.id_transfer
							, tsh.id_user_verified
							, ts.name AS transfer_status
							, ts.reference AS transfer_status_reference
							, CONCAT(uv.FirstName, ' ', uv.LastName) AS verified_by
							, uv.FirstName AS verified_name_first
							, uv.LastName AS verified_name_last
							, tsh.date_verified
					  FROM grow.transfer_status_history tsh
					  JOIN grow.transfer_status ts ON ts.id_transfer_status=tsh.id_transfer_status
					  JOIN base.[user] uv ON uv.id_user=tsh.id_user_verified
					  WHERE tsh.id_transfer=t.id_transfer
					  ORDER BY tsh.date_verified
					  FOR JSON PATH
			), '[]') AS status_list
	FROM grow.transfer t
	LEFT JOIN base.location sl ON sl.id_location=t.id_location_source
	LEFT JOIN base.location dl ON dl.id_location=t.id_location_destination
	LEFT JOIN inventory.vendor sv ON sv.id_vendor=t.id_vendor_source
	LEFT JOIN inventory.vendor dv ON dv.id_vendor=t.id_vendor_destination
	LEFT JOIN [order].driver d1 ON d1.id_driver=t.id_driver1
	LEFT JOIN [order].driver d2 ON d2.id_driver=t.id_driver2
	LEFT JOIN base.[user] d1u ON d1u.id_user=d1.id_user
	LEFT JOIN base.[user] d2u ON d2u.id_user=d2.id_user
	LEFT JOIN [order].vehicle v ON v.id_vehicle=t.id_vehicle
	WHERE t.id_transfer=@id_transfer
go

