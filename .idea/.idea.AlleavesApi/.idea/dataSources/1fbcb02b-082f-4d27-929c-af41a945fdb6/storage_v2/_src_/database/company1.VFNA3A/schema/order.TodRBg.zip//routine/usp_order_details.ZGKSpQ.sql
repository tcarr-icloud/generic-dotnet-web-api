CREATE procedure [order].[usp_order_details] 
    @id_area int = null,
    @id_location int = null,
    @delivery_date date =null,
	@id_driver_list varchar(200) = null
as
SELECT ride.id_ride
	,ride.id_driver
	,ride.id_order
	,ride.id_area
	,ride.id_driver2
	,ride.signature
	,a.delivery_date
	,driver_user.FirstName + ' ' + driver_user.LastName AS driver1_name
	,o.date_created
	,o.type
	,c.name_first + ' ' + c.name_last AS recipient_name
    ,c.phone
    ,c.phone2
	,a.address1 + ISNULL(', ' + NULLIF(REPLACE(a.address2, ' ' ,''), ''), '') AS address
	,a.city
	,a.state
	,a.zip AS postal_code
    ,a.zip_four
    ,a.lat
    ,a.long
	,location.name AS sender_name
	,location.address AS sender_address
	,location.city AS sender_city
	,location.STATE AS sender_state
	,location.postal_code AS sender_postal_code
	,(
		SELECT TOP 1 ers.driver_message
		FROM [order].ecommerce_ride_status_history history
		JOIN [order].ecommerce_ride_status ers ON ers.id_status = history.id_ride_status
		WHERE ride.id_ride = history.id_ride
		ORDER BY history.created_at DESC
		) AS last_ride_status
	,(
		SELECT TOP 1 history.created_at
		FROM [order].ecommerce_ride_status_history history
		WHERE history.id_ride = ride.id_ride
		ORDER BY history.created_at DESC
		) AS last_ride_status_createdat
	,isnull((
			SELECT id_status_history
				,customer_message
				,driver_message
				,created_at
			FROM [order].ecommerce_ride_status_history history
			JOIN [order].ecommerce_ride_status ers ON ers.id_status = history.id_ride_status
			WHERE ride.id_ride = history.id_ride
			ORDER BY history.created_at
			FOR json path
			), '[]') AS status_list
	,(
		SELECT item.id_item
			,ISNULL(ic.[name], 'Uncategorized') AS category
			,ISNULL(ic.[path], 'Uncategorized') AS category_path
			,i.item
			,id_area
			,b.[name] AS batch
			,i.strain
			,i.uom
			,uom_short
			,item.quantity
		FROM [order].item
		INNER JOIN inventory.batch b ON b.id_batch = item.id_batch
		INNER JOIN inventory.vw_item_list i ON i.id_item = b.id_item
		LEFT OUTER JOIN inventory.vw_category_list ic ON ic.id_category = i.id_category
		WHERE item.id_order = ride.id_order
		FOR json path
		) AS pick_list
FROM [order].ecommerce_ride ride
JOIN [order].[order] o ON o.id_order = ride.id_order
JOIN [order].customer c ON c.id_customer = o.id_customer
LEFT JOIN [order].[address] a ON o.id_order = a.id_order
JOIN [order].driver d ON d.id_driver = ride.id_driver
LEFT JOIN base.[user] driver_user ON d.id_user = driver_user.id_user
LEFT JOIN inventory.area ON ride.id_area = area.id_area
LEFT JOIN base.location ON area.id_location = location.id_location
WHERE 
	 (
		@delivery_date IS NULL
		OR a.delivery_date = @delivery_date
		)
	AND (
		@id_area IS NULL
		OR ride.id_area = @id_area
		)
	AND (
		@id_location IS NULL
		OR location.id_location = @id_location
		)
	AND (
		@id_driver_list IS NULL
		OR ride.id_driver in(SELECT * FROM STRING_SPLIT(@id_driver_list,','))
		)
go

