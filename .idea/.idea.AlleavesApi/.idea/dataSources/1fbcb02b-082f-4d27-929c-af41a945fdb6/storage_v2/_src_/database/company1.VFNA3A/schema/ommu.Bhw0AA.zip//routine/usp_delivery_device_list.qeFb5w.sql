CREATE PROCEDURE [ommu].[usp_delivery_device_list]
	
AS

SELECT dd.id_delivery_device 
		,dd.[name] as ommu_delivery_device
		,dd.[id_order_type]
		,ot.[name] as ommu_order_type
		,dd.[id_form]
		,f.[name] as ommu_form
FROM [ommu].[delivery_device] dd
LEFT JOIN [ommu].[order_type] ot ON ot.id_order_type = dd.id_order_type
LEFT JOIN [ommu].[form] f ON f.id_form = dd.id_form
ORDER BY dd.[name]
go

