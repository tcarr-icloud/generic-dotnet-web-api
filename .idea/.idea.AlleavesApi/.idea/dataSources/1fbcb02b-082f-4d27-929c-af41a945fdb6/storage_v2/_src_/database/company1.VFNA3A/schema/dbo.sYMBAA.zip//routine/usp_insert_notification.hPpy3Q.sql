

CREATE   PROCEDURE [dbo].[usp_insert_notification]
    @id_user int,
    @content varchar(max)
AS
INSERT INTO base.user_notifications (id_user, content, created_at) VALUES (@id_user,@content,getutcdate())

EXEC [dbo].[usp_notifications_list]  @id_user
go

