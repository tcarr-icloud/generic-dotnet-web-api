CREATE PROCEDURE terminal.usp_assignment_update
@id_terminal INT = NULL,
@secret VARCHAR = NULL,
@id_user_created_by INT = NULL,
@id_user_updated_by INT = NULL
AS
BEGIN
    IF EXISTS(select 1 from terminal.assignment WHERE id_terminal=@id_terminal)
        BEGIN
            DELETE FROM terminal.assignment
            WHERE id_terminal = @id_terminal
        end
    ELSE
    BEGIN
    INSERT INTO terminal.assignment (id_terminal,secret,id_user_created_by,id_user_updated_by)
	Values (@id_terminal,@secret,@id_user_created_by,@id_user_updated_by)
	DECLARE @id_assignment INT = SCOPE_IDENTITY()
	EXEC terminal.usp_assignment_list @id_assignment = @id_assignment
    end
end
go

