CREATE PROCEDURE [pos].[usp_template_create]
	@name VARCHAR(256),
	@path VARCHAR(256),
	@id_location INT,
	@id_user INT
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO pos.templates ([name],[path],id_location,id_user_created_by, id_user_modified_by) 
	VALUES (@name,@path,@id_location,@id_user,@id_user)
	DECLARE @id_template INT = SCOPE_IDENTITY()
	EXEC pos.usp_template_list @id_template
END
go

