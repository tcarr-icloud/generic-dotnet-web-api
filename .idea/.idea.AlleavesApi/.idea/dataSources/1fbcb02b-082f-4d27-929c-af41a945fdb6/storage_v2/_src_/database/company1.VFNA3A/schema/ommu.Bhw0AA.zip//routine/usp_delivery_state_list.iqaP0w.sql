CREATE PROCEDURE [ommu].[usp_delivery_state_list]
	
AS

SELECT o.id_delivery_state 
		,o.[name] as ommu_delivery_state
FROM [ommu].[delivery_state] o
ORDER BY o.[name]
go

