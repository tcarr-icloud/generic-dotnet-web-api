CREATE PROCEDURE [base].[usp_user_api_list]
    @id_user INT = NULL
AS
	SELECT    ua.id_user
	        , ua.alleaves_api_key
	        , u.UserName
			, u.UserName as username
			, u.FirstName as name_first
			, u.LastName as name_last
			, CONCAT(u.FirstName, ' ', u.Lastname) AS name_full
			, u.WorkSpaceId AS workspace
			, u.PhoneNumber AS phone
			, u.accountDisabled
			, u.id_company
			, u.PIN AS pin
			, u.employee_id
			, u.EmailUpdate AS email_update
			, u.EmailConfirmed AS email_confirmed
			, u.employee_role
			, u.employee_department
			, u.badge_number
			, ISNULL((SELECT ul.id_user_location
							, ul.id_user
							, ul.id_location
							, bl.[name] as location
							, ul.metrc_api_user_key
							, ul.is_accessible
					  FROM [base].[user_location] ul
					  LEFT JOIN [base].[location] bl ON ul.id_location = bl.id_location
					  AND bl.active = 1
					  FOR JSON PATH
			), '[]') AS user_location_list
	FROM [base].[user_api] ua
	LEFT JOIN base.[user] u ON ua.id_user = u.id_user
    WHERE ua.id_user = ISNULL(@id_user, ua.id_user)
go

