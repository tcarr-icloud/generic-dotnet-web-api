CREATE PROCEDURE [dbo].[usp_user_lookup_list]
	@email VARCHAR(MAX)
AS
	SELECT u.id_user_lookup
			, u.id_company
			, u.email
			, c.name AS company
			, c.reference
			, c.workspace
			, c.is_move_client
	FROM dbo.user_lookup u
	JOIN dbo.company c ON c.id_company=u.id_company
	WHERE LOWER(u.email)=LOWER(@email) AND u.active=1 AND c.active=1
go

