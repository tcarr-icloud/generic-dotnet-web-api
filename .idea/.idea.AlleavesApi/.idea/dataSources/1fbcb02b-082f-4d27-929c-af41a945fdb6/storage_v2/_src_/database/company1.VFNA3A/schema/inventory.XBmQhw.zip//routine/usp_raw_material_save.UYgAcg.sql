CREATE PROCEDURE [inventory].[usp_raw_material_save]
	@id_raw_material INT = NULL,
	@name VARCHAR(512),
	@is_harvest_output BIT = 0,
	@harvest_output_wet BIT = 0,
	@harvest_output_dry BIT = 0,
	@harvest_output_waste BIT = 0,
	@id_user INT
AS
	IF EXISTS (SELECT * FROM inventory.raw_material WHERE deleted=0 AND name=@name AND (@id_raw_material IS NULL OR id_raw_material <> @id_raw_material))
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A raw material with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	IF(@id_raw_material IS NULL)
	BEGIN
		INSERT INTO inventory.raw_material (name, is_harvest_output, harvest_output_wet, harvest_output_dry, harvest_output_waste, id_user_created, id_user_updated)
		VALUES (@name, @is_harvest_output, @harvest_output_wet, @harvest_output_dry, @harvest_output_waste, @id_user, @id_user)

		SET @id_raw_material = SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		UPDATE inventory.raw_material
		SET name=@name
			, is_harvest_output=@is_harvest_output
			, harvest_output_wet=@harvest_output_wet
			, harvest_output_dry=@harvest_output_dry
			, harvest_output_waste=@harvest_output_waste
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_raw_material=@id_raw_material
	END

	EXEC inventory.usp_raw_material_list @id_raw_material
go

