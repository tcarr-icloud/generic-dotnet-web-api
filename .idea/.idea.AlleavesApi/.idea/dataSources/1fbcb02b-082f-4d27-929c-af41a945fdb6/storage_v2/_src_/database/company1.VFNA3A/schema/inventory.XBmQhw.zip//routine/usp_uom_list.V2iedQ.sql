


CREATE PROCEDURE [inventory].[usp_uom_list]
AS
	SET NOCOUNT ON;

	SELECT id_uom
			, name AS uom
			, name_short AS uom_short
			, quantity_type AS quantity_type
			, system
			, deleted
	FROM inventory.uom
	WHERE deleted=0
go

