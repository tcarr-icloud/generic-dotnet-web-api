CREATE PROCEDURE [grow].[usp_transfer_cancel]
	@id_transfer INT,
	@id_user INT
AS
	UPDATE grow.transfer
	SET cancelled=1
		, date_cancelled=GETUTCDATE()
		, id_user_updated=@id_user
		, date_updated=GETUTCDATE()
	WHERE id_transfer=@id_transfer

	INSERT INTO grow.transfer_status_history (id_transfer, id_transfer_status, id_user_verified)
	VALUES (@id_transfer, 5, @id_user)

	/* release plants back into inventory. */
	DROP TABLE IF EXISTS #plant_list
	SELECT p.id_plant
			, CONCAT('TransferID: ', @id_transfer, '; Returned to ', a.path, ' at grid location ', grow.fn_grid_label(p.source_row, p.source_column)) AS notes
	INTO #plant_list
	FROM grow.transfer_plant p
	JOIN inventory.vw_area_list a ON a.id_area=p.id_area_source
	WHERE p.id_transfer=@id_transfer

	/* add plant events. */
	DECLARE @plant_list VARCHAR(MAX) = (
			SELECT p.id_plant
					, p.id_area_source AS id_area
					, p.source_row AS [row]
					, p.source_column AS [column]
				FROM grow.transfer_plant p
				JOIN inventory.vw_area_list a ON a.id_area=p.id_area_source
				WHERE p.id_transfer=@id_transfer
				FOR JSON PATH),
			@notes VARCHAR(128) = CONCAT('TransferID: ', @id_transfer)

	EXEC grow.usp_event_create_bulk 'transfer_cancel', NULL, NULL, NULL, @notes, @plant_list, @id_user


	EXEC grow.usp_transfer_fetch @id_transfer
go

