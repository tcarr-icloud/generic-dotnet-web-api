CREATE PROCEDURE [pos].[usp_withdrawal_list]
	@id_session INT
AS
	SELECT *
	FROM [pos].[withdrawal]
	WHERE id_session = @id_session AND closing_deposit = 1
go

