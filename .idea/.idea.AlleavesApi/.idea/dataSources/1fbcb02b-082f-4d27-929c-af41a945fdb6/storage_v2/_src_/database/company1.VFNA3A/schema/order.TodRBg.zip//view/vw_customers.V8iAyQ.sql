CREATE VIEW [order].[vw_customers]

AS

SELECT 
	 c.name_first + ' ' + c.name_last AS 'Customer Name'
	,c.id_customer
	,c.city AS 'City'
	,c.[state] AS 'State'
	,c.zip AS 'Zip'
	,c.patient_number AS 'Patient Number'
	,c.phone AS 'Phone'
	,c.email AS 'Email'
	,c.date_of_birth AS 'Date of Birth'
	,CAST(c.date_created AT TIME ZONE 'UTC' AT TIME ZONE 'US Eastern Standard Time' as date) AS 'Member Since'
	,i.price_post_tax AS 'Amount Spent'
	,CAST(o.date_created AT TIME ZONE 'UTC' AT TIME ZONE 'US Eastern Standard Time' as date) AS 'Order Date'
	,CAST(p.date_created AT TIME ZONE 'UTC' AT TIME ZONE 'US Eastern Standard Time' as date) AS 'Payment Date'
	,l.[name] AS 'Location'
	,ct.[name] AS 'Product Category'
	,rm.[name] AS 'Referal Method'
	,i.id_item
	,o.id_order
	,l.id_location
	,pr.id_item AS id_inventory_item
	,ct.id_category
FROM [order].[order] o
LEFT OUTER JOIN [order].customer c on c.id_customer = o.id_customer
LEFT OUTER JOIN [order].[item] i ON i.id_order = o.id_order
LEFT JOIN inventory.vw_item_list pr ON pr.id_item=i.id_inventory_item
LEFT JOIN inventory.category ct ON ct.id_category = pr.id_category 
LEFT JOIN [order].referral_method rm ON rm.id_referral_method = c.id_referral_method  
LEFT OUTER JOIN [base].[location] l on l.id_location = o.id_location
LEFT OUTER JOIN [order].[status] s on s.id_status = o.id_status
LEFT OUTER JOIN [pos].[session] ses on ses.id_session = o.id_session
LEFT OUTER JOIN [pos].[register] r on r.id_register = ses.id_register
LEFT OUTER JOIN (
	SELECT 
		id_order, 
		ISNULL([CanPay],0) as [CanPay],
		ISNULL([Cash],0) as [Cash],
		ISNULL([Change],0) as [Change],
		ISNULL([Hypur],0) as [Hypur],
		ISNULL([Store Credit],0) as [Store Credit], 
		date_created
	FROM 
	(SELECT id_order, method, tendered, date_created FROM [order].payment) as src
	PIVOT (SUM(tendered) FOR method IN ([CanPay],[Cash],[Change],[Hypur],[Store Credit])) pvt
) p on p.id_order = o.id_order
WHERE o.paid_in_full = 1 AND o.void = 0
go

