CREATE PROCEDURE [process].[usp_process_session_upsert]
	@id_process INT,
	@id_process_session INT = NULL,
	@num_workers INT = NULL,
	@labor_hours INT = NULL,
	@output_list VARCHAR(MAX) = '[]',
	@finish_session BIT = 0,
	@delete_session BIT = 0,
	@id_user INT
AS
	/* start new session */
	IF(@id_process_session IS NULL)
	BEGIN
		/* insert data for new session. */
		INSERT INTO process.process_session (id_process, session_started_by, num_workers, labor_hours)
		VALUES (@id_process, @id_user, @num_workers, @labor_hours)

		SET @id_process_session=SCOPE_IDENTITY()

		/* insert rows for outputs for new session. */
		INSERT INTO process.process_session_output (id_process_session, id_item)
		SELECT @id_process_session AS id_process_session
				, i.id_item
		FROM process.form_output fo
		JOIN process.form f ON f.id_form=fo.id_form
		JOIN process.process p ON p.id_form=f.id_form
		JOIN inventory.item_group g ON g.id_raw_material=fo.id_raw_material
		JOIN inventory.item i ON i.id_item_group=g.id_item_group
		JOIN grow.strain s ON s.id_strain=g.id_strain
		JOIN (
			SELECT DISTINCT pg.id_strain
			FROM process.process_input pri
			JOIN inventory.batch pb ON pb.id_batch=pri.id_batch
			JOIN inventory.item pbi ON pbi.id_item=pb.id_item
			JOIN inventory.item_group pg ON pg.id_item_group=pbi.id_item_group
			WHERE pri.id_process=@id_process
		) sf ON sf.id_strain=s.id_strain
		WHERE p.id_process=@id_process
	END

	/* delete session. */
	ELSE IF (@delete_session=1)
	BEGIN
		SET @id_process=(SELECT TOP 1 id_process FROM process.process_session WHERE id_process_session=@id_process_session)

		IF (SELECT complete FROM process.process WHERE id_process=@id_process) = 0
		BEGIN
			DELETE FROM process.process_session_output 
			WHERE id_process_session=@id_process_session

			DELETE FROM process.process_session
			WHERE id_process_session=@id_process_session
		END
	END

	/* update session. */
	ELSE
	BEGIN
		IF (SELECT complete FROM process.process WHERE id_process=@id_process) = 0
		BEGIN

			-- TODO: check that at least one output has area/quantity if finishing
			--IF NOT EXISTS (SELECT * FROM OPENJSON(@output_list) WITH (id_area INT '$.id_area', quantity FLOAT '$.quantity') WHERE id_area IS NOT NULL AND quantity IS NOT NULL)
			--	RETURN
			
			/* update session data. */
			UPDATE process.process_session
			SET num_workers=@num_workers
				, labor_hours=@labor_hours
				, session_stopped_by=(CASE WHEN @finish_session=1 OR session_stopped_by IS NOT NULL THEN @id_user ELSE NULL END)
				, session_stopped=(CASE WHEN @finish_session=1 OR session_stopped IS NOT NULL THEN getutcdate() ELSE NULL END)
			WHERE id_process_session=@id_process_session
						
			/* update output values. */
			UPDATE t
			SET t.id_area=s.id_area
				, t.quantity=s.quantity
				, t.batch_label=s.batch_label
			FROM process.process_session_output t
			JOIN OPENJSON(@output_list)
			WITH (
				id_process_session_output INT,
				id_item INT,
				id_area INT,
				batch_label VARCHAR(128),
				quantity DECIMAL(18,4)
			) s ON s.id_process_session_output=t.id_process_session_output

		END
	END

	/* return updated process. */
	EXEC process.usp_process_list @id_process
go

