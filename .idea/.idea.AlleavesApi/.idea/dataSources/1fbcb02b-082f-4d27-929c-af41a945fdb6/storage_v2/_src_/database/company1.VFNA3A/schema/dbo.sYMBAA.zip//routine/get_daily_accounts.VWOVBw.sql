CREATE PROCEDURE [dbo].[get_daily_accounts]
AS
	SET NOCOUNT ON;

	SELECT * FROM [dbo].[daily_accounts]
go

