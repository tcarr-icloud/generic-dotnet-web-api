CREATE PROCEDURE [inventory].[usp_chemical_profile_list]
	@id_chemical_profile INT = NULL,
	@include_deleted BIT = 0
AS
	SELECT cp.id_chemical_profile
			, cp.[name] AS chemical_profile
			, cp.[type]
			, cp.deleted
	FROM inventory.chemical_profile cp
	WHERE cp.id_chemical_profile=ISNULL(@id_chemical_profile, cp.id_chemical_profile) AND
		  cp.deleted<=@include_deleted
	ORDER BY cp.[name]
go

