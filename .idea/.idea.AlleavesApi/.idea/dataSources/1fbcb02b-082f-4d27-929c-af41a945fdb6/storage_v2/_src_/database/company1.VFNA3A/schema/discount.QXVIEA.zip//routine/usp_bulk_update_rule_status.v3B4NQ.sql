CREATE PROCEDURE discount.usp_bulk_update_rule_status 
    @id_rule_list varchar(max), 
    @enabled bit,
    @id_user int
AS

UPDATE [discount].[rules]
SET [enabled]   = isnull(@enabled, [enabled]),
    [updatedAt] = getutcdate(),
[id_user_updated] = @id_user
WHERE ([id] in (SELECT [value] FROM OPENJSON(@id_rule_list, '$')))
go

