CREATE PROCEDURE [dbo].[usp_report_list]
	@id_list VARCHAR(MAX)
AS
	SET NOCOUNT ON;

	SELECT * FROM (
		SELECT rg.ID AS id
				, rg.Name AS report_group
				, rg.Icon AS icon
				, (SELECT r.ID AS id
							, r.GUID AS guid
							, r.Name AS report
					FROM report.report r
					WHERE r.ReportGroupID=rg.ID AND r.GUID IN (SELECT * FROM fn_split_list(@id_list, ','))
					FOR JSON PATH
				) AS report_list
		FROM report.reportgroup rg
	) a
	WHERE report_list IS NOT NULL
go

