CREATE PROCEDURE [ommu].[usp_insert_dispensation]
	@ommu_dispensation_list VARCHAR(MAX) = '[]',
	@id_user INT
AS

	DECLARE @ommu_dispensation_id VARCHAR(64),
			@ommu_order_id VARCHAR(64),
			@id_order INT,
			@id_caregiver INT,
			@caregiver_name VARCHAR(255),
			@physician_name VARCHAR(255)

	DECLARE cur CURSOR FAST_FORWARD FOR
	SELECT 
			ommu_dispensation_id,
			ommu_order_id,
			id_order,
			id_caregiver,
			caregiver_name,
			physician_name
	FROM OPENJSON(@ommu_dispensation_list) 
	WITH (
		ommu_dispensation_id VARCHAR(64),
		ommu_order_id VARCHAR(64),
		id_order INT,
		id_caregiver INT,
		caregiver_name VARCHAR(255),
		physician_name VARCHAR(255)
	)

	OPEN cur
	FETCH NEXT FROM cur INTO @ommu_dispensation_id, @ommu_order_id, @id_order, @id_caregiver, @caregiver_name, @physician_name
		
	WHILE(@@FETCH_STATUS = 0)
	BEGIN
		INSERT INTO [ommu].[dispensation] (ommu_dispensation_id, ommu_order_id, id_order, id_caregiver, caregiver_name, physician_name, created_by, updated_by) 
		VALUES (@ommu_dispensation_id, @ommu_order_id, @id_order, @id_caregiver, @caregiver_name, @physician_name, @id_user, @id_user);
		
		/* update the ommu_dispensed flag on the order to be true and update the caregiver and the physician name on the order if applicable. */
		UPDATE [order].[order]
		SET ommu_dispensed = 1, caregiver_name = @caregiver_name, physician_name = @physician_name
		WHERE id_order=@id_order


		FETCH NEXT FROM cur INTO @ommu_dispensation_id, @ommu_order_id, @id_order, @id_caregiver, @caregiver_name, @physician_name
	END

	CLOSE cur
	DEALLOCATE cur
	

	EXEC ommu.usp_dispensation_list @id_order=NULL
go

