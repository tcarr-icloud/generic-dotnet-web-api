
CREATE    PROCEDURE [dbo].[usp_login_failed] @u VARCHAR(128)

AS
    SET NOCOUNT ON;

update [base].[user]
set
    AccessFailedCount = AccessFailedCount + 1,
    LockoutEnabled = case when AccessFailedCount>=9 then 1 else 0 end,
    LockoutEndDateUtc = case when AccessFailedCount>=9 then dateadd(DD, 1, getutcdate()) else null end
WHERE [user].UserName = @u;
go

