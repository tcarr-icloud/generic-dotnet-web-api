CREATE PROCEDURE external_blaze.usp_get_item_ids
AS
BEGIN
	SELECT id_item
	FROM external_blaze.[item]
END
go

