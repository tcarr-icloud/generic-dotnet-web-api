CREATE PROCEDURE [process].[usp_process_category_create]
	@name VARCHAR(64),
	@sequence INT,
	@id_user INT
AS
	SET NOCOUNT ON

	INSERT INTO process.process_category (guid_process_category, name, sequence, created_by, updated_by) VALUES
		(newid(), @name, @sequence, @id_user, @id_user)

	DECLARE @id_category INT
	SET @id_category=SCOPE_IDENTITY()

	/* shift all subsequent category sequences as necessary. */
	UPDATE process.process_category
	SET sequence=sequence+1
	WHERE sequence>=@sequence AND id_process_category<>@id_category AND deleted=0

	SELECT id_process_category
			, guid_process_category
			, name AS process_category
			, sequence
			, deleted
	FROM process.process_category
	WHERE id_process_category=@id_category
go

