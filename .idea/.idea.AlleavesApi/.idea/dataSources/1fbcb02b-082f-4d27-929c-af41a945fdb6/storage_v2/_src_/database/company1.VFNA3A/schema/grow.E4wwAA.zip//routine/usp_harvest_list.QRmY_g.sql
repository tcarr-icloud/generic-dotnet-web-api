CREATE PROCEDURE [grow].[usp_harvest_list]
	@id_harvest INT = NULL,
	@id_location INT = NULL,
	@start_row INT = 0,
	@end_row INT = 100,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
    SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
		SELECT h.id_harvest
				, h.id_location
				, h.name AS harvest
				, l.name AS location
				, s.name AS strain
				, (SELECT COUNT(*) FROM grow.plant p WHERE p.id_harvest=h.id_harvest) AS num_plants
				, (SELECT COUNT(*) FROM grow.plant p WHERE ('','' + p.id_manicure_list + '','') LIKE ''%,'' + CAST(h.id_harvest AS VARCHAR(255)) + '',%'') AS num_plants_manicured
				, CASE WHEN h.finished = 1 OR h.date_trim_end IS NOT NULL THEN ''Finished''
					   WHEN h.date_trim_start IS NOT NULL THEN ''Trimming''
					   ELSE ''Drying'' END AS status
				, h.date_created
				, CAST(h.date_created AT TIME ZONE ''UTC'' AT TIME ZONE tl.[tz_windows] as datetime) as date_created_local	
				, CONCAT(u.FirstName, '' '', u.LastName) AS user_created
				, h.metrc_id
				, h.metrc_harvest
		FROM grow.harvest h
		JOIN base.location l ON l.id_location=h.id_location
		JOIN base.[user] u ON u.id_user=h.id_user_created
		LEFT JOIN grow.strain s ON s.id_strain=h.id_strain
		LEFT OUTER JOIN [dbo].[tz_lookup] as tl ON l.[timezone] = tl.[tz_iana]
	) inventory'
	
	SET @where = 'WHERE id_harvest = '+ ISNULL(CAST(@id_harvest AS VARCHAR(16)), 'id_harvest')
	SET @where = @where + CASE WHEN @id_location IS NULL THEN '' ELSE ' AND id_location = '+ CAST(@id_location AS VARCHAR(16)) END
	
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'id_harvest')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order


	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

