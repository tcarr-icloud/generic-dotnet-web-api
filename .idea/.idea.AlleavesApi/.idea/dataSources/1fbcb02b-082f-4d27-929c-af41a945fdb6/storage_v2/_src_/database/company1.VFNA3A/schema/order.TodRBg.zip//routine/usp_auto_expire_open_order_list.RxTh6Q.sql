CREATE PROCEDURE [order].[usp_auto_expire_open_order_list]
AS
	SELECT oo.id_order
		,oo.id_location
		,bl.[name] AS [location]
		,ISNULL((
					SELECT CAST((CASE WHEN (DATEADD(day, 1, CAST(delivery_date as datetime)) AT TIME ZONE tz.tz_windows > GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows) THEN 1 
							ELSE 0 
							END) AS BIT) AS future_delivery_date
					FROM [order].[address] a
					WHERE id_order = oo.id_order
					FOR JSON PATH
						,WITHOUT_ARRAY_WRAPPER
					), '{}') AS delivery_address
		,CAST((
			CASE WHEN (DATEADD(day, 1, CAST(pu.pickup_date as datetime)) AT TIME ZONE tz.tz_windows > GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows) THEN 1 
			ELSE 0 
			END) AS BIT) AS future_pickup_date
		,DATEDIFF(hour, oo.date_updated, GETUTCDATE()) AS hours_since_last_update
		,DATEDIFF(hour, GETUTCDATE(), DATEADD(day, CASE
	        WHEN DATENAME(dw, oo.date_updated) = 'Friday' THEN 3
            WHEN DATENAME(dw, oo.date_updated) = 'Saturday' THEN 2
            ELSE 1
            END,
			oo.date_updated)
		) AS nbd_hours_since_last_update
	FROM [order].[order] oo 
	LEFT OUTER JOIN [order].[pickup] AS pu ON pu.id_order = oo.id_order
	LEFT OUTER JOIN [base].[location] AS bl ON bl.id_location = oo.id_location
	LEFT OUTER JOIN [dbo].[tz_lookup] tz on tz.tz_iana = bl.timezone
	WHERE oo.cancel = 0 AND oo.paid_in_full = 0 AND oo.void = 0 AND oo.complete = 0 AND oo.ommu_dispensed = 0
	ORDER BY oo.id_order
go

