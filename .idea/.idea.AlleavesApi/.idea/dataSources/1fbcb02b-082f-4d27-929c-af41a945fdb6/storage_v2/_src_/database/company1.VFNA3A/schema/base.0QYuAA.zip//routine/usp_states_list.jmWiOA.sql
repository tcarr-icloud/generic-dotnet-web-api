CREATE   PROCEDURE [base].[usp_states_list]
AS
	SET NOCOUNT ON;

	SELECT s.id_state,
		   s.name,
		   s.abbreviation
	FROM base.states s
	ORDER BY s.name
go

