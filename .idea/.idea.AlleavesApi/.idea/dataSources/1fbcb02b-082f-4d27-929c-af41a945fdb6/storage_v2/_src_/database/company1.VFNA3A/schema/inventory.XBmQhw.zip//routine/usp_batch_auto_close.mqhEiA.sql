
CREATE PROCEDURE [inventory].[usp_batch_auto_close]
	 @id_batch INT
AS
BEGIN
    -- Check if the batch status is closed
    DECLARE @batch_status INT
    SELECT @batch_status = id_status FROM inventory.batch WHERE id_batch = @id_batch

    IF (@batch_status = 3)
    BEGIN
        -- Check if the package has a metrc_package_label and metrc_finished is 1
        IF EXISTS(SELECT 1 FROM [inventory].batch WHERE id_batch = @id_batch AND metrc_package_label IS NOT NULL)
        BEGIN
            DECLARE @metrc_finished BIT
            SELECT @metrc_finished = metrc_finished FROM [inventory].batch WHERE id_batch = @id_batch AND metrc_package_label IS NOT NULL

            IF (@metrc_finished = 1)
            BEGIN
                -- Move the batch to the auto_close_log table
                INSERT INTO inventory.batch_auto_close_log (id_batch, date_created, date_updated)
                SELECT id_batch, GETUTCDATE(), GETUTCDATE() FROM inventory.batch_auto_close
                WHERE id_batch = @id_batch;
                
                -- Remove the batch from the inventory_auto_close table
                DELETE FROM inventory.batch_auto_close
                WHERE id_batch = @id_batch;
            END
        END
        ELSE
        BEGIN
            -- If package does not have metrc_package_label, move the batch to the auto_close_log table
            INSERT INTO inventory.batch_auto_close_log (id_batch, date_created, date_updated)
            SELECT id_batch, GETUTCDATE(), GETUTCDATE() FROM inventory.batch_auto_close
            WHERE id_batch = @id_batch;
            
            -- Remove the batch from the inventory_auto_close table
            DELETE FROM inventory.batch_auto_close
            WHERE id_batch = @id_batch;
        END
    END
END
go

