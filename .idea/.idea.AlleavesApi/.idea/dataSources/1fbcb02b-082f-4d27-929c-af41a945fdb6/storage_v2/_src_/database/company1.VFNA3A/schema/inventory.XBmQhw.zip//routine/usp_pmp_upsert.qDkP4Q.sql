CREATE PROCEDURE [inventory].[usp_pmp_upsert]
	@id_pmp INT = NULL,
    @id_location INT = NULL,
	@enable_pmp BIT,
	@username VARCHAR(128),
	@password VARCHAR(128),
	@iv VARCHAR(128),
	@auto_submit_time VARCHAR(32),
	@deleted BIT = 0,
	@id_user INT
AS
BEGIN
	-- Check if a record with the matching id_location exists
	IF EXISTS(SELECT 1 FROM [inventory].[pmp] WHERE id_location = @id_location)
	BEGIN
		-- Update existing record
		UPDATE [inventory].[pmp]
		SET [enable_pmp] = @enable_pmp
			, [username] = @username
			, [password] = @password
			, [iv] = @iv
			, [auto_submit_time] = @auto_submit_time
			, [deleted] = @deleted
			, [id_user_updated] = @id_user
			, [date_updated] = GETUTCDATE()
		WHERE [id_location] = @id_location
	END
	ELSE
	BEGIN
		-- Insert new record
		INSERT INTO [inventory].[pmp] ([id_location], [enable_pmp], [username], [password], [iv], [auto_submit_time], [deleted], [id_user_created], [id_user_updated], [date_created], [date_updated])
		VALUES (@id_location, @enable_pmp, @username, @password, @iv, @auto_submit_time, 0, @id_user, @id_user, GETUTCDATE(), GETUTCDATE())

		SET @id_pmp = SCOPE_IDENTITY()
	END
		EXEC inventory.usp_pmp_list @id_pmp
END
go

