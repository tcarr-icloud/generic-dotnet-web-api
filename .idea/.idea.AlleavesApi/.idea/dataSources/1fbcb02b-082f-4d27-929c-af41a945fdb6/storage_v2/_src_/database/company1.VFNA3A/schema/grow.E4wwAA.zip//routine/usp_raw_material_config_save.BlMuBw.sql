CREATE PROCEDURE [grow].[usp_raw_material_config_save]
	@id_raw_material_config INT = NULL,
	@id_raw_material INT,
	@item_name VARCHAR(512),
	@id_category INT = NULL,
	@id_uom INT,
	@id_uom_receiving INT,
	@units_per_received DECIMAL(18,4) = NULL,
	@threshold_low_quantity DECIMAL(18,4) = NULL,
	@has_expiration BIT = 0,
	@shelf_life_days INT = NULL,
	@id_uom_weight_useable INT,
	@weight_useable DECIMAL(18,4),
	@id_uom_gross_weight_useable INT,
	@gross_weight_useable DECIMAL(18,4),
	@id_uom_weight_net INT,
	@weight_net DECIMAL(18,4),
	@cost_of_good DECIMAL(18,4),
	@id_user INT
AS
	IF (@id_raw_material_config IS NULL)
	BEGIN

		INSERT INTO grow.raw_material_config (id_raw_material, item_name, id_category, id_uom, id_uom_receiving, units_per_received, threshold_low_quantity, has_expiration, shelf_life_days, id_uom_weight_useable, weight_useable, weight_net, id_uom_weight_net, id_uom_gross_weight_useable, gross_weight_useable, cost_of_good, id_user_created, id_user_updated)
		VALUES (@id_raw_material, @item_name, @id_category, @id_uom, @id_uom_receiving, @units_per_received, @threshold_low_quantity, @has_expiration, @shelf_life_days, @id_uom_weight_useable, @weight_useable, @weight_net, @id_uom_weight_net, @id_uom_gross_weight_useable, @gross_weight_useable, @cost_of_good, @id_user, @id_user)

		SET @id_raw_material_config = SCOPE_IDENTITY()
	END
	ELSE
		UPDATE grow.raw_material_config
		SET id_raw_material=@id_raw_material
			, item_name=@item_name
			, id_category=@id_category
			, id_uom=@id_uom
			, id_uom_receiving=@id_uom_receiving
			, units_per_received=@units_per_received
			, threshold_low_quantity=@threshold_low_quantity
			, has_expiration=@has_expiration
			, shelf_life_days=@shelf_life_days
			, id_uom_weight_useable=@id_uom_weight_useable
			, weight_useable=@weight_useable
			, weight_net=@weight_net
			, id_uom_weight_net=@id_uom_weight_net
			, id_uom_gross_weight_useable=@id_uom_gross_weight_useable
			, gross_weight_useable=@gross_weight_useable
			, cost_of_good=@cost_of_good
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_raw_material_config=@id_raw_material_config

	
	EXEC grow.usp_raw_material_config_list @id_raw_material_config
go

