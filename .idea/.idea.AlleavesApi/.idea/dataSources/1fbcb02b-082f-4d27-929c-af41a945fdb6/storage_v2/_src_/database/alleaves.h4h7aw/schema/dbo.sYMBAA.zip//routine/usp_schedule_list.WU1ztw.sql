CREATE PROCEDURE [dbo].[usp_schedule_list]
	@id_company INT = NULL
AS
	SELECT id_schedule
		, schedule
		, ds.id_company
		, dc.name AS company
		, dc.reference AS client_reference
		, dc.db_host
		, dc.db_user
		, dc.db_password
		, dc.db_port
		, job_reference
		, ds.[url]
	FROM dbo.schedule ds
	LEFT JOIN dbo.company dc ON dc.id_company = ds.id_company
	WHERE ds.id_company=ISNULL(@id_company, ds.id_company) AND
		  ds.active=1
go

