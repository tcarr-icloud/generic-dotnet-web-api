CREATE PROCEDURE [order].[usp_warehouse_list]
	@id_warehouse INT = NULL
AS
    SELECT w.*,
           ISNULL((SELECT er.* FROM [order].ride_warehouse rw
               INNER JOIN [order].ecommerce_ride er ON rw.id_ride = er.id_ride
               WHERE w.id_warehouse = rw.id_warehouse
               FOR JSON PATH),'[]') AS ride_list
    FROM [order].warehouse w
    WHERE w.id_warehouse = ISNULL(@id_warehouse,w.id_warehouse)
go

