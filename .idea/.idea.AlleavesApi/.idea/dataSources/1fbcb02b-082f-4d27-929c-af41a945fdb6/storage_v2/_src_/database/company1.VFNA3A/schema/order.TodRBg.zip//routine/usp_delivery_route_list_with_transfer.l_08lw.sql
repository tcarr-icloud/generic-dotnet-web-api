CREATE PROCEDURE [order].[usp_delivery_route_list_with_transfer]
	@id_delivery_route INT = NULL,
	@id_ride_transfer_delivery_route INT = NULL,
	@id_transfer INT = NULL,
	@id_driver INT = NULL
AS
    SELECT 
    	dr.id_delivery_route, 
    	dr.id_driver,
    	dr.status,
    	rtdr.id_ride_transfer_delivery_route,
    	rtdr.id_transfer,
    	rtdr.position
    FROM [order].delivery_route dr
    LEFT JOIN [order].ride_transfer_delivery_route rtdr
    	ON rtdr.id_delivery_route = dr.id_delivery_route
    WHERE 
    		dr.id_delivery_route = ISNULL(@id_delivery_route, dr.id_delivery_route) 
    	AND dr.id_driver= ISNULL(@id_driver, dr.id_driver) 
    	AND rtdr.id_transfer = ISNULL(@id_transfer, rtdr.id_transfer) 
    	AND rtdr.id_ride_transfer_delivery_route = ISNULL(@id_ride_transfer_delivery_route, rtdr.id_ride_transfer_delivery_route) 
   	ORDER BY dr.id_delivery_route DESC
go

