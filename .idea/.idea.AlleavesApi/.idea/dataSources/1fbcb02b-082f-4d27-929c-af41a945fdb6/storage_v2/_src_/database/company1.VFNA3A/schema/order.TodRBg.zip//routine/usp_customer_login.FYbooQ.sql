CREATE 
 PROCEDURE [order].[usp_customer_login] @email VARCHAR(255)
AS
SELECT c.id_customer
     , c.name_first
     , c.name_last
     , c.phone
     , c.email
     , c.PasswordHash as hash
FROM [order].[customer] c
WHERE c.email = @email
go

