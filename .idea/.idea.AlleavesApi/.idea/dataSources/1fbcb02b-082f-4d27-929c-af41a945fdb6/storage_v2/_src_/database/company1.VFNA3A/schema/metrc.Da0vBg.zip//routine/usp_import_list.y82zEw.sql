CREATE PROCEDURE [metrc].[usp_import_list]
	@id_location INT = NULL,
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
	SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
				SELECT b.id_batch
				, i.id_item
				, l.id_location
				, l.name AS location
				, b.metrc_package_label
				, g.name AS item
				, p.imported_quantity AS quantity
				, uom.name AS uom
				, c.path AS category
				, p.transfer_cost
				, p.imported_quantity * COALESCE(il.price_otd_medical_use, il.price_retail_medical_use, i.price_otd_medical_use, i.price_retail_medical_use, 0) AS retail_value_medical
				, p.imported_quantity * COALESCE(il.price_otd_adult_use, il.price_retail_adult_use, i.price_otd_adult_use, i.price_retail_adult_use, 0) AS retail_value_adult
				, p.manifest_number
				, m.shipper AS vendor
				, m.shipper_facility AS vendor_facility
				, m.package_count
				, m.date_received
				, p.date_imported
				, CONCAT(u.FirstName, '' '', u.LastName) AS imported_by
		FROM metrc.crawler_package p
		JOIN inventory.batch b ON b.metrc_package_label=p.package
		LEFT JOIN inventory.uom uom ON uom.id_uom=p.id_uom_imported
		LEFT JOIN metrc.crawler_manifest m ON m.manifest_number=p.manifest_number
		JOIN base.[user] u ON u.id_user=p.id_user_imported
		JOIN base.location l ON l.id_location=p.id_location
		JOIN inventory.item i ON i.id_item=b.id_item
		JOIN inventory.item_group g ON g.id_item_group=i.id_item_group
		LEFT JOIN inventory.item_location il ON il.id_item=i.id_item AND il.id_location=l.id_location
		LEFT JOIN inventory.vw_category_list c ON c.id_category=g.id_category
		WHERE p.imported=1 AND (p.id_user_imported IS NULL OR p.id_user_imported <> -1)
	) package'

	SET @where = 'WHERE id_location = '+ ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location')
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'date_imported DESC')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

