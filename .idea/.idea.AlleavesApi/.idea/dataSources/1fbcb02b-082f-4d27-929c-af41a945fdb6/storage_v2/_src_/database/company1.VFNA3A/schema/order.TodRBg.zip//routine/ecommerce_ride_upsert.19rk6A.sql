CREATE
 procedure [order].ecommerce_ride_upsert      @id_ride int = null,
                                              @id_user int = null,
                                              @id_order int = null,
                                              @id_area int = null,
                                              @signature varchar(MAX) = '',
                                              @patient_id_front varchar(MAX) = '',
                                              @patient_id_back varchar(MAX) = '',
                                              @driver_license_front varchar(MAX) = '',
                                              @driver_license_back varchar(MAX) = '',
                                              @delivery_date date = null
as


declare
    @id_driver int = NULL
    if (@id_user is not null)
        begin
            set @id_driver = (select id_driver
                      from [order].driver
                      where id_user = @id_user);
        end
    
    if (@id_order is not null)
        begin
            set @id_ride = (select id_ride from [order].ecommerce_ride where id_order = @id_order)
        end
    
    if (@id_ride is null)
        begin
            insert into [order].ecommerce_ride (id_driver, id_order, id_area,signature,delivery_date)
            values (@id_driver, @id_order, @id_area , @signature,@delivery_date);

            set @id_ride = scope_identity()
            declare @id_status int = (select id_status
                                      from [order].ecommerce_ride_status
                                      where reference = 'order_create')

            insert into [order].ecommerce_ride_status_history (id_ride, id_ride_status, created_at)
            values (@id_ride, @id_status, getutcdate());
        end

    ELSE
        BEGIN
            update [order].ecommerce_ride
            set id_driver = isnull(@id_driver,id_driver),
                id_area = isnull(@id_area,id_area),
                signature = isnull(@signature,signature),
                patient_id_front = isnull(@patient_id_front,patient_id_front),
                patient_id_back = isnull(@patient_id_back,patient_id_back),
                driver_license_front = isnull(@driver_license_front,driver_license_front),
                driver_license_back = isnull(@driver_license_back,driver_license_back),
                delivery_date = isnull(@delivery_date,delivery_date),
                delivered_time = getutcdate()
            where id_ride = @id_ride
        end
    exec [order].ecommerce_ride_list @id_ride;
go

