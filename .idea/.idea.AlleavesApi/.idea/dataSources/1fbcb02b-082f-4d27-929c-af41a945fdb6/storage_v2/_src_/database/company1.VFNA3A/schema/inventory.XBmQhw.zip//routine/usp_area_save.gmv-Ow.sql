CREATE PROCEDURE [inventory].[usp_area_save]
	@id_area INT,
	@id_parent INT,
	@id_location INT,
	@id_area_type INT,
	@internal_id_area INT,
	@id_status INT,
	@name VARCHAR(128),
	@rows INT = NULL,
	@columns INT = NULL,
	@canopy_sqft FLOAT = NULL,
	@metrc_id INT,
	@deleted BIT = 0,
	@id_user INT,
	@id_area_move INT = NULL,
	@returnable BIT = 0,
	@priority INT = NULL,
	@mobile BIT = 0
AS
	IF(@id_area IS NOT NULL)
		SELECT @id_area_type=id_area_type, @id_location = id_location
		FROM inventory.area WHERE id_area=@id_area
	DECLARE @msg VARCHAR(MAX)

	/* check for duplicate. */
	IF EXISTS (SELECT * FROM inventory.area WHERE name=@name AND id_area_type=@id_area_type AND @deleted<>1 AND deleted=0 AND ((id_parent IS NULL AND @id_parent IS NULL) OR id_parent=@id_parent) AND (@id_area IS NULL OR id_area<>@id_area) AND id_location=@id_location)
	BEGIN
		SET @msg = 'An area with this name under the same parent already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END
	/* check for delete used metrc area. */
	-- IF (@deleted=1 AND @id_area IS NOT NULL AND (SELECT is_metrc FROM base.location WHERE id_location=@id_location)=1 AND (EXISTS (SELECT * FROM inventory.inventory WHERE id_area=@id_area) OR EXISTS (SELECT * FROM grow.plant WHERE id_area=@id_area)))
	-- BEGIN
	-- 	SET @msg = 'Cannot delete an area from a Metrc facility that has already been in use.'
	-- 	RAISERROR(@msg, 11, 1)
	-- 	RETURN
	-- END


	/* create area. */
	IF (@id_area IS NULL)
	BEGIN
		/* set area type to storage if id_area_type is null. */
		IF(@id_area_type = NULL)
			SET @id_area_type=(SELECT TOP 1 a.id_area_type FROM area_type a WHERE a.name='storage')

		/* insert new area. */
		INSERT INTO inventory.area (id_location, id_parent, name, id_area_type, [rows], [columns], canopy_sqft, updated_by, metrc_id, [priority]) VALUES
			(@id_location, @id_parent, @name, @id_area_type, @rows, @columns, @canopy_sqft, @id_user, @metrc_id, @priority);

		SET @id_area=SCOPE_IDENTITY()
	END
	/* update area. */
	BEGIN
		UPDATE inventory.area
		SET name=@name
			, id_parent=@id_parent
			, [rows]=@rows
			, [columns]=@columns
			, canopy_sqft=@canopy_sqft
			, metrc_id = @metrc_id
			, deleted=@deleted
			, updated_by=@id_user
			, date_updated=getutcdate()
			, returnable=@returnable
			, [priority]=@priority
			, mobile=@mobile
			, internal_id_area=@internal_id_area
		WHERE id_area=@id_area
	END


	IF(@deleted=1 AND @id_area_move IS NOT NULL)
	BEGIN
		/* deleted all child areas. */
		;WITH	area_hierarchy AS (
					SELECT a.* 
					FROM inventory.area a
					WHERE a.id_area=@id_area
					UNION ALL
					SELECT b.* 
					FROM inventory.area b
					JOIN area_hierarchy h ON h.id_area=b.id_parent
				)
		UPDATE inventory.area
		SET deleted=@deleted
			, updated_by=@id_user
			, date_updated=getutcdate()
		WHERE id_area IN (SELECT id_area FROM area_hierarchy)
		
		/* move inventory to new area. */
		DECLARE @id_area_source INT, 
				@id_area_destination INT,
				@id_batch INT,
				@quantity DECIMAL(18,4),
				@quantity_neg DECIMAL(18,4)
		
		DECLARE c CURSOR FOR 
		WITH	area_hierarchy AS (
					SELECT a.* 
					FROM inventory.area a
					WHERE a.id_area=@id_area
					UNION ALL
					SELECT b.* 
					FROM inventory.area b
					JOIN area_hierarchy h ON h.id_area=b.id_parent
				)				
		SELECT id_area AS id_area_source, @id_area_move AS id_area_destination, id_batch, available AS quantity
		FROM inventory.vw_current_inventory
		WHERE id_area IN (SELECT id_area FROM area_hierarchy) AND available>0

		OPEN c

		FETCH NEXT FROM c INTO @id_area_source, @id_area_destination, @id_batch, @quantity

		WHILE @@FETCH_STATUS = 0 BEGIN
			SET @quantity_neg = -@quantity
			/* move items. */
			EXEC [log].usp_event_create 'inventory_move', @id_batch, @id_area_source, @quantity_neg, 'Moving inventory due to area deletion', @id_user
			EXEC [log].usp_event_create 'inventory_move', @id_batch, @id_area_destination, @quantity, 'Moving inventory due to area deletion', @id_user

			FETCH NEXT FROM c INTO @id_area_source, @id_area_destination, @id_batch, @quantity
		END

		CLOSE c
		DEALLOCATE c
		
		/* move plants to new area. */
		;WITH	area_hierarchy AS (
					SELECT a.* 
					FROM inventory.area a
					WHERE a.id_area=@id_area
					UNION ALL
					SELECT b.* 
					FROM inventory.area b
					JOIN area_hierarchy h ON h.id_area=b.id_parent
				)
		UPDATE grow.plant
		SET id_area=@id_area_move
		WHERE id_area IN (SELECT id_area FROM area_hierarchy)
	
	END


	/* return area. */
	EXEC inventory.usp_area_list NULL, @id_area, 1
go

