CREATE PROCEDURE [base].[usp_delete_donation]
    @id INT
AS
BEGIN
    DELETE FROM [base].[donation]
    WHERE id = @id
END;
go

