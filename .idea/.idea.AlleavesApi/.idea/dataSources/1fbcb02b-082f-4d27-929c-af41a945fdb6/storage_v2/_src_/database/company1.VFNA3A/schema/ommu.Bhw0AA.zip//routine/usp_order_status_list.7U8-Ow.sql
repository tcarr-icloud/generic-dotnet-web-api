CREATE PROCEDURE [ommu].[usp_order_status_list]
	
AS

SELECT o.id_order_status 
		,o.[name] as ommu_order_status
FROM [ommu].[order_status] o
ORDER BY o.[name]
go

