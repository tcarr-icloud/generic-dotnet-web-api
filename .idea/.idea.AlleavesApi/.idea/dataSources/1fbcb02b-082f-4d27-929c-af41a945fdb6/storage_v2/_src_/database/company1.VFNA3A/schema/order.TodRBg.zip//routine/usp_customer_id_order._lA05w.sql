CREATE PROCEDURE [order].[usp_customer_id_order]
    @id_order INT = NULL
AS
SELECT o.id_order,
       cd.id_customer,
       cd.name_first,
       cd.name_last,
       cd.phone,
       cd.phone2,
       cd.email,
       cd.address1,
       cd.address2,
       cd.city,
       cd.state,
       cd.zip
from [order].[order] as o
LEFT JOIN [order].[customer] cd ON cd.id_customer = o.id_customer
WHERE o.id_order = @id_order
go

