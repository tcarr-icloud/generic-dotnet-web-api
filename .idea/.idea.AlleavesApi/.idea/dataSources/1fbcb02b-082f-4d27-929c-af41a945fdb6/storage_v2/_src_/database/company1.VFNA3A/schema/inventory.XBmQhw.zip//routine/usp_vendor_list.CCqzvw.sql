CREATE PROCEDURE [inventory].[usp_vendor_list]
	@id_vendor INT = NULL,
	@deleted BIT = 0,
	@postal_code VARCHAR(32) = NULL
AS
	SELECT v.id_vendor
			, v.deleted
			, v.[name] AS vendor
			, v.dba
			, v.account_number
			, v.phone
			, v.fax
			, v.website
			, v.billing_address
			, v.billing_city
			, v.billing_state
			, v.billing_postal_code
			, v.is_same_as_billing
			, CASE WHEN v.is_same_as_billing=1 THEN v.billing_address ELSE v.shipping_address END AS shipping_address
			, CASE WHEN v.is_same_as_billing=1 THEN v.billing_city ELSE v.shipping_city END AS shipping_city
			, CASE WHEN v.is_same_as_billing=1 THEN v.billing_state ELSE v.shipping_state END AS shipping_state
			, CASE WHEN v.is_same_as_billing=1 THEN v.billing_postal_code ELSE v.shipping_postal_code END AS shipping_postal_code
			, v.external_id
			, v.note
			, v.po_terms
			, v.payment_method
			, v.metrc_facility_license_number
			, ISNULL
			(
				(
					SELECT 
						  vb.id_vendor
						, vb.id_brand
						, b.[name] AS brand
					FROM [inventory].[vendor_brand] vb
					LEFT JOIN [inventory].[brand] b ON b.id_brand = vb.id_brand
					WHERE vb.id_vendor = v.id_vendor
					FOR JSON PATH
				), 
				'[]'
			) AS brand_list
			, ISNULL
			(
				(
					SELECT 
						  vc.id_vendor
						, vc.id_vendor_contact
						, vc.name_first			
						, vc.name_last	
						, vc.title			
						, vc.email			
						, vc.phone1				
						, vc.phone2
					FROM [inventory].[vendor_contact] vc
					WHERE vc.id_vendor = v.id_vendor AND vc.deleted=0
					FOR JSON PATH
				), 
				'[]'
			) AS contact_list
	FROM inventory.vendor v
	WHERE v.id_vendor=ISNULL(@id_vendor, v.id_vendor) 
	AND v.deleted <= @deleted
	AND (@postal_code is null or v.billing_postal_code = @postal_code or v.shipping_postal_code=@postal_code )
	ORDER BY v.name
go

