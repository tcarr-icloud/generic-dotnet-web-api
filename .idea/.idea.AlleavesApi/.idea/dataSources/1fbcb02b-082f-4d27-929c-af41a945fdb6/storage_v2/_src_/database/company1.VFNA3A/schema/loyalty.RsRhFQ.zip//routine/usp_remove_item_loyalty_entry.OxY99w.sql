
create procedure loyalty.usp_remove_item_loyalty_entry @id_loyalty_item int
AS

    declare @id_order int = (select oi.id_order from loyalty.[item]
                                             join [order].item oi on item.id_order_item = oi.id_item
where id_loyalty_item = @id_loyalty_item)

delete
from loyalty.[item]
where id_loyalty_item = @id_loyalty_item;
go

