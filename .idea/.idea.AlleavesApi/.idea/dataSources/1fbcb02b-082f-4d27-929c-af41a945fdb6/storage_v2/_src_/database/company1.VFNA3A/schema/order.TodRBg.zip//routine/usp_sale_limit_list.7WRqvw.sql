CREATE PROCEDURE [order].[usp_sale_limit_list]
	@id_sale_limit INT = NULL,
	@id_state INT = NULL,
	@include_deleted BIT = 0
AS
	SELECT s.id_sale_limit
			, s.id_state
			, s.id_uom
			, st.name AS state
			, st.abbreviation AS state_abbreviation
			, s.timespan
			, s.rolling_days
			, s.residence_type
			, s.is_adult
			, s.is_medical
			, s.amount
			, s.weight_type
			, u.name AS uom
			, u.name_short AS uom_short
			, ISNULL((SELECT sr.id_sale_limit_delivery_route
							, sr.id_delivery_route
							, dr.name AS delivery_route
					  FROM [order].sale_limit_delivery_route sr
					  JOIN inventory.delivery_route dr ON dr.id_delivery_route=sr.id_delivery_route
					  WHERE sr.id_sale_limit=s.id_sale_limit
					  FOR JSON PATH
			), '[]') AS delivery_route_list
	FROM [order].sale_limit s
	JOIN inventory.uom u ON u.id_uom=s.id_uom
	JOIN base.states st ON st.id_state=s.id_state
	WHERE (@id_sale_limit IS NULL OR s.id_sale_limit=@id_sale_limit) AND
		  (@id_state IS NULL OR s.id_state=@id_state) AND
		  (@include_deleted IS NULL OR s.deleted<=@include_deleted)
	ORDER BY st.abbreviation, s.timespan, s.residence_type
go

