

CREATE    PROCEDURE [dbo].[usp_user_list]
@id_user INT = NULL
AS
SELECT a.id_user
, c.id_company
, a.UserName as username
, a.FirstName as name_first
, a.LastName as name_last
, a.WorkSpaceId AS workspace
, a.accountDisabled
, c.name AS company
, c.reference AS company_reference
       , a.LockoutEnabled
, (SELECT r.id_role
, r.[Name] as role
FROM [base].[role] r
JOIN [base].[user_role] ur ON ur.id_role=r.id_role
WHERE ur.id_user=a.id_user
FOR JSON PATH
) AS role_list
FROM [base].[user] a
LEFT JOIN base.company c ON c.id_company=a.id_company
WHERE a.id_user <> -1
AND (@id_user IS NULL OR (@id_user = a.id_user))
AND a.deleted = 0
go

