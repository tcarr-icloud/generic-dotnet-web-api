CREATE   PROCEDURE [dbo].[usp_admin_role_update]
	@id_role INT,
	@role VARCHAR(128)
AS
	SET NOCOUNT ON;

	IF(@role='SuperUser')
		RETURN

	UPDATE [base].[role]
	SET [Name]=@role
	WHERE id_role=@id_role

	SELECT id_role, [Name]
	FROM [base].[role]
	WHERE id_role=@id_role
go

