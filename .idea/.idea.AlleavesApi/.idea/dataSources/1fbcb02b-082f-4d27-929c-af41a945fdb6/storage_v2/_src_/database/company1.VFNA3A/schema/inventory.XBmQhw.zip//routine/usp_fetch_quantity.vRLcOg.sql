CREATE PROCEDURE [inventory].[usp_fetch_quantity]
	@id_item INT
AS
BEGIN
SET NOCOUNT ON;
SELECT 
    MIN(b.id_item) AS id_item,
    SUM(i.quantity) AS quantity
FROM inventory.inventory i
JOIN inventory.batch b ON b.id_batch=i.id_batch
WHERE b.id_item = @id_item;
END;
go

