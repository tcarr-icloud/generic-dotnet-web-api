CREATE VIEW [inventory].[vw_inventory_adjustment]

AS

SELECT a.id_area
	,atp.id_area_type
	,b.id_batch
	,i.id_item_group
	,i.id_item
	,c.id_category
	,lo.id_location
	,u.id_user
	,i.item AS inventory_item
	,c.[name] AS category 
	,b.[name] AS batch_number      
	,li.adjustment
	,um.[name] AS uom
	,ar.[name] AS adjust_reason
	,l.adjust_reason AS 'description'
	,atp.[name] AS area
	,lo.[name] AS 'location'
	,u.FirstName + ' ' + u.LastName AS employee
	,l.date_created AS 'date'
FROM [inventory].[log] l
LEFT JOIN [inventory].log_item li ON li.id_log = l.id_log
LEFT JOIN [inventory].adjust_reason ar ON ar.id_adjust_reason = l.id_adjust_reason
LEFT JOIN [inventory].batch b ON b.id_batch = li.id_batch
LEFT JOIN [inventory].inventory iv ON iv.id_batch = b.id_batch
LEFT JOIN [inventory].area a ON a.id_area = iv.id_area
LEFT JOIN [inventory].area_type atp ON atp.id_area_type = a.id_area_type
LEFT JOIN [inventory].vw_item_list i ON i.id_item = b.id_item
LEFT JOIN [inventory].category c ON c.id_category = i.id_category
LEFT JOIN [base].[user] u ON u.id_user = l.created_by
LEFT JOIN [inventory].[uom] um ON um.id_uom = i.id_uom
LEFT JOIN [base].[location] lo ON lo.id_location = a.id_location
go

