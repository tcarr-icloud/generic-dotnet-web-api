create   procedure dbo.usp_update_user_fcm_tokens @id_user int, @fcm_tokens varchar(max)
AS
	SET NOCOUNT ON;
  update base.[user]
  set fcm_tokens = @fcm_tokens
where id_user = @id_user;
go

