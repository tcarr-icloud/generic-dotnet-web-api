CREATE PROCEDURE [metrc].[usp_import_manifest_list]
	@id_location INT = NULL,
	@start_row INT = 0,
	@end_row INT = 100,
	@filter_clause VARCHAR(max) = NULL
AS
	SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
		SELECT m.id_location
				, l.name AS location
				, l.metrc_facility_license_number
				, m.manifest_number
				, m.package_count
				, m.shipper
				, m.shipper_facility
				, m.date_received
				, m.date_created
		FROM metrc.crawler_manifest m
		JOIN base.location l ON l.id_location=m.id_location
	) manifest'

	SET @where = 'WHERE id_location = '+ ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location')
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY manifest_number'
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

