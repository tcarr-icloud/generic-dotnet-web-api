CREATE PROCEDURE terminal.usp_label_delete
               @id_label INT
AS
BEGIN
  DELETE FROM terminal.label
  WHERE id_label = @id_label
  EXEC terminal.usp_label_list
END
go

