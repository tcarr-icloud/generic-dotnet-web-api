CREATE PROCEDURE [pos].[usp_cash_out]
	@id_user INT,
	@id_register INT,
	@balance_ending decimal(18,2)

AS

	DECLARE @id_session INT = (SELECT TOP 1 id_session FROM [pos].[session] WHERE id_register = @id_register ORDER BY date_start DESC)

	UPDATE pos.session 
	SET 
		 balance_ending=@balance_ending
		,id_user_end = @id_user
		,date_end = GETUTCDATE()
	WHERE id_session = @id_session
go

