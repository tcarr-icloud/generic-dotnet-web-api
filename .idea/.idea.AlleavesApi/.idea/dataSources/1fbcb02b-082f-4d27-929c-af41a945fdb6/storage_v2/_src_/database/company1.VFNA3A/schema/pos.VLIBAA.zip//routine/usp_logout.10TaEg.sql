CREATE PROCEDURE [pos].[usp_logout] 
	@id_user INT,
	@id_register INT

AS

	UPDATE pos.session 
	SET date_end=GETUTCDATE()

	WHERE id_user_end=@id_user AND id_register=@id_register AND date_end is NULL
go

