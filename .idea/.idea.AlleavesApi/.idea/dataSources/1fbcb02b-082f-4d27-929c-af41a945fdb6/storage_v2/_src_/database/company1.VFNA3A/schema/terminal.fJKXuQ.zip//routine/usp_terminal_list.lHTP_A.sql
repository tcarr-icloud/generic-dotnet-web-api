CREATE PROCEDURE [terminal].[usp_terminal_list]
              @id_terminal INT = NULL,
              @id_location INT = NULL,
			  @include_deleted BIT = 0
AS
BEGIN

	SELECT tt.id_terminal,
	       tt.[name] AS terminal,
	       tt.terminal_key,
		   tt.id_location,
		   tt.id_register,
		   tt.is_pos,
		   ISNULL((SELECT ia.id_area
						, ia.id_area_type
						, aln.id_location
						, tra.id_terminal
						, ia.name as area
					  FROM terminal.retail_area tra
					  LEFT JOIN inventory.area ia ON ia.id_area = tra.id_area 
					  LEFT JOIN [base].[location] aln ON aln.id_location = ia.id_location
					  WHERE tra.id_terminal = tt.id_terminal AND ia.deleted = 0
					  FOR JSON PATH
			), '[]') AS retail_areas,
		   ISNULL((SELECT tl.id_terminal
						, tln.id_location
						, tln.[name] as [location]
					  FROM terminal.terminal_location tl
					  LEFT JOIN [base].[location] tln ON tln.id_location = tl.id_location
					  WHERE tl.id_terminal = tt.id_terminal AND tln.active = 1
					  FOR JSON PATH
			), ISNULL((SELECT tt.id_terminal
						, tl.id_location
						, tl.[name] as [location]
					  FROM [base].[location] tl
					  WHERE tl.id_location = tt.id_location					  
					  FOR JSON PATH), '[]')) AS locations,
		   tt.opos_printer_name,
		   COALESCE(tt.opos_receipt_printer_name, tt.opos_printer_name) as opos_receipt_printer_name,
		   COALESCE(tt.opos_pickticket_printer_name, tt.opos_printer_name) as opos_pickticket_printer_name,
		   tt.cash_drawer_name,
		   tt.label_printer_name,
		   tt.id_patient_label,
		   pl.[name] as patient_label,
		   pl.[path] as patient_label_path,
		   tt.id_deli_label,
		   dl.[name] as deli_label,
		   dl.[path] as deli_label_path,
		   pr.tf_AuthKey,
		   pr.tf_RegisterID,
		   pr.gift_card_auth_key,
		   pr.gift_card_register_id,
	       tt.id_user_created_by
	FROM terminal.terminal tt
	LEFT JOIN pos.register pr ON tt.id_register = pr.id_register
	LEFT JOIN terminal.[label] dl on tt.id_deli_label = dl.id_label
	LEFT JOIN terminal.[label] pl on tt.id_patient_label = pl.id_label
	WHERE 
		tt.deleted <= @include_deleted AND 
		(@id_terminal IS NULL OR @id_terminal = tt.id_terminal) AND 
		(
			(@id_location IS NULL) OR 
			(@id_location IN (
				SELECT id_location FROM terminal.terminal_location WHERE id_terminal = tt.id_terminal
			))
		)
	ORDER BY tt.name
END
go

