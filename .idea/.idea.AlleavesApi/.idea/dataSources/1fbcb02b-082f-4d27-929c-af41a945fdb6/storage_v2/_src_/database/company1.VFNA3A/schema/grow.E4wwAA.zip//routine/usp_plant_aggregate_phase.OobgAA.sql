CREATE PROCEDURE [grow].[usp_plant_aggregate_phase]
	@id_location INT = NULL,
	@id_area INT = NULL
AS
	SELECT t.phase_current
			, ISNULL(p.count_phase, 0) AS count_phase
	FROM (VALUES ('Seedling'), ('Germination'), ('Vegetative'), ('Pre-Flowering'), ('Flowering')) t(phase_current)
	LEFT JOIN (
		SELECT phase_current
				, COUNT(*) AS count_phase
		FROM (
			SELECT CASE WHEN date_flower IS NOT NULL THEN 'Flowering'
						WHEN date_preflower IS NOT NULL THEN 'Pre-Flowering'
						WHEN date_vegetative IS NOT NULL THEN 'Vegetative'
						WHEN date_germination IS NOT NULL THEN 'Germination'
						WHEN date_seedling IS NOT NULL THEN 'Seedling'
						ELSE NULL END AS phase_current
			FROM grow.plant p
			JOIN inventory.area a ON a.id_area=p.id_area
			WHERE p.harvested = 0 AND p.destroyed = 0 AND p.packaged = 0 AND
				(@id_location IS NULL OR a.id_location = @id_location) AND
				(@id_area IS NULL OR a.id_area = @id_area)
		) t
		GROUP BY phase_current
	) p ON p.phase_current=t.phase_current
go

