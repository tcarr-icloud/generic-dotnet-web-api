CREATE VIEW [order].[vw_orders] as (
SELECT 
	 o.id_order
	,o.metrc_receipt_id
	,o.id_location
	,r.id_register
	,r.[name] as register_name
	,ol.[name] as [location]
	,c.id_customer
	,c.name_first +  ' ' + c.name_last as customer
	,c.patient_number
	,s.[name] as order_status
	,o.id_external
	,o.id_session
	,o.use_type
	,UPPER(SUBSTRING(o.[type], 1,1)) + LOWER(SUBSTRING(o.[type], 2, LEN(o.[type]))) as [type]
	,CAST(o.date_created as date) as order_date_utc
	,CAST(o.date_created AT TIME ZONE 'UTC' AT TIME ZONE 'US Eastern Standard Time' as date) as order_date_est
	,CAST(o.date_created AT TIME ZONE 'UTC' AT TIME ZONE otl.[tz_windows] as datetime) as local_order_datetime
	,o.date_paid AT TIME ZONE 'UTC' as date_paid_utc
	,o.date_paid AT TIME ZONE 'UTC' AT TIME ZONE otl.tz_windows as date_paid_order_local
	,o.date_paid AT TIME ZONE 'UTC' AT TIME ZONE rtl.tz_windows as date_paid_register_local
	,o.subtotal
	,o.discount
	,ISNULL(o.delivery_fee,0) as delivery_fee
	,o.tax
	,ISNULL((SELECT SUM(price_post_order_discount) FROM [order].item WHERE id_order = o.id_order and id_item_return IS NOT NULL),0) as [returns]
	,o.total
	,o.paid_in_full
	,p.[CanPay]
	,p.[Cash]
	,p.[Change]
	,p.[Hypur]
	,p.[Store Credit]
	,p.[Cashless Atm]
	,p.[Gift Card]
	,o.complete
	,o.cancel
	,o.verified
	,o.void
	,v.FirstName + ' ' + v.LastName as verified_by
	,o.scheduled
	,sch.FirstName + ' ' + sch.LastName as scheduled_by
	,o.packed
	,pac.FirstName + ' ' + pac.LastName as packed_by
	,cr.FirstName + ' ' + cr.LastName as created_by
	,CASE 
		WHEN o.paid_in_full = 1 THEN 
			(SELECT  FirstName + ' ' + LastName FROM base.[user] WHERE id_user IN (SELECT TOP 1 id_user_created FROM [order].payment WHERE id_order = o.id_order)) ELSE NULL END as cashier
	,uw.FirstName + ' ' + uw.LastName as [owner]
	,lu.FirstName + ' ' + lu.LastName as last_updated_by
	,o.ommu_dispensed
FROM [order].[order] o
LEFT OUTER JOIN [order].customer c on c.id_customer = o.id_customer
LEFT OUTER JOIN [base].[location] ol on ol.id_location = o.id_location
LEFT OUTER JOIN [order].[status] s on s.id_status = o.id_status
LEFT OUTER JOIN [pos].[session] ses on ses.id_session = o.id_session
LEFT OUTER JOIN [pos].[register] r on r.id_register = ses.id_register
LEFT OUTER JOIN [base].[location] rl on rl.id_location = r.id_location
LEFT OUTER JOIN [base].[user] as v on v.id_user = o.verified_by
LEFT OUTER JOIN [base].[user] as sch on sch.id_user = o.scheduled_by
LEFT OUTER JOIN [base].[user] as pac on pac.id_user = o.packed_by
LEFT OUTER JOIN [base].[user] as cr on cr.id_user = o.created_by
LEFT OUTER JOIN [base].[user] as uw on uw.id_user = o.id_user_working
LEFT OUTER JOIN [base].[user] as lu on lu.id_user = o.updated_by
LEFT OUTER JOIN [dbo].[tz_lookup] as otl ON ol.[timezone] = otl.[tz_iana]
LEFT OUTER JOIN [dbo].[tz_lookup] as rtl ON rl.[timezone] = rtl.[tz_iana]
LEFT OUTER JOIN (
	SELECT 
		id_order, 
		ISNULL([CanPay],0) as [CanPay],
		ISNULL([Cash],0) as [Cash],
		ISNULL([Change],0) as [Change],
		ISNULL([Hypur],0) as [Hypur],
		ISNULL([Store Credit],0) as [Store Credit],
		ISNULL([Cashless Atm], 0) AS [Cashless Atm],
		ISNULL([Gift Card], 0) AS [Gift Card]
	FROM 
	(SELECT id_order, method, tendered FROM [order].payment) as src
	PIVOT (SUM(tendered) FOR method IN ([CanPay],[Cash],[Change],[Hypur],[Store Credit],[Cashless Atm],[Gift Card])) pvt
) p on p.id_order = o.id_order
WHERE o.void = 0
AND o.cancel = 0
)
go

