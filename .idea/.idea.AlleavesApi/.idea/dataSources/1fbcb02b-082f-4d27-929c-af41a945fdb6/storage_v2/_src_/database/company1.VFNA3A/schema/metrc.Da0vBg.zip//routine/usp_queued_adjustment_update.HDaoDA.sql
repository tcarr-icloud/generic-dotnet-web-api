CREATE PROCEDURE [metrc].[usp_queued_adjustment_update]
	@id_adjustment INT,
	@sent_to_metrc BIT = 0,
	@ignored BIT = 0,
	@id_user INT
AS
	
UPDATE [metrc].[queued_adjustment]
SET [sent_to_metrc] = @sent_to_metrc,
	[ignored] = @ignored, 
	[updated_by] = @id_user,
	[date_updated] = GETUTCDATE()
	WHERE id_adjustment = @id_adjustment
go

