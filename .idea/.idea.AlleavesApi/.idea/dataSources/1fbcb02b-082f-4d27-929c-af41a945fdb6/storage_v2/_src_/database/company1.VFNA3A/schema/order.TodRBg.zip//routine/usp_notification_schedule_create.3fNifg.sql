CREATE PROCEDURE [order].usp_notification_schedule_create
	@notification_text VARCHAR(256) = NULL,
    @delivery_date VARCHAR(256)= NULL,
	@id_user INT= NULL
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [order].notification_schedule (notification_text,delivery_date,id_user)
	Values (@notification_text,@delivery_date,@id_user)
	DECLARE @id_notification_schedule INT = SCOPE_IDENTITY()
	EXEC [order].usp_notification_list @id_notification = @id_notification_schedule
END
go

