CREATE PROCEDURE [biotrack].[usp_biotrack_import_list]
	@biotrack_imported_location INT = NULL,
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
	SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
				SELECT 
					it.id_item,
					b.biotrack_barcode_id,
					b.id_batch,
					bi.id_location AS biotrack_imported_location,
					bi.quantity AS biotrack_imported_quantity,
					ISNULL(bi.rejected_quantity, 0) as rejected_quantity,
					bi.date_created,
					a.FirstName + " " + a.LastName as name,
					z.name AS item_name,
					l.name AS location_name
				FROM biotrack.import bi
				LEFT JOIN inventory.batch b on bi.id_batch=b.id_batch
				LEFT JOIN inventory.item it ON b.id_item=it.id_item
				LEFT JOIN inventory.item_group z ON z.id_item_group=it.id_item_group
				LEFT JOIN base.location l ON l.id_location=bi.id_location
				LEFT JOIN [base].[user] a ON a.id_user=bi.id_created_by
				WHERE bi.id_location=' + CAST(@biotrack_imported_location AS VARCHAR(16))
	+ ') package'
	SET @where = ''
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT('WHERE ', @filter_clause)
	
	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'date_created DESC')
	
	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

