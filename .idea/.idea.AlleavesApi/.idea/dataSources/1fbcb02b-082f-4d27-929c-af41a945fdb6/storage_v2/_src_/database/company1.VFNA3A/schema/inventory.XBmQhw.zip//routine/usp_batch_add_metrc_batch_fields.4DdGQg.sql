CREATE PROCEDURE [inventory].[usp_batch_add_metrc_batch_fields]
	@id_batch INT,
	@metrc_package_label VARCHAR(128),
	@uom_metrc VARCHAR(255),
	@id_user INT
AS
	DECLARE @id_uom INT
	
	SET @id_uom=(SELECT TOP 1 id_uom FROM inventory.uom WHERE name=@uom_metrc)

	UPDATE inventory.batch
	SET metrc_package_label=@metrc_package_label
		, id_uom_metrc=@id_uom
		, updated_by=@id_user
		, date_updated=getutcdate()
	WHERE id_batch=@id_batch
go

