CREATE VIEW [order].[vw_voids]

AS

SELECT o.id_order
	, l.id_location
	, u.id_user
	, c.id_customer
	, o.date_updated AS 'date'
	, o.total
	, l.name AS 'location'
	, u.FirstName + ' ' + u.LastName AS 'employee_name'
	, c.name_first + ' ' + c.name_last AS 'customer_name'
	, c.patient_number
	, o.type AS 'order_type'
	, r.name AS 'terminal'
	, r.id_register
FROM [order].[order] o
LEFT JOIN [order].[customer] c ON c.id_customer=o.id_customer
LEFT JOIN [base].[user] u ON u.id_user=o.updated_by
LEFT JOIN [order].[payment] p ON p.id_order=o.id_order
LEFT JOIN [pos].[register] r ON r.id_register=p.id_register
LEFT JOIN [base].[location] l ON l.id_location=r.id_location
WHERE o.void = 1
go

