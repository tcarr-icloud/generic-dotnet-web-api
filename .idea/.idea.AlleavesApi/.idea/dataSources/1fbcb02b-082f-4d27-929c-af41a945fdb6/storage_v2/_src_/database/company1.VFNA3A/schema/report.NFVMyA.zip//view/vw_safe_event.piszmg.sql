


-------------------------------------------------------------------------------------
---Safe Events-----------------------------------------------------------------------
CREATE VIEW [report].[vw_safe_event]
	AS 

SELECT  
	cse.[id_safe_event] as 'safe_event_id'
	,cse.[id_user_created]
	,bu.[FirstName] + ' ' + bu.[LastName] as 'user_name'
	,cse.[previous_amount]
    ,cse.[adjustment]
    ,cse.[reason]
    ,cse.[reason_type]
    ,cse.[note]
	,cse.[date_created] as 'UTC_created_datetime'
	,CASE
		WHEN cse.[date_created] IS NOT NULL
		THEN CAST(cse.[date_created] AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime)
		ELSE NULL
	END as 'local_created_datetime'

FROM [cash].[safe_event] cse
	LEFT OUTER JOIN [base].[user] bu ON cse.[id_user_created] = bu.[id_user]
	LEFT OUTER JOIN [cash].[safe] cs ON cse.[id_safe] = cs.[id_safe]
	LEFT OUTER JOIN [base].[location] bl on cs.[id_location] = bl.[id_location]
	LEFT OUTER JOIN [dbo].[tz_lookup] tl ON bl.[timezone] = tl.[tz_iana]
go

