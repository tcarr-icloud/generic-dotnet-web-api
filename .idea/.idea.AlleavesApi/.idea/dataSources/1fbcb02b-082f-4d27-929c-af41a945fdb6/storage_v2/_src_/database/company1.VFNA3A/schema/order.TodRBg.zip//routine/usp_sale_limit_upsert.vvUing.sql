CREATE PROCEDURE [order].[usp_sale_limit_upsert]
	@id_sale_limit INT = NULL,
	@id_state INT,
	@timespan VARCHAR(64),
	@rolling_days INT = NULL,
	@residence_type VARCHAR(64),
	@weight_type VARCHAR(64),
	@is_adult BIT,
	@is_medical BIT,
	@amount DECIMAL(18,4),
	@id_uom INT,
	@delivery_route_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	/* insert new sale limit. */
	IF(@id_sale_limit IS NULL) 
	BEGIN
		INSERT INTO [order].sale_limit (id_state, timespan, rolling_days, residence_type, weight_type, is_adult, is_medical, amount, id_uom, id_user_created, id_user_updated)
		VALUES (@id_state, @timespan, @rolling_days, @residence_type, @weight_type, @is_adult, @is_medical, @amount, @id_uom, @id_user, @id_user)

		SET @id_sale_limit = SCOPE_IDENTITY()
	END
	/* update existing sale limit. */
	ELSE
	BEGIN
		UPDATE [order].sale_limit
		SET id_state=@id_state
			, timespan=@timespan
			, weight_type=@weight_type
			, rolling_days=@rolling_days
			, residence_type=@residence_type
			, is_adult=@is_adult
			, is_medical=@is_medical
			, amount=@amount
			, id_uom=@id_uom
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_sale_limit=@id_sale_limit
	END

	/* merge list of delivery routes. */
	;WITH route_list AS (
		SELECT @id_sale_limit AS id_sale_limit, *
		FROM OPENJSON(@delivery_route_list)
		WITH (
			id_sale_limit_delivery_route INT,
			id_delivery_route INT
		)
	)
	MERGE [order].sale_limit_delivery_route t
	USING route_list s
	ON t.id_sale_limit_delivery_route=s.id_sale_limit_delivery_route
	WHEN MATCHED THEN
		UPDATE SET t.id_sale_limit=s.id_sale_limit
					, t.id_delivery_route=s.id_delivery_route
					, t.id_user_updated=@id_user
					, t.date_updated=GETUTCDATE()
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_sale_limit, id_delivery_route, id_user_created, id_user_updated)
		VALUES (s.id_sale_limit, s.id_delivery_route, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND t.id_sale_limit=@id_sale_limit
		THEN DELETE
	;

	/* return new/updated sale limit. */
	EXEC [order].usp_sale_limit_list @id_sale_limit
go

