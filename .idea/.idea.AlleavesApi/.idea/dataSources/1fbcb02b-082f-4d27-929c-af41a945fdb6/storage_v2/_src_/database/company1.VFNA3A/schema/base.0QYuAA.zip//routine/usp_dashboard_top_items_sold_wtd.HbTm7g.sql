CREATE PROCEDURE [base].[usp_dashboard_top_items_sold_wtd]

	AS

SELECT aa.product,
	aa.brand,
	aa.category,
	aa.units_sold,
	aa.gross_revenue,
	aa.net_revenue,
	CASE
        WHEN aa.cog_per_unit_batch IS NOT NULL THEN aa.cog_per_unit_batch
        WHEN aa.cog_per_unit_location IS NOT NULL THEN aa.cog_per_unit_location
        ELSE aa.cog_per_unit_actual
    END AS cog_per_unit,
	CASE
        WHEN aa.cog_per_unit_batch IS NOT NULL THEN aa.cog_per_unit_batch * aa.units_sold
        WHEN aa.cog_per_unit_location IS NOT NULL THEN aa.cog_per_unit_location * aa.units_sold
        ELSE aa.cog_per_unit_actual * aa.units_sold
    END AS cog_on_hand,
	CASE
        WHEN unit_wholesale_price IS NULL OR unit_wholesale_price = 0 THEN 0
        WHEN aa.cog_per_unit_batch IS NOT NULL THEN (aa.net_revenue - (aa.cog_per_unit_batch * aa.units_sold))/aa.net_revenue * 100
        WHEN aa.cog_per_unit_location IS NOT NULL THEN (aa.net_revenue - (aa.cog_per_unit_location * aa.units_sold))/aa.net_revenue * 100
        ELSE (aa.net_revenue - (aa.cog_per_unit_actual * aa.units_sold))/aa.net_revenue * 100
    END AS margin,
	CASE
		WHEN aa.gross_revenue IS NULL OR aa.gross_revenue = 0 THEN 0
		ELSE (aa.gross_revenue - aa.net_revenue)/aa.gross_revenue * 100
	END AS discount_rate_percentage
FROM (
	SELECT TOP 20 
		MAX(vwoi.inventory_item) as product,
		MAX(ib.name) as brand,
		MAX(vwoi.inventory_category) as category,
		SUM(vwoi.current_cost_of_good) AS unit_wholesale_price,
		SUM(vwoi.quantity) AS units_sold,
		SUM(vwoi.price) AS gross_revenue,
		SUM(vwoi.price_post_all_adjustments) as net_revenue,
		AVG(invb.cost_of_good) AS cog_per_unit_batch,
		CASE 
			WHEN AVG(iil.cost_of_good) <> 0 THEN AVG(iil.cost_of_good)
			ELSE AVG(iil.price_wholesale)
		END AS cog_per_unit_location,
		CASE 
			WHEN AVG(ivil.cost_of_good) <> 0 THEN AVG(ivil.cost_of_good)
			ELSE AVG(ivil.price_wholesale)
		END AS cog_per_unit_actual
	FROM [order].[vw_orders] vwo
	LEFT OUTER JOIN [order].[vw_order_items] vwoi ON vwo.id_order = vwoi.id_order
	LEFT OUTER JOIN [inventory].[batch] invb ON vwoi.id_batch = invb.id_batch
	LEFT OUTER JOIN [inventory].[item_group] ig ON ig.id_item_group = vwoi.id_item_group
	LEFT OUTER JOIN [inventory].[brand] ib ON ib.id_brand = ig.id_brand
	LEFT OUTER JOIN [base].[location] l on vwo.id_location = l.id_location
	LEFT OUTER JOIN [dbo].[tz_lookup] tz on l.timezone = tz.tz_iana
	LEFT OUTER JOIN [inventory].[item_location] iil ON iil.id_item = vwoi.id_inventory_item AND iil.id_location = vwo.id_location
	LEFT OUTER JOIN [inventory].[vw_item_list] ivil ON ivil.id_item = vwoi.id_inventory_item AND ivil.id_location = vwo.id_location
	WHERE vwo.paid_in_full = 1 AND 
		vwo.cancel = 0 AND 
		vwo.void = 0 AND
		CAST(vwo.date_paid_order_local AS DATE) >= DATEADD(WEEK, DATEDIFF(WEEK, 0, DATEADD(DAY, -1, GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows)), 0)
	GROUP BY vwoi.id_inventory_item
	ORDER BY units_sold DESC

) aa
go

