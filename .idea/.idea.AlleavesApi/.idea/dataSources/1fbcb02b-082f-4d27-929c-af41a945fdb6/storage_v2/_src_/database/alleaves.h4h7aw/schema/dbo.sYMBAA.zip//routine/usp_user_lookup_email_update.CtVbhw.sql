CREATE PROCEDURE [dbo].[usp_user_lookup_email_update]
	@email VARCHAR(256),
	@email_update VARCHAR(256),
	@id_company INT
AS
	UPDATE dbo.user_lookup 
	SET email=@email_update,
		date_updated=GETUTCDATE() 
	WHERE email=@email AND id_company=@id_company
go

