CREATE PROCEDURE [order].[usp_customer_type_update]
	@id_customer_type INT,
	@name VARCHAR(512),
	@deleted BIT = 0

AS
	IF((SELECT [system] FROM [order].[customer_type] WHERE id_customer_type = @id_customer_type) = 1)
	BEGIN		
		DECLARE @msg1 VARCHAR(max) = 'System types cannot be modified';
		THROW 50001, @msg1, 1
	END

	IF EXISTS (SELECT * FROM [order].customer_type WHERE deleted=0 AND @deleted<>1 AND name=@name AND id_customer_type<>@id_customer_type)
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A customer type with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	UPDATE [order].customer_type
	SET 
		[name]=@name
	  , deleted = @deleted
	WHERE id_customer_type = @id_customer_type
	AND system = 0
	EXEC [order].usp_customer_type_list @id_customer_type, 1
go

