CREATE PROCEDURE [biotrack].[usp_biotrack_inventory_type_list]

AS

SELECT	 it.id_inventory_type 
		,it.[name] as biotrack_inventory_type
		,it.requires_weighing as biotrack_requires_weighing
		,it.delivery_route_id
FROM [biotrack].[inventory_type] it
ORDER BY it.id_inventory_type
go

