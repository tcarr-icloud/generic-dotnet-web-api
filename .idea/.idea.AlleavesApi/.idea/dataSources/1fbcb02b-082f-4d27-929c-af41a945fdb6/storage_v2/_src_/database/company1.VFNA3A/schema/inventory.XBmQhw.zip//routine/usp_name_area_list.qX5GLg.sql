CREATE PROCEDURE [inventory].[usp_name_area_list]
	@id_location INT = NULL,
	@id_area INT = NULL,
	@show_deleted BIT = 0
AS
	SET NOCOUNT ON;

	SELECT DISTINCT a.path AS area_path
	FROM base.location l
	LEFT JOIN inventory.vw_area_list a ON a.id_location=l.id_location
	LEFT JOIN area_type atp ON atp.id_area_type=a.id_area_type
	LEFT JOIN status st ON st.id_status=a.id_status
	WHERE l.id_location=ISNULL(@id_location, l.id_location) 
			AND a.id_area=ISNULL(@id_area, a.id_area)
			AND a.deleted<=ISNULL(@show_deleted, 0)
			AND atp.name <> 'scrap'
	ORDER BY a.path
go

