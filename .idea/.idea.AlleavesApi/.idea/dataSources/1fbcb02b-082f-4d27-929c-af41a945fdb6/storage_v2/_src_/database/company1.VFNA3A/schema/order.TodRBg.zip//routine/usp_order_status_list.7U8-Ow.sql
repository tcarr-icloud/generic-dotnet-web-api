-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [order].[usp_order_status_list]
	@date_recieved_in_UTC BIT = 0
AS
BEGIN
	--DECLARE	@date_recieved_in_UTC BIT = 0
	
	SELECT o.id_order
			, o.id_location
			, o.id_status
			, c.id_customer
			, c.id_user_online
			, o.id_user_working
			, c.patient_number
			, c.name_first
			, c.name_last
			, c.email
			, COALESCE(o.id_order_online, o.id_external) as id_order_online
			, o.type
			, l.name AS location
			, s.name AS status
			, pu.pickup_date
			, pu.pickup_time
			, pu.pickup_vehicle_color
			, pu.pickup_vehicle_make
			, pu.pickup_customer_arrived
			, pu.pickup_order_incoming
			, CASE WHEN u.FirstName IS NOT NULL THEN u.FirstName + ' ' + u.LastName ELSE null END AS user_working
			, o.verified
			, o.scheduled
			, o.packed
			, o.void
			, o.ommu_dispensed
			, o.caregiver_purchase
			, o.id_caregiver
			, o.caregiver_name
			, o.caregiver_card_number
			, o.id_physician
			, o.physician_name
			, CASE WHEN d.id_driver IS NULL THEN NULL ELSE CONCAT(du.FirstName, ' ', du.LastName) END AS driver
			, CASE WHEN d.id_driver IS NULL THEN NULL ELSE du.Email END AS driver_email
			, rs.ride_status
			, CASE 
				WHEN @date_recieved_in_UTC = 1 THEN CONVERT(VARCHAR(32), CAST(CAST(o.date_created AS DATETIME2(0)) AT TIME ZONE 'UTC' as DATETIME), 120)
				WHEN @date_recieved_in_UTC = 0 THEN CONVERT(VARCHAR(32), CAST(CAST(o.date_created AS DATETIME2(0)) AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows as DATETIME), 120) 
			  END AS date_received
			, CASE 
				WHEN @date_recieved_in_UTC = 1 THEN CONVERT(VARCHAR(20), CAST(CAST(o.date_created AS DATETIME2(0)) AT TIME ZONE 'UTC' as DATETIME), 0)
				WHEN @date_recieved_in_UTC = 0 THEN CONVERT(VARCHAR(20), CAST(CAST(o.date_created AS DATETIME2(0)) AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows as DATETIME), 0) 
			  END AS date_received_display
			  , (
					SELECT address1, address2, city, [state], zip, delivery_date 
							, a.id_driver1
							, a.id_driver2
							, a.id_vehicle
							, CASE WHEN u1.id_user IS NOT NULL THEN u1.FirstName+' '+u1.LastName ELSE NULL END AS driver1
							, d1.license AS driver1_license
							, CASE WHEN u2.id_user IS NOT NULL THEN u2.FirstName+' '+u2.LastName ELSE NULL END AS driver2
							, d2.license AS driver2_license
							, v.name AS vehicle
							, v.make
							, v.model
							, v.license AS vehicle_license
					FROM [order].[address] a
					LEFT JOIN [order].driver d1 ON d1.id_driver=a.id_driver1
					LEFT JOIN [order].driver d2 ON d2.id_driver=a.id_driver2
					LEFT JOIN base.[user] u1 ON u1.id_user=d1.id_user
					LEFT JOIN base.[user] u2 ON u2.id_user=d2.id_user
					LEFT JOIN [order].vehicle v ON v.id_vehicle=a.id_vehicle
					WHERE id_order = o.id_order 
					FOR JSON PATH
			  ) as delivery_address
			  ,rs.cancellation_note
	FROM [order].[order] o
	LEFT JOIN [order].customer c ON c.id_customer=o.id_customer
	LEFT JOIN [order].status s ON s.id_status=o.id_status
	LEFT JOIN base.location l ON l.id_location=o.id_location
	LEFT JOIN [order].pickup pu ON pu.id_order=o.id_order
	LEFT JOIN [order].address a ON a.id_order=o.id_order
	LEFT JOIN dbo.tz_lookup tz on tz.tz_iana = l.timezone
    LEFT JOIN [base].[user] u ON u.id_user=o.id_user_working
	LEFT JOIN [order].ecommerce_ride er ON er.id_order=o.id_order
	LEFT JOIN [order].driver d ON d.id_driver=er.id_driver
	LEFT JOIN base.[user] du ON du.id_user=d.id_user
	LEFT JOIN (
		SELECT er.id_order
				, ers.driver_message AS ride_status
				, erh.cancellation_note
		FROM [order].ecommerce_ride er
		JOIN [order].ecommerce_ride_status_history erh ON erh.id_ride=er.id_ride
		JOIN [order].ecommerce_ride_status ers ON ers.id_status=erh.id_ride_status
		JOIN (
			SELECT id_ride, MAX(created_at) AS created_at
			FROM [order].ecommerce_ride_status_history 
			GROUP BY id_ride
		) erht ON erht.id_ride=erh.id_ride AND erht.created_at=erh.created_at
	) rs ON rs.id_order=o.id_order
	WHERE 
			(o.complete=0 OR (o.complete=1 AND o.date_updated>=DATEADD(dd, -4, getutcdate())))
	AND		o.void = 0
	AND		o.cancel = 0
	
END
go

