CREATE   VIEW [dbo].[syspolicy_policy_categories]
AS
    SELECT     
        policy_category_id,
        name,
        mandate_database_subscriptions
    FROM [dbo].[syspolicy_policy_categories_internal]
go

grant select on dbo.syspolicy_policy_categories to PolicyAdministratorRole
go

grant select on dbo.syspolicy_policy_categories to [public]
go

