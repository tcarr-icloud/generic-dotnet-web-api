
CREATE PROCEDURE [pos].[usp_register_save]
    @id_user int,
    @id_register int,
    @id_location int,
    @name nvarchar(50),
    @mac nvarchar(25),
    @tf_RegisterID nvarchar(50),
    @tf_AuthKey nvarchar(50),
	@gift_card_register_id nvarchar(50) = NULL,
	@gift_card_auth_key nvarchar(50) = NULL,
    @receipt_header nvarchar(1500),
    @receipt_footer nvarchar(1500)
AS
    IF(@id_register IS NULL)
    BEGIN
            SELECT @id_register = id_register FROM pos.register WHERE mac = @mac
    END

    IF(@id_register IS NOT NULL)
    BEGIN
            UPDATE pos.register
            SET
                     [name] = @name
                    ,id_location = @id_location
                    ,date_modified = GETUTCDATE()
                    ,modified_by = @id_user
                    ,tf_RegisterID = @tf_RegisterID
                    ,tf_AuthKey = @tf_AuthKey
				    ,gift_card_register_id = @gift_card_register_id
				    ,gift_card_auth_key = @gift_card_auth_key
                    ,receipt_header = @receipt_header
                    ,receipt_footer = @receipt_footer

            WHERE id_register = @id_register
    END
    ELSE
    BEGIN
            INSERT INTO pos.register (id_location, [name], mac, created_by, modified_by, tf_RegisterID, tf_AuthKey, gift_card_register_id, gift_card_auth_key, receipt_header, receipt_footer )
            VALUES (@id_location, @name, @mac, @id_user, @id_user, @tf_RegisterID, @tf_AuthKey, @gift_card_register_id, @gift_card_auth_key, @receipt_header, @receipt_footer)
            SET @id_register = SCOPE_IDENTITY()
    END

    SELECT id_register, id_location, [name], mac, tf_RegisterID, tf_AuthKey, gift_card_register_id, gift_card_auth_key, receipt_header, receipt_footer FROM pos.register WHERE id_register = @id_register
go

