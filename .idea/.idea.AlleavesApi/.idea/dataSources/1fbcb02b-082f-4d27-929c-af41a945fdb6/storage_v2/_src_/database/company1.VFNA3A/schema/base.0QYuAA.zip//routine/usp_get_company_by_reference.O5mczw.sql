CREATE   PROCEDURE [base].[usp_get_company_by_reference]
	@reference VARCHAR(64)
AS
	SELECT * FROM base.company WHERE reference=@reference
go

