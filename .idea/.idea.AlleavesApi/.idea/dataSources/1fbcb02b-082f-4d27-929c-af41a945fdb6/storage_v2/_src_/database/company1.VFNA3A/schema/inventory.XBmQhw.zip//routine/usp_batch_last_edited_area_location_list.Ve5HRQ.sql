CREATE PROCEDURE [inventory].[usp_batch_last_edited_area_location_list]
	@id_batch INT = NULL,
	@id_location INT = NULL
AS
;WITH LastBatchUpdate AS (
    SELECT 
        le.id_batch, 
        MAX(le.date_created) as last_date_updated
    FROM [log].[event] le
    WHERE (le.original_quantity > 0 AND le.original_quantity + le.adjustment = 0)
		OR (le.adjustment > 0 AND le.original_quantity = 0)
    GROUP BY le.id_batch
)
	SELECT 
		le.id_batch,
		le.id_area,
		ia.id_location,
		le.item,
		bl.[name]
	FROM LastBatchUpdate lbu
	LEFT JOIN [log].[event] le ON lbu.id_batch = le.id_batch AND lbu.last_date_updated = le.date_created
	LEFT JOIN [inventory].[area] ia ON ia.id_area = le.id_area
	LEFT JOIN [base].[location] bl ON bl.id_location = ia.id_location
	WHERE (@id_batch IS NULL OR le.id_batch = @id_batch)
	AND (@id_location IS NULL OR ia.id_location = @id_location)
go

