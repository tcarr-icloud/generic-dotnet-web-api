CREATE PROCEDURE [dbo].[reset_daily_accounts]
AS
	SET NOCOUNT ON;

	TRUNCATE TABLE [dbo].[daily_accounts]
go

