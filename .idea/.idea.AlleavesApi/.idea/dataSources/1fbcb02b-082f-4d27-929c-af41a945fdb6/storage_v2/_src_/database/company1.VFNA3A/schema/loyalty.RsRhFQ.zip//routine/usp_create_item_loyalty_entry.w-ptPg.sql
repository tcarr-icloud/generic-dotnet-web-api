
CREATE PROCEDURE [loyalty].[usp_create_item_loyalty_entry] @id_order_item INT
	,@id_order INT
	,@loyalty_vender VARCHAR(256)
	,@loyalty_name VARCHAR(256)
	,@item_value INT
	,@redemption_type VARCHAR(50)
	,@id_offer_reward VARCHAR(50)
	,@amount DECIMAL(18, 2)
	,@discount_type VARCHAR(1)
	,@expiry_date DATETIME
	,@id_user INT
AS
INSERT INTO loyalty.[item] (
	id_order_item
	,loyalty_vender
	,loyalty_name
	,item_value
	,redemption_type
	,id_offer_reward
	,amount
	,discount_type
	,expiry_date
	,date_created
	,id_user_created_by
	)
VALUES (
	@id_order_item
	,@loyalty_vender
	,@loyalty_name
	,@item_value
	,@redemption_type
	,@id_offer_reward
	,@amount
	,@discount_type
	,@expiry_date
	,getutcdate()
	,@id_user
	)
go

