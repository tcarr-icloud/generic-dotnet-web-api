CREATE PROCEDURE [inventory].[usp_transfer_status_update]
	@id_transfer INT,
	@id_transfer_status INT,
	@id_user INT,
	@return BIT = 1,
	@signature VARCHAR(MAX) = NULL
AS
	INSERT INTO inventory.transfer_status_history (id_transfer, id_transfer_status, id_user_verified)
	VALUES (@id_transfer, @id_transfer_status, @id_user)

	DECLARE @reference VARCHAR(128) = (SELECT reference FROM inventory.transfer_status WHERE id_transfer_status=@id_transfer_status)

	IF(@reference='shipped' OR @reference='received')
	BEGIN
		UPDATE inventory.transfer 
		SET 
			complete=1,
			delivered_time = getutcdate(),
			[signature] = isnull(@signature,[signature])
    	WHERE id_transfer = @id_transfer
	END
    ELSE 
		UPDATE inventory.transfer 
		SET complete=0
		WHERE id_transfer=@id_transfer

	IF(@return=1)
		EXEC inventory.usp_transfer_list @id_transfer
go

