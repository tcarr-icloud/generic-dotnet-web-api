CREATE PROCEDURE [customer].[usp_location_queue_list] @id_location INT
AS
SELECT 
	 q.id_queue
	,c.id_customer
	,c.name_first
	,c.name_last
	,c.email
	,c.date_of_birth
	,c.patient_number
	,c.is_banned
	,l.[name] as [location]
	,q.time_in
	,q.time_out
FROM base.[location] l
INNER JOIN [order].[queue] q ON l.id_location = q.id_location
INNER JOIN [order].customer c ON q.id_customer = c.id_customer
WHERE 
	l.id_location = @id_location
	AND q.time_out IS NULL
go

