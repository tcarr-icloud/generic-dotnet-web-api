CREATE PROCEDURE [inventory].[usp_transfer_status_list]
AS
	SELECT id_transfer_status
			, name AS transfer_status
			, reference AS transfer_status_reference
			, sequence
	FROM inventory.transfer_status
go

