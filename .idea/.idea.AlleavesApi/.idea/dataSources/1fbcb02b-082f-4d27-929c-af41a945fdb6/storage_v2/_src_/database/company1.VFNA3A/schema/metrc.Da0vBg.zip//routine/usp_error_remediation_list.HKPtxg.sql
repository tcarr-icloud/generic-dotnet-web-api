CREATE PROCEDURE [metrc].[usp_error_remediation_list]
	-- Add the parameters for the stored procedure here
	@deleted BIT = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT *
	FROM [metrc].[error_remediation]
	WHERE deleted = @deleted;
END
go

