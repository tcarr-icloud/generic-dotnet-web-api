CREATE PROCEDURE [inventory].[usp_category_list]
	@id_category INT = NULL,
	@show_deleted BIT = 0
AS
	SET NOCOUNT ON;

	SELECT c.id_category
			, c.id_parent
			, c.[name] AS category
			, c.[path] AS category_path
			, c.id_category_image
			, c.id_delivery_route
			, c.[system]
			, deleted
	FROM inventory.vw_category_list c
	WHERE c.id_category=ISNULL(@id_category, c.id_category) AND c.deleted<=@show_deleted
	ORDER BY c.path
go

