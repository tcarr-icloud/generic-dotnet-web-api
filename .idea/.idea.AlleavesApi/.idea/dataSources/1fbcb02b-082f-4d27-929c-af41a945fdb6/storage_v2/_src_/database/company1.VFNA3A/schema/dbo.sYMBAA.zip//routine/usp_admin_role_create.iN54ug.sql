CREATE   PROCEDURE [dbo].[usp_admin_role_create]
	@role VARCHAR(128)
AS
	SET NOCOUNT ON;

	INSERT INTO [base].[role] ([Name]) 
	VALUES 
		(@role)

	SELECT 
		 id_role
		,[Name] AS [role]
	FROM [base].[role]
	WHERE id_role=SCOPE_IDENTITY()
go

