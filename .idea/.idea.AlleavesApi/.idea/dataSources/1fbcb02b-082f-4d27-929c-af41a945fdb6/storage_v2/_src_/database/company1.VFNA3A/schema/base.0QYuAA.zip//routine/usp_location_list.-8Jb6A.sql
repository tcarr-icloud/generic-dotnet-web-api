
CREATE 
 PROCEDURE [base].[usp_location_list] @id_location BIGINT = NULL,
                                           @id_area INT = NULL,
                                           @postal_code VARCHAR(32) = NULL
AS
    SET NOCOUNT ON;

	SELECT DISTINCT l.id_location
			, l.name AS location
			, l.legal_name
			, l.reference
			, l.license
			, l.dea
			, l.npi
			, l.address
			, l.city
			, l.state
			, ts.id_state
			, ts.[name] AS full_state_name
			, l.postal_code
			, l.country
			, l.phone
			, l.timezone
			, l.retail
			, l.pickup
			, l.delivery
			, l.curbside
			, l.express_delivery
			, l.delivery_zipcodes
			, l.local_tax_percentage
			, l.active
			, l.custom_id
			, l.metrc_facility_license_number
			, l.metrc_system_api_key
			, l.metrc_last_crawl
			, l.ommu_api_security_token
			, l.ommu_api_user_id
			, l.biotrack_license_number
			, l.biotrack_ubi
			, l.biotrack_access_token
			, l.biotrack_refresh_token
			, l.biotrack_token_expiration_date
			, l.is_adult_use
			, l.is_medical_use
			, l.is_metrc
			, l.is_ommu
			, l.is_biotrack
			, p.id_pmp
            , p.id_location AS pmp_id_location
            , p.enable_pmp
			, p.username AS pmp_username
            , p.password AS pmp_password
			, p.iv
			, p.auto_submit_time
			, l.is_vermont_ccb
			, l.vt_facility_license
			, l.vt_client_id
			, l.vt_client_secret
			, l.area_priority
			, ISNULL((SELECT id_safe, [name] FROM cash.[safe] WHERE id_location = l.id_location AND deleted = 0 FOR JSON AUTO),'[]') as safe_list
			, ISNULL((
				SELECT
					bl.id_location,
					pc.order_auto_expire_timeframe,
					pc.alleaves_pay_rounding_method,
					pc.cashless_atm_rounding_method,
					pc.[auto_close],
					pc.auto_print_receipt,
					pc.auto_print_patient_label,
					pc.cash_payment,
					pc.credit_payment,
					pc.canpay_payment,
					pc.hypur_payment,
					pc.alleaves_pay_payment,
					pc.gift_card_payment,
					pc.cashless_atm_payment,
					pc.other_payment,
					pc.pay_cloud_payment,
					pc.require_checkout_pin,
					pc.require_checkout_username_password,
					pc.prevent_underage_account,
					pc.account_age_limit_adult,
					pc.account_age_limit_medical,
					pc.sale_age_limit_adult,
					pc.sale_age_limit_medical,
					pc.prevent_underage_sale,
					pc.use_sales_limit_2,					
					pc.sales_limit_2_prevent_sale,
					pc.sales_limit_2_patient_override,
					pc.metrc_inactive_patient_override,
					pc.scale_rounding_enabled,
					pc.donations_enabled,
					pc.donations,
					pc.enable_scan_address
				FROM [base].[location] bl
				LEFT JOIN [pos].[configuration] pc ON bl.id_location = pc.id_location
				WHERE bl.active=1 AND l.id_location=pc.id_location
				FOR JSON PATH), '[]') as pos_configuration_list
			, ISNULL((
				SELECT tlg.id_tax_group,
					tg.[name]
				FROM [tax].[location_group] tlg
				LEFT JOIN [tax].[group] tg ON tg.id_tax_group = tlg.id_tax_group
				WHERE tlg.id_location =ISNULL(@id_location,l.id_location) AND tlg.active=1 AND tg.active=1
				FOR JSON PATH), '[]') as tax_group_list
	FROM base.location l
	LEFT OUTER JOIN base.[states] ts ON l.state = ts.abbreviation
	LEFT OUTER JOIN inventory.area a ON a.id_location=l.id_location
	LEFT OUTER JOIN [inventory].pmp p ON p.id_location = l.id_location
	WHERE 
			l.active=1 AND 
			(l.id_location = ISNULL(@id_location, l.id_location)) AND
			(
				CASE 
					WHEN @postal_code IS NULL THEN 1
					WHEN @postal_code = l.postal_code THEN 1
					ELSE 0
				END = 1
			) AND
			(
				CASE 
					WHEN @id_area IS NULL THEN 1
					WHEN @id_area = a.id_area THEN 1
					ELSE 0
				END = 1
			)
	ORDER BY l.name
go

