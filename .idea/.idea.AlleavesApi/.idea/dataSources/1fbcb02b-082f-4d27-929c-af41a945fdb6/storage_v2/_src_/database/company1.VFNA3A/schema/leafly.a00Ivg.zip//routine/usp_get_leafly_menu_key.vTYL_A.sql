CREATE PROCEDURE [leafly].[usp_get_leafly_menu_key]
	@id_location INT
AS
	SELECT *
	FROM [leafly].[menu_key]
	WHERE id_location = @id_location
go

