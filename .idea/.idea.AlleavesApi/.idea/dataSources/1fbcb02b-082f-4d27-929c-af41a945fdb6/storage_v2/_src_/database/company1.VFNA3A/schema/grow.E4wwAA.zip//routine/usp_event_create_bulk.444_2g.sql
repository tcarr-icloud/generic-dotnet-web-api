CREATE PROCEDURE [grow].[usp_event_create_bulk]
	@type_reference VARCHAR(128),
	@id_area INT,
	@row INT = NULL,
	@column INT = NULL,
	@notes VARCHAR(MAX) = NULL,
	@event_list VARCHAR(MAX) = '[]',
	@id_user INT
AS

	IF (@event_list IS NULL)
		RETURN

	DECLARE @id_plant INT,
			@event_id_area INT,
			@event_row INT,
			@event_column INT,
			@event_type VARCHAR(128),
			@event_notes VARCHAR(MAX)

	/* set up list of events. */
	DROP TABLE IF EXISTS #event_list
	SELECT e.*
	INTO #event_list
	FROM (
		SELECT * FROM OPENJSON(@event_list)
		WITH (
			id_plant INT,
			id_area INT,
			[row] INT,
			[column] INT,
			type_reference VARCHAR(128),
			notes VARCHAR(MAX)
		)	
	) e

	/* lop through event list and insert events. */
	DECLARE c CURSOR FOR SELECT id_plant, id_area, [row], [column], type_reference, notes FROM #event_list
	OPEN c
	FETCH NEXT FROM c INTO @id_plant, @event_id_area, @event_row, @event_column, @event_type, @event_notes
	WHILE @@FETCH_STATUS = 0 BEGIN

		/* only create event if all data is present for this row. */
		IF (@id_plant IS NOT NULL)
		BEGIN
			SET @event_id_area = ISNULL(@event_id_area, @id_area)
			SET @event_type = ISNULL(@event_type, @type_reference)
			SET @event_notes = ISNULL(@event_notes, @notes)
			SET @event_row = ISNULL(@event_row, @row)
			SET @event_column = ISNULL(@event_column, @column)

			EXEC grow.usp_event_create @event_type, @id_plant, @event_id_area, @event_row, @event_column, @event_notes, @id_user
		END

		FETCH NEXT FROM c INTO @id_plant, @event_id_area, @event_row, @event_column, @event_type, @event_notes
	END

	CLOSE c
	DEALLOCATE c
go

