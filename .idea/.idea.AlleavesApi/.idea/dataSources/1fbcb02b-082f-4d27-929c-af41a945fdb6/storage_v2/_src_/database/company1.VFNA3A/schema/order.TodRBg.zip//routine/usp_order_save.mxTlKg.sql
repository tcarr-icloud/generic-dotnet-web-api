CREATE PROCEDURE [order].[usp_order_save] @id_order INT
	,@id_customer INT
	,@id_location INT
	,@id_external VARCHAR(255)
	,@id_session INT
	,@id_status INT
	,@type VARCHAR(32)
	,@use_type VARCHAR(64) = NULL
	,@apply_delivery_fee BIT
	,@delivery_address VARCHAR(max)
	,@pickup_date DATE
	,@pickup_time VARCHAR(100)
	,@pickup_phone VARCHAR(100) = NULL
	,@pickup_email VARCHAR(100) = NULL
	,@pickup_customer_arrived BIT = 0
	,@pickup_order_incoming BIT = 0
	,@pickup_vehicle_make VARCHAR(100) = NULL
    ,@pickup_vehicle_color VARCHAR(100) = NULL
	,@verified BIT = 0
	,@packed BIT = 0
	,@scheduled BIT = 0
	,@paid_in_full BIT = 0
	,@complete BIT = 0
	,@cancel BIT
	,@void BIT = 0
	,@subtotal DECIMAL(18, 2)
	,@discount DECIMAL(18, 2)
	,@taxable_discount DECIMAL(18, 2)
	,@round_amount DECIMAL(18, 5)
	,@loyalty DECIMAL(18, 2)
	,@delivery_fee DECIMAL(18, 2)
	,@tax DECIMAL(18, 2) = 0
	,@state_tax DECIMAL(18, 2) = 0
	,@local_tax DECIMAL(18, 2) = 0
	,@excise_tax DECIMAL(18, 2) = 0
	,@sales_tax DECIMAL(18, 2) = 0
	,@state_tax_percentage DECIMAL(18, 5) = 0
	,@local_tax_percentage DECIMAL(18, 5) = 0
	,@excise_tax_percentage DECIMAL(18, 5) = 0
	,@sales_tax_percentage DECIMAL(18, 5) = 0
	,@returns DECIMAL(18, 2)
	,@total DECIMAL(18, 2)
	,@items VARCHAR(max)
	,@discounts NVARCHAR(max)
	,@payments VARCHAR(max)
	,@id_user INT
	,@void_reason VARCHAR(255) = NULL
	,@void_reason_other VARCHAR(255) = NULL
	,@metrc_receipt_id VARCHAR(64) = NULL
	,@biotrack_receipt_id VARCHAR(64) = NULL
	,@ommu_dispensed BIT = 0
	,@caregiver_purchase BIT = 0
	,@id_caregiver INT = NULL
	,@caregiver_name VARCHAR(255) = NULL
	,@caregiver_card_number VARCHAR(255) = NULL
	,@id_physician INT = NULL
	,@physician_name VARCHAR(255) = NULL
	,@auto_apply_discount_exclusions VARCHAR(255)
	,@force BIT = 0
	,@source VARCHAR(128) = NULL
	,@non_mmic BIT = 0
	,@biotrack_delivery_id BIGINT = NULL
	,@biotrack_order_id BIGINT = NULL
	,@biotrack_ticket_id BIGINT = NULL
	,@biotrack_pickup_id BIGINT = NULL
AS
SET NOCOUNT ON

DECLARE @was_voided BIT = ISNULL((
			SELECT void
			FROM [order].[order]
			WHERE id_order = @id_order
			), 0)
DECLARE @was_cancelled BIT = ISNULL((
			SELECT cancel
			FROM [order].[order]
			WHERE id_order = @id_order
			), 0)

SET @force = ISNULL(@force, 0)

DECLARE @default_driver_id INT = (
		SELECT TOP 1 d.id_driver
		FROM [order].[driver] d
		INNER JOIN [base].[user] u on d.id_user= u.id_user
		WHERE id_location = @id_location
		AND u.deleted = 0
		)


/* Check to see if the order save should be allowed. */
DECLARE @ErrorMessage NVARCHAR(100)
SET @ErrorMessage = N'An order cannot be marked as cancelled and paid at the same time.'
IF (@cancel = 1 AND @paid_in_full = 1) THROW 60000
		,@ErrorMessage
		,1;

/* Update Order */
IF (@id_order IS NULL)
BEGIN
	/* Dont allow duplicate external ids */
	DECLARE @external_id_order INT

	SELECT TOP 1 @external_id_order = id_order
	FROM [order].[order]
	WHERE id_external = @id_external
		AND @id_external IS NOT NULL
		AND void = 0
		AND cancel = 0

	DECLARE @Message NVARCHAR(100)

	SET @Message = N'An order for this external id already exists see order #' + Cast(@external_id_order AS NVARCHAR(100))

	IF (@external_id_order IS NOT NULL) THROW 60000
		,@Message
		,1;
		INSERT INTO [order].[order] (
			id_customer
			,id_location
			,id_external
			,id_order_online
			,id_status
			,[type]
			,[use_type]
			,created_by
			,updated_by
			,id_session
			,apply_delivery_fee
			,packed
			,verified
			,scheduled
			,complete
			,cancel
			,auto_apply_discount_exclusions
			,[source]
			,non_mmic
			,subtotal
			,discount
			,taxable_discount
			,round_amount
			,loyalty
			,tax
			,state_tax
			,local_tax
			,excise_tax
			,state_tax_percentage
			,local_tax_percentage
			,excise_tax_percentage
			,sales_tax_percentage
			,delivery_fee
			,total
			)
		VALUES (
			@id_customer
			,@id_location
			,@id_external
			,@id_external
			,Isnull(@id_status, 1)
			,@type
			,@use_type
			,@id_user
			,@id_user
			,@id_session
			,@apply_delivery_fee
			,Isnull(@packed, 0)
			,Isnull(@verified, 0)
			,Isnull(@scheduled, 0)
			,Isnull(@complete, 0)
			,Isnull(@cancel, 0)
			,@auto_apply_discount_exclusions
			,@source
			,@non_mmic
			,@subtotal
			,@discount
			,@taxable_discount
			,@round_amount
			,@loyalty
			,@tax
			,@state_tax
			,@local_tax
			,@excise_tax
			,@state_tax_percentage
			,@local_tax_percentage
			,@excise_tax_percentage
			,@sales_tax_percentage
			,@delivery_fee
			,@total
			)

	SET @id_order = Scope_identity()
END
ELSE
BEGIN
	UPDATE [order].[order]
	SET id_location = Isnull(@id_location, id_location)
		,id_customer = Isnull(@id_customer, id_customer)
		,id_status = Isnull(@id_status, id_status)
		,void = Isnull(@void, void)
		,[type] = Isnull(@type, [type])
		,[use_type] = Isnull(@use_type, [use_type])
		,updated_by = @id_user
		,date_updated = Getutcdate()
		,packed = Isnull(@packed, packed)
		,verified = Isnull(@verified, verified)
		,scheduled = Isnull(@scheduled, scheduled)
		,complete = Isnull(@complete, complete)
		,cancel = Isnull(@cancel, cancel)
		,subtotal = Isnull(@subtotal, subtotal)
		,discount = Isnull(@discount, discount)
		,taxable_discount = Isnull(@taxable_discount, taxable_discount)
		,round_amount = Isnull(@round_amount, round_amount)
		,loyalty = Isnull(@loyalty, loyalty)
		,tax = Isnull(@tax, tax)
		,state_tax = Isnull(@state_tax, state_tax)
		,local_tax = Isnull(@local_tax, local_tax)
		,excise_tax = Isnull(@excise_tax, excise_tax)
		,state_tax_percentage = Isnull(@state_tax_percentage, state_tax_percentage)
		,local_tax_percentage = Isnull(@local_tax_percentage, local_tax_percentage)
		,excise_tax_percentage = Isnull(@excise_tax_percentage, excise_tax_percentage)
		,sales_tax_percentage = Isnull(@sales_tax_percentage, sales_tax_percentage)
		,delivery_fee = Isnull(@delivery_fee, delivery_fee)
		,[returns] = Isnull(@returns, [returns])
		,total = Isnull(@total, total)
		,paid_in_full = Isnull(@paid_in_full, paid_in_full)
		,apply_delivery_fee = Isnull(@apply_delivery_fee, apply_delivery_fee)
		,metrc_receipt_id = Isnull(@metrc_receipt_id, metrc_receipt_id)
		,biotrack_receipt_id = Isnull(@biotrack_receipt_id, biotrack_receipt_id)
		,auto_apply_discount_exclusions = Isnull(@auto_apply_discount_exclusions, auto_apply_discount_exclusions)
		,ommu_dispensed = Isnull(@ommu_dispensed, ommu_dispensed)
		,caregiver_purchase = Isnull(@caregiver_purchase, caregiver_purchase)
		,id_caregiver = @id_caregiver
		,caregiver_name = @caregiver_name
		,caregiver_card_number = @caregiver_card_number
		,id_physician = @id_physician
		,physician_name = @physician_name
		,non_mmic = Isnull(@non_mmic, non_mmic)
		,biotrack_delivery_id = @biotrack_delivery_id
		,biotrack_order_id = @biotrack_order_id
		,biotrack_ticket_id = @biotrack_ticket_id
		,biotrack_pickup_id = @biotrack_pickup_id
	WHERE id_order = @id_order
END

 -- After updating the order, check if it was cancelled
-- If yes, then delete all related donations
IF (@cancel = 1)
BEGIN
	DELETE FROM [base].[donation]
	WHERE order_id = @id_order;
END

/* Update Items if not voiding or cancelling order */
IF @items IS NOT NULL
	AND ISNULL(@void, 0) = 0
	AND ISNULL(@cancel, 0) = 0
BEGIN
	EXEC [order].usp_order_item_save @items
		,@id_order
		,@id_user
		,@force
END
		/* Return all items to inventory if voiding. */
ELSE IF (
		(
			@void = 1
			AND @was_voided = 0
			)
		OR (
			@cancel = 1
			AND @was_cancelled = 0
			)
		)
BEGIN
	/* get all order items to return. */
	DROP TABLE

	IF EXISTS #return_list
		SELECT id_batch
			,id_area
			,adjustment
		INTO #return_list
		FROM (
			SELECT oi.id_batch
				,oi.id_area
				,Sum(oi.quantity) * CASE 
					WHEN oi.id_item_return IS NOT NULL
						THEN - 1
					ELSE 1
					END AS adjustment
			FROM [order].[order] o
			INNER JOIN [order].[item] oi ON o.id_order = oi.id_order
			WHERE o.id_order = @id_order
				AND (
					oi.id_item_return IS NULL
					OR (
						oi.id_inventory_item IS NOT NULL
						AND o.paid_in_full = 1
						)
					)
			GROUP BY oi.id_batch
				,oi.id_area
				,oi.id_item_return
			) AS t

	DECLARE @return_list VARCHAR(max) = (
			SELECT *
			FROM #return_list
			FOR json path
			)
	DECLARE @reason VARCHAR(50) = CASE 
			WHEN (
					@void = 1
					AND @was_voided = 0
					)
				THEN 'order_void'
			WHEN (
					@cancel = 1
					AND @was_cancelled = 0
					)
				THEN 'order_cancel'
			END

	IF (@reason = 'order_void')
	BEGIN
		UPDATE [order].[order]
		SET [order].void_reason = @void_reason
			,[order].void_reason_other = @void_reason_other
		WHERE id_order = @id_order;
	END

	/* insert adjustment events for returned items. */
	EXEC [log].usp_event_create_bulk @reason
		,NULL
		,@return_list
		,@id_user
		-- Credit adjustments due to void are happening in POS code but should probably happen here
END

/* Update Order Discounts */
MERGE [order].[discount] AS t
USING (
	SELECT @id_order AS id_order
		,id_order_discount
		,id_discount
		,id_rule
		,amount
	FROM Openjson(@discounts) WITH (
			id_order_discount INT '$.id_order_discount'
			,id_discount INT '$.id_discount'
			,id_rule INT '$.id_rule'
			,amount DECIMAL(18, 2) '$.amount'
			)
	) AS s(id_order, id_order_discount, id_discount, id_rule, amount)
	ON t.id_order_discount = s.id_order_discount
		AND t.id_order = s.id_order
WHEN MATCHED
	AND isnull(s.amount, 0) <> isnull(t.amount, 0)
	THEN
		UPDATE
		SET t.amount = s.amount
WHEN NOT MATCHED BY target
	THEN
		INSERT (
			id_order
			,id_discount
			,id_rule
			,amount
			)
		VALUES (
			@id_order
			,s.id_discount
			,s.id_rule
			,s.amount
			)
WHEN NOT MATCHED BY source
	AND t.id_order = @id_order
	THEN
		DELETE;





IF (
		@type = 'delivery'
		OR @type = 'ecom_delivery'
		OR @type = 'ecom_express_delivery'
		)
BEGIN
	MERGE [order].[address] t
	USING (
		SELECT @id_order
			,delivery_date
			,address1
			,address2
			,city
			,[state]
			,zip
		    ,zip_four
			,note
			,lat
			,long
			,@id_user
		FROM Openjson(@delivery_address) WITH (
				delivery_date VARCHAR(100) '$.delivery_date'
				,address1 VARCHAR(100) '$.address1'
				,address2 VARCHAR(100) '$.address2'
				,city VARCHAR(100) '$.city'
				,[state] VARCHAR(50) '$.state'
				,zip VARCHAR(20) '$.zip'
		        ,zip_four VARCHAR(20) '$.zip_four'
				,note VARCHAR(500) '$.note'
				,lat VARCHAR(20) '$.lat'
				,long VARCHAR(20) '$.long'
				)
		) s(id_order, delivery_date, address1, address2, city, [state], zip, zip_four, note, lat, long, id_user)
		ON t.id_order = @id_order
	WHEN NOT MATCHED
		THEN
			INSERT (
				id_order
				,id_driver1
				,delivery_date
				,address1
				,address2
				,city
				,STATE
				,zip
				,zip_four
				,note
				,lat
				,long
				,id_user_created
				,id_user_updated
				)
			VALUES (
				s.id_order
				,@default_driver_id
				,s.delivery_date
				,s.address1
				,s.address2
				,s.city
				,s.[state]
				,s.zip
				,s.zip_four
				,s.note
				,s.lat
				,s.long
				,s.id_user
				,s.id_user
				)
	WHEN MATCHED
		THEN
			UPDATE
			SET t.delivery_date = s.delivery_date
				,t.id_driver1 = @default_driver_id
				,t.address1 = s.address1
				,t.address2 = s.address2
				,t.city = s.city
				,t.[state] = s.[state]
				,t.zip = s.zip
			    ,t.zip_four = s.zip_four
			    ,t.note = s.note
				,t.lat = s.lat
				,t.long = s.long
				,t.id_user_updated = s.id_user;
END

IF (@type = 'pickup' or @type ='curbside')
BEGIN
	MERGE [order].[pickup] t
	USING (
		SELECT @id_order
			,@pickup_date
			,@pickup_time
			,@pickup_phone
			,@pickup_email
			,@pickup_customer_arrived
			,@pickup_order_incoming
			,@pickup_vehicle_make
			,@pickup_vehicle_color
		) AS s(id_order, pickup_date, pickup_time, pickup_phone, pickup_email, pickup_customer_arrived, pickup_order_incoming, pickup_vehicle_make, pickup_vehicle_color)
		ON t.id_order = s.id_order
	WHEN NOT MATCHED BY target
		THEN
			INSERT (
				id_order
				,pickup_date
				,pickup_time
				,pickup_phone
				,pickup_email
				,pickup_customer_arrived
				,pickup_order_incoming
				,pickup_vehicle_make
				,pickup_vehicle_color
				)
			VALUES (
				s.id_order
				,s.pickup_date
				,s.pickup_time
				,s.pickup_phone
				,s.pickup_email
				,s.pickup_customer_arrived
				,s.pickup_order_incoming
				,s.pickup_vehicle_make
				,s.pickup_vehicle_color
				)
	WHEN MATCHED
		THEN
			UPDATE
			SET t.pickup_date = s.pickup_date
				,t.pickup_time = s.pickup_time
				,t.pickup_phone=s.pickup_phone
				,t.pickup_email=s.pickup_email
				,t.pickup_customer_arrived=s.pickup_customer_arrived
				,t.pickup_order_incoming=s.pickup_order_incoming
				,t.pickup_vehicle_make=s.pickup_vehicle_make
				,t.pickup_vehicle_color=s.pickup_vehicle_color;
END

SELECT @id_order as id_order
go

