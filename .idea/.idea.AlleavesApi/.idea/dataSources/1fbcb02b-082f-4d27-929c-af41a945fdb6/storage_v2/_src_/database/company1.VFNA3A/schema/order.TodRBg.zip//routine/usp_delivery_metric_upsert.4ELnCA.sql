CREATE  PROCEDURE [order].[usp_delivery_metric_upsert] 
    @idOrder INT,
    @idMetrc INT,
    @lastUpdated DATETIME
AS
BEGIN
    IF EXISTS (SELECT 1 FROM [order].delivery_metrc WHERE id_order = @idOrder)
    BEGIN
        -- If the record exists, update
        UPDATE [order].delivery_metrc
        SET id_metrc = @idMetrc,
            last_updated = @lastUpdated
        WHERE id_order = @idOrder;
    END
    ELSE
    BEGIN
        -- If the record does not exist, insert
        INSERT INTO [order].delivery_metrc (id_order, id_metrc, last_updated)
        VALUES (@idOrder, @idMetrc, @lastUpdated);
    END
END
go

