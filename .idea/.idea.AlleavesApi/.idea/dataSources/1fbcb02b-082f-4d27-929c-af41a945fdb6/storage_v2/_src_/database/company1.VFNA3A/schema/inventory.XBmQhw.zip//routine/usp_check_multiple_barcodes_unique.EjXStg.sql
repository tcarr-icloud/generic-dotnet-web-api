CREATE PROCEDURE [inventory].[usp_check_multiple_barcodes_unique]
    @barcodes VARCHAR(MAX)
AS
BEGIN
    SELECT name 
    FROM [inventory].[batch]
    WHERE name IN (SELECT value FROM STRING_SPLIT(@barcodes, ','));
END;
go

