CREATE   PROCEDURE [dbo].[usp_role_list]
	@id_role INT = NULL
AS
	SET NOCOUNT ON;

	SELECT r.id_role
			, r.[Name] as role
			, (SELECT u.id_user
						, u.UserName AS username
						, u.FirstName AS name_first
						, u.LastName AS name_last
				FROM [base].[user] u
				JOIN [base].[user_role] ur ON ur.id_user=u.id_user
				WHERE ur.id_role=r.id_role
				FOR JSON PATH
			) AS user_list
	FROM [base].[role] r
	WHERE r.id_role=ISNULL(@id_role, r.id_role)
go

