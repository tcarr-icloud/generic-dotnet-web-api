CREATE PROCEDURE [biotrack].[usp_form_list]
	
AS

SELECT o.id_form 
		,o.[name] as ommu_form
FROM [biotrack].[order_form] o
ORDER BY o.[name]
go

