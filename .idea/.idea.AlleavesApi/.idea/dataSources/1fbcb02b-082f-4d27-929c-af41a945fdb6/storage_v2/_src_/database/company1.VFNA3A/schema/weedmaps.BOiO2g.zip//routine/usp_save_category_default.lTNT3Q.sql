CREATE PROCEDURE [weedmaps].[usp_save_category_default]
	@default_category varchar(255)
AS
	IF(@default_category IS NOT NULL)
	BEGIN
		DELETE FROM weedmaps.default_category

		INSERT INTO weedmaps.default_category
		SELECT @default_category
	END
RETURN 0
go

