CREATE FUNCTION [inventory].[fn_generate_item_barcode]
(
	@id_item INT
)
RETURNS VARCHAR(64)
AS
BEGIN
	DECLARE @date_created DATETIME = (SELECT date_created FROM inventory.item WHERE id_item=@id_item)

	IF(@date_created IS NULL) RETURN 'IERROR'

	DECLARE @year VARCHAR(4) = YEAR(@date_created),
		    @date VARCHAR(4) = CONCAT(RIGHT('00'+CAST(MONTH(@date_created) AS VARCHAR(2)), 2), RIGHT('00'+CAST(DAY(@date_created) AS VARCHAR(2)), 2)),
			@pkid VARCHAR(8) = RIGHT('00000000'+CAST(@id_item AS VARCHAR(8)), 8)

	RETURN CONCAT('I', @pkid, @year, @date)
END
go

