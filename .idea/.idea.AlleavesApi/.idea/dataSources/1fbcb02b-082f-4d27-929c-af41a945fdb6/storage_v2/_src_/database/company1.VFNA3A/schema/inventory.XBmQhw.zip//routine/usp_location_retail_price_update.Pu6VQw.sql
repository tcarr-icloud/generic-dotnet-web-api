CREATE PROCEDURE [inventory].[usp_location_retail_price_update]
	@price_list VARCHAR(MAX) = '[]',
	@id_user INT
AS

	;WITH price_list AS (
		SELECT id_item_location
			, price_otd
			, price_otd_adult_use
			, price_otd_medical_use
			, price_retail
			, price_retail_adult_use
			, price_retail_medical_use
		FROM OPENJSON(@price_list)
		WITH (
			  id_item_location INT,
			  price_otd DECIMAL(18, 4),
			  price_otd_adult_use DECIMAL(18, 4),
			  price_otd_medical_use DECIMAL(18, 4),
			  price_retail DECIMAL(18, 4),
			  price_retail_adult_use DECIMAL(18, 4),
			  price_retail_medical_use DECIMAL(18, 4)
		)
	)
	MERGE [inventory].[item_location] AS il
	USING price_list AS pl
	ON pl.id_item_location = il.id_item_location
	WHEN MATCHED THEN
	UPDATE SET 
		il.id_user_updated=@id_user, 
		il.date_updated=getutcdate(),
		il.price_retail=pl.price_retail ,
		il.price_retail_adult_use=pl.price_retail_adult_use,
		il.price_retail_medical_use=pl.price_retail_medical_use,
		il.price_otd=pl.price_otd,
		il.price_otd_adult_use=pl.price_otd_adult_use,
		il.price_otd_medical_use=pl.price_otd_medical_use
	;
go

