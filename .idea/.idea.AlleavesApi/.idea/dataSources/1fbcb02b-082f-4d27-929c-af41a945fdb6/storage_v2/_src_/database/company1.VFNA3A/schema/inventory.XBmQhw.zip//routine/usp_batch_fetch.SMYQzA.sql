CREATE PROCEDURE [inventory].[usp_batch_fetch]
	@id_batch INT = NULL,
	@metrc_package_label VARCHAR(128) = NULL
AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET ANSI_WARNINGS OFF;
	
	--SET STATISTICS TIME ON;
	--DECLARE @id_batch INT = 2175
	--DECLARE @metrc_package_label VARCHAR(128) = NULL

	DECLARE @_id_batch INT = @id_batch
	DECLARE @_metrc_package_label VARCHAR(128) = @metrc_package_label

	IF(@_id_batch IS NULL AND @_metrc_package_label IS NOT NULL)
	BEGIN
		SET @_id_batch = (SELECT id_batch FROM inventory.batch where metrc_package_label = @_metrc_package_label)
	END

	DECLARE @id_item INT = (SELECT TOP 1 id_item FROM inventory.batch WHERE id_batch = @_id_batch)
	DECLARE @id_test_result INT = (SELECT TOP 1 id_test_result FROM inventory.test_result WHERE id_batch = @_id_batch)
	DECLARE @id_uom_g INT = (SELECT id_uom FROM inventory.uom WHERE name_short = 'g')

	;WITH category_list_cte as (
		SELECT id_category, [name], [path] FROM inventory.vw_category_list
	), current_inventory_cte as (
		SELECT    b.id_batch
				, SUM(i.quantity) AS on_hand
				, SUM(i.quantity + ISNULL(tx.quantity, 0) + ISNULL(ord.ordered, 0) - ISNULL(ord.paid, 0)) AS available
		FROM inventory.inventory as i
		LEFT OUTER JOIN inventory.area as a on i.id_area=a.id_area
		LEFT OUTER JOIN inventory.batch as b on i.id_batch = b.id_batch
		LEFT OUTER JOIN (
			SELECT    ti.id_batch
					, ti.id_area
					, SUM(ti.quantity) AS quantity
			FROM inventory.transfer t
			JOIN inventory.transfer_item ti ON ti.id_transfer=t.id_transfer
			CROSS APPLY (SELECT TOP 1 id_transfer_status FROM inventory.transfer_status_history h WHERE h.id_transfer=t.id_transfer ORDER BY h.date_verified DESC) x 
			WHERE x.id_transfer_status = 1
			GROUP BY ti.id_batch, ti.id_area		
		) as tx ON tx.id_batch=b.id_batch AND tx.id_area=a.id_area
		/* order items not packed yet. */
		LEFT OUTER JOIN (
			SELECT oi.id_batch
					, oi.id_area
					, SUM(oi.quantity) AS ordered
					, SUM(CASE WHEN o.packed = 1 THEN oi.quantity END) as packed
					, SUM(CASE WHEN o.paid_in_full = 1 THEN oi.quantity END) as paid
			FROM [order].[order] o
			JOIN [order].item oi ON oi.id_order=o.id_order
			WHERE o.void=0 AND o.cancel = 0
			AND oi.id_inventory_item IS NOT NULL
			GROUP BY oi.id_batch, oi.id_area
		) ord ON ord.id_batch=b.id_batch AND ord.id_area=a.id_area
		WHERE b.id_batch=@_id_batch
		GROUP BY b.id_batch
	)
	, test_result_chemical_profile_cte as (
		SELECT [value], id_chemical_profile, id_test_result FROM inventory.test_result_chemical_profile
		WHERE id_test_result = @id_test_result
	)
	SELECT 
			  b.id_batch
			, ig.id_location
			, i.id_item_group
			, i.id_item
			, c.id_category
			, u.id_uom
			, s.id_strain
			, t.id_test_result
			, st.id_status
			, b.name AS batch
			, b.[name] as batch_split
			, base.fn_barcode_human_readable(b.name) AS batch_split
			, b.metrc_finished
			, b.date_closed
			, b.date_use_by
			, b.date_packed as date_packed
			, b.vendor_batch_id
			, b.external_id
			, b.metrc_package_label
			, b.id_uom_metrc
			, b.harvest_batch
			, 'api/inventory/batch/methodlabs/' + b.harvest_batch as methodlabs_coa
			, b.cultivator
			, b.cultivator_license
			, b.manufactured_by
			, b.activation_time
			, b.packager
			, b.extraction_method
			, b.solvent_type
			, ig.[name] as item_group
			, RTRIM(CONCAT(ig.name, ' ', (
					SELECT STRING_AGG(av.name, ' ')
					FROM inventory.item_attribute_value iav
					LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
					WHERE iav.id_item=i.id_item)
				)) AS item
			, i.sku
			, i.barcode as item_barcode
			, b.initial_quantity
			, i.use_otd_price
			, br.[name] as brand
			, ISNULL(b.cost_of_good, i.cost_of_good) AS cost_of_good
			, ISNULL(i.price_retail, 0) as price_retail
			, ISNULL(i.price_otd, 0) as price_otd
			, ISNULL(i.price_retail_adult_use, 0) as price_retail_adult_use
			, ISNULL(i.price_otd_adult_use, 0) as price_otd_adult_use
			, ISNULL(i.price_retail_medical_use, 0) as price_retail_medical_use
			, ISNULL(i.price_otd_medical_use, 0) as price_otd_medical_use
			, i.metrc_item_id
			, i.metrc_category
			, b.biotrack_barcode_id
			, b.biotrack_inventory_type_id
			, biot.[name] as biotrack_inventory_type_name
			, biot.requires_weighing as biotrack_requires_weighing
	        , ig.product_description
	        , ISNULL((SELECT id_media
							, content
							, type
					  FROM inventory.item_media
					  WHERE item_media.id_item = @id_item
					  FOR JSON PATH
			), '[]') as media_list
			, c.name AS category
			, c.path AS category_path
			, u.name AS uom
			, u.quantity_type AS uom_type
			, u.name_short AS uom_short
			, s.name AS strain
			, st.name AS status
	        , stt.name AS strain_type
			, w.name_short as weight_useable_uom_short
			, w.[name] as weight_useable_uom
			, i.weight_useable
			, i.weight_net
			, i.id_uom_weight_net
			, i.gross_weight_useable
			, ucc.multiplier * i.gross_weight_useable as gross_weight_useable_g
			, wu.[name] as gross_weight_useable_uom
			, wu.name_short as gross_weight_useable_uom_short
			, b.qc_hold
			, ISNULL(CAST((SELECT TOP 1 trcp.[value]
				FROM test_result_chemical_profile_cte trcp
				LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
				WHERE icp.id_chemical_profile=2 AND trcp.id_test_result=@id_test_result) / 100.0 AS DECIMAL(6, 5)), NULL) as thc
			, ISNULL(CAST((SELECT TOP 1 trcp.[value]
				FROM test_result_chemical_profile_cte trcp
				LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
				WHERE icp.id_chemical_profile=1 AND trcp.id_test_result=@id_test_result) / 100.0 AS DECIMAL(6, 5)), NULL) as cbd
			, ISNULL(CAST((SELECT TOP 1 trcp.[value]
				FROM test_result_chemical_profile_cte trcp
				LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
				WHERE icp.id_chemical_profile = 60 AND trcp.id_test_result=@id_test_result) AS DECIMAL(18,3)), NULL) as thc_mg
			, ISNULL(CAST((SELECT TOP 1 trcp.[value]
				FROM test_result_chemical_profile_cte trcp
				LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
				WHERE icp.id_chemical_profile = 61 AND trcp.id_test_result=@id_test_result) AS DECIMAL(18,3)), NULL) as cbd_mg
			, t.coa_s3_key
			, t.test_name
			, t.test_lab
			, t.test_batch
			, t.test_date
			, ig.is_cannabis
			, ig.is_plant
			, ig.is_seed
			, inv.on_hand
			, inv.available
			, bt.total_thc as biotrack_thc
			, bt.total_cbd as biotrack_cbd, 
			bt.cbd,
			bt.moisture_content,
			bt.d8_thc,
			bt.thca,
			bt.cbda,
			bt.d9_thc,
			bt.thcv,
			bt.cbdv,
			bt.cbga,
			bt.cbn,
			bt.cbc,
			bt.filth_feces_foreign_matter,
			bt.shiga_toxin_producing_escherichia_coli,
			bt.aspergillus_niger,
			bt.aspergillus_fumigatus,
			bt.aspergillus_flavus,
			bt.staphylococcus_aureus,
			bt.bile_tolerant_gram_negative_bacteria,
			bt.total_aerobic_microbial_count,
			bt.acetone,
			bt.acetonitrile,
			bt.benzene,
			bt.butane,
			bt.one_2_dichloroethane,
			bt.one_1_dichloroethene,
			bt.ethanol,
			bt.ethyl_acetate,
			bt.ethyl_ether,
			bt.ethylene_oxide,
			bt.heptane,
			bt.hexane,
			bt.isopropyl_alcohol,
			bt.methanol,
			bt.methylene_chloride,
			bt.pentane,
			bt.propane,
			bt.trichloroethylene,
			bt.toluene,
			bt.total_xylenes,
			bt.alfatoxin_b1,
			bt.alfatoxin_b2,
			bt.alfatoxin_01,
			bt.alfatoxin_02,
			bt.ochratoxin_a,
			bt.[lead],
			bt.arsenic,
			bt.cadmium,
			bt.mercury,
			bt.total_contaminant_load,
			bt.water_activity,
			bt.abamectin,
			bt.acephate,
			bt.acequinocyl,
			bt.acetamiprid,
			bt.aldicarb,
			bt.azoxystrobin,
			bt.bifenazate,
			bt.bifenthrin,
			bt.boscalid,
			bt.captan,
			bt.carbaryl,
			bt.carbofuran,
			bt.chlorantraniliprole,
			bt.chlordane,
			bt.chlorfenapyr,
			bt.chlormequat_chloride,
			bt.chlorpyrifos,
			bt.clofentezine,
			bt.coumaphos,
			bt.cyfluthrin,
			bt.cypermethrin,
			bt.daminozide,
			bt.diazinon,
			bt.dichlorvos,
			bt.dimethoate,
			bt.dimethomorph,
			bt.ethoprophos,
			bt.etofenprox,
			bt.etoxazole,
			bt.fenhexamid,
			bt.fenoxycarb,
			bt.fenpyroximate,
			bt.fipronil,
			bt.flonicamid,
			bt.fludioxonil,
			bt.hexythiazox,
			bt.imazalil,
			bt.imidacloprid,
			bt.kresoxim_methyl,
			bt.malathion,
			bt.metalaxyl,
			bt.methiocarb,
			bt.methomyl,
			bt.methyl_parathion,
			bt.mevinphos,
			bt.myclobutanil,
			bt.naled,
			bt.oxamyl,
			bt.paclobutrazol,
			bt.pentachloronitrobenzene,
			bt.permethrin,
			bt.phosmet,
			bt.piperonyl_butoxide,
			bt.prallethrin,
			bt.propiconazole,
			bt.propoxur,
			bt.pyrethrins,
			bt.pyridaben,
			bt.spinetoram,
			bt.spinosad_a_and_D,
			bt.spiromesifen,
			bt.spirotetramat,
			bt.spiroxamine,
			bt.tebuconazole,
			bt.thiacloprid,
			bt.thiamethoxam,
			bt.trifloxystrobin,
			bt.total_combined_yeast_mold
			, CASE WHEN ISNULL(inv.on_hand, 0) > 0 THEN 1 ELSE 0 END AS has_inventory
			, CONVERT(VARCHAR(32), b.date_created, 127) AS date_received
			, CAST(b.date_production AS VARCHAR(16)) AS date_production
			, CASE WHEN ig.has_shelf_life=1 THEN CAST(ISNULL(b.date_expire, DATEADD(day, ig.shelf_life_days, b.date_production)) AS VARCHAR(16)) ELSE b.date_expire END AS date_expire
			, CONCAT(us.FirstName, ' ', us.LastName) AS updated_by
			, b.date_updated
			, CASE 
				WHEN b.date_harvest IS NOT NULL THEN CAST(b.date_harvest AS VARCHAR(16))
				WHEN @_id_batch IS NULL THEN NULL
				ELSE
				(
					SELECT TOP 1 
						pp.date_started
					FROM grow.plant_phase pp
					JOIN grow.phase ph ON ph.id_phase=pp.id_phase
					JOIN grow.plant p ON p.id_plant=pp.id_plant
					JOIN grow.batch_plant bp ON bp.id_plant=p.id_plant
					WHERE bp.id_batch=@_id_batch
					ORDER BY ph.sequence DESC, pp.date_started
				) 
			  END AS date_harvest
			, ISNULL((SELECT p.id_plant
							, p.id_strain
							, s.id_strain_type
							, p.name AS plant
							, base.fn_barcode_human_readable(p.name) AS plant_split
							, s.name AS strain
							, st.name AS strain_type
							, (SELECT pp.id_phase
										, ph.name AS phase
										, pp.date_started
								FROM grow.plant_phase pp
								JOIN grow.phase ph ON ph.id_phase=pp.id_phase
								WHERE pp.id_plant=p.id_plant
								ORDER BY ph.sequence
								FOR JSON PATH
								) AS phase_list
					FROM grow.batch_plant bp
					JOIN grow.plant p ON p.id_plant=bp.id_plant
					JOIN grow.strain s ON s.id_strain=p.id_strain
					JOIN grow.strain_type st ON st.id_strain_type=s.id_strain_type
					WHERE bp.id_batch=@_id_batch
					FOR JSON PATH
			), '[]') AS plant_list
			, ISNULL((SELECT cp.id_chemical_profile
							, tr.id_test_result
							, tr.[value]
							, cp.[type]
							, cp.[name] AS chemical_profile
					FROM [inventory].[chemical_profile] cp
					JOIN [inventory].[test_result_chemical_profile] tr ON cp.id_chemical_profile=tr.id_chemical_profile AND @id_test_result =tr.id_test_result
					WHERE cp.deleted=0
					ORDER BY cp.[name]
					FOR JSON PATH
			), '[]') AS chemical_profile_list,
            b.biotrack_package_label
	FROM inventory.batch b
	LEFT OUTER JOIN inventory.item as i ON i.id_item = b.id_item
	LEFT OUTER JOIN inventory.item_group ig ON i.id_item_group = ig.id_item_group
	LEFT OUTER JOIN biotrack.inventory_type biot ON biot.id_inventory_type=i.biotrack_inventory_type_id
	LEFT OUTER JOIN biotrack.biotrack_test_result bt ON bt.id_batch=@id_batch
	LEFT OUTER JOIN inventory.uom u ON u.id_uom=ig.id_uom
	LEFT OUTER JOIN inventory.uom w ON w.id_uom=ig.id_uom_weight_useable
	LEFT OUTER JOIN inventory.uom wu ON wu.id_uom=i.id_uom_gross_weight_useable
	LEFT OUTER JOIN inventory.uom_convert ucc on 
		ucc.id_uom_from = i.id_uom_gross_weight_useable AND
		ucc.id_uom_to = @id_uom_g
	LEFT JOIN category_list_cte c ON c.id_category=ig.id_category
	LEFT JOIN inventory.status st ON st.id_status=b.id_status
	LEFT JOIN grow.strain s ON s.id_strain=ig.id_strain
	LEFT JOIN grow.strain_type stt ON s.id_strain_type=stt.id_strain_type
	LEFT JOIN inventory.test_result t ON t.id_batch=b.id_batch
	LEFT JOIN base.[user] us ON us.id_user=b.updated_by
	LEFT OUTER JOIN inventory.brand br on br.id_brand = ig.id_brand
	LEFT JOIN current_inventory_cte inv on inv.id_batch=b.id_batch
	WHERE 
		(@_id_batch IS NOT NULL AND b.id_batch=@_id_batch)
go

