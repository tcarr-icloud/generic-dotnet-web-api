CREATE PROCEDURE [dbo].[usp_user_profile_update]
	@id_user INT,
	@username VARCHAR(128),
	@password VARCHAR(128) = NULL
AS
	SET NOCOUNT ON;
	
	UPDATE [base].[user]
	SET UserName=@username,
		Email=@username,
		PasswordHash=ISNULL(@password, Passwordhash)
	WHERE id_user=@id_user

	SELECT id_user
			, UserName AS username
			, Email AS email
	FROM [base].[user]
	WHERE id_user=@id_user
go

