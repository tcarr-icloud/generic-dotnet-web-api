CREATE PROCEDURE [discount].[usp_discount_update]
	@id_discount INT,
	@name VARCHAR(128),
	@code VARCHAR(128),
	@id_adjustment_type INT,
	@id_sale_type INT,
	@use_category_in_list BIT,
	@use_product_in_list BIT,
	@auto_apply BIT,
	@apply_pre_tax BIT,
	@apply_post_tax BIT, 
	@active BIT,
	@can_be_combined BIT,
	@num_uses INT,
	@date_valid_start DATE,
	@date_valid_end DATE,
	@filter_category_list VARCHAR(MAX) = '[]',
	@filter_product_list VARCHAR(MAX) = '[]',
	@rule_list VARCHAR(MAX) = '[]',
	@id_user INT,
	@del BIT = 0
AS

	--DECLARE @id_discount INT = 1005
	--DECLARE @name VARCHAR(128) = N'10% Off'
	--DECLARE @code VARCHAR(128) = N'10OFF'
	--DECLARE @id_adjustment_type INT = 1
	--DECLARE @id_sale_type INT = NULL
	--DECLARE @use_category_in_list BIT = NULL
	--DECLARE @use_product_in_list BIT = NULL
	--DECLARE @auto_apply BIT = 0
	--DECLARE @apply_pre_tax BIT = 1
	--DECLARE @apply_post_tax BIT = 0
	--DECLARE @active BIT = 1
	--DECLARE @can_be_combined BIT = 1
	--DECLARE @num_uses INT = 2
	--DECLARE @date_valid_start DATE = NULL
	--DECLARE @date_valid_end DATE = NULL
	--DECLARE @filter_category_list VARCHAR(MAX) = N'[]'
	--DECLARE @filter_product_list VARCHAR(MAX) = N'[]'
	--DECLARE @rule_list VARCHAR(MAX) = N'[{"id_rule":6,"id_discount":1005,"id_type":1,"value":10,"type_reference":"percent"}]'
	--DECLARE @id_user INT = 2
	--DECLARE @del BIT = 0 

	/* handle deleting discount. */
	IF (@del = 1)
	BEGIN
		UPDATE discount.discount
		SET deleted=1
			, updated_by=@id_user
			, date_updated=getutcdate()
		WHERE id_discount=@id_discount

		EXEC discount.usp_discount_list @id_discount, 0, 1

		RETURN
	END
	
	/* get original adjustment type. */
	DECLARE @orig_id_adj INT = (SELECT TOP 1 id_adjustment_type FROM discount.discount WHERE id_discount=@id_discount)
	DECLARE @adj_orig VARCHAR(64) = (SELECT TOP 1 reference FROM discount.adjustment_type WHERE id_adjustment_type=@orig_id_adj)
	DECLARE @adj VARCHAR(64) = (SELECT TOP 1 reference FROM discount.adjustment_type WHERE id_adjustment_type=@id_adjustment_type)

	/* update main discount data. */
	UPDATE discount.discount
	SET name=@name
		, code=@code
		, id_adjustment_type=@id_adjustment_type
		, id_sale_type=@id_sale_type
		, use_category_in_list=@use_category_in_list
		, use_product_in_list=@use_product_in_list
		, auto_apply=@auto_apply
		, apply_pre_tax=@apply_pre_tax
		, apply_post_tax=@apply_post_tax
		, active=@active
		, can_be_combined=@can_be_combined
		, num_uses=@num_uses
		, date_valid_start=@date_valid_start
		, date_valid_end=@date_valid_end
		, updated_by=@id_user
		, date_updated=getutcdate()
	WHERE id_discount=@id_discount


	/* update category filter. */
	;WITH category_list AS (
		SELECT @id_discount AS id_discount
				, id_category
		FROM OPENJSON(@filter_category_list)
		WITH ( id_category INT '$.id_category')
	)
	MERGE discount.filter_category t
	USING category_list s
	ON t.id_discount=s.id_discount AND t.id_category=s.id_category
	WHEN NOT MATCHED BY TARGET THEN INSERT (id_discount, id_category) VALUES (s.id_discount, s.id_category)
	WHEN NOT MATCHED BY SOURCE AND t.id_discount=@id_discount THEN DELETE;


	/* update product filter. */
	;WITH product_list AS (
		SELECT @id_discount AS id_discount
				, id_item
		FROM OPENJSON(@filter_product_list)
		WITH ( id_item INT '$.id_item')
	)
	MERGE discount.filter_product t
	USING product_list s
	ON t.id_discount=s.id_discount AND t.id_item=s.id_item
	WHEN NOT MATCHED BY TARGET THEN INSERT (id_discount, id_item) VALUES (s.id_discount, s.id_item)
	WHEN NOT MATCHED BY SOURCE AND t.id_discount=@id_discount THEN DELETE;

	
	/* if adjustment type changed, delete old rules and insert new rules. */
	IF (@adj_orig != @adj)
	BEGIN
		/* delete old rules based on original adjustment type. */
		IF (@adj_orig='bulk') DELETE FROM discount.rule_bulk WHERE id_discount=@id_discount
		ELSE IF (@adj_orig='bxgx') DELETE FROM discount.rule_bxgx WHERE id_discount=@id_discount
		ELSE DELETE FROM discount.rule_basic WHERE id_discount=@id_discount

		/* insert new rules based on adjustment type. */
		IF (@adj = 'bulk')
		BEGIN
			INSERT INTO [discount].[rule_bulk] (id_discount, range_min, range_max, id_type, value)
			SELECT @id_discount AS id_discount
					, range_min
					, range_max
					, id_type
					, value
			FROM OPENJSON(@rule_list)
			WITH (
				range_min DECIMAL(18,4) '$.range_min',
				range_max DECIMAL(18,4) '$.range_max',
				id_type INT '$.id_type',
				value DECIMAL(18,4) '$.value'
			)
		END
		IF (@adj = 'bxgx')
		BEGIN
			INSERT INTO [discount].[rule_bxgx] (id_discount, qty_bought, qty_discounted, id_type, value)
			SELECT @id_discount AS id_discount
					, qty_bought
					, qty_discounted
					, id_type
					, value
			FROM OPENJSON(@rule_list)
			WITH (
				qty_bought INT '$.qty_bought',
				qty_discounted INT '$.qty_discounted',
				id_type INT '$.id_type',
				value DECIMAL(18,4) '$.value'
			)
		END
		ELSE
		BEGIN
			INSERT INTO [discount].[rule_basic] (id_discount, id_type, value)
			SELECT @id_discount AS id_discount
					, id_type
					, value
			FROM OPENJSON(@rule_list)
			WITH (
				id_type INT '$.id_type',
				value DECIMAL(18,4) '$.value'
			)
		END
	END
	/* merge rules if adjustment type has not changed. */
	ELSE
	BEGIN
		IF (@adj = 'bulk')
		BEGIN
			/* merge BULK rules. */
			;WITH rule_list AS (
				SELECT id_rule, range_min, range_max, id_type, value
				FROM OPENJSON(@rule_list)
				WITH (
					id_rule INT '$.id_rule',
					range_min DECIMAL(18,4) '$.range_min',
					range_max DECIMAL(18,4) '$.range_max',
					id_type INT '$.id_type',
					value DECIMAL(18,4) '$.value'
				)
			)
			MERGE discount.rule_bulk t
			USING rule_list s ON s.id_rule=t.id_rule
			WHEN MATCHED THEN UPDATE SET t.range_min=s.range_min, t.range_max=s.range_max, t.id_type=s.id_type, t.value=s.value
			WHEN NOT MATCHED BY TARGET THEN INSERT (id_discount, range_min, range_max, id_type, value) VALUES (@id_discount, s.range_min, s.range_max, s.id_type, s.value)
			WHEN NOT MATCHED BY SOURCE AND t.id_discount=@id_discount THEN DELETE
			;
		END
		IF (@adj = 'bxgx')
		BEGIN			
			/* merge BUY X GET X rules. */
			;WITH rule_list AS (
				SELECT id_rule, qty_bought, qty_discounted, id_type, value
				FROM OPENJSON(@rule_list)
				WITH (
					id_rule INT '$.id_rule',
					qty_bought INT '$.qty_bought',
					qty_discounted INT '$.qty_discounted',
					id_type INT '$.id_type',
					value DECIMAL(18,4) '$.value'
				)
			)
			MERGE discount.rule_bxgx t
			USING rule_list s ON s.id_rule=t.id_rule
			WHEN MATCHED THEN UPDATE SET t.qty_bought=s.qty_bought, t.qty_discounted=s.qty_discounted, t.id_type=s.id_type, t.value=s.value
			WHEN NOT MATCHED BY TARGET THEN INSERT (id_discount, qty_bought, qty_discounted, id_type, value) VALUES (@id_discount, s.qty_bought, s.qty_discounted, s.id_type, s.value)
			WHEN NOT MATCHED BY SOURCE AND t.id_discount=@id_discount THEN DELETE
			;
		END
		ELSE
		BEGIN
			/* merge BASIC rules. */
			;WITH rule_list AS (
				SELECT id_rule, id_type, value
				FROM OPENJSON(@rule_list)
				WITH (
					id_rule INT '$.id_rule',
					id_type INT '$.id_type',
					value DECIMAL(18,4) '$.value'
				)
			)
			MERGE discount.rule_basic t
			USING rule_list s ON s.id_rule=t.id_rule
			WHEN MATCHED THEN UPDATE SET t.id_type=s.id_type, t.value=s.value
			WHEN NOT MATCHED BY TARGET THEN INSERT (id_discount, id_type, value) VALUES (@id_discount, s.id_type, s.value)
			WHEN NOT MATCHED BY SOURCE AND t.id_discount=@id_discount THEN DELETE
			;
		END
	END

	/* return updated discount. */
	EXEC discount.usp_discount_list @id_discount = @id_discount, @include_deleted = 0
go

