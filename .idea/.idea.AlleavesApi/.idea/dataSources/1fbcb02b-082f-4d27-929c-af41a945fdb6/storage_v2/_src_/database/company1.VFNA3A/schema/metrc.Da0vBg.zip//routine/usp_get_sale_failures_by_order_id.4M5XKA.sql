CREATE PROCEDURE metrc.usp_get_sale_failures_by_order_id
	@id_order INT
AS
BEGIN
	SELECT e.*,
	        vwo.id_order AS id_order,
	        u_loc.metrc_api_user_key

	    FROM [metrc].[sale_failure]
	        as e
	        INNER JOIN [order].vw_orders AS vwo ON vwo.id_order = e.id_order
	        LEFT JOIN [base].user_location AS u_loc ON vwo.id_location = u_loc.id_location
	        AND e.created_by = u_loc.id_user

	    WHERE e.remediated = 0 AND vwo.id_order=@id_order
END
go

