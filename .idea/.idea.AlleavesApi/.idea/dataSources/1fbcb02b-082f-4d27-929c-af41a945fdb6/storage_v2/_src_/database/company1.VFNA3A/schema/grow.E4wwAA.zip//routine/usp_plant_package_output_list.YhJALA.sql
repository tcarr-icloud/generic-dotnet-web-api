CREATE PROCEDURE [grow].[usp_plant_package_output_list]
	@id_strain INT = NULL
AS
	SELECT g.id_item_group
			, i.id_item
			, s.id_strain
			, RTRIM(CONCAT(g.name, ' ', (
					SELECT STRING_AGG(av.name, ' ')
					FROM inventory.item_attribute_value iav
					LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
					WHERE iav.id_item=i.id_item)
				)) AS item
			, s.name AS strain
			, u.name AS uom
	FROM inventory.item_group g 
	LEFT JOIN inventory.item i ON i.id_item_group=g.id_item_group
	LEFT JOIN inventory.uom u ON u.id_uom=g.id_uom
	LEFT JOIN grow.strain s ON s.id_strain=g.id_strain
	WHERE g.is_plant=1 AND 
		  i.weight_useable=1 AND
			(@id_strain IS NULL OR g.id_strain=@id_strain)
go

