CREATE 
 procedure [dbo].[usp_get_driver_fcm_tokens] @id_driver_list varchar(max) = null
AS
    SET NOCOUNT ON;

select isnull(fcm_tokens, '[]') as fcm_tokens, id_user
from base.[user]
where id_user in (select id_user
                  from [order].driver
                  where id_driver not in (select id_driver from [inventory].area_driver) and
                        @id_driver_list is null
                     or id_driver in (SELECT [value] FROM OPENJSON(@id_driver_list, '$'))
)
go

