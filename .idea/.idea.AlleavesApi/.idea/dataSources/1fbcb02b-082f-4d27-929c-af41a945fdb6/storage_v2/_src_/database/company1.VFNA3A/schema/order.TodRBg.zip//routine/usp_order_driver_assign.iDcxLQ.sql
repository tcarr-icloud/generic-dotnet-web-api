CREATE PROCEDURE [order].[usp_order_driver_assign]
    @id_order int = null,
	@id_driver int = null,
	@id_driver2 int = null
AS
BEGIN

    UPDATE [order].ecommerce_ride SET id_driver = ISNULL(@id_driver, id_driver),
                                      id_driver2 = ISNULL(@id_driver2, id_driver2)
    WHERE id_order =@id_order
    EXEC [order].ecommerce_ride_list @id_order=@id_order;
END
go

