CREATE PROCEDURE customer.usp_alpine_opt_in_create @id_customer int = null,
                                                      @phone_number varchar(32) = null,
                                                      @new_member bit = 0,
                                                      @alpine_member_id varchar(32) = null,
                                                      @id_pos int = null,
                                                      @id_location int = null,
                                                      @id_user int = null,
                                                      @created_by int = null,
                                                      @updated_by int = null
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO customer.alpine_opt_in (id_customer, phone_number, new_member, alpine_member_id,
                                           id_pos, id_location, id_user, created_by, updated_by)
    values (@id_customer, @phone_number, @new_member, @alpine_member_id, @id_pos, @id_location,
            @id_user, @created_by, @updated_by);
END
go

