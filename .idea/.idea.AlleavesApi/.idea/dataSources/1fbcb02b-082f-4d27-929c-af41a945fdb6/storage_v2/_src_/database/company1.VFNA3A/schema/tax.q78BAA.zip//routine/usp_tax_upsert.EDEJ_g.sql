CREATE PROCEDURE [tax].[usp_tax_upsert]
	@id_tax INT,
    @name VARCHAR(256),
    @percentage DECIMAL(18,5),
    @is_cannabis BIT,
    @is_non_cannabis BIT,
    @is_excise_tax BIT,
    @is_state_tax BIT,
    @is_local_tax BIT,
    @is_adult_use BIT,
    @is_medical_use BIT,
    @is_arms_length BIT,
    @is_gross_tax BIT,
    @markup_rate DECIMAL(18,5),
    @stacking_order INT,
    @active BIT,
    @id_user INT,
    @vendor_list VARCHAR(MAX) = '[]',
    @tax_group_list VARCHAR(MAX) = '[]'
AS
    UPDATE [tax].[tax]
    SET [name] = @name,
        [percentage] = @percentage,
        is_cannabis = @is_cannabis,
        is_non_cannabis = @is_non_cannabis,
        is_excise_tax = @is_excise_tax,
        is_state_tax = @is_state_tax,
        is_local_tax = @is_local_tax,
        is_adult_use = @is_adult_use,
        is_medical_use = @is_medical_use,
        is_arms_length = @is_arms_length,
        is_gross_tax = @is_gross_tax,
        markup_rate = @markup_rate,
        stacking_order = @stacking_order,
        active = @active,
        updated_by = @id_user,
        date_updated = getutcdate()
    WHERE id_tax = @id_tax

    ;WITH vendor_list AS (
		SELECT @id_tax AS id_tax
			, id_vendor
		FROM OPENJSON(@vendor_list)
		WITH (
			  id_vendor INT
		)
	)
	MERGE [tax].[vendor] AS tv
	USING vendor_list AS vl
	ON vl.id_vendor = tv.id_vendor AND vl.id_tax = tv.id_tax
	WHEN MATCHED THEN
	UPDATE SET tv.updated_by=@id_user, tv.date_updated=getutcdate(), tv.active=@active
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_tax, id_vendor, active, created_by, updated_by) VALUES(vl.id_tax, vl.id_vendor, @active, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND tv.id_tax = @id_tax THEN
	UPDATE SET tv.active=0, tv.updated_by=@id_user, tv.date_updated=getutcdate()
	;

    ;WITH tax_group_list AS (
		SELECT @id_tax AS id_tax
			, id_tax_group
		FROM OPENJSON(@tax_group_list)
		WITH (
			  id_tax_group INT
		)
	)
	MERGE [tax].[group_value] AS tgv
	USING tax_group_list AS cl
	ON cl.id_tax_group = tgv.id_tax_group AND cl.id_tax = tgv.id_tax
	WHEN MATCHED THEN
	UPDATE SET tgv.updated_by=@id_user, tgv.date_updated=getutcdate(), tgv.active=@active
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_tax, id_tax_group, active, created_by, updated_by) VALUES(cl.id_tax, cl.id_tax_group, @active, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND tgv.id_tax = @id_tax THEN
	UPDATE SET tgv.active=0, tgv.updated_by=@id_user, tgv.date_updated=getutcdate()
	;
    
	EXEC [tax].[usp_get_tax_list] @id_tax
go

