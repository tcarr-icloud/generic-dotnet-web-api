CREATE PROCEDURE [order].[usp_customer_type_list]
	@id_customer_type INT = NULL,
	@deleted BIT = 0

	--DECLARE @id_customer_type INT = NULL

AS

	SELECT ct.id_customer_type
		, ct.[name] AS customer_type
	FROM [order].customer_type ct
	WHERE ct.id_customer_type = ISNULL(@id_customer_type, ct.id_customer_type) AND ct.deleted <= @deleted
	ORDER BY ct.[name]
go

