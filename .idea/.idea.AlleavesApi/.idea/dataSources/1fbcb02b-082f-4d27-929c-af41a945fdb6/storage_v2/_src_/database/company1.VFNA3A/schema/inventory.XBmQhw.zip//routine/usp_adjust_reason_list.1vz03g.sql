CREATE PROCEDURE [inventory].[usp_adjust_reason_list]
	@id_location BIGINT = NULL,
	@include_deleted BIT = 0
AS
	SELECT id_adjust_reason
			, name AS adjust_reason
			, system
			, adjust_reason_required
	FROM inventory.adjust_reason
	WHERE (@id_location IS NULL OR id_location = @id_location)
		OR id_location IS NULL
		AND (deleted IS NULL OR deleted <= @include_deleted)
	ORDER BY (CASE WHEN name = 'Other' THEN 1 ELSE 0 END)
go

