CREATE PROCEDURE [order].[usp_delivery_route_remove_ride]
	                    @id_delivery_route INT,
	                    @id_ride INT = NULL,
						@id_transfer INT = NULL
    AS
    BEGIN
	    IF (@id_ride IS NOT NULL)
	    BEGIN
	       DELETE [order].ride_delivery_route
	       WHERE id_delivery_route =@id_delivery_route
	       AND id_ride = @id_ride
		   update [order].ride_delivery_route set eta= null where id_delivery_route =@id_delivery_route
            UPDATE [order].ecommerce_ride SET id_driver = null
            WHERE id_ride = @id_ride
	    END
	    
	    IF (@id_transfer IS NOT NULL)
	    BEGIN
	       DELETE [order].ride_transfer_delivery_route
	       WHERE id_delivery_route =@id_delivery_route
	       AND id_transfer = @id_transfer
	       update [order].ride_transfer_delivery_route set eta= null where id_delivery_route =@id_delivery_route
	    END
    END
go

