CREATE PROCEDURE [base].[usp_dashboard_reporting_list_previous_wtd]

	AS
-- Create a temporary table that will be dropped at the end of this stored procedure to hold a list of customers that existed prior to the current time period.
CREATE TABLE #returnCustomerList (id_customer INT);

INSERT INTO #returnCustomerList (id_customer)
SELECT DISTINCT vwo.id_customer
FROM [order].[vw_orders] vwo
LEFT OUTER JOIN [base].[location] l ON vwo.id_location = l.id_location
LEFT OUTER JOIN dbo.tz_lookup AS tz ON l.timezone = tz.tz_iana
WHERE vwo.paid_in_full = 1 AND
    vwo.cancel = 0 AND
    vwo.void = 0 AND
    CAST(vwo.date_paid_order_local AS DATE) < DATEADD(WEEK, DATEDIFF(WEEK, 0, DATEADD(DAY, -1, GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows)) - 1, 0);

SELECT 
	aa.net_revenue/NULLIF(aa.total_tickets, 0) AS average_ticket_price,
	(aa.gross_revenue - aa.net_revenue)/aa.gross_revenue * 100 AS discount_rate_percentage,
	aa.gross_revenue/NULLIF(aa.units_sold, 0) AS average_unit_retail,
	aa.net_revenue/NULLIF(aa.units_sold, 0) AS average_unit_net_retail,
	aa.total_tickets,
	aa.total_customers,
	aa.new_customers,
	aa.total_customers-aa.new_customers AS returning_customers,
	aa.total_customers/NULLIF(aa.total_customers, 0) * 100 AS total_customers_percentage,
	(CAST(aa.new_customers AS DECIMAL)/NULLIF(aa.total_customers, 0)) * 100 AS new_customers_percentage,
	(aa.total_customers-aa.new_customers)/NULLIF(CAST(aa.total_customers AS DECIMAL), 0) * 100 AS returning_customers_percentage,
	aa.units_sold,
	aa.gross_revenue,
	aa.net_revenue,
	aa.units_per_transaction
FROM (
	SELECT
		(SUM(vwoi.quantity) / COUNT(DISTINCT vwo.id_order)) AS units_per_transaction,
		COUNT(DISTINCT vwo.id_order) AS total_tickets,
		COUNT(DISTINCT vwo.id_customer) AS total_customers,
		COUNT(DISTINCT CASE WHEN rcl.id_customer IS NULL THEN vwo.id_customer END) AS new_customers,
		SUM(vwoi.quantity) AS units_sold,
		SUM(vwoi.price_post_all_adjustments) as net_revenue,
		SUM(vwoi.price) AS gross_revenue
	FROM [order].[vw_orders] vwo
	LEFT JOIN [order].[vw_order_items] vwoi ON vwo.id_order = vwoi.id_order
	LEFT OUTER JOIN [base].[location] l on vwo.id_location = l.id_location
	LEFT OUTER JOIN [dbo].[tz_lookup] tz on l.timezone = tz.tz_iana
	LEFT OUTER JOIN #returnCustomerList rcl ON vwo.id_customer = rcl.id_customer
	WHERE 
		vwo.paid_in_full = 1 AND 
		vwo.cancel = 0 AND 
		vwo.void = 0 AND
		CAST(vwo.date_paid_order_local AS DATE) >= DATEADD(WEEK, DATEDIFF(WEEK, 0, DATEADD(DAY, -1, GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows)) - 1, 0) AND
		CAST(vwo.date_paid_order_local AS DATE) < DATEADD(WEEK, DATEDIFF(WEEK, 0, DATEADD(DAY, -1, GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows)), 0)
) aa

-- Drop the temporary table
DROP TABLE #returnCustomerList;

--TODO: CHANGE DATES
go

