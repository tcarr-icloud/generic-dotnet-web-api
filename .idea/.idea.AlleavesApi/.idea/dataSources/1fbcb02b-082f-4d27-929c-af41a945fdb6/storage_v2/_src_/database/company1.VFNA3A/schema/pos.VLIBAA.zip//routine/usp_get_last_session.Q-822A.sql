CREATE PROCEDURE pos.[usp_get_last_session] 
@id_register INT
AS 
SELECT [id_session]
      ,[id_register]
      ,[id_user_start]
      ,[balance_starting]
      ,[date_start]
      ,[id_user_end]
      ,[balance_ending]
      ,[date_end]
FROM [pos].[session]
WHERE id_session = (SELECT TOP 1 id_session FROM pos.[session] WHERE id_register = @id_register ORDER BY date_start DESC)
go

