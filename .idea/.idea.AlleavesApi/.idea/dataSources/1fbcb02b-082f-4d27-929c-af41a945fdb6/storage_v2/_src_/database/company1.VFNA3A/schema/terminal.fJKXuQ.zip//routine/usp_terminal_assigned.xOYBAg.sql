CREATE PROCEDURE terminal.usp_terminal_assigned
              @id_terminal INT = NULL
AS
BEGIN
	SELECT a.id_assignment,a.id_terminal,a.[secret],t.terminal_key
	FROM terminal.assignment a
	LEFT OUTER JOIN terminal.terminal t on a.id_terminal = t.id_terminal
	WHERE a.id_terminal = @id_terminal
END
go

