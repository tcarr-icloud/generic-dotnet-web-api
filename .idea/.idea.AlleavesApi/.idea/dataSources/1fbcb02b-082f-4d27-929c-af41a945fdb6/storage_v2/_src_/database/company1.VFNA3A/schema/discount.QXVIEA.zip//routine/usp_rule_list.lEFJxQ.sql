CREATE PROCEDURE [discount].[usp_rule_list]
	@enabled_only BIT = 0,
	@id INT
AS

SELECT 
    COALESCE(od.id_rule, id.id_rule) as id_rule, 
    COUNT(od.id_rule)+COUNT(id.id_rule) as use_count  
	INTO #use_count
FROM [order].[order] o
LEFT OUTER JOIN [order].[discount] od on od.id_order = o.id_order
LEFT OUTER JOIN [order].item_discount id on id.id_order = o.id_order
WHERE o.void = 0
GROUP BY COALESCE(od.id_rule, id.id_rule)

SELECT 
	[rules].id,
	[rules].[enabled],
	[rules].exclusive,
	[rules].title,
	[rules].title,
	[rules].[priority],
	COALESCE([rules].bundledFilters, [rules].filters) as bundledFilters,
	[rules].filters,
	[rules].conditions,
	NULLIF([rules].product_adjustments,'') as product_adjustments,
	NULLIF([rules].cart_adjustments,'') as cart_adjustments,
	NULLIF([rules].buy_x_get_x_adjustments,'') as buy_x_get_x_adjustments,
	NULLIF([rules].buy_x_get_y_adjustments,'') as buy_x_get_y_adjustments,
	NULLIF([rules].bulk_adjustments,'') as bulk_adjustments,
	NULLIF([rules].set_adjustments,'')as set_adjustments,
	NULLIF([rules].other_discounts,'')as other_discounts,
	[rules].dateFrom,
	[rules].dateTo,
	[rules].usageLimit,
	[rules].additional,
	[rules].max_discount_sum,
	NULLIF([rules].advance_discount_message,'') as advance_discount_message,
	[rules].discount_type,
	[rules].id_user_updated,
	[rules].createdAt,
	[rules].updatedAt,
	[rules].deletedAt,
	[rules].exclude_sales_items,
    [rules].discount_options,
	[rules].auto_apply,
	[rules].apply_pre_tax,
	[rules].apply_post_tax,
	[rules].promotion_code,
	ISNULL([uses].use_count,0) as use_count,
	CONCAT(ISNULL(uu.FirstName,''), ' ', ISNULL(uu.LastName,'')) as last_updated_by,
	[discountTypeDetails].[id]   AS [discountTypeDetails.id],
	[discountTypeDetails].[name] AS [discountTypeDetails.name],
	[discountTypeDetails].[columnName] AS [discountTypeDetails.columnName],
	[discountTypeDetails].[category] AS [discountTypeDetails.category]
FROM [discount].[rules] AS [rules]
LEFT OUTER JOIN [base].[user] uu on uu.id_user = [rules].id_user_updated
LEFT OUTER JOIN #use_count as uses on uses.id_rule = rules.id
LEFT OUTER JOIN [discount].[discount_types] AS [discountTypeDetails]
                         ON [rules].[discount_type] = [discountTypeDetails].[id] AND
                            ([discountTypeDetails].[deletedAt] IS NULL)
WHERE (
	[rules].[deletedAt] IS NULL
	AND rules.[enabled] >= @enabled_only
	AND @id IS NULL OR [rules].id=@id
)
ORDER BY [rules].[priority] DESC
go

