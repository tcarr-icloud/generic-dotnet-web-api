CREATE PROCEDURE [dbo].[usp_user_lookup_deactivate]
	@id_user_lookup INT = NULL,
	@email VARCHAR(MAX) = NULL
AS
	IF (@id_user_lookup IS NULL AND @email IS NULL) RETURN

	UPDATE dbo.user_lookup
	SET active=0
		, date_updated=GETUTCDATE()
	WHERE (@id_user_lookup IS NOT NULL AND id_user_lookup=@id_user_lookup) OR
		  (@email IS NOT NULL AND LOWER(email)=LOWER(@email))
go

