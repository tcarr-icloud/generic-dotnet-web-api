
-- =============================================
-- Author:		Name
-- Create date: 
-- Description:	
-- =============================================
CREATE FUNCTION [order].[fn_order_item_discount_json]
(
	@id_order INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result VARCHAR(MAX)

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = ISNULL((SELECT * FROM [order].fn_order_item_discount(@id_order) FOR JSON PATH, INCLUDE_NULL_VALUES),'[]')

	-- Return the result of the function
	RETURN @Result

END
go

