CREATE PROCEDURE base.usp_user_api_create
	@id_user VARCHAR(256),
	@alleaves_api_key VARCHAR(256)
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO base.user_api (id_user, alleaves_api_key) Values (@id_user,@alleaves_api_key)
	DECLARE @id_user_api INT = SCOPE_IDENTITY()
	EXEC base.usp_user_api_list @id_user=@id_user_api
END
go

