CREATE PROCEDURE [inventory].[usp_inventory_adjust]
	@id_adjust_reason INT,
	@adjust_reason VARCHAR(MAX) = NULL,
	@list VARCHAR(MAX) = '[]',
	@id_user INT,
	@is_biotrack BIT = 0
AS
	SET NOCOUNT ON;

	/* get adjust reason text. */
	DECLARE @notes VARCHAR(MAX)
	SET @notes = (SELECT name FROM inventory.adjust_reason WHERE id_adjust_reason=@id_adjust_reason)
	IF @is_biotrack = 1
	BEGIN
		SET @notes = (SELECT name FROM biotrack.adjust_reason WHERE id_adjust_reason=@id_adjust_reason)
	END

	IF(@adjust_reason IS NOT NULL)
		SET @notes = CONCAT(@notes, '; ', @adjust_reason)

	/* loop through batch list and update inventory. */
	DECLARE @id_batch INT, 
			@id_area INT,
			@adjustment DECIMAL(18,4)

	DECLARE item_cursor CURSOR FAST_FORWARD FOR 
	SELECT * FROM OPENJSON(@list)
	WITH (
		id_batch INT,
		id_area INT,
		adjustment DECIMAL(18,4)
	)
	WHERE adjustment<>0
		
	OPEN item_cursor
	FETCH NEXT FROM item_cursor INTO @id_batch, @id_area, @adjustment
		
	WHILE(@@FETCH_STATUS = 0)
	BEGIN
		/* update item quantity. */
		EXEC [log].usp_event_create 'inventory_adjust', @id_batch, @id_area, @adjustment, @notes, @id_user, 1

		FETCH NEXT FROM item_cursor INTO @id_batch, @id_area, @adjustment
	END

	CLOSE item_cursor
	DEALLOCATE item_cursor

	/* create move log. */
go

