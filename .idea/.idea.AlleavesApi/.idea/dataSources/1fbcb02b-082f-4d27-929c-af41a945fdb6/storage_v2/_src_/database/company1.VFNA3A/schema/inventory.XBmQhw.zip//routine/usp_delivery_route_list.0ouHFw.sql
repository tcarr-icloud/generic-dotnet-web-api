CREATE PROCEDURE [inventory].[usp_delivery_route_list]
@route_version TINYINT = 1
AS

IF(@route_version = 1)
BEGIN
	SELECT * FROM inventory.vw_delivery_route
	ORDER BY delivery_route_path
END

IF(@route_version = 2)
BEGIN
	SELECT
		id_delivery_route,
		[name] as [route],
		biotrack_invtype_id,
		[route_version]
	FROM inventory.delivery_route
	WHERE route_version = 2
END
go

