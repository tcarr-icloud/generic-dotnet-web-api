--WARNING! ERRORS ENCOUNTERED DURING SQL PARSING!
CREATE PROCEDURE [order].usp_receipt_audit_list
AS
SELECT *
FROM [order].receipt_audit
go

