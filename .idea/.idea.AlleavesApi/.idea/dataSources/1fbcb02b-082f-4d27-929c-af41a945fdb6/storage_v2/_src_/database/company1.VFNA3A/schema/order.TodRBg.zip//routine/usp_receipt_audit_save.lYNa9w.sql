
CREATE PROCEDURE [order].[usp_receipt_audit_save] @id_order INT
	,@verified BIT
AS
MERGE [order].receipt_audit AS t
USING (
	SELECT @id_order AS id_order
		,@verified AS verified
	) AS s
	ON t.id_order = s.id_order
	WHEN NOT MATCHED THEN INSERT (id_order, verified)
	VALUES (s.id_order, s.verified)
	WHEN MATCHED THEN UPDATE 
	SET t.verified = s.verified;

SELECT * FROM [order].receipt_audit WHERE id_order = @id_order
go

