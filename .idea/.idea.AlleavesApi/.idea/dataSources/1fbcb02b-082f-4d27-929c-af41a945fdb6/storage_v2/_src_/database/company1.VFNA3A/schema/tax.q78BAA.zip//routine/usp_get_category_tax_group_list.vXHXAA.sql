CREATE PROCEDURE [tax].[usp_get_category_tax_group_list]
	@id_tax_category INT = NULL
AS
	SELECT clg.id_tax_category,
		tc.[name] as tax_category,
		clg.id_tax_group,
		tg.[name] as tax_group,
		ISNULL((
			SELECT
				tt.[name] as tax_name,
				tt.percentage,
				tt.is_cannabis,
				tt.is_non_cannabis,
				tt.is_excise_tax,
				tt.is_state_tax,
				tt.is_local_tax,
				tt.is_adult_use,
				tt.is_medical_use,
				tt.is_arms_length,
				tt.is_gross_tax,
				tt.markup_rate,
				tt.stacking_order,
				ISNULL((
					SELECT tv.id_vendor,
						iv.name as vendor
					FROM [tax].[vendor] tv
					LEFT JOIN [inventory].[vendor] iv ON iv.id_vendor=tv.id_vendor
					WHERE tv.id_tax=tt.id_tax AND tv.active=1
				FOR JSON PATH), '[]') as vendor_list
			FROM [tax].[group_value] tgv
			LEFT JOIN [tax].[tax] tt ON tt.id_tax = tgv.id_tax
			WHERE tgv.id_tax_group=clg.id_tax_group AND tgv.active = 1 AND tt.active = 1
			ORDER BY tt.stacking_order, tt.[name]
		FOR JSON PATH), '[]') as tax_list
	FROM [tax].[category_group] clg
	LEFT JOIN [tax].[category] tc ON tc.id_tax_category = clg.id_tax_category
	LEFT JOIN [tax].[group] tg ON tg.id_tax_group = clg.id_tax_group
	WHERE (@id_tax_category IS NULL OR clg.id_tax_category = @id_tax_category) AND clg.active=1 AND tc.active=1 AND tg.active=1
	ORDER BY clg.id_tax_category
go

