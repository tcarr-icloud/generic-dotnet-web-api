CREATE PROCEDURE [pos].[usp_latest_email_receipt]
AS
BEGIN
	SET NOCOUNT ON;
SELECT TOP 1 email_header,
	      email_footer,
		  email_subject,
		  email_logo,
	       email_template,
	       id_user_created_by
	FROM pos.email_receipt WHERE deleted = 0 ORDER BY id_email_receipt DESC;
END
go

