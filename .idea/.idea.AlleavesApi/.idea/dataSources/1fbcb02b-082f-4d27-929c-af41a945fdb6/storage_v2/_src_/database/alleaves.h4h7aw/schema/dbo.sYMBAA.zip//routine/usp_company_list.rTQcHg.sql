CREATE PROCEDURE [dbo].[usp_company_list]
	@id_company INT = NULL
AS
	SELECT id_company
			, name AS company
			, reference
			, workspace
			, is_move_client
			, db_host
			, db_user
			, db_password
			, db_port
	FROM dbo.company
	WHERE id_company=ISNULL(@id_company, id_company) AND
		  active=1
go

