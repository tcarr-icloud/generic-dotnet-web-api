CREATE PROCEDURE [grow].[usp_harvest_trim_cancel]
	@id_harvest INT
AS
	DECLARE @msg VARCHAR(MAX)

	IF (SELECT date_trim_end FROM grow.harvest WHERE id_harvest=@id_harvest) IS NOT NULL
	BEGIN
		SET @msg = 'Cannot cancel a trim for a harvest that has already been completed.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	UPDATE grow.harvest
	SET date_trim_start=NULL
		, id_user_trim_start=NULL
	WHERE id_harvest=@id_harvest
	

	EXEC grow.usp_harvest_fetch @id_harvest
go

