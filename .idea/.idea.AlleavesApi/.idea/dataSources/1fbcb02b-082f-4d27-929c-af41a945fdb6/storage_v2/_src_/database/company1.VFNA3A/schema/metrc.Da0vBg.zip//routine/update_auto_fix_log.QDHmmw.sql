CREATE PROCEDURE [metrc].[update_auto_fix_log]
    @id_log INT,
    @id_order INT = NULL,
    @raw_response VARCHAR(MAX) = NULL,
    @status VARCHAR(100) = NULL
AS
    UPDATE [metrc].[auto_fix_log]
	SET id_order = ISNULL(@id_order, id_order)
		, raw_response = ISNULL(@raw_response, raw_response)
  		, status = ISNULL(@status, status)
		, updated_at = GETUTCDATE()
	WHERE id_log=@id_log
go

