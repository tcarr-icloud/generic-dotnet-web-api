CREATE PROCEDURE [cash].[usp_safe_upsert]
	@id_location INT = NULL,
	@id_safe INT = NULL,
	@name VARCHAR(512),
	@amount DECIMAL(18,2) = 0.00,
	@id_user INT,
	@deleted BIT = 0

AS
	IF EXISTS (SELECT * FROM cash.safe WHERE deleted=0 AND @deleted<>1 AND name=@name AND (@id_safe IS NULL OR id_safe<>@id_safe) AND id_location=@id_location)
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A safe with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	/* add new safe. */
	IF (@id_safe IS NULL) 
	BEGIN
		INSERT INTO [cash].[safe] (id_location, name, amount, id_user_created, id_user_updated) 
		VALUES (@id_location, @name, @amount, @id_user, @id_user)

		SET @id_safe=SCOPE_IDENTITY()
	END
	/* update safe. */
	ELSE
	BEGIN
		UPDATE [cash].[safe]
		SET name=@name
			, amount=@amount
			, id_location=@id_location
			, deleted=@deleted
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_safe=@id_safe
	END
	
	/* return updated/created safe. */
	EXEC [cash].[usp_safe_list] @id_location, @id_safe, 1
go

