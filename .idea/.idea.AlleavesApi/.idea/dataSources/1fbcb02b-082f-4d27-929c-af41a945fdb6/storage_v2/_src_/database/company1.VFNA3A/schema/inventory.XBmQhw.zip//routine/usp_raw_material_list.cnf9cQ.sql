CREATE PROCEDURE [inventory].[usp_raw_material_list]
	@id_raw_material INT = NULL,
	@include_deleted BIT = 0
AS
	SELECT id_raw_material
			, name AS raw_material
			, is_harvest_output
			, CAST(CASE WHEN is_harvest_output=1 AND harvest_output_wet=0 AND harvest_output_dry=0 AND harvest_output_waste=0 THEN 1 ELSE harvest_output_wet END AS BIT) AS harvest_output_wet
			, harvest_output_dry
			, harvest_output_waste
			, deleted
	FROM inventory.raw_material 
	WHERE (@id_raw_material IS NULL OR id_raw_material=@id_raw_material) AND
			deleted <= @include_deleted
	ORDER BY name
go

