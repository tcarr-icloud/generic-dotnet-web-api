CREATE PROCEDURE [grow].[usp_plant_move_list]
	@id_location INT = NULL,
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
	SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = '	
	SELECT * FROM (
		SELECT m.id_plant_move
				, l.id_location
				, m.id_area_from
				, m.id_area_to
				, l.name AS location
				, af.path AS area_from
				, ad.path AS area_to
				, COUNT(mi.id_plant_move_item) AS num_plants
				, m.date_created
		FROM grow.plant_move m
		JOIN inventory.vw_area_list af ON af.id_area=m.id_area_from
		JOIN inventory.vw_area_list ad ON ad.id_area=m.id_area_to
		JOIN grow.plant_move_item mi ON mi.id_plant_move=m.id_plant_move
		JOIN base.location l ON l.id_location=af.id_location
		GROUP BY m.id_plant_move, l.id_location, m.id_area_from, m.id_area_to, l.name, af.path, ad.path, m.date_created
	) p'

	SET @where = 'WHERE id_location = '+ ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location')
	

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'id_plant_move')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DROP TABLE IF EXISTS #plant_move_list;
	SELECT * INTO #plant_move_list FROM ('+@base_sql+') t;

	SELECT 
		*, 
		(SELECT COUNT(1) FROM #plant_move_list) AS total_rows
	FROM #plant_move_list t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

