CREATE PROCEDURE [order].[usp_customer_type_create]
	@name VARCHAR(512)

AS
	IF EXISTS (SELECT * FROM [order].customer_type WHERE deleted=0 AND name=@name)
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A customer type with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	INSERT INTO [order].customer_type ([name]) VALUES (@name)

	DECLARE @id_customer_type INT = SCOPE_IDENTITY()

	EXEC [order].usp_customer_type_list @id_customer_type
go

