CREATE PROCEDURE [inventory].[usp_category_image_update]
	@id_category_image INT,
	@name varchar(256),
	@image_path varchar(256),
	@deleted BIT = 0,
	@id_user INT
AS
	BEGIN
		UPDATE [inventory].[category_image]
		SET name=@name
			, image_path=@image_path
			, deleted=@deleted
			, id_user_modified_by=@id_user

		WHERE id_category_image=@id_category_image
	END

	EXEC inventory.usp_category_image_list @id_category_image
go

