CREATE PROCEDURE external_blaze.usp_update_already_existed_customer
	@first_name VARCHAR(200) = NULL,
	@last_name VARCHAR(200) = NULL,
	@dob VARCHAR(200) = NULL,
	@patient_number VARCHAR(200) = NULL,
	@apt_unit VARCHAR(200) = NULL,
	@street VARCHAR(200) = NULL,
	@state VARCHAR(200) = NULL,
	@city VARCHAR(200) = NULL,
	@zip VARCHAR(200) = NULL,
	@primary_phone VARCHAR(200) = NULL,
	@phone VARCHAR(200)= NULL ,
	@email VARCHAR(200) = NULL,
	@driver_license VARCHAR(200) = NULL,
	@driver_license_state VARCHAR(200) = NULL,
	@passport VARCHAR(200) = NULL,
	@physician VARCHAR(200) = NULL,
	@caregiver VARCHAR(200) = NULL,
	@referral_method VARCHAR(200) = NULL,
	@customer_type VARCHAR(200) = NULL,
	@other VARCHAR(200)= NULL,
	@id_member VARCHAR(200)
AS
BEGIN
    UPDATE external_blaze.customer SET first_name=@first_name , last_Name = @last_name , dob = @dob , patient_number =@patient_number
    , apt_unit = @apt_unit , street = @street , state = @state , city = @city ,
          zip = @zip , primary_phone = @primary_phone , phone = @phone , email = @email
      , driver_license = @driver_license , drivers_license_state = @driver_license_state , passport = @passport
      , physician = @physician , caregiver = @caregiver , referral_method = @referral_method
      , customer_type = @customer_type , other = @other where id_member =@id_member
end
go

