CREATE PROCEDURE [order].[usp_delivery_route_by_id]
	@id_delivery_route INT = NULL,
	@id_driver INT = NULL
AS
    SELECT dr.id_driver,u.id_user, u.FirstName AS name_first, u.LastName AS name_last, dr.id_driver, dr.delivery_start_date,
	status, dr.delivery_start_time,dr.id_delivery_route,dr.delivery_end_eta,
           ISNULL((SELECT rdr.id_ride as id_ride_id,rdr.position, er.*,
                 a.address1
				,a.address2
				,a.city
				,a.[state]
				,a.zip
				,a.zip_four
				,a.note
				,a.id_driver1
				,a.id_vehicle
			    ,a.lat
			    ,a.long,
				ISNULL((select s.driver_message from [order].ecommerce_ride_status s
				INNER JOIN [order].ecommerce_ride_status_history h on s.id_status=h.id_ride_status where h.id_status_history=
				(select top 1 id_status_history from [order].[ecommerce_ride_status_history] h where h.id_ride=er.id_ride order by id_status_history desc)),null) as ride_status
                FROM [order].ride_delivery_route rdr
               INNER JOIN [order].ecommerce_ride er ON rdr.id_ride = er.id_ride
               INNER JOIN [order].address a ON er.id_order = a.id_order			   
               WHERE dr.id_delivery_route = rdr.id_delivery_route  
               ORDER BY rdr.position
               FOR JSON PATH),'[]') AS ride_list
    FROM [order].delivery_route dr
	LEFT JOIN [order].driver d ON d.id_driver=dr.id_driver
	LEFT JOIN [base].[user] u on u.id_user = d.id_user
    WHERE dr.id_delivery_route = ISNULL(@id_delivery_route,dr.id_delivery_route) 
   ORDER BY dr.id_delivery_route DESC
go

