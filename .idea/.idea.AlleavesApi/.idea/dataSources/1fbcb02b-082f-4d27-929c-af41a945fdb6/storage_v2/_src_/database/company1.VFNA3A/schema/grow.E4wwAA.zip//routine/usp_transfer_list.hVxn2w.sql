CREATE PROCEDURE [grow].[usp_transfer_list]
	@id_transfer BIGINT = NULL,
	@id_location INT = NULL,	
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
   
	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = '	
	SELECT * FROM (
		SELECT t.id_transfer
				, t.id_location_source
				, t.id_vendor_source
				, t.id_location_destination
				, t.id_vendor_destination
				, ISNULL(sl.name, sv.name) AS source_name
				, ISNULL(dl.name, dv.name) AS destination_name
				, t.source_address
				, t.source_city
				, t.source_state
				, t.source_postal_code
				, t.recipient
				, t.destination_address
				, t.destination_city
				, t.destination_state
				, t.destination_postal_code
				, t.received
				, t.date_received
				, t.cancelled
				, t.date_cancelled
				, sta.id_transfer_status
				, sta.date_verified
				, sta.status
				, sta.status_reference
				, t.date_created
				, t.date_updated
		FROM grow.transfer t
		LEFT JOIN base.location sl ON sl.id_location=t.id_location_source
		LEFT JOIN base.location dl ON dl.id_location=t.id_location_destination
		LEFT JOIN inventory.vendor sv ON sv.id_vendor=t.id_vendor_source
		LEFT JOIN inventory.vendor dv ON dv.id_vendor=t.id_vendor_destination
		LEFT JOIN (
			SELECT tsh.id_transfer
					, tsh.id_transfer_status
					, tsh.date_verified
					, st.name AS status
					, st.reference AS status_reference
			FROM (
				SELECT id_transfer, MAX(date_verified) AS date_verified
				FROM grow.transfer_status_history
				GROUP BY id_transfer
			) ts
			JOIN grow.transfer_status_history tsh ON tsh.id_transfer=ts.id_transfer AND tsh.date_verified=ts.date_verified
			JOIN grow.transfer_status st ON st.id_transfer_status=tsh.id_transfer_status
		) sta ON sta.id_transfer=t.id_transfer
	) transfer
	'

	SET @where = 'WHERE (id_location_source = ' + ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location_source')
	SET @where = @where + ' OR id_location_destination = ' + ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location_destination') + ')'
	SET @where = @where + ' AND id_transfer = ' + ISNULL(CAST(@id_transfer AS VARCHAR(16)), 'id_transfer')
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'id_transfer')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DROP TABLE IF EXISTS #transfer_list
	SELECT * INTO #transfer_list FROM ('+@base_sql+') t;

	SELECT 
		*, 
		(SELECT COUNT(1) FROM #transfer_list) AS total_rows
	FROM #transfer_list t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

