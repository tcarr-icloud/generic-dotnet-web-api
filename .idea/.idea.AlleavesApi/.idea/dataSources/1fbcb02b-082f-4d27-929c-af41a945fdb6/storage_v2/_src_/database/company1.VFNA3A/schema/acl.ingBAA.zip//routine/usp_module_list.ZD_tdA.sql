CREATE PROCEDURE [acl].[usp_module_list]
AS
	SELECT id_module
			, name AS module
	FROM acl.module
go

