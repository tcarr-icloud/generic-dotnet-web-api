CREATE PROCEDURE [grow].[usp_batch_history_list]
	@id_plant INT = NULL,
	@id_batch INT = NULL
AS
	SELECT p.id_plant
			, b.id_batch
			, i.id_item
			, g.id_item_group
			, p.name AS plant
			, RTRIM(CONCAT(g.name, ' ', (
				SELECT STRING_AGG(av.name, ' ') 
				FROM inventory.item_attribute_value iav
				LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
				WHERE iav.id_item=i.id_item)
			)) AS item
			, b.name AS batch
			, ISNULL(b.date_production, b.date_created) AS date_production
	FROM grow.plant p
	JOIN grow.batch_plant bp ON bp.id_plant=p.id_plant
	JOIN inventory.batch b ON b.id_batch=bp.id_batch
	JOIN inventory.item i ON i.id_item=b.id_item
	JOIN inventory.item_group g ON g.id_item_group=i.id_item_group
	JOIN inventory.status s ON s.id_status=b.id_status
	WHERE (@id_plant IS NULL OR p.id_plant=@id_plant) AND 
		  (@id_batch IS NULL OR b.id_batch=@id_batch)
go

