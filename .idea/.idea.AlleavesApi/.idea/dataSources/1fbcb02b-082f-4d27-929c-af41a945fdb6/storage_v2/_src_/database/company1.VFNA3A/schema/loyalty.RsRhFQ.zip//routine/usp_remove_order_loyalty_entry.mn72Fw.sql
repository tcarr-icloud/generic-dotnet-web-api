create procedure loyalty.usp_remove_order_loyalty_entry @id_loyalty_order int
AS

    declare @id_order int = (select id_order from loyalty.[order]
where id_loyalty_order = @id_loyalty_order)
delete
from loyalty.[order]
where id_loyalty_order = @id_loyalty_order;
go

