CREATE PROCEDURE [grow].[usp_plant_create]
	@num_plants INT,
	@id_strain BIGINT,
	@is_medical BIT = NULL,
	@is_adult BIT = NULL,
	@source VARCHAR(64),
	@inventory_id_batch INT = NULL,
	@inventory_id_area INT = NULL,
	@id_area BIGINT,
	@id_mother BIGINT = NULL,
	@is_mother BIT = 0,
	@date_seedling DATE = NULL,
	@date_germination DATE = NULL,
	@date_vegetative DATE = NULL,
	@date_preflower DATE = NULL,
	@date_flower DATE = NULL,
	@id_user VARCHAR(128)
AS
	SET NOCOUNT ON

	DECLARE @id_location INT = (SELECT TOP 1 id_location FROM inventory.area WHERE id_area=@id_area),
			@id_plant BIGINT,
		    @plant_name VARCHAR(32)

	/* build base plant name. ----------------------------------- */
	DECLARE @curr_date DATE = COALESCE(@date_seedling, @date_germination, @date_vegetative, @date_preflower, @date_flower, GETUTCDATE())

	DECLARE @year VARCHAR(4) = YEAR(@curr_date),
			@date VARCHAR(4) = CONCAT(RIGHT('00'+CAST(MONTH(@curr_date) AS VARCHAR(2)), 2), RIGHT('00'+CAST(DAY(@curr_date) AS VARCHAR(2)), 2)),
			@sequ VARCHAR(8),
			@num INT


	/* get most recent plant. */
	DECLARE @curr VARCHAR(32) = (SELECT MAX(name) FROM grow.plant WHERE name LIKE CONCAT('P', @year, @date, '%'))
	
	/* set sequence number. */
	SET @sequ = CASE WHEN @curr IS NULL THEN '00000000' ELSE RIGHT(@curr, 8) END
	SET @num = @sequ + 1

	/* get table of available grid spaces. --------------------------------------- */
	;WITH grid ([row], [column], sequence) AS (
		SELECT b.[row], a.[column], ROW_NUMBER() OVER(ORDER BY b.[row] ASC) + @num - 1 AS sequence
		FROM (
			SELECT [column] = number 
			FROM master..[spt_values] 
			WHERE type='P' AND number BETWEEN 1 AND (SELECT columns FROM inventory.area WHERE id_area=@id_area)
		) a
		CROSS JOIN (
			SELECT [row] = number 
			FROM master..[spt_values] 
			WHERE type='P' AND number BETWEEN 1 AND (SELECT rows FROM inventory.area WHERE id_area=@id_area)
		) b
		LEFT JOIN grow.plant p ON p.[row]=b.[row] AND 
								  p.[column]=a.[column] AND 
								  p.harvested = 0 AND
								  p.destroyed = 0 AND
								  p.id_area=@id_area
		WHERE p.id_plant IS NULL
	)

	/* insert new plants -----------------------------------------. */
	INSERT INTO grow.plant (name, id_strain, source, id_batch_planted, id_mother, is_mother, id_area, row, [column], date_seedling, date_germination, date_vegetative, date_preflower, date_flower, is_medical, is_adult, id_user_created, id_user_updated) 
	SELECT CONCAT('P', @year, @date, RIGHT('00000000' + CONVERT(VARCHAR(32), s.sequence), 8)) AS name
			, @id_strain AS id_strain
			, @source AS source
			, @inventory_id_batch AS id_batch_planted
			, @id_mother AS id_mother
			, @is_mother AS is_mother
			, @id_area AS id_area
			, g.[row] AS [row]
			, g.[column] AS [column]
			, @date_seedling AS date_seedling
			, @date_germination AS date_germination
			, @date_vegetative AS date_vegetative
			, @date_preflower AS date_preflower
			, @date_flower AS date_flower
			, @is_medical AS is_medical
			, @is_adult AS is_adult
			, @id_user AS id_user_created
			, @id_user AS id_user_updated
	FROM (
		SELECT sequence = number 
		FROM master..[spt_values] 
		WHERE type='P' AND number BETWEEN @num AND @num+@num_plants-1
	) s
	LEFT JOIN grid g ON g.sequence=s.sequence

	/* get created plants. */
	DROP TABLE IF EXISTS #plant_list
	SELECT * INTO #plant_list FROM (
		SELECT p.id_plant
				, s.id_strain
				, st.id_strain_type
				, l.id_location
				, a.id_area
				, p.id_mother
				, l.name AS location
				, p.name AS plant
				, p.source
				, s.name AS strain
				, st.name AS strain_type
				, CAST(ph.date_birth AS VARCHAR(16)) AS date_birth
				, ph.phase_current
				, CAST(ph.phase_current_date AS VARCHAR(16)) AS phase_current_date
				, (CASE WHEN ph.phase_current_date IS NOT NULL THEN DATEDIFF(day, ph.phase_current_date, GETUTCDATE()) ELSE NULL END) AS phase_current_days
				, p.date_seedling
				, p.date_germination
				, p.date_vegetative
				, p.date_preflower
				, p.date_flower
				, p.date_harvest
				, p.harvested
				, p.destroyed
				, a.name AS area
				, a.path AS area_path
				, p.[row]
				, p.[column]
				, p.is_mother
				, m.name AS mother
				, m.metrc_batch AS mother_metrc_batch
				, m.metrc_label AS mother_metrc_label
				, ms.name AS mother_strain
		FROM grow.plant p
		JOIN grow.strain s ON s.id_strain=p.id_strain
		JOIN grow.strain_type st ON st.id_strain_type=s.id_strain_type
		LEFT JOIN grow.plant m ON m.id_plant=p.id_mother
		LEFT JOIN grow.strain ms ON ms.id_strain=m.id_strain
		LEFT JOIN inventory.vw_area_list a ON a.id_area=p.id_area
		LEFT JOIN base.location l ON l.id_location=a.id_location	
		JOIN (
			SELECT id_plant
					, CASE WHEN harvested = 1 THEN 'Harvested'
							WHEN date_flower IS NOT NULL THEN 'Flowering'
							WHEN date_preflower IS NOT NULL THEN 'Pre-Flowering'
							WHEN date_vegetative IS NOT NULL THEN 'Vegetative'
							WHEN date_germination IS NOT NULL THEN 'Germination'
							WHEN date_seedling IS NOT NULL THEN 'Seedling'
							ELSE NULL END AS phase_current
					, CASE WHEN harvested = 1 THEN NULL
							ELSE COALESCE(date_flower, date_preflower, date_vegetative, date_germination, date_seedling) END 
						AS phase_current_date
					, COALESCE(date_seedling, date_germination, date_vegetative, date_preflower, date_flower) AS date_birth
			FROM grow.plant
		) ph ON ph.id_plant=p.id_plant
	) plant
	WHERE plant BETWEEN CONCAT('P', @year, @date, RIGHT('00000000' + CONVERT(VARCHAR(32), @num), 8)) AND CONCAT('P', @year, @date, RIGHT('00000000' + CONVERT(VARCHAR(32), @num+@num_plants-1), 8))

	/* consume inventory, if applicable -----------------------------------------. */
	IF @inventory_id_batch IS NOT NULL AND @inventory_id_area IS NOT NULL
	BEGIN
		IF @num_plants > (SELECT TOP 1 quantity FROM inventory.inventory WHERE id_batch=@inventory_id_batch AND id_area=@inventory_id_area)
		BEGIN
			RAISERROR('Cannot use more inventory than is available', 11, 1)
			RETURN
		END

		DECLARE @plant_consume_quantity DECIMAL(18,4) = -@num_plants
		EXEC [log].usp_event_create 'plant_cultivate', @inventory_id_batch, @inventory_id_area, @plant_consume_quantity, NULL, @id_user
	END

	/* add events. */
	DECLARE @create_notes VARCHAR(MAX) = CASE WHEN @id_mother IS NOT NULL THEN CONCAT('Cloned from ', (SELECT TOP 1 name FROM grow.plant WHERE id_plant=@id_plant)) ELSE 'Planted' END,
			@phase_notes VARCHAR(MAX) = CONCAT('Changed to '
							, CASE WHEN @date_flower IS NOT NULL THEN 'Flowering'
										  WHEN @date_preflower IS NOT NULL THEN 'Pre-Flowering'
										  WHEN @date_vegetative IS NOT NULL THEN 'Vegetative'
										  WHEN @date_germination IS NOT NULL THEN 'Germination'
										  ELSE 'Seedling' END
							, ' on ', 
							COALESCE(@date_flower, @date_preflower, @date_vegetative, @date_germination, @date_seedling))

	DECLARE @list_create VARCHAR(MAX) = (SELECT id_plant, id_area, [row], [column], @create_notes AS notes FROM #plant_list FOR JSON PATH),
			@list_phase VARCHAR(MAX) = (SELECT id_plant, id_area, [row], [column], @phase_notes AS notes FROM #plant_list FOR JSON PATH)

	EXEC grow.usp_event_create_bulk 'create', NULL, NULL, NULL, NULL, @list_create, @id_user
	EXEC grow.usp_event_create_bulk 'phase_change', NULL, NULL, NULL, NULL, @list_phase, @id_user
			
	/* return created plants. */
	SELECT * FROM #plant_list
go

