CREATE PROCEDURE [inventory].[usp_category_image_list] 
	@id_category_image INT = NULL
AS
	SET NOCOUNT ON;
	SELECT id_category_image,
	       name AS image,
	       image_path,
		   deleted,
	       id_user_created_by
	FROM inventory.category_image
	WHERE id_category_image = ISNULL(@id_category_image, id_category_image)
	ORDER BY image
go

