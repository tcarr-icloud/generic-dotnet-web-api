CREATE PROCEDURE [grow].[usp_harvest_dry_start]
	@id_strain INT,
	@id_location INT,
	@id_area INT,
	@weight_total_g DECIMAL(18,4),
	@weight_wet_g DECIMAL(18,4),
	@weight_wet_waste_g DECIMAL(18,4),
	@plant_list VARCHAR(MAX) = '[]',
	@id_user INT,
	@is_manicure BIT = 0
AS
	SET NOCOUNT ON

	DECLARE @id_harvest INT
	DECLARE @id_phase_harvested INT = (SELECT id_phase FROM grow.phase WHERE name='Harvested')
	DECLARE @id_item INT
	DECLARE @quantity DECIMAL(18,4)
	DECLARE @id_batch INT
	DECLARE @notes VARCHAR(512)
	DECLARE @is_wet BIT, @is_waste BIT

	/* create new harvest. */
	INSERT INTO grow.harvest (id_strain, id_location, id_area_dry, weight_total_g, weight_wet_g, weight_wet_waste_g, id_user_created, is_manicure) 
	VALUES (@id_strain, @id_location, @id_area, @weight_total_g, @weight_wet_g, @weight_wet_waste_g, @id_user, @is_manicure)
	
	SET @id_harvest = SCOPE_IDENTITY()


	/* update plant phases to harvested. */
	IF @is_manicure=0
	BEGIN
		UPDATE p
		SET p.harvested=1
			, p.id_harvest=@id_harvest
			, p.date_harvest=getutcdate()
			, p.date_updated=getutcdate()
			, p.id_user_updated=@id_user
			, p.harvest_weight_g=l.weight_g
		FROM grow.plant p
		JOIN (
			SELECT * FROM OPENJSON(@plant_list)
			WITH (
				id_plant INT,
				weight_g DECIMAL(18,4)
			)
		) l ON l.id_plant=p.id_plant
	END
	ELSE
	BEGIN
		UPDATE p
		SET	
			p.id_user_updated=@id_user,
			p.id_manicure_list = CASE
									WHEN p.id_manicure_list IS NULL THEN CAST(@id_harvest AS VARCHAR(MAX))
									ELSE p.id_manicure_list + ',' + CAST(@id_harvest AS VARCHAR(MAX))
								END
		FROM grow.plant p
		JOIN (
			SELECT * FROM OPENJSON(@plant_list)
			WITH (
				id_plant INT,
				weight_g DECIMAL(18,4)
			)
		) l ON l.id_plant=p.id_plant
	END

	/* add barcode to all harvests that are missing one. */
	UPDATE grow.harvest
	SET name = grow.fn_generate_harvest_barcode(id_harvest)
	WHERE name IS NULL OR name <> grow.fn_generate_harvest_barcode(id_harvest)


	/* add plant log event. */
	DECLARE @list VARCHAR(MAX) = (
					SELECT id_plant
							, id_area
							, [row]
							, [column]
					FROM grow.plant
					WHERE id_plant IN (SELECT x.id_plant FROM OPENJSON(@plant_list) WITH (id_plant INT) x)
					FOR JSON PATH)

	IF @is_manicure=0
	BEGIN
		EXEC grow.usp_event_create_bulk 'harvest', NULL, NULL, NULL, @notes, @list, @id_user
	END
	ELSE
	BEGIN
		EXEC grow.usp_event_create_bulk 'manicure', NULL, NULL, NULL, @notes, @list, @id_user
	END
	


	/* return newly created harvest. */
	EXEC grow.usp_harvest_fetch @id_harvest
go

