CREATE PROCEDURE [order].[usp_note_upsert]
	@id_note INT = NULL,
	@id_order INT,
	@note VARCHAR(MAX),
	@deleted BIT = 0,
	@id_user INT
AS
	IF(@id_note IS NULL)
	BEGIN
		INSERT INTO [order].note (id_order, note, created_by, updated_by) VALUES (@id_order, @note, @id_user, @id_user)

		SET @id_note=SCOPE_IDENTITY()
	END
	ELSE
		UPDATE [order].note SET note=@note, deleted=@deleted
		WHERE id_note=@id_note


	SELECT n.id_note
			, n.note
			, CASE WHEN n.created_by=-1 THEN 'System' ELSE uc.FirstName+' '+uc.LastName END AS created_by
			, CASE WHEN n.updated_by=-1 THEN 'System' ELSE uu.FirstName+' '+uu.LastName END AS updated_by
			, n.date_created
			, n.date_updated
	FROM [order].note n
	LEFT JOIN base.[user] uc ON uc.id_user=n.created_by
	LEFT JOIN base.[user] uu ON uu.id_user=n.updated_by 
	WHERE n.id_note=@id_note
go

