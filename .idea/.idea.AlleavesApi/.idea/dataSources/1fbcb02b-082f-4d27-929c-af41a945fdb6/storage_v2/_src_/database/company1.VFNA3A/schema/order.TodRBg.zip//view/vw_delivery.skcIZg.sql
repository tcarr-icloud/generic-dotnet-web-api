CREATE VIEW [order].[vw_delivery]

AS

SELECT CASE WHEN o.[type] = 'pickup' THEN p.pickup_date ELSE a.delivery_date END AS pickup_delivery_date
	,l.id_location
	,s.id_status
	,c.id_customer
	,u1.id_user as id_driver1
	,u2.id_user as id_driver2
    ,l.[name] as [location]
    ,o.id_order
	,o.[type] as order_type
	,s.[name] as order_status
	,c.name_first + ' ' + c.name_last customer_name
	,c.patient_number
	,u1.FirstName + ' ' + u1.LastName driver1
	,u2.FirstName + ' ' + u2.LastName driver2
FROM [order].[order] o
LEFT JOIN [order].[address] a on a.id_order = o.id_order
JOIN [base].[location] l on l.id_location = o.id_location
JOIN [order].[customer] c on c.id_customer = o.id_customer
JOIN [order].[status] s on s.id_status = o.id_status AND s.name <> 'Cancelled'
JOIN [order].[pickup] p on p.id_order = o.id_order	
LEFT JOIN [order].[driver] d1 on d1.id_driver = a.id_driver1
LEFT JOIN [order].[driver] d2 on d2.id_driver = a.id_driver2
LEFT JOIN [base].[user] u1 on u1.id_user = d1.id_user
LEFT JOIN [base].[user] u2 on u2.id_user = d2.id_user
WHERE (o.[type] = 'delivery' OR o.[type] = 'pickup') AND o.void = 0
go

