CREATE PROCEDURE [pos].[usp_payment_method_list]
	@id_payment_method INT = NULL,
	@id_location INT = NULL
AS
BEGIN
	SET NOCOUNT ON;
	SELECT id_payment_method, id_location, [name], [enabled], deleted, date_created, id_user_created_by, id_user_modified_by 
	FROM [pos].[payment_methods] 
	WHERE deleted = 0 
		AND (@id_payment_method IS NULL OR id_payment_method = @id_payment_method) 
		AND (@id_location IS NULL OR id_location = @id_location)
END
go

