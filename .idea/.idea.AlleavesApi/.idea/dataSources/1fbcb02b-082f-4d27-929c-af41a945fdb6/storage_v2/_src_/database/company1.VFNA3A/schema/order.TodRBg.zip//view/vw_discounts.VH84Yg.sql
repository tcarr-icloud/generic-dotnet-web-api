CREATE VIEW [order].[vw_discounts]

AS

SELECT
CAST(o.date_created AS DATE) as 'date'
,l.id_location
,l.name AS 'location'
,COUNT(DISTINCT od.id_order) as 'order_count'
,o.id_order
,d.id_discount
,COUNT(od.id_order) AS order_count_total
,d.name as discount_code
,o.discount
FROM [order].[order] o
INNER JOIN discount.order_discount od ON od.id_order=o.id_order
LEFT JOIN [base].[location] l on l.id_location=o.id_location
LEFT JOIN [discount].[discount] d on d.id_discount=od.id_discount
WHERE o.void = 0
GROUP BY o.date_created ,d.name, l.name ,o.discount ,o.id_order ,d.id_discount, l.id_location
go

