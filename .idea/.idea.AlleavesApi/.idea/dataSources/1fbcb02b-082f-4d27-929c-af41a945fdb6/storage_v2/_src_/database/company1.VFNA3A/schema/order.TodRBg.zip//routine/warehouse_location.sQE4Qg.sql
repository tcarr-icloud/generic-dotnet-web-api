CREATE PROCEDURE [order].[warehouse_location]
	@id_location INT = NULL
AS
    SELECT id_location,name,address,city,state,postal_code
    FROM [base].[location] l
    WHERE id_location = ISNULL(@id_location,id_location)
go

