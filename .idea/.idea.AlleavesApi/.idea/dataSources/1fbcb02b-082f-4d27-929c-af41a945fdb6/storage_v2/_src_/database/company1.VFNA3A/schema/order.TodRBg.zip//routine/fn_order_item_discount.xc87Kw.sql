


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [order].[fn_order_item_discount]
(	
	@id_item INT
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT
		 d.id_item_discount
		,d.id_discount
		,d.id_rule
		,d.amount
		,COALESCE(dis.code, r.title) as title
		,CASE 
			WHEN dt.columnName = 'cart_adjustments' THEN (SELECT label FROM OPENJSON(r.cart_adjustments) WITH (label varchar(50))) 
			WHEN dt.columnName = 'product_adjustments' THEN (SELECT label FROM OPENJSON(r.product_adjustments) WITH (label varchar(50))) 
			WHEN dt.columnName = 'bulk_adjustments' THEN (SELECT label FROM OPENJSON(r.bulk_adjustments) WITH (label varchar(50))) 
			WHEN dt.columnName = 'set_adjustments' THEN (SELECT label FROM OPENJSON(r.set_adjustments) WITH (label varchar(50))) 
			WHEN dt.columnName = 'buy_x_get_y_adjustments' THEN (SELECT label FROM OPENJSON(r.buy_x_get_y_adjustments) WITH (label varchar(50))) 
			WHEN dt.columnName = 'buy_x_get_x_adjustments' THEN (SELECT label FROM OPENJSON(r.buy_x_get_x_adjustments) WITH (label varchar(50))) 			
		END as [label]
	FROM [order].item_discount d
	LEFT OUTER JOIN discount.discount dis on d.id_discount = dis.id_discount
	LEFT OUTER JOIN discount.rules r on r.id = d.id_rule
	LEFT OUTER JOIN discount.discount_types dt on dt.id = r.discount_type	
	WHERE d.id_item = @id_item
)
go

