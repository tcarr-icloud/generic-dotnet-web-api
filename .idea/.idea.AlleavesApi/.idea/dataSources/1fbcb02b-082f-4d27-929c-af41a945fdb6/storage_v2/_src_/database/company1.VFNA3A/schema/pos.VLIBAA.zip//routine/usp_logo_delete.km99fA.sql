CREATE PROCEDURE [pos].[usp_logo_delete]
	@id_logo INT
AS
	DELETE FROM pos.logos WHERE id_logo = @id_logo

