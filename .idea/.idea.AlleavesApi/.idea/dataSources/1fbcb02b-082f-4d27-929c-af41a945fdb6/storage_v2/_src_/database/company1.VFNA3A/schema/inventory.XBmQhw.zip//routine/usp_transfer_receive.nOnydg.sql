CREATE   PROCEDURE [inventory].[usp_transfer_receive]
	@id_transfer INT,
	@manifest VARCHAR(MAX) = '[]',
	@id_user INT,
	@mobile bit = null
AS

	/* setup item list temp table. */
	SELECT *
	INTO #manifest
	FROM OPENJSON(@manifest)
	WITH (
		id_item INT '$.id_item',
		id_batch INT '$.id_batch',
		batch VARCHAR(128) '$.batch',
		id_strain INT '$.id_strain',
		id_area_destination INT '$.id_area_destination',
		cost DECIMAL(18,4) '$.cost',
		quantity DECIMAL(18,4) '$.quantity',
		quantity_received DECIMAL(18,4) '$.quantity_received',
		quantity_refused DECIMAL(18,4) '$.quantity_refused',
		id_refuse_reason INT '$.id_refuse_reason',
		refuse_reason VARCHAR(MAX) '$.refuse_reason'
	)

	DECLARE @id_batch INT,
		    @id_area INT,
			@id_item INT,
			@id_strain INT,
			@batch VARCHAR(128),
			@qty DECIMAL(18,4),
			@qty_received DECIMAL(18,4),
			@qty_refused DECIMAL(18,4),
			@id_refuse_reason INT,
			@refuse_reason VARCHAR(256),
			@cost DECIMAL(18,4),
			@cog_total DECIMAL(18,4)

	/* get transfer type (internal or external). */
	DECLARE @type VARCHAR(32) = (SELECT CASE WHEN id_location_source IS NOT NULL THEN 'internal' ELSE 'external' END FROM inventory.transfer WHERE id_transfer=@id_transfer)
	
	DECLARE @note VARCHAR(64) = CONCAT('TransferID: ', @id_transfer)
	DECLARE @event_list VARCHAR(MAX)
	/* insert items into inventory. */
	IF(@type='internal')
	BEGIN
		/* if source was internal location. */
		SET @event_list = (SELECT id_area_destination AS id_area
						, id_batch
						, quantity_received - ISNULL(quantity_refused, 0) AS adjustment
					FROM #manifest
					WHERE quantity_received - ISNULL(quantity_refused, 0) > 0
					FOR JSON PATH)

		/* add log event and adjust inventory. */
		EXEC [log].usp_event_create_bulk 'transfer_receive', @note, @event_list, @id_user
		
	END
	ELSE
	BEGIN
		/* if source was external vendor. */
		DECLARE c CURSOR FOR
		SELECT id_item, id_batch, batch, id_strain, id_area_destination, quantity_received-ISNULL(quantity_refused, 0), cost
		FROM #manifest
		WHERE quantity_received-ISNULL(quantity_refused, 0) > 0

		OPEN c

		FETCH NEXT FROM c INTO @id_item, @id_batch, @batch, @id_strain, @id_area, @qty, @cost

		WHILE @@FETCH_STATUS = 0 BEGIN
			SET @cog_total = @cost * @qty

			/* handle batch creation if required. */
			IF(@id_batch IS NULL)
			BEGIN
				/* try and get batch based on name. */
				IF (@batch IS NOT NULL)
				BEGIN
					SET @id_batch = (SELECT TOP 1 id_batch FROM inventory.batch WHERE name=@batch AND id_item=@id_item)

					IF (@id_batch IS NULL) AND EXISTS (SELECT TOP 1 id_batch FROM inventory.batch WHERE name=@batch)
					BEGIN
						DECLARE @msg VARCHAR(500) = CONCAT('A batch with the label ', @batch, ' already exists for a different item.')
						RAISERROR(@msg, 11, 1)
						RETURN
					END
						

					/* if batch does not exist. */
					IF (@id_batch IS NULL)
					BEGIN
						/* create new batch id or get default batch id if no batch is required. */
						EXEC @id_batch = inventory.usp_batch_create @id_item, @id_strain, NULL, NULL, @qty, @cog_total

						/* update batch name if value is passed in. */
						IF(@batch IS NOT NULL)
							UPDATE inventory.batch SET name=@batch WHERE id_batch=@id_batch
					END
					/* if batch exists. */
					ELSE IF @id_batch IS NOT NULL AND @cost IS NOT NULL
					BEGIN
						/* update cost per unit. */
						UPDATE inventory.batch
						SET cost_of_good = ((ISNULL(initial_quantity, 0) * ISNULL(cost_of_good, 0)) + @cog_total) / (ISNULL(initial_quantity, 0) + @qty)
							, initial_quantity = ISNULL(initial_quantity, 0) + @qty
						WHERE id_batch=@id_batch
					END
				END
				ELSE
					/* create new batch id or get default batch id if no batch is required. */
					EXEC @id_batch = inventory.usp_batch_create @id_item, @id_strain, NULL, NULL, @qty, @cog_total
			END
			ELSE IF (@id_batch IS NOT NULL AND @cost IS NOT NULL)
			BEGIN
				/* update cost per unit. */
				UPDATE inventory.batch
				SET cost_of_good = ((ISNULL(initial_quantity, 0) * ISNULL(cost_of_good, 0)) + @cog_total) / (ISNULL(initial_quantity, 0) + @qty)
					, initial_quantity = ISNULL(initial_quantity, 0) + @qty
				WHERE id_batch=@id_batch
			END


			/* add item to inventory. */
			EXEC [log].usp_event_create 'transfer_receive', @id_batch, @id_area, @qty, @note, @id_user

			FETCH NEXT FROM c INTO @id_item, @id_batch, @batch, @id_strain, @id_area, @qty, @cost
		END

		CLOSE c
		DEALLOCATE c
	END


	/* update original item list to add quantity received, quantity refused and refused reason. */
	IF(@type='internal')
	BEGIN
		DECLARE cur CURSOR FOR
		SELECT id_batch, quantity, quantity_received, quantity_refused, id_refuse_reason, refuse_reason, cost
		FROM #manifest

		OPEN cur

		FETCH NEXT FROM cur INTO @id_batch, @qty, @qty_received, @qty_refused, @id_refuse_reason, @refuse_reason, @cost

		WHILE @@FETCH_STATUS = 0 BEGIN

			DECLARE @amount_received DECIMAL(18,4) = 0
			DECLARE @amount_refused DECIMAL(18,4) = 0

			UPDATE x
			SET
			/* set received qty. */		  @amount_received = quantity_received = IIF(quantity-@qty_received>=0 OR is_last=1, @qty_received, quantity)
			/* update remaining qty. */	, @qty_received = IIF(quantity-@qty_received>=0, 0, @qty_received-quantity)
			/* set refused qty. */		, @amount_refused = quantity_refused = IIF(quantity-@qty_refused>=0 OR is_last=1, @qty_refused, quantity)
			/* update remaining qty. */	, @qty_refused = IIF(quantity-@qty_refused>=0, 0, @qty_refused-quantity)
										, id_refuse_reason = IIF(@amount_refused>0, @id_refuse_reason, NULL)
										, refuse_reason = IIF(@amount_refused>0, @refuse_reason, NULL)
			FROM (
				SELECT *, CASE WHEN LEAD(id_area,1) OVER (ORDER BY id_area) IS NULL THEN 1 ELSE 0 END AS is_last
				FROM inventory.transfer_item
				WHERE id_batch=@id_batch AND id_transfer=@id_transfer
			) x


			FETCH NEXT FROM cur INTO @id_batch, @qty, @qty_received, @qty_refused, @id_refuse_reason, @refuse_reason, @cost
		END

		CLOSE cur
		DEALLOCATE cur
	END
	ELSE
	BEGIN
		UPDATE i
		SET i.quantity_received=m.quantity_received
			, i.quantity_refused=m.quantity_refused
			, i.id_refuse_reason=m.id_refuse_reason
			, i.refuse_reason=m.refuse_reason
		FROM inventory.transfer_item i
		JOIN #manifest m ON (m.id_item IS NULL OR m.id_item=i.id_item)
						AND (m.quantity=i.quantity)
						AND i.id_transfer=@id_transfer
						AND i.quantity_refused IS NULL
	END


	/* set transfer status. */
	DECLARE @id_status INT = (SELECT id_transfer_status FROM inventory.transfer_status WHERE reference='received')

	EXEC inventory.usp_transfer_status_update @id_transfer, @id_status, @id_user, 0

	 /* insert ride status. */
    DECLARE @id_ride_status INT = (SELECT id_ride_status FROM inventory.ride_status WHERE reference='delivered')

	IF (@id_ride_status IS NOT NULL)
   		INSERT INTO inventory.ride_status_history (id_transfer, id_ride_status, id_user_verified)
   		VALUES (@id_transfer, @id_ride_status, @id_user)

    update inventory.transfer set mobile= isnull(@mobile,0) where id_transfer = @id_transfer;

	/* if items were refused, create new manifest. */
	IF EXISTS (SELECT * FROM #manifest WHERE quantity_refused > 0)
	BEGIN
		DECLARE @id_location_source INT,
				@id_location_destination INT,
				@id_vendor_destination INT,
				@address VARCHAR(256),
				@city VARCHAR(256),
				@state VARCHAR(256),
				@postal_code VARCHAR(32),
				@id_driver1 INT,
				@id_driver2 INT,
				@id_vehicle INT,
				@return_item_list VARCHAR(MAX)

		/* set values for new return transfer. */
		SELECT @id_location_source=id_location_destination
				, @id_location_destination=id_location_source
				, @id_vendor_destination=id_vendor_source
				, @address=ISNULL(l.address, v.shipping_address)
				, @city=ISNULL(l.city, v.shipping_city)
				, @state=ISNULL(l.state, v.shipping_state)
				, @postal_code=ISNULL(l.postal_code, v.shipping_postal_code)
				, @id_driver1=t.id_driver1
				, @id_driver2=t.id_driver2
				, @id_vehicle=t.id_vehicle
		FROM inventory.transfer t
		LEFT JOIN base.location l ON l.id_location=t.id_location_source
		LEFT JOIN inventory.vendor v ON v.id_vendor=t.id_vendor_source
		WHERE t.id_transfer=@id_transfer

		/* if returning internal transfer. */
		IF(@type='internal')
		BEGIN

			/* prep item list. */
			SET @return_item_list=CAST((
				SELECT id_batch
					, quantity_refused AS quantity
				FROM #manifest
				WHERE quantity_refused>0
				FOR JSON PATH
			) AS VARCHAR(MAX))


		END
		/* if returning external transfer. */
		ELSE
		BEGIN

			/* prep item list. */
			SET @return_item_list=CAST((
				SELECT id_item
					, quantity_refused AS quantity
				FROM #manifest
				WHERE quantity_refused>0
				FOR JSON PATH
			) AS VARCHAR(MAX))

		END

		/* create return transfer. */
		EXEC inventory.usp_transfer_upsert NULL, NULL
				, @id_location_source
				, NULL
				, @id_location_destination
				, @id_vendor_destination
				, NULL
				, @address
				, @city
				, @state
				, @postal_code
				, NULL
				, NULL
				, NULL
				, @id_driver1
				, @id_driver2
				, @id_vehicle
				, @return_item_list
				, @id_transfer
				, @id_user
	END
go

