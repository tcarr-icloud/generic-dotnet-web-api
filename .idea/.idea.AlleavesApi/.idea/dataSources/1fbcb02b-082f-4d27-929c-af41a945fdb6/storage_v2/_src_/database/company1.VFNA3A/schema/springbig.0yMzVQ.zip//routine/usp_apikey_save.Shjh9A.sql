CREATE PROCEDURE [springbig].[usp_apikey_save]
	@id_location int,
	@key varchar(512),
	@email_required bit = 0
AS
    SET NOCOUNT ON;
	IF NOT EXISTS (SELECT 1 FROM [springbig].[apikey] WHERE id_location = @id_location)
		INSERT INTO [springbig].[apikey] (id_location, [key], [email_required])
		VALUES(@id_location, @key, @email_required)
	ELSE
		UPDATE [springbig].[apikey]
		SET [key] = @key, [email_required] = @email_required
		WHERE id_location = @id_location
go

