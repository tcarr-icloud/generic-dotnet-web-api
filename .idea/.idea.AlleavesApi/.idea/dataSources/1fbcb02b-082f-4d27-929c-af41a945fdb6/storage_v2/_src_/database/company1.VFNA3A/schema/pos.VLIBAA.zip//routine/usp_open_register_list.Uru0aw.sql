CREATE PROCEDURE [pos].[usp_open_register_list]
@id_location INT = NULL

AS

SELECT s.id_session
      , r.id_register
      , r.[name] AS register
      , r.id_location
FROM [pos].[register] r
JOIN [pos].[session] s ON s.id_register = r.id_register AND s.date_end IS NULL
WHERE r.id_location=ISNULL(@id_location, r.id_location)
go

