CREATE PROCEDURE [tax].[usp_get_tax_category_list]
	@id_tax_category INT = NULL
AS
	SELECT tc.id_tax_category,
		tc.name,
		tc.active,
		tc.created_by,
		tc.updated_by,
		tc.date_created,
		tc.date_updated,
		ISNULL((
			SELECT tg.*
			FROM [tax].[category_group] tcg
			LEFT JOIN [tax].[group] tg ON tg.id_tax_group = tcg.id_tax_group
			WHERE tcg.id_tax_category = ISNULL(@id_tax_category, tc.id_tax_category) AND tcg.active = 1 AND tg.active=1
		FOR JSON PATH), '[]') as tax_group_list
	FROM [tax].[category] tc
	WHERE tc.active = 1 AND tc.id_tax_category=ISNULL(@id_tax_category, tc.id_tax_category)
	ORDER BY tc.[name]
go

