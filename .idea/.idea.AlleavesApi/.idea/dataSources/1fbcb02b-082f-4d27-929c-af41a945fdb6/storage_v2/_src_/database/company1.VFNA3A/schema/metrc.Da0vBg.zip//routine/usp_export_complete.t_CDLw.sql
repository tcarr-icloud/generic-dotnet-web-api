CREATE PROCEDURE [metrc].[usp_export_complete]
	@id_export INT,
	@id_user INT
AS
	UPDATE metrc.export
	SET id_user_updated = @id_user
		, completed = 1
		, date_completed = GETUTCDATE()
		, date_updated = GETUTCDATE()
	WHERE id_export = @id_export

	EXEC metrc.usp_export_fetch @id_export
go

