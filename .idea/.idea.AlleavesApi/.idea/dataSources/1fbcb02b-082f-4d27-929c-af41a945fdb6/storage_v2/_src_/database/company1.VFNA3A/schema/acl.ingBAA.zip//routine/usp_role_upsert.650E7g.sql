CREATE PROCEDURE [acl].[usp_role_upsert]
	@id_role INT = NULL,
	@name VARCHAR(256),
	@permission_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	/* insert new role. */
	IF(@id_role IS NULL)
	BEGIN
		INSERT INTO acl.role (name, id_user_created, id_user_updated)
		VALUES (@name, @id_user, @id_user)

		SET @id_role=SCOPE_IDENTITY()
	END
	/* update existing role. */
	ELSE
	BEGIN
		UPDATE acl.role
		SET name=@name
			, id_user_updated=@id_user
			, date_updated=getutcdate()
		WHERE id_role=@id_role
	END

	/* upsert role permissions. */
	;WITH list AS (
		SELECT @id_role AS id_role
				, p.id_permission
				, ISNULL(a.allowed, 0) AS allowed
		FROM acl.permission p
		LEFT JOIN (
			SELECT * FROM OPENJSON(@permission_list)
			WITH (
				id_permission INT,
				allowed BIT
			)
		) a ON a.id_permission=p.id_permission
	)
	MERGE acl.role_permission t
	USING list s
	ON t.id_permission=s.id_permission AND t.id_role=s.id_role
	WHEN MATCHED THEN
		UPDATE SET t.allowed=s.allowed, t.id_user_updated=@id_user, t.date_updated=getutcdate()
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_role, id_permission, allowed, id_user_created, id_user_updated)
		VALUES (s.id_role, s.id_permission, s.allowed, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND t.id_role=@id_role THEN
		DELETE
	;


	/* return updated role. */
	EXEC acl.usp_role_list @id_role, 1
go

