CREATE FUNCTION [dbo].[fn_lookup_tz]
(
	@tz VARCHAR(128)
)
RETURNS VARCHAR(128)
AS
BEGIN
	DECLARE @rtn VARCHAR(128)

	SET @rtn=(SELECT tz_windows FROM [dbo].[tz_lookup] WHERE tz_iana=@tz)

	IF @rtn IS NULL
		RETURN 'UTC'
	RETURN @rtn
END
go

