CREATE PROCEDURE [grow].[usp_plant_move_fetch]
	@id_plant_move INT
AS
	SELECT m.id_plant_move
			, l.id_location
			, m.id_area_from
			, m.id_area_to
			, l.name AS location
			, af.path AS area_from
			, ad.path AS area_to
			, m.notes
			, CAST(m.date_created AS VARCHAR(32)) AS date_created
			, ISNULL((SELECT mi.id_plant_move_item
							, p.id_plant
							, p.name AS plant
							, s.name AS strain
							, CONCAT(ISNULL(CAST(mi.row_from AS VARCHAR(16)), '-'), 
									 '-',
									 CASE WHEN mi.column_from IS NOT NULL AND (mi.column_from - ((mi.column_from - 1) % 26)) / 26 > 0 THEN NCHAR(UNICODE(N'A') + (((mi.column_from - ((mi.column_from - 1) % 26)) / 26 - 1) % 26) ) ELSE '' END,
									 CASE WHEN mi.column_from IS NOT NULL THEN NCHAR(UNICODE(N'A') + ((mi.column_from - 1) % 26)) ELSE '-' END
								) AS grid_from
							, CONCAT(ISNULL(CAST(mi.row_to AS VARCHAR(16)), '-'), 
									 '-',
									 CASE WHEN mi.column_to IS NOT NULL AND (mi.column_to - ((mi.column_to - 1) % 26)) / 26 > 0 THEN NCHAR(UNICODE(N'A') + (((mi.column_to - ((mi.column_to - 1) % 26)) / 26 - 1) % 26) ) ELSE '' END,
									 CASE WHEN mi.column_to IS NOT NULL THEN NCHAR(UNICODE(N'A') + ((mi.column_to - 1) % 26)) ELSE '-' END
								) AS grid_to
					  FROM grow.plant_move_item mi
					  JOIN grow.plant p ON p.id_plant=mi.id_plant
					  JOIN grow.strain s ON s.id_strain=p.id_strain
					  WHERE mi.id_plant_move=m.id_plant_move
					  FOR JSON PATH
			), '[]') AS plant_list
	FROM grow.plant_move m
	JOIN inventory.vw_area_list af ON af.id_area=m.id_area_from
	JOIN inventory.vw_area_list ad ON ad.id_area=m.id_area_to
	JOIN base.location l ON l.id_location=af.id_location
	WHERE m.id_plant_move=@id_plant_move
go

