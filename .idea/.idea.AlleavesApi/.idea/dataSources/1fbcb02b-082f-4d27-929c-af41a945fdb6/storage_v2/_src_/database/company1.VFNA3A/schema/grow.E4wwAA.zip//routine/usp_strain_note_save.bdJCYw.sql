CREATE PROCEDURE [grow].[usp_strain_note_save]
	@id_strain INT,
	@id_strain_note INT = NULL,
	@topic VARCHAR(256) = NULL,
	@note VARCHAR(MAX) = NULL,
	@id_user INT,
	@deleted BIT = 0
AS
	IF(@id_strain_note IS NOT NULL)
	BEGIN 
		UPDATE grow.strain_note
		SET topic=@topic
			, note=@note
			, updated_by=@id_user
			, date_updated=getutcdate()
			, deleted=ISNULL(@deleted, 0)
		WHERE id_strain_note=@id_strain_note
	END

	ELSE
	BEGIN
		INSERT INTO grow.strain_note (id_strain, topic, note, created_by, updated_by)
		VALUES (@id_strain, @topic, @note, @id_user, @id_user)

		SET @id_strain_note=SCOPE_IDENTITY()
	END

	SELECT n.id_strain_note
		, n.id_strain
		, n.topic
		, n.note
		, n.date_created
		, n.date_updated
		, CONCAT(uc.FirstName, ' ', uc.LastName) AS created_by
		, CONCAT(uu.FirstName, ' ', uu.LastName) AS updated_by
		, n.deleted
	FROM grow.strain_note n
	JOIN base.[user] uc ON uc.id_user=n.created_by
	JOIN base.[user] uu ON uu.id_user=n.updated_by
	WHERE n.id_strain_note=@id_strain_note
go

