CREATE PROCEDURE [inventory].[usp_area_open_grid_list]
	@id_area INT,
	@id_plant INT = NULL
AS
	;WITH grid ([row], [column], sequence) AS (
		SELECT b.[row], a.[column], ROW_NUMBER() OVER(ORDER BY b.[row] ASC) AS sequence
		FROM (
			SELECT [column] = number 
			FROM master..[spt_values] 
			WHERE type='P' AND number BETWEEN 1 AND (SELECT columns FROM inventory.area WHERE id_area=@id_area)
		) a
		CROSS JOIN (
			SELECT [row] = number 
			FROM master..[spt_values] 
			WHERE type='P' AND number BETWEEN 1 AND (SELECT rows FROM inventory.area WHERE id_area=@id_area)
		) b
		LEFT JOIN grow.plant p ON p.[row]=b.[row] AND 
								  p.[column]=a.[column] AND 
								  p.harvested = 0 AND
								  p.destroyed = 0 AND
								  p.id_area=@id_area
		WHERE p.id_plant IS NULL OR (@id_plant IS NOT NULL AND p.id_plant=@id_plant)
	)

	SELECT @id_area AS id_area
			, NULL AS [row]
			, NULL AS [column]
			, '---' AS grid
	UNION ALL
	SELECT @id_area AS id_area
			, [row]
			, [column]
			, grow.fn_grid_label([row], [column]) AS grid
	FROM grid
go

