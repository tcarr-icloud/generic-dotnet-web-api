CREATE PROCEDURE [order].[usp_vehicle_list]
	@id_vehicle INT = NULL,
	@include_deleted BIT = 0
AS
	SELECT v.id_vehicle
			, v.name AS vehicle
			, v.company
			, v.phone
			, v.make
			, v.model
			, v.color
			, v.license
			, v.vin
			, v.[year]
			, v.deleted
			, v.biotrack_transaction_id
			, v.internal_vehicle_id
	FROM [order].vehicle v
	WHERE id_vehicle=ISNULL(@id_vehicle, id_vehicle) AND deleted<=@include_deleted
go

