CREATE PROCEDURE [tax].[usp_tax_category_create]
	@name VARCHAR(256),
    @active BIT,
	@id_user INT,
	@tax_group_list VARCHAR(MAX) = '[]'
AS
	INSERT INTO tax.category ([name], active, created_by, updated_by) 
	VALUES(@name, @active, @id_user, @id_user)

	DECLARE @id_tax_category INT = SCOPE_IDENTITY()

	-- INSERT VALUES INTO THE CATEGORY_VALUES TABLE FOR ANY SELECTED VALUES HERE.
	;WITH tax_list AS (
		SELECT @id_tax_category AS id_tax_category
			, id_tax_group
		FROM OPENJSON(@tax_group_list)
		WITH (
			  id_tax_group INT
		)
	)
	MERGE [tax].[category_group] AS tcg
	USING tax_list AS taxl
	ON taxl.id_tax_category = tcg.id_tax_category AND taxl.id_tax_group = tcg.id_tax_group
	WHEN MATCHED THEN
	UPDATE SET tcg.updated_by=@id_user, tcg.date_updated=getutcdate(), tcg.active=@active
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_tax_group, id_tax_category, active, created_by, updated_by) VALUES(taxl.id_tax_group, taxl.id_tax_category, @active, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND tcg.id_tax_category = @id_tax_category THEN
	UPDATE SET tcg.active=0, tcg.updated_by=@id_user, tcg.date_updated=getutcdate()
	;

	EXEC [tax].[usp_get_tax_category_list] @id_tax_category
go

