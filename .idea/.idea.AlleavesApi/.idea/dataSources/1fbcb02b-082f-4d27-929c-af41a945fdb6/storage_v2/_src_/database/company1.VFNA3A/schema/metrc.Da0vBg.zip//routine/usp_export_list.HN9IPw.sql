CREATE PROCEDURE [metrc].[usp_export_list]
	@id_location INT = NULL,
	@id_export INT = NULL,
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
	SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
		SELECT e.id_export
				, l.id_location
				, e.metrc_id
				, e.metrc_name
				, l.name AS source_name
				, ISNULL(dl.name, dv.name) AS destination_name
				, e.source_address
				, e.source_city
				, e.source_state
				, e.source_postal_code
				, e.destination_address
				, e.destination_city
				, e.destination_state
				, e.destination_postal_code
				, e.completed
				, e.cancelled
				, e.transfer_type
				, e.biotrack_barcode_id
				, e.biotrack_barcode_pickup_id
				, CASE WHEN e.completed=1 THEN ''Completed''
					   WHEN e.cancelled=1 THEN ''Cancelled''
					   ELSE ''Open'' 
				  END AS [status]
				, e.date_completed
				, CAST(e.date_completed AT TIME ZONE ''UTC'' AT TIME ZONE tl.[tz_windows] as datetime) as local_datetime_completed
				, e.date_cancelled
				, CAST(e.date_cancelled AT TIME ZONE ''UTC'' AT TIME ZONE tl.[tz_windows] as datetime) as local_datetime_cancelled
				, e.date_created
				, CAST(e.date_created AT TIME ZONE ''UTC'' AT TIME ZONE tl.[tz_windows] as datetime) as local_datetime_created
				, ISNULL((SELECT *
					  FROM metrc.stops st
					  WHERE st.id_export=e.id_export
					  FOR JSON PATH
			), ''[]'') AS stops
		FROM metrc.export e
		JOIN base.location l ON l.id_location=e.id_location_source
		LEFT JOIN base.location dl ON dl.id_location=e.id_location_destination
		LEFT JOIN inventory.vendor dv ON dv.id_vendor=e.id_vendor_destination
		LEFT OUTER JOIN [dbo].[tz_lookup] as tl ON l.[timezone] = tl.[tz_iana]
	) inventory'

	SET @where = 'WHERE id_location = '+ ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location')
	SET @where = @where + ' AND id_export = '+ ISNULL(CAST(@id_export AS VARCHAR(16)), 'id_export')	
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'id_export')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

