CREATE PROCEDURE [grow].[usp_harvest_fetch]
	@id_harvest INT
AS
	SELECT h.id_harvest
			, h.is_manicure
			, h.id_location
			, h.id_area_dry
			, h.id_area_trim
			, h.id_strain
			, h.name AS harvest
			, s.name AS strain
			, l.name AS location
			, h.finished
			, adr.path AS area_dry
			, atr.path AS area_trim
			, h.weight_total_g
			, h.weight_wet_g
			, h.weight_wet_waste_g
			, h.weight_dry_g
			, h.weight_dry_waste_g
			, CASE WHEN h.finished = 1 OR h.date_trim_end IS NOT NULL THEN 'Finished'
				   WHEN h.date_trim_start IS NOT NULL THEN 'Trimming'
				   ELSE 'Drying' END AS status
			, h.date_harvest
			, CAST(h.date_harvest AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as date_harvest_local
			, h.date_trim_start
			, CAST(h.date_trim_start AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as date_trim_start_local
			, h.date_trim_end
			, CAST(h.date_trim_end AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as date_trim_end_local
			, h.date_finished
			, CAST(h.date_finished AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as date_finished_local
			, CONCAT(u.FirstName, ' ', u.LastName) AS user_created
			, CONCAT(uts.FirstName, ' ', uts.LastName) AS user_trim_start
			, CONCAT(ute.FirstName, ' ', ute.LastName) AS user_trim_end
			, CONCAT(uf.FirstName, ' ', uf.LastName) AS user_finished
			, h.date_created
			, CAST(h.date_created AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as date_created_local
			, h.metrc_id
			, h.metrc_harvest
			-- plant list:
			, ISNULL((SELECT p.id_plant
							, p.name AS plant
							, s.name AS strain
							, a.path AS area
							, ISNULL(p.harvest_weight_g, h.weight_total_g) AS harvest_weight_g
							, p.[row]
							, p.[column]
							, CONCAT(ISNULL(CAST(p.[row] AS VARCHAR(16)), '-'), 
									 '-',
									 CASE WHEN p.[row] IS NOT NULL AND (p.[column] - ((p.[column] - 1) % 26)) / 26 > 0 THEN NCHAR(UNICODE(N'A') + (((p.[column] - ((p.[column] - 1) % 26)) / 26 - 1) % 26) ) ELSE '' END,
									 CASE WHEN p.[column] IS NOT NULL THEN NCHAR(UNICODE(N'A') + ((p.[column] - 1) % 26)) ELSE '-' END
								) AS grid
							, p.metrc_label
					  FROM grow.plant p
					  JOIN grow.strain s ON s.id_strain=p.id_strain
					  LEFT JOIN inventory.vw_area_list a ON a.id_area=p.id_area
					  WHERE p.id_harvest=h.id_harvest OR (',' + p.id_manicure_list + ',') LIKE '%,' + CAST(h.id_harvest AS VARCHAR(255)) + ',%'
					  FOR JSON PATH
			), '[]') AS plant_list
			-- output list:
			, ISNULL((SELECT g.id_item_group
							, i.id_item
							, b.id_batch
							, a.id_area
							, RTRIM(CONCAT(g.name, ' ', (
								SELECT STRING_AGG(av.name, ' ')
								FROM inventory.item_attribute_value iav
								LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
								WHERE iav.id_item=i.id_item)
							)) AS item
							, b.name AS batch
							, hi.quantity
							, u.name AS uom
							, a.path AS area
							, hi.is_wet
							, hi.is_dry
							, hi.is_waste
							, b.metrc_package_label
							, il.metrc_name
							, il.metrc_item_id
					  FROM grow.harvest_item hi
					  JOIN inventory.batch b ON b.id_batch=hi.id_batch
					  JOIN inventory.item i ON i.id_item=b.id_item
					  JOIN inventory.item_group g ON g.id_item_group=i.id_item_group
					  JOIN inventory.uom u ON u.id_uom=g.id_uom
					  JOIN inventory.vw_area_list a ON a.id_area=hi.id_area
					  JOIN base.location l ON l.id_location=a.id_location
					  LEFT JOIN inventory.item_location il ON il.id_location=l.id_location AND il.id_item=i.id_item
					  WHERE hi.id_harvest=h.id_harvest
					  FOR JSON PATH
			), '[]') AS output_list
	FROM grow.harvest h
	JOIN base.[user] u ON u.id_user=h.id_user_created
	JOIN base.location l ON l.id_location=h.id_location
	JOIN grow.strain s ON s.id_strain=h.id_strain
	LEFT JOIN base.[user] uts ON uts.id_user=h.id_user_trim_start
	LEFT JOIN base.[user] ute ON ute.id_user=h.id_user_trim_end
	LEFT JOIN base.[user] uf ON uf.id_user=h.id_user_finished
	LEFT JOIN inventory.vw_area_list adr ON adr.id_area=h.id_area_dry
	LEFT JOIN inventory.vw_area_list atr ON atr.id_area=h.id_area_trim
	LEFT OUTER JOIN [dbo].[tz_lookup] as tl ON l.[timezone] = tl.[tz_iana]
	WHERE h.id_harvest=@id_harvest
go

