CREATE PROCEDURE [order].[usp_physician_create]
	@name_first VARCHAR(128),
	@name_last VARCHAR(128),
	@phone VARCHAR(20),
	@email VARCHAR(263),
	@address1 VARCHAR(255),
	@address2 VARCHAR(255),
	@city VARCHAR(150),
	@state VARCHAR(150),
	@zip VARCHAR(15),
	@license_number VARCHAR(50),
	@dea VARCHAR(50),
	@npi VARCHAR(50),
	@id_user INT
AS
	INSERT INTO [order].physician (name_first, name_last, phone, email, address1, address2, city, state, zip, license_number, dea,  npi, created_by, updated_by) VALUES
	(@name_first, @name_last, @phone, @email, @address1, @address2, @city, @state, @zip, @license_number, @dea,  @npi, @id_user, @id_user)

	DECLARE @id_physician INT = SCOPE_IDENTITY()

	EXEC [order].usp_physician_list @id_physician
go

