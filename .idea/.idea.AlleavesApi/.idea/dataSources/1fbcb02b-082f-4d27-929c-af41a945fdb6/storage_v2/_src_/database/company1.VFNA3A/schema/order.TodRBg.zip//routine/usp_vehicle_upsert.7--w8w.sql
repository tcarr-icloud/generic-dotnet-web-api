CREATE PROCEDURE [order].[usp_vehicle_upsert]
	@id_vehicle INT = NULL,
	@name VARCHAR(128),
	@company VARCHAR(128),
	@phone VARCHAR(32),
	@make VARCHAR(128),
	@model VARCHAR(128),
	@color VARCHAR(128),
	@license VARCHAR(128),
	@vin VARCHAR(128),
	@year INT,
	@biotrack_transaction_id VARCHAR(128),
	@internal_vehicle_id INT = NULL,
	@deleted BIT = 0,
	@id_user INT
AS
	IF(@id_vehicle IS NULL)
	BEGIN
		INSERT INTO [order].vehicle (name, company, phone, make, model, color, license, vin, [year], biotrack_transaction_id, internal_vehicle_id, created_by, updated_by) 
		VALUES (@name, @company, @phone, @make, @model, @color, UPPER(@license), @vin, @year, @biotrack_transaction_id, @internal_vehicle_id, @id_user, @id_user)

		SET @id_vehicle=SCOPE_IDENTITY()
	END
	ELSE
		UPDATE [order].vehicle 
		SET name=@name
			, company=@company
			, phone=@phone
			, make=@make
			, model=@model
			, color=@color
			, license=UPPER(@license)
			, vin=@vin
			, [year]=@year
			, biotrack_transaction_id=@biotrack_transaction_id
			, internal_vehicle_id=@internal_vehicle_id
			, deleted=@deleted
			, updated_by=@id_user
			, date_updated=getutcdate()
		WHERE id_vehicle=@id_vehicle

	EXEC [order].usp_vehicle_list @id_vehicle, 1
go

