CREATE VIEW [order].[payment_view]

AS

SELECT p.tendered 
	, p.method AS 'payment_type'
	, l.name AS 'location'
	, r.name AS 'terminal_name'
	, l.id_location
	, p.id_order
	, p.date_created AS 'order_date'
	, (u.FirstName + ' ' + u.LastName) AS 'user'
	, p.id_user_created
	, p.id_payment
	, o.tax 
	, CASE WHEN s.date_end IS NULL THEN 'Open' ELSE 'Closed' END AS 'register_status'
FROM [order].payment p
JOIN [pos].[session] s ON s.id_register=p.id_register
JOIN [order].[order] o ON o.id_order=p.id_order
JOIN [base].[location] l ON l.id_location=o.id_location
JOIN [base].[user] u ON u.id_user=p.id_user_created 
JOIN [pos].[register] r ON r.id_register=p.id_register
go

