CREATE PROCEDURE base.[usp_get_user_pin]
@id_user INT AS
SELECT TOP 1 pin FROM base.[user] WHERE id_user = @id_user
go

