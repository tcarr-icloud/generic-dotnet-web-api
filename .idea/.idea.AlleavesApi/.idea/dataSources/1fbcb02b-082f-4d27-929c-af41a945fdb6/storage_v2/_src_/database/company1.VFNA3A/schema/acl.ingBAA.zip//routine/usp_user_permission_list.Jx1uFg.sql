CREATE PROCEDURE [acl].[usp_user_permission_list]
	@id_user INT
AS
	SELECT p.id_permission
			, p.id_parent
			, m.id_module
			, ISNULL(m.name, 'Uncategorized') AS module
			, p.reference
			, p.reference_path
			, p.reference_path as [path]
			, p.label 
			, ISNULL(o.allowed, 0) AS allowed
	FROM acl.permission p
	LEFT JOIN acl.module m ON m.id_module=p.id_module
	LEFT JOIN (
		SELECT rp.id_permission, rp.allowed
		FROM acl.role_permission rp 
		JOIN acl.role r ON r.id_role=rp.id_role
		JOIN acl.user_role ur ON ur.id_role=r.id_role
		WHERE ur.id_user=@id_user
	) o ON o.id_permission=p.id_permission
	WHERE p.active=1
go

