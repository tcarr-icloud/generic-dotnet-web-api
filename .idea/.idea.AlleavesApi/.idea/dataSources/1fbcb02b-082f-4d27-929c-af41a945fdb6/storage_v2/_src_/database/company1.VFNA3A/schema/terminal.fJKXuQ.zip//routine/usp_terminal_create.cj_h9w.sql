CREATE PROCEDURE [terminal].[usp_terminal_create]
	@name VARCHAR(256),
	@terminal_key VARCHAR(256),
	@id_register INT = NULL,
	@is_pos BIT = 0,
	@locations VARCHAR(MAX) = '[]',
	@retail_areas VARCHAR(MAX) = '[]',
	@opos_receipt_printer_name VARCHAR(256) = NULL,
	@opos_pickticket_printer_name VARCHAR(256) = NULL,
	@cash_drawer_name VARCHAR(256) = NULL,
	@label_printer_name VARCHAR(256) = NULL,
	@id_patient_label INT = NULL,
	@id_deli_label INT = NULL,
	@tf_AuthKey VARCHAR(50) = NULL,
	@tf_RegisterID VARCHAR(50) = NULL,
	@gift_card_auth_key VARCHAR(50) = NULL,
	@gift_card_register_id VARCHAR(50) = NULL,
	@id_user INT
AS
BEGIN
	SET NOCOUNT ON;

	IF (@is_pos = 1)
	BEGIN
		INSERT INTO pos.register ([name], mac, created_by, modified_by, tf_RegisterID, tf_AuthKey,  gift_card_register_id, gift_card_auth_key)
		VALUES (@name, '1', @id_user, @id_user, @tf_RegisterID, @tf_AuthKey, @gift_card_register_id, @gift_card_auth_key)
		SET @id_register = SCOPE_IDENTITY()
	END;
	
	INSERT INTO terminal.terminal ([name],terminal_key,id_register,is_pos,opos_receipt_printer_name,opos_pickticket_printer_name,cash_drawer_name,label_printer_name,id_patient_label,id_deli_label,id_user_created_by,id_user_modified_by) 
	Values (@name,@terminal_key,@id_register,@is_pos,@opos_receipt_printer_name,@opos_pickticket_printer_name,@cash_drawer_name,@label_printer_name,@id_patient_label,@id_deli_label,@id_user,@id_user)
	
	DECLARE @id_terminal INT = SCOPE_IDENTITY()

	
	/* upsert locations. */
	;WITH location_list AS (
		SELECT 
			 id_terminal = @id_terminal
			,id_location
		FROM OPENJSON(@locations)
		WITH (
			id_location INT
		)
	)
	MERGE terminal.terminal_location t
	USING location_list s
	ON t.id_terminal=s.id_terminal AND t.id_location=s.id_location
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_terminal, id_location) VALUES (s.id_terminal, s.id_location)
	WHEN NOT MATCHED BY SOURCE AND t.id_terminal=@id_terminal THEN
		DELETE
	;

	/* upsert retail areas. */
	;WITH retail_area_list AS (
		SELECT @id_terminal AS id_terminal
				, id_area
		FROM OPENJSON(@retail_areas)
		WITH (
			id_area INT
		)
	)
	MERGE terminal.retail_area t
	USING retail_area_list s
	ON t.id_terminal=s.id_terminal AND t.id_area=s.id_area
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_terminal, id_area) VALUES (s.id_terminal, s.id_area)
	WHEN NOT MATCHED BY SOURCE AND t.id_terminal=@id_terminal THEN
		DELETE
	;

	EXEC terminal.usp_terminal_list @id_terminal
END
go

