CREATE PROCEDURE [inventory].[usp_batch_inherit_plant_lineage]
	@id_batch INT,
	@id_batch_parent INT = NULL
AS
	/* insert rows into batch_plant table for every plant that the parent batches used. */	
	MERGE grow.batch_plant t
	USING (
		SELECT DISTINCT bp.id_plant, bh.id_batch
		FROM inventory.batch_history bh
		JOIN grow.batch_plant bp ON bp.id_batch=bh.id_batch_parent
		WHERE bh.id_batch=@id_batch AND bh.id_batch_parent=ISNULL(@id_batch_parent, bh.id_batch_parent)
	) s
	ON t.id_plant=s.id_plant AND t.id_batch=s.id_batch
	WHEN NOT MATCHED BY TARGET THEN INSERT (id_plant, id_batch) VALUES (s.id_plant, s.id_batch)
	;
go

