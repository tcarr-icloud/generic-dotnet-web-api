CREATE PROCEDURE [metrc].[usp_unfinish_package_failure_list]
	-- Add the parameters for the stored procedure here
	@id_batch INT = NULL,
	@remediated BIT = 0,
	@start_date datetime = null,
	@end_date datetime = null
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT upf.*,
	       usr.UserName as user_name
	FROM [metrc].[unfinish_package_failure] upf
    LEFT JOIN base.[user] usr on upf.created_by = usr.id_user
	WHERE (@id_batch IS NULL OR id_batch=@id_batch) AND (remediated=@remediated)
    AND ((@start_date IS NULL AND @end_date IS NULL) OR (upf.date_created >= @start_date AND upf.date_created <= @end_date))
END
go

