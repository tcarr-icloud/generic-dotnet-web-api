CREATE PROCEDURE [inventory].[usp_complete_ride]
	@id_transfer INT,
	@id_user int
AS

        INSERT INTO inventory.ride_status_history (id_transfer, id_ride_status, id_user_verified)
		VALUES (@id_transfer, (select ride_status.id_ride_status from inventory.ride_status where reference = 'delivered'), @id_user)

		EXEC inventory.usp_transfer_list @id_transfer
go

