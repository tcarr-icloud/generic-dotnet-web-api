CREATE
    procedure [order].ecommerce_ride_list @id_ride int = null,
                                          @id_user int = null,
                                          @id_order int = null,
                                          @id_area int = null,
                                          @id_location int = null
as

declare
    @id_driver int = (select id_driver
                      from [order].driver
                      where id_user = @id_user)
declare
    @is_area_driver bit = case
                              when (select id_area_driver
                                    from inventory.area_driver
                                    where id_driver = @id_driver) is null then 0
                              else 1 end

select ride.*,
       driver_user.FirstName + ' ' + driver_user.LastName as driver1_name,
       o.date_created,
       o.type,
       c.name_first + ' ' + c.name_last                   as recipient_name,
       a.address1 + ', ' + a.address2                     as address,
       a.city,
       a.state,
       a.zip                                              as postal_code,
       a.zip_four,
       location.name                                      AS sender_name
        ,
       location.address                                   AS sender_address
        ,
       location.city                                      AS sender_city
        ,
       location.state                                     AS sender_state
        ,
       location.postal_code                               AS sender_postal_code,
       (SELECT top 1 ers.driver_message
        from [order].ecommerce_ride_status_history history
                 join [order].ecommerce_ride_status ers on ers.id_status = history.id_ride_status
        where ride.id_ride = history.id_ride
        ORDER BY history.created_at desc)                 as last_ride_status,
       isnull(
               (
                   select id_status_history, customer_message, driver_message, created_at
                   from [order].ecommerce_ride_status_history history
                            join [order].ecommerce_ride_status ers
                                 on ers.id_status = history.id_ride_status
                   where ride.id_ride = history.id_ride
                   order by history.created_at
                   for json path
               ), '[]'
           )                                              as status_list,
       (
           select item.id_item
                , ISNULL(ic.[name], 'Uncategorized') as category
                , ISNULL(ic.[path], 'Uncategorized') as category_path
                , i.item
                , id_area
                , b.[name]                           as batch
                , i.strain
                , i.uom
                , uom_short
                , item.quantity
           from [order].item
                    INNER JOIN inventory.batch b on b.id_batch = item.id_batch
                    INNER JOIN inventory.vw_item_list i on i.id_item = b.id_item
                    LEFT OUTER JOIN inventory.vw_category_list ic on ic.id_category = i.id_category
           where item.id_order = ride.id_order
           for json path
       )                                                  as pick_list
from [order].ecommerce_ride ride
         join [order].[order] o on o.id_order = ride.id_order
         join customer c on c.id_customer = o.id_customer
         left join [order].address a
                   on o.id_order = a.id_order
         left join [order].driver d on d.id_driver = ride.id_driver
         left join base.[user] driver_user on d.id_user = driver_user.id_user
         join inventory.area on ride.id_area = area.id_area
         join base.location on area.id_location = location.id_location
where (@id_ride IS NULL
    OR id_ride = @id_ride)
  AND (@id_user IS NULL
    OR ride.id_driver = @id_driver
    or (ride.id_driver is null and @is_area_driver = 0))
  AND (@id_order IS NULL
    OR ride.id_order = @id_order)
  AND (@id_area IS NULL
    OR ride.id_area = @id_area)
  and (@id_location IS NULL
    OR location.id_location = @id_location)
go

