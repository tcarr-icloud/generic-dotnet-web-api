CREATE PROCEDURE [order].[usp_sale_limit_upsert2]
	@id_sale_limit INT = NULL,
	@id_state INT,
	@deleted BIT,
	@limits VARCHAR(max),
	@id_user INT
AS
	/* insert new sale limit. */
	IF(@id_sale_limit IS NULL) 
	BEGIN
		INSERT INTO [order].sale_limit2 ([id_state], limits, id_user_created, id_user_updated)
		VALUES (@id_state, @limits, @id_user, @id_user)

		SET @id_sale_limit = SCOPE_IDENTITY()
	END
	/* update existing sale limit. */
	ELSE
	BEGIN
		UPDATE [order].sale_limit2
		SET	  [id_state]=@id_state
			, limits=@limits
			, deleted=ISNULL(@deleted, deleted)
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_sale_limit=@id_sale_limit
	END

	/* return new/updated sale limit. */
	EXEC [order].usp_sale_limit_list2 @id_sale_limit
go

