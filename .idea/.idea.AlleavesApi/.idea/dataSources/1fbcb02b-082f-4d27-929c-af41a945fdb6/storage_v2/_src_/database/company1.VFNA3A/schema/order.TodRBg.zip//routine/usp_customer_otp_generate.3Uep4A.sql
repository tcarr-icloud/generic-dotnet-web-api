
CREATE 
 PROCEDURE [order].[usp_customer_otp_generate] @id_customer int
AS

DECLARE @otp int = (SELECT FLOOR(RAND() * (100000 - 999999)) + 999999)

insert into [order].customer_otp (id_customer, otp, expiry_date)
values (@id_customer, @otp, dateadd(MINUTE, 10, getutcdate()));

select @otp as otp
go

