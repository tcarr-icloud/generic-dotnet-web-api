CREATE PROCEDURE [inventory].[usp_item_fetch]
	@id_item_group INT = NULL,
	@id_item INT = NULL,
	@item_name VARCHAR(512) = NULL
AS

	DECLARE 
		@Local_id_item INT = @id_item,
        @Local_id_item_group INT = @id_item_group,
        @Local_item_name VARCHAR(512) = @item_name;

	DECLARE @ResolvedID_Item_Group INT;

	IF @Local_id_item IS NOT NULL
		SET @ResolvedID_Item_Group = (SELECT TOP 1 id_item_group FROM inventory.item WHERE id_item=@Local_id_item);
	ELSE IF @Local_id_item_group IS NOT NULL
		SET @ResolvedID_Item_Group = @Local_id_item_group;
	ELSE IF @Local_item_name IS NOT NULL
		SET @ResolvedID_Item_Group = (SELECT TOP 1 id_item_group FROM inventory.item_group WHERE name = @Local_item_name);
		
	WITH AttributeListCTE AS (
		SELECT
			id.id_item_group,
			JSON_QUERY(ISNULL((SELECT ida.id_attribute, ida.id_item_group, a.name AS attribute
                           FROM inventory.item_group_attribute ida 
                           LEFT JOIN inventory.attribute a ON a.id_attribute = ida.id_attribute
                           WHERE ida.id_item_group = id.id_item_group
                           FOR JSON PATH), '[]')) AS attribute_list
		FROM inventory.item_group id
		WHERE id.id_item_group = @ResolvedID_Item_Group
	), MediaListCTE AS (
		SELECT
			id.id_item_group,
			JSON_QUERY(ISNULL((SELECT id_media, content, type
							   FROM inventory.item_media
							   WHERE item_media.id_item_group = id.id_item_group
							   FOR JSON PATH), '[]')) AS media_list
		FROM inventory.item_group id
		WHERE id.id_item_group = @ResolvedID_Item_Group
	), NutrientIngredientListCTE AS (
		SELECT
			id.id_item_group,
			JSON_QUERY(ISNULL((SELECT n.id_nutrient_ingredient, n.name, n.percentage
							   FROM inventory.item_group_nutrient_ingredient n
							   WHERE n.id_item_group = id.id_item_group
							   FOR JSON PATH), '[]')) AS nutrient_ingredient_list
		FROM inventory.item_group id
		WHERE id.id_item_group = @ResolvedID_Item_Group
	), ItemListCTE AS (
		SELECT
			id.id_item_group,
			JSON_QUERY(ISNULL((SELECT 
								  i.id_item_group
								, i.id_item
								, i.sku
								, i.barcode as item_barcode
								, i.cost_of_good
								, i.price_wholesale
								, i.price_retail
								, i.price_retail_medical_use
								, i.price_retail_adult_use
								, i.price_otd
								, i.price_otd_medical_use
								, i.price_otd_adult_use
								, i.use_otd_price
								, i.use_tiered_pricing
								, i.tiered_pricing
								, i.tiered_pricing_option
								, i.id_preset_tiered_pricing
								, i.show_price_total
								, i.flat_excise
								, i.weight_useable
								, i.weight_net
								, i.id_uom_weight_net
								, i.gross_weight_useable
								, i.id_uom_gross_weight_useable
								, i.metrc_item_id
								, i.metrc_category
								, i.biotrack_barcode_id
								, i.biotrack_inventory_type_id
								, i.vt_product_number
								, i.vt_product_name
								, i.vt_product_type
								, i.vt_business_name
								, biot.name as biotrack_inventory_type_name
								, biot.requires_weighing as biotrack_requires_weighing
								, i.external_id
								, ISNULL((SELECT il.id_item_location
												, il.id_item
												, il.id_location
												, ll.name AS location
												, il.cost_of_good
												, il.price_wholesale
												, il.price_retail
												, il.price_retail_medical_use
												, il.price_retail_adult_use
												, il.price_otd
												, il.price_otd_medical_use
												, il.price_otd_adult_use
												, il.use_location_otd_price
												, il.use_tiered_pricing
												, il.tiered_pricing
												, il.tiered_pricing_option
												, il.id_preset_tiered_pricing
												, il.show_price_total
												, il.flat_excise
												, il.metrc_item_id
												, il.metrc_name
												, il.metrc_category
												, il.metrc_brand
												, ll.metrc_facility_license_number
												, il.biotrack_barcode_id
												, il.biotrack_inventory_type_id
												, ll.is_metrc
												, il.location_threshold_low_quantity_value
												, il.location_threshold_low_quantity_selected
										  FROM inventory.item_location il
										  JOIN base.location ll ON ll.id_location=il.id_location
										  WHERE il.id_item=i.id_item AND il.deleted=0 AND ll.active = 1
										  FOR JSON PATH
								), '[]') AS location_list
								, ISNULL((SELECT av.id_attribute
												   , iav.id_attribute_value
												   , iav.id_item
												   , a.name AS attribute
												   , av.name AS attribute_value
										  FROM inventory.item_attribute_value iav
										  LEFT JOIN inventory.attribute_value av ON av.id_attribute_value = iav.id_attribute_value
										  LEFT JOIN inventory.attribute a ON a.id_attribute = av.id_attribute
										  WHERE iav.id_item = i.id_item
										  FOR JSON PATH
								), '[]') AS attribute_value_list
								, ISNULL((SELECT bg.id_bom_group
												, bg.id_item
												, bg.quantity
												, (SELECT bi.id_bom_item
														, bi.id_bom_group
														, bi.id_item
														, bii.item
														, bii.item_barcode
														, ISNULL(bii.cost_of_good, 0) as cost_of_good
														, bu.name AS uom
														, bu.name_short AS uom_short
													FROM process.bom_item bi
													JOIN inventory.vw_item_list bii ON bii.id_item=bi.id_item
													JOIN inventory.uom bu ON bu.id_uom=bii.id_uom
													WHERE bi.id_bom_group=bg.id_bom_group AND bi.deleted=0
													FOR JSON PATH
											) AS item_list
											FROM process.bom_group bg
											WHERE bg.id_item=i.id_item AND bg.deleted=0
											FOR JSON PATH
								), '[]') AS bom_list
								, ISNULL((SELECT id_media
												, content
												, [type]
										  FROM inventory.item_media
										  WHERE item_media.id_item = i.id_item
										  FOR JSON PATH
								), '[]') as media_list
								FROM inventory.item i
								LEFT JOIN biotrack.inventory_type biot ON biot.id_inventory_type=i.biotrack_inventory_type_id
								WHERE i.id_item_group = id.id_item_group AND i.deleted = 0
								FOR JSON PATH), '[]')) AS item_list
		FROM inventory.item_group id
		WHERE id.id_item_group = @ResolvedID_Item_Group
	)
	SELECT 
		 id.id_item_group
		, id.id_location
		, l.name AS location
		-- GENERAL
		, id.name AS item_group
		, id.is_global
		, id.id_category
		, c.name AS category
		, c.path AS category_path
		, id.id_tax_category
		, tc.name AS tax_category
		, r.id_raw_material
		, r.name AS raw_material
		, id.id_brand
		, br.name AS brand
		, id.id_vendor
		, v.name AS vendor
		, v.metrc_facility_license_number AS vendor_metrc_facility_license_number
		, id.is_cannabis
		, id.is_plant
		, id.is_seed
		-- STORAGE
		, id.id_uom
		, u.name AS uom
		, u.name_short AS uom_short
		, id.id_uom_receiving 
		, ur.name AS uom_receiving
		, id.units_per_received
		, id.batch_required
		, id.has_shelf_life
		, id.shelf_life_days
		, id.threshold_low_quantity
		, id.threshold_low_quantity_selected
		, conf.auto_close
		-- CANNABIS
		, id.id_strain
		, s.[name] as strain
		, id.id_uom_weight_useable
		, uw.name AS uom_weight_useable
		, uw.name_short AS uom_weight_useable_short
		, un.name_short AS uom_weight_net_short
		, id.thc
		, id.cbd
		, id.thc_mg
		, id.cbd_mg
		, id.id_delivery_route
		, dr.delivery_route AS delivery_route
		, dr.delivery_route_path
		, id.is_adult_use
		, id.is_medical_use
		, id.dosage_recommended
		, id.allergens
		, id.nutritional_information
		, id.servings
		, id.extraction_method
		, id.solvent_type
		, id.ingredients_list
		-- OMMU (Cannabis)
		, id.is_low_thc
		, id.is_medicated
		, id.is_smoking
		, id.is_low_thc_and_medical
		, id.id_ommu_form
		, id.is_ommu_delivery_device
		-- PLANT NUTRIENT
		, id.is_plant_nutrient
		, id.nutrient_type
		, id.nutrient_application_device
		-- PRODUCT
		, id.is_tax_exempt
		, id.is_product
		, id.product_description
		, id.deleted
		-- ADDITIONAL DETAIL OBJECTS --			
		-- attribute_list
		, al.attribute_list
		-- media_list
		, ml.media_list	
		-- nutrient_ingredient_list
		, nil.nutrient_ingredient_list
		-- item_list
		, il.item_list			 
	FROM inventory.item_group id
		 LEFT JOIN inventory.item i ON i.id_item_group = id.id_item_group
         LEFT JOIN inventory.vw_category_list c ON c.id_category=ISNULL(id.id_category, (SELECT TOP 1 id_category FROM inventory.category WHERE LOWER([name]) = 'uncategorized'))
         LEFT JOIN tax.category tc ON tc.id_tax_category = id.id_tax_category
		 LEFT JOIN inventory.vw_delivery_route dr ON dr.id_delivery_route = id.id_delivery_route
         LEFT JOIN inventory.uom u ON u.id_uom = id.id_uom
         LEFT JOIN inventory.uom ur ON ur.id_uom = id.id_uom_receiving
         LEFT JOIN inventory.uom uw ON uw.id_uom = id.id_uom_weight_useable
		 LEFT JOIN inventory.uom un ON un.id_uom = i.id_uom_weight_net
	     LEFT JOIN base.location l ON l.id_location=id.id_location
         LEFT JOIN inventory.brand br ON br.id_brand = id.id_brand
		 LEFT JOIN inventory.vendor v ON v.id_vendor=id.id_vendor
		 LEFT JOIN inventory.raw_material r ON r.id_raw_material=id.id_raw_material
		 LEFT JOIN grow.strain s ON s.id_strain=id.id_strain
		 LEFT JOIN AttributeListCTE al on al.id_item_group = id.id_item_group
		 LEFT JOIN MediaListCTE ml on ml.id_item_group = id.id_item_group
		 LEFT JOIN NutrientIngredientListCTE nil on nil.id_item_group = id.id_item_group
		 LEFT JOIN ItemListCTE il on il.id_item_group = id.id_item_group
		 LEFT JOIN (SELECT id_location, auto_close FROM pos.configuration) as conf 
			ON id.id_location = conf.id_location
	WHERE id.id_item_group = @ResolvedID_Item_Group
go

