CREATE PROCEDURE [order].[usp_driver_list_id_user]
	@id_user INT = NULL
AS
	SELECT u.id_user AS id_user_alleaves
			, d.id_driver
			, l.id_location
			, u.FirstName AS name_first
			, u.LastName AS name_last
	        , u.Email as email
	        , u.PhoneNumber as phone_number
	        , u.UserName as user_name
			, d.license
	        , d.lat
	        , d.long
	        , d.journey_started
			, l.name AS location
	FROM base.[user] u
	LEFT JOIN [order].driver d ON d.id_user=u.id_user
	LEFT JOIN base.location l ON l.id_location=d.id_location
	WHERE (@id_user IS NOT NULL AND d.id_user=@id_user) OR
		  (@id_user IS NULL AND 1=(CASE WHEN d.license IS NULL THEN 0 ELSE 1 END) AND
			u.id_user<>-1 AND
			u.Email NOT LIKE 'TERM-%')
	ORDER BY u.LastName
go

