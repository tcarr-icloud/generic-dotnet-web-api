CREATE PROCEDURE [grow].[usp_nutrient_list]
	@id_location INT,
	@id_plant INT,
	@id_nutrient INT,
	@start_row INT = 0,
	@end_row INT = 100,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
	SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT id_nutrient
					, id_item_group
					, id_item
					, id_batch
					, id_plant
					, id_location
					, id_area
					, location
					, area
					, plant
					, item
					, batch
					, uom
					, total_quantity
					, plant_count
					, CAST(total_quantity / plant_count AS DECIMAL(18,8)) AS quantity_to_plant
					, applied_by
					, date_created
			FROM (
				SELECT n.id_nutrient
						, g.id_item_group
						, i.id_item
						, b.id_batch
						, p.name AS plant
						, g.name AS item
						, b.name AS batch
						, p.id_plant
						, u.name AS uom
						, n.quantity AS total_quantity
						, (SELECT COUNT(*) FROM grow.nutrient_plant np WHERE np.id_nutrient=n.id_nutrient) AS plant_count
						, CONCAT(us.FirstName, '' '', us.LastName) AS applied_by
						, a.path AS area
						, a.id_area
						, l.id_location
						, l.name AS location
						, n.date_created
				FROM grow.nutrient n
				JOIN inventory.batch b ON b.id_batch=n.id_batch
				JOIN inventory.item i ON i.id_item=b.id_item
				JOIN inventory.item_group g ON g.id_item_group=i.id_item_group
				JOIN inventory.uom u ON u.id_uom=g.id_uom
				JOIN grow.nutrient_plant np ON np.id_nutrient=n.id_nutrient
				JOIN grow.plant p ON p.id_plant=np.id_plant
				JOIN base.[user] us ON us.id_user=n.id_user_created
				JOIN inventory.vw_area_list a ON a.id_area=p.id_area
				JOIN base.location l ON l.id_location=a.id_location
				LEFT JOIN inventory.vendor v ON v.id_vendor=g.id_vendor
			) n'
	
	SET @where = 'WHERE id_plant = '+ ISNULL(CAST(@id_plant AS VARCHAR(16)), 'id_plant')
	SET @where = @where + CASE WHEN @id_location IS NULL THEN '' ELSE ' AND id_location = '+ CAST(@id_location AS VARCHAR(16)) END
	SET @where = @where + CASE WHEN @id_nutrient IS NULL THEN '' ELSE ' AND id_nutrient = '+ CAST(@id_nutrient AS VARCHAR(16)) END
	
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'plant')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order


	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

