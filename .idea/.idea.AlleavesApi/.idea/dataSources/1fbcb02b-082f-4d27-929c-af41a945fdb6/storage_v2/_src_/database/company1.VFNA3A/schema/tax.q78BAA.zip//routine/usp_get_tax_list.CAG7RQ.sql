CREATE PROCEDURE [tax].[usp_get_tax_list]
	@id_tax INT = NULL
AS
	SELECT tt.*,
		ISNULL((
			SELECT tv.id_vendor,
				iv.name as vendor
			FROM [tax].[vendor] tv
			LEFT JOIN [inventory].[vendor] iv ON iv.id_vendor = tv.id_vendor
			WHERE tv.id_tax = ISNULL(@id_tax, tt.id_tax) AND tv.active = 1
		FOR JSON PATH), '[]') as vendor_list,
		ISNULL((
				SELECT tc.id_tax_group,
					tcv.id_tax,
					tc.name
				FROM [tax].[group_value] tcv
				LEFT JOIN [tax].[group] tc ON tc.id_tax_group = tcv.id_tax_group
				WHERE tcv.active=1 AND tc.active=1 AND tcv.id_tax=tt.id_tax
			FOR JSON PATH), '[]') as tax_group_list
	FROM [tax].[tax] tt
	WHERE tt.active = 1 AND tt.id_tax=ISNULL(@id_tax, tt.id_tax)
	ORDER BY tt.stacking_order, tt.name
go

