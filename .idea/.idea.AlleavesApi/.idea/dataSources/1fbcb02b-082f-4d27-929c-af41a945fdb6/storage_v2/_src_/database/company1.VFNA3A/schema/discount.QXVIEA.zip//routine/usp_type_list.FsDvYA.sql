CREATE PROCEDURE [discount].[usp_type_list]
AS
	SELECT id_type
			, name AS discount_type
			, reference AS discount_type_reference
	FROM discount.type
go

