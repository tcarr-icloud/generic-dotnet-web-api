CREATE PROCEDURE [pos].[usp_withdrawal]
	@id_session INT,
	@amount DECIMAL(18,2),
	@reason varchar(50),
	@notes varchar(max),
	@id_safe int,
	@id_user int,
	@id_manager int,
	@closing_deposit bit
AS
BEGIN
	DECLARE @id_user_withdrawal INT = ISNULL(@id_manager, @id_user);

	INSERT INTO pos.withdrawal (id_session, amount, id_safe, reason, closing_deposit, notes, created_by)
	VALUES (@id_session, @amount, @id_safe, @reason, @closing_deposit, @notes, @id_user_withdrawal);

	IF(@reason = 'Deposit')
	BEGIN
		EXEC [cash].[usp_safe_amount_adjust] @id_session, @amount, @reason, @notes, @notes, @id_safe, @id_user_withdrawal, @closing_deposit 
	END

	SELECT 1;
END;
go

