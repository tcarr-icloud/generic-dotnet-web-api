
CREATE VIEW
--CREATE VIEW
[order].[vw_metrc_order_items] as (
SELECT o.id_order
,oi.[id_inventory_item] as id_inventory_item
,ii.[id_item_group]
,l.[name] as 'location'
,o.[type] as order_type
,r.[name] as register_name
,s.id_session
,o.date_created as utc_created_datetime
,CAST(o.date_created AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as local_created_datetime
,CAST(o.[date_paid] AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as local_paid_datetime
,o.paid_in_full
,o.id_status
,iig.id_category
,i.item as product
,ISNULL(ivc.[name], 'Uncategorized') as product_category
,ISNULL(ivc.[path], 'Uncategorized') as product_category_path
,ii.[metrc_category]
,iu.[quantity_type]
,iu.[name] as inventory_base_name
,CASE
WHEN (iu.[quantity_type] = 'count')
THEN (oi.[quantity])
ELSE NULL
END as quantity_each
,CASE
WHEN (iu.[quantity_type] = 'weight')
THEN (oi.[quantity]*(ii.weight_useable * iuc.multiplier))
ELSE NULL
END as weight_sold_grams
,ib.metrc_package_label
,CONCAT(metrcq.metrc_package_label, metrcq.id_order) as 'transaction'
,ii.[metrc_item_id]
,oi.[id_batch]
,ib.[name] as batch_number
,gs.[name] as strain
,ibb.[name] as brand
,iv.[name] as vendor
,iig.[is_cannabis]
,iig.[is_medical_use]
,idr.[name] as delivery_route
,CASE
WHEN idr.[id_parent] IS NULL
THEN idr.[name]
ELSE idr2.[name]
END as 'parent_delivery_route'
,c.name_first + ' ' + c.name_last as customer
,cr.FirstName + ' ' + cr.LastName as created_by_employee
,ii.cost_of_good as cost_of_good_per
,ii.price_retail as retail_price_per
,oi.price
,oi.price_override
,oi.discount
,oi.price_post_item_discount
,oi.price_post_order_discount
,oi.price_post_tax
,oi.price_post_tax as order_item_total
,oi.[price_post_tax] - oi.[price_post_order_discount] as item_tax
FROM [order].[order] o
LEFT JOIN [order].[item] oi on oi.id_order = o.id_order
LEFT JOIN [pos].[session] s on o.id_session = s.id_session
LEFT JOIN [pos].register r on r.id_register = s.id_register
LEFT JOIN inventory.batch ib on ib.id_batch = oi.id_batch
LEFT JOIN inventory.vw_item_list i on i.id_item = ib.id_item
LEFT JOIN inventory.vw_category_list ivc on ivc.id_category = i.id_category
LEFT JOIN [inventory].[item] ii ON ib.id_item = ii.id_item
LEFT JOIN [inventory].[item_group] iig ON ii.[id_item_group] = iig.[id_item_group]
LEFT JOIN [inventory].[category] ic on iig.id_category = ic.id_category
LEFT JOIN [base].[location] l on l.id_location = o.id_location
LEFT JOIN [dbo].[tz_lookup] tl ON l.[timezone] = tl.[tz_iana]
LEFT JOIN [inventory].[uom] iu ON ib.id_uom_metrc = iu.id_uom
LEFT JOIN [inventory].[uom_convert] iuc ON iu.id_uom = iuc.id_uom_from
LEFT JOIN [grow].[strain] gs ON ib.[id_strain] = gs.[id_strain]
LEFT JOIN [order].[customer] c on c.id_customer = o.id_customer
LEFT JOIN [base].[user] cr on cr.id_user = o.created_by
LEFT JOIN [inventory].[brand] ibb on iig.[id_brand] = ibb.[id_brand]
LEFT JOIN [inventory].[vendor] iv on iig.[id_vendor] = iv.[id_vendor]
LEFT JOIN [inventory].[delivery_route] idr ON iig.[id_delivery_route] = idr.[id_delivery_route]
LEFT JOIN [inventory].[delivery_route] as idr2 ON idr2.[id_delivery_route] = idr.[id_parent] LEFT JOIN
(SELECT
oo.[id_order]
,oi.id_item
,ib.metrc_package_label
,oo.metrc_receipt_id
,oi.[quantity]
,oi.[price_post_tax]
,oo.[date_paid]
,oo.[created_by]
,oo.[updated_by]
,oo.[date_created]
,oo.[date_updated]
,ii.[metrc_category]
FROM [order].[order] oo
LEFT JOIN [order].[item] oi ON oo.id_order = oi.id_order
LEFT JOIN [inventory].[batch] ib ON oi.id_batch = ib.id_batch
LEFT JOIN [inventory].[item] ii ON ib.id_item = ii.id_item
LEFT JOIN [inventory].[item_group] iig ON ii.id_item_group = iig.id_item_group
LEFT JOIN [order].[item] oii ON oi.id_item = oii.id_item_return
LEFT JOIN [base].[location] l on l.[id_location] = oo.[id_location]
LEFT JOIN [dbo].[tz_lookup] as tl ON l.[timezone] = tl.[tz_iana]
LEFT JOIN [inventory].[uom] iu ON ib.[id_uom_metrc] = iu.[id_uom]
WHERE
oo.void = 0
AND oo.cancel = 0
AND ib.metrc_package_label IS NOT NULL
AND metrc_receipt_id IS NOT NULL
AND oi.id_item_return IS NULL
AND oii.id_item_return IS NULL
AND oi.[price_post_tax] > 0 ) as metrcq ON oi.id_item = metrcq.id_item
WHERE metrcq.id_order IS NOT NULL
)
go

