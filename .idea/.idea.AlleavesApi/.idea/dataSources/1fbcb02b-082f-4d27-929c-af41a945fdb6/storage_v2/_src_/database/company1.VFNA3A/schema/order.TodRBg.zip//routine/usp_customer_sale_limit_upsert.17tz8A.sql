CREATE PROCEDURE [order].[usp_customer_sale_limit_upsert]
	@id_sale_limit INT = NULL,
	@id_customer INT,
	@id_state INT,
	@deleted BIT,
	@limits VARCHAR(MAX),
	@id_user INT
AS
	/* insert new customer sale limit */
	IF(@id_sale_limit IS NULL) 
	BEGIN
		INSERT INTO [order].[customer_sale_limit] (id_customer, id_state, limits, id_user_created, id_user_updated)
		VALUES (@id_customer, @id_state, @limits, @id_user, @id_user)

		SET @id_sale_limit = SCOPE_IDENTITY()
	END
	/* update existing customer sale limit */
	ELSE
	BEGIN
		UPDATE [order].[customer_sale_limit]
		SET	  [id_customer]=@id_customer
			, [id_state]=@id_state
			, limits=@limits
			, deleted=ISNULL(@deleted, deleted)
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_sale_limit=@id_sale_limit
	END

	/* return new/updated sale limit. */
	EXEC [order].[usp_customer_sale_limit_list] @id_sale_limit, @id_customer
go

