CREATE PROCEDURE [inventory].[usp_inventory_move]
	@id_area_destination INT,
	@list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	SET NOCOUNT ON;

	/* loop through batch list and update inventory. */
	DECLARE @id_batch INT, 
			@id_area INT,
			@quantity DECIMAL(18,4), 
			@quantity_neg DECIMAL(18,4)

	DECLARE item_cursor CURSOR FAST_FORWARD FOR 
	SELECT * FROM OPENJSON(@list)
	WITH (
		id_batch INT,
		id_area INT,
		quantity DECIMAL(18,4)
	)
	WHERE quantity>0
		
	OPEN item_cursor
	FETCH NEXT FROM item_cursor INTO @id_batch, @id_area, @quantity
		
	WHILE(@@FETCH_STATUS = 0)
	BEGIN
		/* check for current quantity. */
		DECLARE @curr_val DECIMAL(18,4) = (SELECT TOP 1 quantity FROM inventory.inventory WHERE id_batch=@id_batch AND id_area=@id_area)
		IF @curr_val < @quantity
			SET @quantity = @curr_val
		IF @curr_val IS NOT NULL AND @quantity > 0
		BEGIN
			SET @quantity_neg = -@quantity

			/* move item. */
			EXEC [log].usp_event_create 'inventory_move', @id_batch, @id_area, @quantity_neg, NULL, @id_user, 1
			EXEC [log].usp_event_create 'inventory_move', @id_batch, @id_area_destination, @quantity, NULL, @id_user, 1
		END

		FETCH NEXT FROM item_cursor INTO @id_batch, @id_area, @quantity
	END

	CLOSE item_cursor
	DEALLOCATE item_cursor

	/* create move log. */
go

