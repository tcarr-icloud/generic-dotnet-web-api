CREATE PROCEDURE [order].[usp_order_set_flag]
	@id_order INT,
	@flag VARCHAR(32),
	@flag_value BIT
AS
	SET NOCOUNT ON;

	DECLARE @query VARCHAR(MAX);
	DECLARE @column VARCHAR(50);
	SELECT @column = COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'order' AND TABLE_SCHEMA = 'ORDER' AND COLUMN_NAME = @flag

	SET @query='
	UPDATE [order].[order] 
	SET '+@column+'='+CAST(@flag_value AS VARCHAR(1))+',
		date_updated=getutcdate()
	WHERE id_order= ' + CAST(@id_order AS VARCHAR(32))

	EXEC (@query)

	SELECT 1 AS rtn
go

