CREATE PROCEDURE [pos].[usp_payment_method_update]
	@id_payment_method INT,
	@id_user INT,
	@name VARCHAR(256),
	@enabled BIT
AS
	UPDATE [pos].[payment_methods] 
	SET name = @name, id_user_modified_by = @id_user, enabled = @enabled 
	WHERE id_payment_method = @id_payment_method
	
	SELECT id_payment_method, id_location, [name], enabled, deleted, date_created, id_user_created_by, id_user_modified_by 
	FROM [pos].[payment_methods] 
	WHERE id_payment_method = @id_payment_method
go

