CREATE PROCEDURE [customer].[usp_file_list]
	 @id_customer INT
	,@id_file INT
AS
	SELECT
		 f.id_file
		,f.id_customer
		,f.[filename]
		,f.[label]
		,f.[key]
		,ISNULL(c.FirstName, '??') + ' ' + ISNULL(c.LastName, '??') as created_by
		,ISNULL(u.FirstName, '??') + ' ' + ISNULL(u.LastName, '??') as updated_by
		,date_created
		,date_updated
	FROM [customer].[file] f
	INNER JOIN [base].[user] c ON c.id_user = f.id_user_created
	INNER JOIN [base].[user] u ON u.id_user = f.id_user_updated
	WHERE 
		(@id_customer IS NULL OR f.id_customer = @id_customer)
	AND	(@id_file IS NULL OR  f.id_file = @id_file)
go

