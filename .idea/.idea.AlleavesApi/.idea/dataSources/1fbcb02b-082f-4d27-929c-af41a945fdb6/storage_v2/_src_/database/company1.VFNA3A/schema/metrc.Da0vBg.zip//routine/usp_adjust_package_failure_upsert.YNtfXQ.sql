CREATE PROCEDURE [metrc].[usp_adjust_package_failure_upsert]
	@id_adjust_failure INT = NULL,
	@id_adjust_reason INT,
	@adjust_reason VARCHAR(MAX) = NULL,
	@list VARCHAR(MAX) = '[]',
	@fail_reason VARCHAR(MAX) = NULL,
	@remediated BIT = 0,
	@id_user INT
AS
	SET NOCOUNT ON;


	IF (@id_adjust_failure IS NOT NULL)
	BEGIN
		UPDATE [metrc].[adjust_package_failure]
		SET remediated=@remediated, updated_by=@id_user, date_updated=GETUTCDATE()
		WHERE id_adjust_failure = @id_adjust_failure
	END
	ELSE
	BEGIN
		/* get adjust reason text. */
		DECLARE @notes VARCHAR(MAX)
		SET @notes = (SELECT name FROM inventory.adjust_reason WHERE id_adjust_reason=@id_adjust_reason)

		IF(@adjust_reason IS NOT NULL)
			SET @notes = CONCAT(@notes, '; ', @adjust_reason)

		/* loop through batch list and update inventory. */
		DECLARE @id_area INT, @id_batch INT, @adjustment DECIMAL(18,4)
		DECLARE item_cursor CURSOR FAST_FORWARD FOR 
		SELECT * FROM OPENJSON(@list)
		WITH (
			id_area INT '$.id_area',
			id_batch INT '$.id_batch',
			adjustment DECIMAL(18,4) '$.adjustment'
		)
		WHERE adjustment<>0
		
		OPEN item_cursor
		FETCH NEXT FROM item_cursor INTO @id_area, @id_batch, @adjustment
		
		WHILE(@@FETCH_STATUS = 0)
		BEGIN
			/* get current value. */
			DECLARE @curr_val DECIMAL(18,4) = (SELECT TOP 1 quantity FROM inventory.inventory WHERE id_batch=@id_batch AND id_area=@id_area)

			INSERT INTO [metrc].[adjust_package_failure] (id_batch, id_area, original_quantity, adjustment, notes, fail_reason, remediated, created_by, updated_by)
			VALUES (@id_batch, @id_area, ISNULL(@curr_val , 0), @adjustment, @notes, @fail_reason, 0, @id_user, @id_user)
		
			FETCH NEXT FROM item_cursor INTO @id_area, @id_batch, @adjustment
		END

		CLOSE item_cursor
		DEALLOCATE item_cursor
	END
go

