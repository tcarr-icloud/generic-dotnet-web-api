CREATE FUNCTION [base].[fn_barcode_human_readable]
(
	@barcode VARCHAR(512)
)
RETURNS VARCHAR(512)
AS
BEGIN
	IF (@barcode IS NULL) RETURN ''

	IF (@barcode NOT LIKE '[A-Z][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
		RETURN @barcode

	RETURN CONCAT(SUBSTRING(@barcode, 1, 5), ' ', SUBSTRING(@barcode, 6, 4), ' ', SUBSTRING(@barcode, 10, 4), ' ', SUBSTRING(@barcode, 14, 4))
END
go

