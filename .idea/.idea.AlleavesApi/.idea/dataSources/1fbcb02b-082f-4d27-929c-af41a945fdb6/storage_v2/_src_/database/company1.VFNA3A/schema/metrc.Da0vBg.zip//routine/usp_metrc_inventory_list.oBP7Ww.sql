CREATE PROCEDURE [metrc].[usp_metrc_inventory_list]
	@id_location INT = NULL
AS

/* main list of batches to use. */
DROP TABLE IF EXISTS #inv_lookup
SELECT inv.id_batch, inv.id_area
INTO #inv_lookup
FROM [log].event inv
JOIN (
	SELECT id_batch, MAX(id_event) as id_event
	FROM [log].vw_event_list
	WHERE id_type=1
	GROUP BY id_batch

	UNION ALL 

	SELECT id_batch, MAX(id_event) as id_event
	FROM [log].vw_event_list
	WHERE id_batch NOT IN (SELECT distinct id_batch FROM [log].event WHERE id_type=1)
	GROUP BY id_batch
) e ON e.id_event=inv.id_event

/* quantities in cart. */
DROP TABLE IF EXISTS #cart
SELECT oi.id_batch
		, oi.uom
		, oi.weight_useable
		, oi.weight_useable_uom
		, SUM(oi.quantity) AS in_cart_total
INTO #cart
FROM [order].[order] oo
LEFT JOIN [order].[item] oi ON oi.id_order = oo.id_order
WHERE paid_in_full <> 1 AND void = 0 AND cancel = 0 AND ommu_dispensed = 0 AND id_batch IS NOT NULL
GROUP BY oi.id_batch, oi.uom, oi.weight_useable, oi.weight_useable_uom

/* quantities with metrc fails. */
DROP TABLE IF EXISTS #fails
SELECT id_batch,
	uom,
	weight_useable,
	weight_useable_uom,
	SUM(in_cart_total) as total_quantity
INTO #fails
FROM
(
	SELECT oi.id_batch
		, oi.uom
		, oi.weight_useable
		, oi.weight_useable_uom
		, SUM(oi.quantity) AS in_cart_total
FROM [metrc].[sale_failure] sf
LEFT JOIN [order].[order] oo ON oo.id_order = sf.id_order
LEFT JOIN [order].[item] oi ON oi.id_order = oo.id_order
LEFT JOIN [inventory].[batch] ib ON ib.id_batch = oi.id_batch
WHERE sf.remediated = 0 AND oo.paid_in_full = 1 AND oo.void = 0 AND oo.cancel = 0
AND ib.metrc_package_label IS NOT NULL
AND ommu_dispensed = 0 AND oi.id_batch IS NOT NULL
GROUP BY oi.id_batch, oi.uom, oi.weight_useable, oi.weight_useable_uom
UNION 
	SELECT oi.id_batch
		, oi.uom
		, oi.weight_useable
		, oi.weight_useable_uom
		, SUM(oi.quantity) AS in_cart_total
FROM [metrc].[update_sale_failure] usf
LEFT JOIN [order].[order] oo ON oo.id_order = usf.id_order
LEFT JOIN [order].[item] oi ON oi.id_order = oo.id_order
LEFT JOIN [inventory].[batch] ib ON ib.id_batch = oi.id_batch
WHERE usf.remediated = 0 AND oo.paid_in_full = 1 AND oo.void = 0 AND oo.cancel = 0
AND ib.metrc_package_label IS NOT NULL
AND ommu_dispensed = 0 AND oi.id_batch IS NOT NULL
GROUP BY oi.id_batch, oi.uom, oi.weight_useable, oi.weight_useable_uom
) fa
GROUP BY fa.id_batch, fa.uom, fa.weight_useable, fa.weight_useable_uom

/* current inventory quantities. */
DROP TABLE IF EXISTS #inv
SELECT id_batch
		, SUM(on_hand) AS on_hand
		, SUM(available) AS available
		INTO #inv
FROM inventory.vw_current_inventory
GROUP BY id_batch


/* main query. */
SELECT DISTINCT
		b.id_batch
		, i.id_item
		, i.id_item_group
		, ia.id_location AS id_location
		, RTRIM(CONCAT(ig.name, ' ', (
					SELECT STRING_AGG(av.name, ' ') 
					FROM inventory.item_attribute_value iav
					LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
					WHERE iav.id_item=i.id_item)
				)) AS item_name
		, ISNULL(b.name, 'N/A') AS batch_name
		, l.name as location_name
		, ia.path AS area
		, l.metrc_facility_license_number
		, bs.name as full_state_name
		, b.metrc_package_label
		, inv.on_hand
		, inv.available
		, u.name AS uom
		, u.name_short AS uom_short
		, i.weight_useable
		, (ISNULL(inv.on_hand, 0) * ISNULL(i.weight_useable, 0)) as on_hand_weight_useable
		, (ISNULL(inv.available, 0) * ISNULL(i.weight_useable, 0)) as available_weight_useable
		, uu.name as weight_useable_uom
		, uu.name_short as weight_useable_uom_short
		, cart.in_cart_total as in_cart_total_quantity
		, cart.uom as in_cart_uom
		, (cart.in_cart_total * cart.weight_useable) as in_cart_weight_useable
		, cart.weight_useable_uom as in_cart_weight_useable_uom
		, fails.total_quantity as failed_sales_total_quantity
		, fails.uom as failed_sales_uom
		, (ISNULL(fails.total_quantity, 0) * ISNULL(fails.weight_useable, 0)) as failed_sales_weight_useable
		, fails.weight_useable_uom as failed_sales_weight_useable_uom
		, pa.pending_adjustment_total_quantity
		, pa.pending_adjustment_uom
FROM #inv_lookup invi
LEFT JOIN inventory.vw_area_list ia ON ia.id_area = invi.id_area
LEFT JOIN base.[location] l ON l.id_location = ia.id_location
LEFT JOIN base.[states] bs ON bs.abbreviation = l.[state]
LEFT JOIN inventory.batch b on b.id_batch = invi.id_batch
LEFT JOIN inventory.item i ON i.id_item=b.id_item
LEFT JOIN inventory.item_group ig ON ig.id_item_group=i.id_item_group
LEFT JOIN inventory.uom u ON u.id_uom=ig.id_uom
LEFT OUTER JOIN inventory.uom uu ON uu.id_uom=ig.id_uom_weight_useable
LEFT JOIN #inv inv ON inv.id_batch=b.id_batch
LEFT JOIN #cart cart ON cart.id_batch=b.id_batch
LEFT JOIN #fails fails ON fails.id_batch=b.id_batch
LEFT JOIN (
	SELECT mqa.id_batch
		, SUM(mqa.adjustment) as pending_adjustment_total_quantity
		, u.name as pending_adjustment_uom
	FROM [metrc].[queued_adjustment] mqa
	LEFT JOIN [inventory].[uom] u ON mqa.id_uom = u.id_uom
	WHERE sent_to_metrc = 0 AND ignored = 0
	GROUP BY mqa.id_batch, u.name
) pa ON pa.id_batch=b.id_batch
WHERE b.metrc_package_label IS NOT NULL AND ia.id_location=ISNULL(@id_location, ia.id_location) AND b.id_status=1
go

