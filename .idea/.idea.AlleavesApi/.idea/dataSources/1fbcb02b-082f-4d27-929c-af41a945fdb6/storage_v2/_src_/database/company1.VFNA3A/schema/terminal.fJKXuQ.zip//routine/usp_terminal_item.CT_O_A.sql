CREATE PROCEDURE terminal.usp_terminal_item
	@terminal_key VARCHAR(256),
	@id_terminal INT,
	@include_deleted BIT = 0
AS
BEGIN
	SELECT 
		id_terminal,
	    [name] AS terminal,
	    terminal_key,
		id_register,
	    id_user_created_by
	FROM terminal.terminal	
	WHERE (@id_terminal IS NULL OR id_terminal = @id_terminal)
	AND (@terminal_key IS NULL OR terminal_key = @terminal_key)
	AND (@id_terminal IS NOT NULL OR @terminal_key IS NOT NULL)
	AND deleted <= @include_deleted
END
go

