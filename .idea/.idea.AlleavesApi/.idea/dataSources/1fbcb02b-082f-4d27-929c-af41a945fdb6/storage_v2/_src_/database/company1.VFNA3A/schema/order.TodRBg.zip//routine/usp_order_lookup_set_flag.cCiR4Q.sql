CREATE PROCEDURE [order].[usp_order_lookup_set_flag]
	@id_order_lookup INT,
	@flag VARCHAR(32),
	@flag_value BIT
AS
	SET NOCOUNT ON;

	DECLARE @query VARCHAR(MAX);
	DECLARE @column VARCHAR(50);
	SELECT @column = COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'order_lookup' AND TABLE_SCHEMA = 'ORDER' AND COLUMN_NAME = @flag

	SET @query='
	UPDATE [order].[order_lookup] 
	SET '+@column+'='+CAST(@flag_value AS VARCHAR(1))+',
		date_updated=getutcdate()
	WHERE id_order_lookup= ' + CAST(@id_order_lookup AS VARCHAR(32))

	EXEC (@query)

	EXEC [order].usp_order_lookup_list @id_order_lookup
go

