CREATE PROCEDURE [inventory].[usp_get_inventory_base_data]
@id_batch INT,
@id_area INT,
@id_location INT
AS
SET NOCOUNT ON;
SELECT inv.id_batch
			,inv.id_area
			,l.id_location
			,l.[name] AS [location]
			,a.[name] AS area
			,a.[path] AS area_path
			,aty.[name] AS area_type
			,a.mobile AS mobile
			,inv.quantity AS available
			,a.priority as priority
		FROM inventory.inventory inv
		INNER JOIN inventory.vw_area_list a ON inv.id_area = a.id_area
		INNER JOIN inventory.area_type aty ON aty.id_area_type = a.id_area_type
		INNER JOIN [base].[location] l ON l.id_location = a.id_location
		WHERE 1=1
		AND l.id_location = ISNULL(@id_location, l.id_location)
		AND inv.id_batch = ISNULL(@id_batch, inv.id_batch)
		AND inv.id_area = ISNULL(@id_area, inv.id_area)
go

