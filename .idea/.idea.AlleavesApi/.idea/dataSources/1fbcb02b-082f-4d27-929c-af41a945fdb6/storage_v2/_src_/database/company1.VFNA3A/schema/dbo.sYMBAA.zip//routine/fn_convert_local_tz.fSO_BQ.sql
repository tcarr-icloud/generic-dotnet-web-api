CREATE FUNCTION [dbo].[fn_convert_local_tz]
(
	@param1 int,
	@param2 int
)
RETURNS INT
AS
BEGIN
	RETURN @param1 + @param2
END
go

