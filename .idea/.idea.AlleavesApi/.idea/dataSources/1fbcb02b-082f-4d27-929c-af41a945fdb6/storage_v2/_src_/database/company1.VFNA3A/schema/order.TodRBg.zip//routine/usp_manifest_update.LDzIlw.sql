
CREATE PROCEDURE [order].[usp_manifest_update]
	@id_manifest INT,
	@origin_name VARCHAR(128),
	@origin_address VARCHAR(128),
	@origin_city VARCHAR(128),
	@origin_state VARCHAR(128),
	@origin_postal_code VARCHAR(32),
	@customer_name VARCHAR(128),
	@customer_patient_number VARCHAR(32),
	@customer_address VARCHAR(128),
	@customer_city VARCHAR(128),
	@customer_state VARCHAR(128),
	@customer_postal_code VARCHAR(32),
	@customer_phone VARCHAR(32),
	@driver_1_name VARCHAR(128),
	@driver_1_license VARCHAR(32),
	@driver_2_name VARCHAR(128),
	@driver_2_license VARCHAR(32),
	@vehicle_make VARCHAR(32),
	@vehicle_model VARCHAR(32),
	@vehicle_plate VARCHAR(32),
	@id_user INT
AS
	SET NOCOUNT ON;

	UPDATE [order].[manifest]
	SET origin_name=@origin_name,
		origin_address=@origin_address,
		origin_city=@origin_city,
		origin_state=@origin_state,
		origin_postal_code=@origin_postal_code,
		customer_name=@customer_name,
		customer_patient_number=@customer_patient_number,
		customer_address=@customer_address,
		customer_city=@customer_city,
		customer_state=@customer_state,
		customer_postal_code=@customer_postal_code,
		customer_phone=@customer_phone,
		driver_1_name=@driver_1_name,
		driver_1_license=@driver_1_license,
		driver_2_name=@driver_2_name,
		driver_2_license=@driver_2_license,
		vehicle_make=@vehicle_make,
		vehicle_model=@vehicle_model,
		vehicle_plate=@vehicle_plate,
		updated_by=@id_user,
		date_updated=getutcdate()
	WHERE id_manifest=@id_manifest

	DELETE FROM [order].[manifest_item] WHERE id_manifest=@id_manifest


	SELECT m.id_manifest
			, m.id_order_lookup
			, m.origin_name
			, m.origin_address
			, m.origin_city
			, m.origin_state
			, m.origin_postal_code
			, m.stop_number
			, m.customer_name
			, m.customer_patient_number
			, m.customer_address
			, m.customer_city
			, m.customer_state
			, m.customer_postal_code
			, m.customer_phone
			, m.driver_1_name
			, m.driver_1_license
			, m.driver_2_name
			, m.driver_2_license
			, m.vehicle_make
			, m.vehicle_model
			, m.vehicle_plate
	FROM [order].[manifest] m
	WHERE id_manifest=@id_manifest
go

