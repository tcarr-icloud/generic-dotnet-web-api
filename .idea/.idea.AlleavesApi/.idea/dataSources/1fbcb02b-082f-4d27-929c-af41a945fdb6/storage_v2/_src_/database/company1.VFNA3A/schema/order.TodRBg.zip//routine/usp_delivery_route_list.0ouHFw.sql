CREATE PROCEDURE [order].[usp_delivery_route_list]
	@id_delivery_route INT = NULL,
	@id_driver INT = NULL,@id_location int=null
AS
    SELECT dr.id_driver,u.id_user, u.FirstName AS name_first, u.LastName AS name_last, dr.id_driver, 
	status, dr.delivery_start_time,dr.delivery_start_date,dr.id_delivery_route,dr.delivery_end_eta,
           ISNULL((SELECT rdr.id_ride as id_ride_id,rdr.position,rdr.eta, er.*,
                 a.address1
				,a.address2
				,a.city
				,a.[state]
				,a.zip
				,a.zip_four
				,a.note
				,a.id_driver1
				,a.id_vehicle
			    ,a.lat
			    ,a.long
				,c.name_first as customer_name
				,ISNULL((select s.driver_message from [order].ecommerce_ride_status s
				INNER JOIN [order].ecommerce_ride_status_history h on s.id_status=h.id_ride_status where h.id_status_history=
				(select top 1 id_status_history from [order].[ecommerce_ride_status_history] h where h.id_ride=er.id_ride order by id_status_history desc)),null) as ride_status
                FROM [order].ride_delivery_route rdr
               INNER JOIN [order].ecommerce_ride er ON rdr.id_ride = er.id_ride
               INNER JOIN [order].address a ON er.id_order = a.id_order
			   LEFT JOIN [order].[order] o ON o.id_order=a.id_order
			   LEFT JOIN [order].[customer] c ON c.id_customer=o.id_customer
               WHERE dr.id_delivery_route = rdr.id_delivery_route  and o.id_location=@id_location
               ORDER BY rdr.position
               FOR JSON PATH),'[]') AS ride_list,
           ISNULL((
			SELECT rtdr.id_transfer AS id_transfer_id, rtdr.position, rtdr.eta, 
			tr.*,
			ISNULL((
					SELECT top 1 trs.name 
					FROM [inventory].transfer_status_history trsh
					INNER JOIN [inventory].transfer_status trs ON trs.id_transfer_status = trsh.id_transfer_status 
					WHERE trsh.id_transfer = tr.id_transfer
					ORDER BY trsh.id_transfer_status_history DESC
				), null) AS ride_status,
			ISNULL((
					SELECT loc_source.*
					FROM [base].location loc_source
					WHERE loc_source.id_location = tr.id_location_source
					FOR JSON PATH
				), '{}') AS source_location,
			ISNULL((
					SELECT loc_dest.*
					FROM [base].location loc_dest
					WHERE loc_dest.id_location = tr.id_location_destination
					FOR JSON PATH
				), '{}') AS destination_location
			FROM [order].ride_transfer_delivery_route rtdr
			INNER JOIN [inventory].transfer tr ON rtdr.id_transfer = tr.id_transfer
			WHERE dr.id_delivery_route = rtdr.id_delivery_route  and tr.id_location_source=@id_location
			ORDER BY rtdr.position
			FOR JSON PATH
			), '[]') AS transfer_list
    FROM [order].delivery_route dr
	LEFT JOIN [order].driver d ON d.id_driver=dr.id_driver
	LEFT JOIN [base].[user] u on u.id_user = d.id_user	
    WHERE dr.id_delivery_route = ISNULL(@id_delivery_route,dr.id_delivery_route) 
    OR dr.id_driver = ISNULL(@id_driver,dr.id_driver) order by dr.id_delivery_route desc
go

