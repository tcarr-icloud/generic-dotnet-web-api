
create 
 procedure inventory.usp_area_driver_update @id_area int,
                                                 @id_driver int,
                                                 @remove bit = null
as
    set nocount on ;

    IF (@remove = 1)
        BEGIN
            delete
            from inventory.area_driver
            where id_driver = @id_driver
              and id_area = @id_area
        end

    else
        begin
            declare @id_area_driver int = (select id_area_driver
                                           from inventory.area_driver
                                           where id_area = @id_area
                                              or id_driver = @id_driver)

            if (@id_area_driver is null)
                begin
                    insert into inventory.area_driver (id_area, id_driver) values (@id_area, @id_driver);
                end
            else
                update inventory.area_driver
                set id_area   = @id_area,
                    id_driver = @id_driver
                where id_area_driver = @id_area_driver
        end
go

