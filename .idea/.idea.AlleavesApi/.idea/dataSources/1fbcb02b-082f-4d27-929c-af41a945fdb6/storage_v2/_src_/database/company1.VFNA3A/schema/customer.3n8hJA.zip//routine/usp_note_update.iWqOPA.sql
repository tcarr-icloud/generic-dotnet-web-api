-- =============================================
-- Author:		Jeff
-- Create date: 2/23/2021
-- Description:	
-- =============================================
CREATE PROCEDURE [customer].[usp_note_update]
	@id_customer int,
	@id_note int,
	@entry varchar(max),
	@deleted bit = 0,
	@is_alert bit,
	@id_user int
AS
BEGIN
	SET NOCOUNT ON;

	UPDATE customer.note
	SET 
		 [entry] = @entry
		,is_alert = @is_alert
		,date_updated = GETUTCDATE()
		,updated_by = @id_user
		,deleted = @deleted
	WHERE id_note = @id_note
	EXEC customer.usp_note_list @id_customer, @id_note
END
go

