CREATE PROCEDURE [grow].[usp_plant_phase_change]
	@phase VARCHAR(32),
	@date_phase DATE,
	@plant_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
    SET NOCOUNT ON;

	/* update plants. */
	UPDATE p
	SET p.date_flower = CASE WHEN @phase='flower' THEN @date_phase ELSE NULL END
		, p.date_preflower = CASE WHEN @phase='flower' THEN p.date_preflower
								  WHEN @phase='preflower' THEN @date_phase
								  ELSE NULL END
		, p.date_vegetative = CASE WHEN @phase='flower' THEN p.date_vegetative
								   WHEN @phase='preflower' THEN p.date_vegetative
								   WHEN @phase='vegetative' THEN @date_phase
								   ELSE NULL END
		, p.date_germination = CASE WHEN @phase='seedling' THEN NULL
								    WHEN @phase='germination' THEN @date_phase
								    ELSE p.date_germination END
		, p.date_seedling = CASE WHEN @phase='seedling' THEN @date_phase
								 ELSE p.date_seedling END
		, p.id_user_updated=@id_user
		, p.date_updated=GETUTCDATE()
	FROM grow.plant p
	JOIN (
		SELECT value AS id_plant
		FROM OPENJSON(@plant_list)
	) l ON l.id_plant=p.id_plant

	/* add log event. */
	DECLARE @list VARCHAR(MAX) = (
					SELECT id_plant
							, id_area
							, [row]
							, [column]
					FROM grow.plant
					WHERE id_plant IN (SELECT value AS id_plant FROM OPENJSON(@plant_list))
					FOR JSON PATH),
			@notes VARCHAR(128) = CONCAT('Changed to '
							, CASE @phase WHEN 'flower' THEN 'Flowering'
										  WHEN 'preflower' THEN 'Pre-Flowering'
										  WHEN 'vegetative' THEN 'Vegetative'
										  WHEN 'germination' THEN 'Germination'
										  ELSE 'Seedling' END
							, ' on ', @date_phase)

	EXEC grow.usp_event_create_bulk 'phase_change', NULL, NULL, NULL, @notes, @list, @id_user

	/* return changed plants. */
	EXEC grow.usp_plant_list NULL, NULL, NULL, NULL, NULL, NULL, @plant_list
go

