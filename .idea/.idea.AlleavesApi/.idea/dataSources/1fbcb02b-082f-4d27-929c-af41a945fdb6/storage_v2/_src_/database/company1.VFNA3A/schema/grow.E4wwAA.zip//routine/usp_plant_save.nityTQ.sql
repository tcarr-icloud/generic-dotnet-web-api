CREATE PROCEDURE [grow].[usp_plant_save]
	@id_plant INT,
	@id_strain BIGINT,
	@source VARCHAR(64),
	@id_area BIGINT,
	@row INT = NULL,
	@column INT = NULL,
	@id_mother BIGINT = NULL,
	@is_mother BIT = 0,
	@date_seedling DATE = NULL,
	@date_germination DATE = NULL,
	@date_vegetative DATE = NULL,
	@date_preflower DATE = NULL,
	@date_flower DATE = NULL,
	@metrc_batch VARCHAR(128) = NULL,
	@metrc_id INT = NULL,
	@metrc_label VARCHAR(128) = NULL,
	@id_user VARCHAR(128)
AS
	DECLARE @id_area_orig INT,
			@row_orig INT,
			@column_orig INT,
			@phase_orig VARCHAR(64),
			@phase_date_orig DATE,
			@phase_curr VARCHAR(64) = CASE WHEN @date_flower IS NOT NULL THEN 'Flowering'
										   WHEN @date_preflower IS NOT NULL THEN 'Pre-Flowering'
										   WHEN @date_vegetative IS NOT NULL THEN 'Vegetative'
										   WHEN @date_germination IS NOT NULL THEN 'Germination'
										   ELSE 'Seedling' END,
			@phase_date_curr DATE = COALESCE(@date_flower, @date_preflower, @date_vegetative, @date_germination, @date_seedling)

	/* get original values. */
	SELECT @id_area_orig=id_area
			, @row_orig=[row]
			, @column_orig=[column]
			, @phase_orig = CASE WHEN date_flower IS NOT NULL THEN 'Flowering'
								 WHEN date_preflower IS NOT NULL THEN 'Pre-Flowering'
								 WHEN date_vegetative IS NOT NULL THEN 'Vegetative'
								 WHEN date_germination IS NOT NULL THEN 'Germination'
								 ELSE 'Seedling' END
			, @phase_date_orig = COALESCE(date_flower, date_preflower, date_vegetative, date_germination, date_seedling)
	FROM grow.plant
	WHERE id_plant=@id_plant

	/* add events where applicable. */
	DECLARE @notes VARCHAR(MAX)
	IF(@id_area<>@id_area_orig OR @row <> @row_orig OR @column <> @column_orig)
		EXEC grow.usp_event_create 'move', @id_plant, @id_area, @row, @column, NULL, @id_user
	IF(@phase_curr <> @phase_orig OR @phase_date_curr <> @phase_date_orig)
	BEGIN
		SET @notes = CONCAT('Changed to ', @phase_curr, ' on ', @phase_date_curr)
		EXEC grow.usp_event_create 'phase_change', @id_plant, @id_area, @column, @row, @notes, @id_user
	END


	/* update plant. */
	UPDATE grow.plant
	SET id_strain=@id_strain
		, source=@source
		, id_area=@id_area
		, [row]=@row
		, [column]=@column
		, id_mother=@id_mother
		, is_mother=@is_mother
		, date_seedling=@date_seedling
		, date_germination=@date_germination
		, date_vegetative=@date_vegetative
		, date_preflower=@date_preflower
		, date_flower=@date_flower
		, metrc_batch=@metrc_batch
		, metrc_id=@metrc_id
		, metrc_label=@metrc_label
		, id_user_updated=@id_user
		, date_updated=GETUTCDATE()
	WHERE id_plant = @id_plant

	/* return updated_plant. */
	EXEC grow.usp_plant_list @id_plant
go

