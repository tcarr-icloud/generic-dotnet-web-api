CREATE PROCEDURE [order].[usp_queue_update]
	@id_queue INT
AS

UPDATE [order].queue
SET time_out = GETUTCDATE()
WHERE id_queue=@id_queue
go

