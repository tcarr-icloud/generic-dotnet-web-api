CREATE PROCEDURE [inventory].[usp_item_list]
	@id_item INT = NULL,
	@id_location INT = NULL,
	@start_row INT = 0,
	@end_row INT = 100,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
    SET NOCOUNT ON;

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = '	
	SELECT * FROM (
		SELECT ig.id_item_group
				, i.id_item
				, il.id_location
				, RTRIM(CONCAT(ig.name, '' '', (
							SELECT STRING_AGG(av.name, '' '') 
							FROM inventory.item_attribute_value iav
							LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
							WHERE iav.id_item=i.id_item)
						)) AS item
				, ig.name AS item_group
				, ig.product_description
				, ISNULL((SELECT id_media
											, content
											, [type]
									  FROM inventory.item_media
									  WHERE item_media.id_item = i.id_item
									  FOR JSON PATH
							), ''[]'') as media_list
				, c.path AS category_path
				, c.name AS category
				, c.id_category
				, i.barcode
				, i.sku
				, i.weight_useable
				, i.gross_weight_useable
				, i.id_uom_gross_weight_useable
				, i.weight_net
				, i.id_uom_weight_net
				, ig.id_uom_weight_useable
				, uw.name as uom_weight_useable
				, uw.name_short as uom_weight_useable_short
				, uwg.name as uom_gross_weight_useable
				, uwg.name_short as uom_gross_weight_useable_short


				, CAST(COALESCE(il.use_location_otd_price, i.use_otd_price, 0) as bit) as use_price_otd

				, COALESCE(il.cost_of_good, i.cost_of_good, 0) as cost_of_good
				, COALESCE(il.price_retail, i.price_retail, 0) as price_retail
				, COALESCE(il.price_retail_adult_use, i.price_retail_adult_use, 0) as price_retail_adult_use
				, COALESCE(il.price_retail_medical_use, i.price_retail_medical_use, 0) as price_retail_medical_use

				, COALESCE(il.price_otd, i.price_otd, 0) as price_otd
				, COALESCE(il.price_otd_adult_use, i.price_otd_adult_use, 0) as price_otd_adult_use
				, COALESCE(il.price_otd_medical_use, i.price_otd_medical_use, 0) as price_otd_medical_use
				
				, u.id_uom
				, u.name AS uom
				, u.quantity_type as uom_quantity_type
				, rm.name AS raw_material
				, v.name AS vendor
				, br.name AS brand
				, st.name AS strain
				, st.id_strain_type
				, stt.name AS strain_type
				, dr.name AS delivery_route
				, ig.ingredients_list
				, ig.batch_required
				, ig.allergens
				, ig.nutritional_information
				, cfg.auto_close
				, CAST(ISNULL(ig.is_product, 0) as bit) as is_product
				, CAST(ISNULL(ig.is_cannabis, 0) as bit) as is_cannabis
				, CAST(ISNULL(ig.is_plant, 0) as bit) as is_plant
				, CAST(ISNULL(ig.is_seed, 0) as bit) as is_seed
				, CAST(ISNULL(ig.is_plant_nutrient, 0) as bit) as is_plant_nutrient
				, CAST(ISNULL(ig.is_adult_use, 0) as bit) as is_adult_use
				, CAST(ISNULL(ig.is_medical_use, 0) as bit) as is_medical_use
				, CAST(ISNULL(ig.is_low_thc, 0) as bit) as is_low_thc
				, CAST(ISNULL(ig.is_medicated, 0) as bit) as is_medicated
				, CAST(ISNULL(ig.is_smoking, 0) as bit) as is_smoking
				, CAST(ISNULL(ig.is_low_thc_and_medical, 0) as bit) as is_low_thc_and_medical
				, ig.id_ommu_form
				, CAST(ISNULL(ig.is_ommu_delivery_device, 0) as bit) as is_ommu_delivery_device
				, il.metrc_item_id
				, il.metrc_name
				, il.metrc_category
				, i.biotrack_barcode_id
				, i.biotrack_inventory_type_id
				, i.vt_product_number
				, i.vt_product_name
				, i.vt_product_type
				, i.vt_business_name
				, biot.name AS biotrack_inventory_type_name
				, biot.requires_weighing as biotrack_requires_weighing
				, CAST(CASE WHEN i.deleted=1 THEN 1 ELSE ig.deleted END AS BIT) AS deleted
				, CAST(CASE WHEN ig.name IS NULL OR ig.name = '''' THEN 1
				       WHEN ig.id_uom IS NULL THEN 1
					   WHEN ig.has_shelf_life=1 AND ISNULL(ig.shelf_life_days, 0) <= 0 THEN 1
					   WHEN ig.is_cannabis=1 AND i.weight_useable IS NULL THEN 1
					   WHEN ig.is_cannabis=1 AND ig.id_uom_weight_useable IS NULL THEN 1
					   WHEN (ig.is_cannabis=1 OR ig.is_plant=1 OR ig.is_seed=1) AND ig.id_delivery_route IS NULL THEN 1
					   WHEN (ig.is_cannabis=1 OR ig.is_plant=1 OR ig.is_seed=1) AND ig.is_product=1 AND ISNULL(ig.is_adult_use, 0) = 0 AND ISNULL(ig.is_medical_use, 0) = 0 THEN 1
					   WHEN ig.is_cannabis=0 AND ig.is_product=1 AND i.price_retail IS NULL THEN 1
					   WHEN (ig.is_cannabis=1 OR ig.is_plant=1 OR ig.is_seed=1) AND ig.is_product=1 AND ig.is_medical_use=1 AND i.price_retail_medical_use IS NULL THEN 1
					   WHEN (ig.is_cannabis=1 OR ig.is_plant=1 OR ig.is_seed=1) AND ig.is_product=1 AND ig.is_adult_use=1 AND i.price_retail_adult_use IS NULL THEN 1
				  ELSE 0
				  END AS BIT) AS missing_data
				, ISNULL(ai.has_inventory, 0) as has_inventory
				, ISNULL(ai.has_available_inventory,0) as has_available_inventory
				, ISNULL(ai.has_available_retail_inventory,0) as has_available_retail_inventory
				,i.use_tiered_pricing
				,il.use_tiered_pricing as location_use_tiered_pricing
				,i.tiered_pricing
				,il.tiered_pricing as location_tiered_pricing
				,i.tiered_pricing_option
				,il.tiered_pricing_option as location_tiered_pricing_option
				,i.id_preset_tiered_pricing as preset_id_preset_tiered_pricing
				,il.id_preset_tiered_pricing as location_preset_id_preset_tiered_pricing
				,ltp.name as location_preset_tier_name
				,ltp.tier as location_preset_tiers
				,ltp.enable_cumulative_weights as location_enable_cumulative_weights
				,ltp.enable_combined_tiers as location_enable_combined_tiers
				,tp.enable_combined_tiers
				,tp.enable_cumulative_weights
				,lu.name as location_preset_uom
				,lu.name_short as location_preset_uom_short
				,tp.name as preset_tier_name
				,tp.tier as preset_tiers
				,uu.name as preset_uom
				,uu.name_short as preset_uom_short
		FROM inventory.item_group ig
		JOIN inventory.item i ON i.id_item_group=ig.id_item_group
		LEFT JOIN inventory.item_location il ON il.id_item=i.id_item AND ' + CASE WHEN @id_location IS NOT NULL THEN 'il.id_location = ' + CAST(@id_location as VARCHAR(16)) ELSE 'il.id_location IS NULL' END + '
		LEFT JOIN pos.configuration cfg ON ig.id_location = cfg.id_location
		LEFT JOIN inventory.vw_category_list c ON c.id_category=ig.id_category
		LEFT JOIN inventory.uom u ON u.id_uom=ig.id_uom
		LEFT JOIN inventory.uom uw ON uw.id_uom=ig.id_uom_weight_useable
		LEFT JOIN inventory.uom uwg ON uwg.id_uom=i.id_uom_gross_weight_useable
		LEFT JOIN inventory.brand br ON br.id_brand=ig.id_brand
		LEFT JOIN inventory.vendor v ON v.id_vendor=ig.id_vendor
		LEFT JOIN inventory.tiered_pricing tp ON tp.id_tiered_pricing=i.id_preset_tiered_pricing
		LEFT JOIN inventory.tiered_pricing ltp ON ltp.id_tiered_pricing=il.id_preset_tiered_pricing
		LEFT JOIN inventory.uom lu ON lu.id_uom=ltp.id_uom
		LEFT JOIN inventory.uom uu ON uu.id_uom=tp.id_uom
		LEFT JOIN inventory.raw_material rm ON rm.id_raw_material=ig.id_raw_material
		LEFT JOIN grow.strain st ON st.id_strain=ig.id_strain
		LEFT JOIN grow.strain_type stt ON stt.id_strain_type=st.id_strain_type
		LEFT JOIN inventory.delivery_route dr ON dr.id_delivery_route=ig.id_delivery_route
		LEFT JOIN biotrack.inventory_type biot ON biot.id_inventory_type=i.biotrack_inventory_type_id
		LEFT JOIN #AggregatedInventory ai ON ai.id_item = i.id_item
		' + CASE WHEN @id_location IS NOT NULL THEN 'WHERE il.id_location = ' + CAST(@id_location as VARCHAR(16)) ELSE '' END + '
	) inventory'
	
	SET @where = 'WHERE ' + CASE WHEN @id_item IS NULL THEN '1=1' ELSE + 'id_item = '+ CAST(@id_item AS VARCHAR(16)) END
	SET @where = @where + CASE WHEN @id_location IS NULL THEN '' ELSE ' AND id_location = '+ CAST(@id_location AS VARCHAR(16)) END
	
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'item')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	
	DECLARE @sql VARCHAR(MAX) = '
		;WITH inventory_agg
AS (
	SELECT b.id_item
		,i.id_batch
		,i.id_area
		,CASE 
			WHEN i.quantity < 0
				THEN 0
			ELSE i.quantity
			END AS available
		,aty.[name]
		,CASE 
			WHEN aty.[name] = ''retail''
				AND i.quantity > 0
				THEN i.quantity
			ELSE 0
			END AS available_retail
	FROM inventory.inventory AS i
	INNER JOIN inventory.batch AS b ON b.id_batch = i.id_batch
	INNER JOIN inventory.area AS a ON a.id_area = i.id_area
	INNER JOIN inventory.area_type AS aty ON aty.id_area_type = a.id_area_type
	INNER JOIN [base].[location] AS l ON l.id_location = a.id_location
	'+CASE WHEN @id_location IS NOT NULL THEN 'WHERE l.id_location = ' + CAST(@id_location as VARCHAR(16)) ELSE '' END + '
	)
	,order_agg
AS (
	SELECT oi.id_inventory_item
		,oi.id_batch
		,oi.id_area
		,SUM(oi.quantity) AS ordered
	FROM [order].[order] AS o
	INNER JOIN [order].[item] AS oi ON o.id_order = oi.id_order
	WHERE o.void = 0
		AND o.cancel = 0
		AND o.paid_in_full = 0		
		AND oi.id_batch IN (SELECT id_batch FROM inventory_agg)
		AND oi.id_area IN (SELECT id_area FROM inventory_agg)
	GROUP BY oi.id_inventory_item
		,oi.id_batch
		,oi.id_area
	)
	,transfer_agg
AS (
	SELECT ti.id_item
		,ti.id_batch
		,ti.id_area
		,SUM(ti.quantity) AS transfered
	FROM inventory.transfer t
	JOIN inventory.transfer_item ti ON ti.id_transfer = t.id_transfer
	CROSS APPLY (
		SELECT TOP 1 id_transfer_status
		FROM inventory.transfer_status_history h
		WHERE h.id_transfer = t.id_transfer
		ORDER BY h.date_verified DESC
		) x
	WHERE x.id_transfer_status = 1
	AND ti.id_batch IN (SELECT id_batch FROM inventory_agg)
	AND ti.id_area IN (SELECT id_area FROM inventory_agg)
	GROUP BY ti.id_item
		,ti.id_batch
		,ti.id_area
	)
	,has_inventory_values
AS (
	SELECT inv.id_item
		,CAST(CASE 
				WHEN SUM(inv.available) + SUM(ISNULL(orders.ordered, 0)) + SUM(ISNULL(transfers.transfered, 0)) > 0
					THEN 1
				ELSE 0
				END AS BIT) AS has_inventory
		,CAST(CASE 
				WHEN SUM(inv.available) > 0
					THEN 1
				ELSE 0
				END AS BIT) AS has_available_inventory
		,CAST(CASE 
				WHEN SUM(inv.available_retail) > 0
					THEN 1
				ELSE 0
				END AS BIT) AS has_available_retail_inventory
	FROM inventory_agg inv
	LEFT JOIN order_agg orders ON orders.id_inventory_item = inv.id_item
		AND orders.id_batch = inv.id_batch
		AND orders.id_area = inv.id_area
	LEFT JOIN transfer_agg transfers ON transfers.id_item = inv.id_item
		AND transfers.id_batch = inv.id_batch
		AND transfers.id_area = inv.id_area
	GROUP BY inv.id_item
	)
	SELECT * INTO #AggregatedInventory FROM has_inventory_values
	
	SELECT *, COUNT(*) OVER() AS total_rows FROM ('+@base_sql+') t
	' + @order
	   
	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

