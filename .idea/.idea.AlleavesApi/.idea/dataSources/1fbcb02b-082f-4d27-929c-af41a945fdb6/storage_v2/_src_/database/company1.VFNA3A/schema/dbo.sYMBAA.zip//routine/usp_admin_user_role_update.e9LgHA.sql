CREATE   PROCEDURE [dbo].[usp_admin_user_role_update]
	@id_user INT,
	@join_list VARCHAR(MAX)
AS
	SET NOCOUNT ON;

	DECLARE @query VARCHAR(MAX)
	IF(@join_list IS NULL)
	BEGIN
		DELETE FROM [base].[user_role] WHERE id_user = @id_user
	END
	ELSE
	BEGIN
		SET @query='
		MERGE [base].[user_role] AS t
		USING (SELECT * FROM (VALUES '+@join_list+') AS t(id_user, id_role)) AS s ON
			t.id_user=s.id_user AND t.id_role=s.id_role
		WHEN NOT MATCHED BY TARGET THEN 
				INSERT (id_user, id_role) VALUES
					(s.id_user, s.id_role)
		WHEN NOT MATCHED BY SOURCE AND t.id_user='+CAST(@id_user as varchar(10))+' THEN 
				DELETE;'
		EXEC (@query)
	END
go

