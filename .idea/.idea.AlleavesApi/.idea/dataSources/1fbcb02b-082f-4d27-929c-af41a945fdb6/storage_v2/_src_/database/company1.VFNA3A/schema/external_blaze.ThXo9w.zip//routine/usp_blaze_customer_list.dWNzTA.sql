CREATE PROCEDURE external_blaze.usp_blaze_customer_list
    @first_name VARCHAR(200) ,
	@last_name VARCHAR(200) ,
	@dob VARCHAR(200) ,
	@patient_number VARCHAR(200) ,
	@apt_unit VARCHAR(200) ,
	@street VARCHAR(200) ,
	@state VARCHAR(200) ,
	@city VARCHAR(200) ,
	@zip VARCHAR(200) ,
	@primary_phone VARCHAR(200) ,
	@phone VARCHAR(200) ,
	@email VARCHAR(200) ,
	@driver_license VARCHAR(200) ,
	@driver_license_state VARCHAR(200) ,
	@passport VARCHAR(200) ,
	@physician VARCHAR(200) ,
	@caregiver VARCHAR(200) ,
	@referral_method VARCHAR(200) ,
	@customer_type VARCHAR(200) ,
	@other VARCHAR(200),
	@id_member VARCHAR(200)
AS
BEGIN
	SELECT id_member,id_customer
	FROM external_blaze.customer
    WHERE first_name=@first_name AND last_Name = @last_name AND dob = @dob AND patient_number =@patient_number
    AND apt_unit = @apt_unit AND street = @street AND state = @state AND city = @city AND
          zip = @zip AND primary_phone = @primary_phone AND phone = @phone AND email = @email
      AND driver_license = @driver_license AND drivers_license_state = @driver_license_state AND passport = @passport
      AND physician = @physician AND caregiver = @caregiver AND referral_method = @referral_method
      AND customer_type = @customer_type AND other = @other AND id_member = @id_member
END
go

