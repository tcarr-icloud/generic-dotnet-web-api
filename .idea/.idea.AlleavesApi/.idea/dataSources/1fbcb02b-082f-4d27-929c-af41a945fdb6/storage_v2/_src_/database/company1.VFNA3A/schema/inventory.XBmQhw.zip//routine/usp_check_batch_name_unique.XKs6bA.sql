CREATE PROCEDURE [inventory].[usp_check_batch_name_unique]
    @batch_name VARCHAR(64)
AS
BEGIN
    DECLARE @batch_count INT;
    SELECT @batch_count = COUNT(*)
    FROM [inventory].[batch]
    WHERE [name] = @batch_name;

    SELECT CASE WHEN @batch_count = 0 THEN 1 ELSE 0 END as is_unique;
END;
go

