CREATE PROCEDURE external_blaze.usp_get_customer_ids
AS
BEGIN
	SELECT id_member
	FROM external_blaze.customer
END
go

