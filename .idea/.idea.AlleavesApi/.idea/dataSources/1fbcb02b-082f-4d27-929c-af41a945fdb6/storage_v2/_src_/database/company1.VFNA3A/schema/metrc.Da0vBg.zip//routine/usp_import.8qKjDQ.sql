CREATE PROCEDURE [metrc].[usp_import]
	@id_location INT,
	@id_item INT=NULL,
	@item_alleaves VARCHAR(512),
	@metrc_package_label VARCHAR(128),
	@alleavesBarcode VARCHAR(512),
	/* item details. */
	@uom VARCHAR(64),
	@weight_useable DECIMAL(18,4),
	@uom_weight_useable VARCHAR(64),
	@gross_weight_useable DECIMAL(18,4),
	@uom_gross_weight_useable VARCHAR(64),
	@category VARCHAR(512),
	@vendor VARCHAR(512),
	@brand VARCHAR(512),
	@strain VARCHAR(256),
	@delivery_route VARCHAR(512),
	@sku VARCHAR(512),
	@item_thc DECIMAL(18,5),
	@item_cbd DECIMAL(18,5),
	@item_thc_mg DECIMAL(18,5),
	@item_cbd_mg DECIMAL(18,5),
	/* biotrack*/
	@biotrack_barcode_id VARCHAR(512) = NULL,
	@biotrack_imported_location INT = NULL,
	@biotrack_imported_quantity VARCHAR(256) = NULL,
	@biotrack_inventory_type_id INT = NULL,
	@rejected_quantity VARCHAR(256) = NULL,
	@is_product BIT = 1,
	/* ommu/biotrack fl */
	@is_low_thc BIT = 0,
	@is_medicated BIT = 0,
	@is_smoking BIT = 0,
	@is_ommu_delivery_device BIT = 0,
	@id_ommu_form INT = NULL,
	/* retail. */
	@is_tax_exempt BIT,
	@tax_category VARCHAR(256),
	@is_medical_use BIT,
	@is_adult_use BIT,
	@cost_of_good DECIMAL(18,4),
	@price_retail_medical_use DECIMAL(18,4),
	@price_otd_medical_use DECIMAL(18,4),
	@price_retail_adult_use DECIMAL(18,4),
	@price_otd_adult_use DECIMAL(18,4),
	@product_description VARCHAR(MAX),
	@dosage_recommended VARCHAR(512),
	@servings INT,
	/* package details. */
	@quantity DECIMAL(18,4),
	@area VARCHAR(512),
	@vendor_batch_id VARCHAR(256),
	@date_production DATE,
	@date_expire DATE,
	@date_use_by DATE,
	@test_date DATE,
	@lab_testing_facility VARCHAR(512),
	@test_results VARCHAR(MAX) = '[]',
	/* metrc fields. */
	@item_metrc VARCHAR(512),
	@metrc_item_id VARCHAR(512),
	@metrc_category VARCHAR(512),
	@metrc_uom VARCHAR(64),
	@manifest_number VARCHAR(64),
	/* metadata. */
	@id_user INT
AS
	SET NOCOUNT ON;

	DECLARE @metrc_state VARCHAR(16) = (SELECT TOP 1 state FROM base.location WHERE id_location=@id_location)
	DECLARE @id_item_group INT,
			@id_uom INT = (SELECT TOP 1 id_uom FROM inventory.uom WHERE name=@uom),
			@id_uom_weight_useable INT = (SELECT TOP 1 id_uom FROM inventory.uom WHERE name=@uom_weight_useable AND @uom_weight_useable IS NOT NULL),
			@id_uom_gross_weight_useable INT = (SELECT TOP 1 id_uom FROM inventory.uom WHERE name=@uom_gross_weight_useable AND @uom_gross_weight_useable IS NOT NULL),
			@id_category INT = (SELECT TOP 1 id_category FROM inventory.vw_category_list WHERE path=@category AND deleted = 0),
			@id_strain INT = (SELECT TOP 1 id_strain FROM grow.strain WHERE name=@strain AND @strain IS NOT NULL),
            @id_delivery_route INT = (SELECT TOP 1 id_delivery_route FROM inventory.vw_delivery_route WHERE delivery_route_path=@delivery_route AND @delivery_route IS NOT NULL),
			@id_vendor INT = (SELECT TOP 1 id_vendor FROM inventory.vendor WHERE name=@vendor),
            @id_brand INT = (SELECT TOP 1 id_brand FROM inventory.brand WHERE name=@brand),
			@id_tax_category INT = (SELECT TOP 1 id_tax_category FROM tax.category WHERE name=@tax_category),
			@id_area INT = (SELECT TOP 1 id_area FROM inventory.vw_area_list WHERE path=@area AND id_location=@id_location),
			@id_uom_metrc INT = (SELECT TOP 1 id_uom FROM inventory.uom WHERE name=@metrc_uom),
			@id_test_result INT,
			@notes VARCHAR(128)

	/* attempt to get item if metrc item has been seen in this facility. */
	IF @id_item IS NULL AND @biotrack_barcode_id IS NULL
		SET @id_item = (SELECT TOP 1 id_item FROM inventory.batch WHERE metrc_item_id=@metrc_item_id AND metrc_state=@metrc_state)

	/* check for duplicate. */
	IF @id_item IS NULL AND EXISTS (SELECT * FROM inventory.item_group WHERE name=@item_alleaves AND deleted=0)
	BEGIN
		DECLARE @msg VARCHAR(512) = CONCAT('An item with the name "', @item_alleaves, '" already exists. Cannot create duplicate.')
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	/********************************************************************************************* create fields if necessary. */

	/* create category if doesnt exist. */
	IF (@category IS NOT NULL AND @id_category IS NULL)
	BEGIN
		INSERT INTO [inventory].[category] ([name],[updated_by]) 
		VALUES (@category, @id_user)

		SET @id_category = SCOPE_IDENTITY()
	END

	/* create strain if doesnt exist. */
	IF (@strain IS NOT NULL AND @id_strain IS NULL)
	BEGIN
		INSERT INTO [grow].[strain]
					([id_strain_type]
					,[name]
					,[created_by]
					,[updated_by])
				VALUES
					(1, @strain, @id_user, @id_user)

		SET @id_strain = SCOPE_IDENTITY()
	END

	/* create vendor if doesnt exist. */
	IF (@vendor IS NOT NULL AND @id_vendor IS NULL)
	BEGIN
		INSERT INTO [inventory].[vendor]
					([name]
					,[id_user_created]
					,[id_user_updated])
				VALUES
					(@vendor, @id_user, @id_user)

		SET @id_vendor = SCOPE_IDENTITY()
	END

	/* create brand if doesnt exist. */
	IF (@brand IS NOT NULL AND @id_brand IS NULL)
	BEGIN
		INSERT INTO [inventory].[brand]
					([name]
					,[id_user_created]
					,[id_user_updated])
				VALUES
					(@brand, @id_user, @id_user)

		SET @id_brand = SCOPE_IDENTITY()
	END
	

	/********************************************************************************************* create item. */
	IF @id_item IS NULL
	BEGIN
		/* insert item group. */
        INSERT INTO [inventory].[item_group]
               ([name]
               ,[is_global]
               ,[id_category]
               ,[id_uom]
               ,[id_uom_receiving]
               ,[id_uom_weight_useable]
               ,[id_vendor]
               ,[id_brand]
               ,[batch_required]
               ,[units_per_received]
               ,[is_product]
               ,[is_tax_exempt]
               ,[id_tax_category]
               ,[product_description]
               ,[is_cannabis]
               ,[id_strain]
               ,[is_adult_use]
               ,[is_medical_use]
               ,[id_delivery_route]
			   ,[thc]
			   ,[cbd]
			   ,[thc_mg]
			   ,[cbd_mg]
               ,[dosage_recommended]
               ,[servings]
			   ,[is_low_thc]
			   ,[is_medicated]
			   ,[is_smoking]
			   ,[is_ommu_delivery_device]
			   ,[id_ommu_form]
               ,[id_user_created]
               ,[id_user_updated])
         VALUES
               (@item_alleaves
               ,0
               ,@id_category
               ,@id_uom
               ,@id_uom
               ,@id_uom_weight_useable
               ,@id_vendor
               ,@id_brand
               ,1
               ,1
               ,@is_product
               ,@is_tax_exempt
               ,@id_tax_category
               ,@product_description
               ,1
               ,@id_strain
               ,@is_adult_use
               ,@is_medical_use
               ,@id_delivery_route
			   ,@item_thc
			   ,@item_cbd
			   ,@item_thc_mg
			   ,@item_cbd_mg
               ,@dosage_recommended
               ,@servings
			   ,@is_low_thc
			   ,@is_medicated
			   ,@is_smoking
			   ,@is_ommu_delivery_device
			   ,@id_ommu_form
               ,@id_user
               ,@id_user)


		SET @id_item_group = SCOPE_IDENTITY()

		/* insert item variant. */
		INSERT INTO [inventory].[item]
			   ([id_item_group]
               ,[sku]
               ,[cost_of_good]
               ,[price_retail_medical_use]
			   ,[price_otd_medical_use]
               ,[price_retail_adult_use]
               ,[price_otd_adult_use]
			   ,[weight_useable]
			   ,[id_user_created]
			   ,[id_user_updated]
			   ,[biotrack_barcode_id]
			   ,[biotrack_inventory_type_id])
		VALUES 
			   (@id_item_group
               ,@sku
               ,@cost_of_good
               ,@price_retail_medical_use
			   ,@price_otd_medical_use
               ,@price_retail_adult_use
			   ,@price_otd_adult_use
               ,@weight_useable
               ,@id_user
               ,@id_user
			   ,@biotrack_barcode_id
			   ,@biotrack_inventory_type_id)

		SET @id_item = SCOPE_IDENTITY()
        
        /* insert item location. */
		INSERT INTO [inventory].[item_location]
			   ([id_item]
			   ,[id_location]
			   ,[cost_of_good]
			   ,[price_retail_medical_use]
			   ,[price_otd_medical_use]
			   ,[price_retail_adult_use]
			   ,[price_otd_adult_use]
			   ,[metrc_item_id]
			   ,[metrc_name]
			   ,[metrc_category]
			   ,[id_user_created]
			   ,[id_user_updated]
			   ,[biotrack_barcode_id])
		 VALUES
			   (@id_item
			   ,@id_location
			   ,@cost_of_good
               ,@price_retail_medical_use
			   ,@price_otd_medical_use
               ,@price_retail_adult_use
			   ,@price_otd_adult_use
			   ,@metrc_item_id
			   ,@item_metrc
			   ,@metrc_category
			   ,@id_user
			   ,@id_user
			   ,@biotrack_barcode_id)
	END
	/********************************************************************************************* update item. */
	ELSE
	BEGIN
		SET @id_item_group = (SELECT TOP 1 id_item_group FROM inventory.item WHERE id_item=@id_item)

		UPDATE inventory.item_group
		SET id_category = @id_category
			, id_uom = @id_uom
			, id_uom_receiving = @id_uom
			, id_vendor = @id_vendor
			, id_brand = @id_brand
			, is_tax_exempt = @is_tax_exempt
			, id_tax_category = @id_tax_category
			, product_description = @product_description
			, dosage_recommended = @dosage_recommended
			, id_strain = @id_strain
			, is_medical_use = @is_medical_use
			, is_adult_use = @is_adult_use
			, id_delivery_route = @id_delivery_route
			, thc = @item_thc
			, cbd = @item_cbd
			, thc_mg = @item_thc_mg
			, cbd_mg = @item_cbd_mg
			, servings = @servings
			, is_low_thc = @is_low_thc
			, is_medicated = @is_medicated
			, is_smoking = @is_smoking
			, is_ommu_delivery_device = @is_ommu_delivery_device
			, id_ommu_form = @id_ommu_form
			, id_user_updated = @id_user
			, date_updated = GETUTCDATE()
		WHERE id_item_group=@id_item_group

		UPDATE inventory.item
		SET sku = @sku
			, cost_of_good = @cost_of_good
			, price_retail_medical_use = @price_retail_medical_use
			, price_otd_medical_use = @price_otd_medical_use
			, price_retail_adult_use = @price_retail_adult_use
			, price_otd_adult_use = @price_otd_adult_use
			, weight_useable = @weight_useable
			, id_user_updated = @id_user
			, date_updated = GETUTCDATE()
		WHERE id_item=@id_item

		IF NOT EXISTS (SELECT * FROM inventory.item_location WHERE id_item=@id_item AND id_location=@id_location)
		BEGIN
			INSERT INTO [inventory].[item_location]
			   ([id_item]
			   ,[id_location]
			   ,[cost_of_good]
			   ,[price_retail_medical_use]
			   ,[price_otd_medical_use]
			   ,[price_retail_adult_use]
			   ,[price_otd_adult_use]
			   ,[metrc_item_id]
			   ,[metrc_name]
			   ,[metrc_category]
			   ,[id_user_created]
			   ,[id_user_updated])
		 VALUES
			   (@id_item
			   ,@id_location
			   ,@cost_of_good
               ,@price_retail_medical_use
			   ,@price_otd_medical_use
               ,@price_retail_adult_use
			   ,@price_otd_adult_use
			   ,@metrc_item_id
			   ,@item_metrc
			   ,@metrc_category
			   ,@id_user
			   ,@id_user)
		END
		ELSE
		BEGIN
			UPDATE inventory.item_location
			SET cost_of_good = @cost_of_good
				, price_retail_medical_use = @price_retail_medical_use
				, price_otd_medical_use = @price_otd_medical_use
				, price_retail_adult_use = @price_retail_adult_use
				, price_otd_adult_use = @price_otd_adult_use
				, id_user_updated = @id_user
				, date_updated = GETUTCDATE()
			WHERE id_item=@id_item AND id_location=@id_location
		END
	END

	
	/********************************************************************************************* handle batch. */

	DECLARE @id_batch INT = (SELECT TOP 1 id_batch FROM inventory.batch WHERE metrc_package_label = @metrc_package_label AND id_item = @id_item)
	IF (@biotrack_barcode_id IS NOT NULL)
	BEGIN
		SET @id_batch = (SELECT TOP 1 id_batch FROM inventory.batch WHERE name=@biotrack_barcode_id)
		IF @id_batch IS NOT NULL
		BEGIN
			UPDATE inventory.batch
				SET id_item=@id_item,
					initial_quantity=@quantity,
					updated_by=@id_user
			WHERE biotrack_barcode_id=@biotrack_barcode_id
		END
		IF @id_batch IS NULL
		BEGIN
			EXEC @id_batch = inventory.usp_batch_create @id_item, NULL, NULL, @id_location, @quantity, NULL, @biotrack_barcode_id, NULL, @biotrack_barcode_id, @biotrack_inventory_type_id, NULL, NULL, @id_user
		END
		ELSE
		BEGIN
			DECLARE @id_exisiting_location INT = (SELECT TOP 1 id_location FROM inventory.item_location WHERE id_location=@id_location)
			IF @id_exisiting_location IS NULL
			BEGIN
				INSERT INTO [inventory].[item_location]
				   ([id_item]
				   ,[id_location]
				   ,[cost_of_good]
				   ,[price_retail_medical_use]
				   ,[price_otd_medical_use]
				   ,[price_retail_adult_use]
				   ,[price_otd_adult_use]
				   ,[id_user_created]
				   ,[id_user_updated])
				VALUES
				   (@id_item
				   ,@id_location
				   ,@cost_of_good
				   ,@price_retail_medical_use
				   ,@price_otd_medical_use
				   ,@price_retail_adult_use
				   ,@price_otd_adult_use
				   ,@id_user
				   ,@id_user)
			END
		END
		
		INSERT INTO [biotrack].[import]
			([id_batch]
			,[id_location]
			,[id_created_by]
			,[quantity]
			,[rejected_quantity])
		VALUES
			(@id_batch
			,@biotrack_imported_location
			,@id_user
			,@quantity
			,@rejected_quantity)
	END
	ELSE
	BEGIN
	/* create batch. */
		IF (@id_batch IS NULL AND @id_item IS NOT NULL)
		BEGIN
			EXEC @id_batch = inventory.usp_batch_create @id_item, NULL, NULL, @id_location, @quantity, NULL, @alleavesBarcode, NULL, NULL, NULL
        
			UPDATE inventory.batch 
			SET date_production = @date_production
				, date_expire = @date_expire
				, date_use_by = @date_use_by
				, vendor_batch_id = @vendor_batch_id
				, cost_of_good = @cost_of_good
				, metrc_package_label = @metrc_package_label
				, metrc_item_id = @metrc_item_id
				, metrc_state = @metrc_state
				, id_uom_metrc = @id_uom_metrc
				, biotrack_barcode_id = @biotrack_barcode_id
				, biotrack_inventory_type_id = @biotrack_inventory_type_id
			WHERE id_batch=@id_batch
		END
	END
	
	/********************************************************************************************* handle test results. */

	IF (@test_results IS NOT NULL AND @test_results <> '[]')
	BEGIN
		SET @id_test_result = (SELECT TOP 1 id_test_result FROM inventory.test_result WHERE id_batch=@id_batch)

		IF @id_test_result IS NULL
		BEGIN
			INSERT INTO inventory.test_result (id_batch, test_lab, test_date, created_by, updated_by) 
			VALUES (@id_batch, @lab_testing_facility, @test_date, @id_user, @id_user)

			SET @id_test_result=SCOPE_IDENTITY()
		END

		INSERT INTO inventory.test_result_chemical_profile (id_chemical_profile, id_test_result, value, metrc_state, metrc_test_result, metrc_test_date, metrc_lab_testing_facility, id_user_created, id_user_updated)
		SELECT id_chemical_profile
				, @id_test_result AS id_test_result
				, value
				, metrc_state
				, metrc_test_result
				, metrc_test_date
				, metrc_lab_testing_facility
				, @id_user AS id_user_created
				, @id_user AS id_user_updated
		FROM OPENJSON(@test_results)
		WITH (
			id_chemical_profile INT,
			value VARCHAR(512),
			metrc_state VARCHAR(128),
			metrc_test_result VARCHAR(512),
			metrc_test_date DATE,
			metrc_lab_testing_facility VARCHAR(512)
		)
	END
	
	/********************************************************************************************* update crawler record. */
	UPDATE metrc.crawler_package
	SET imported = 1
		, imported_quantity = @quantity
		, id_uom_imported = @id_uom
		, date_imported = GETUTCDATE()
		, id_user_imported = @id_user
		, date_updated = GETUTCDATE()
	WHERE package=@metrc_package_label

	/********************************************************************************************* add inventory. */

	/* add item to inventory. */
	IF @quantity > 0
	BEGIN
		IF @id_area IS NULL
        BEGIN
            INSERT INTO inventory.area (id_location, name, id_area_type, updated_by) 
            VALUES (@id_location, @area, 1000, -1)
            
            SET @id_area = SCOPE_IDENTITY()
        END

		IF @manifest_number IS NOT NULL
			SET @notes = CONCAT('Metrc Shipment: ', @manifest_number)

		IF @biotrack_barcode_id IS NULL
			EXEC [log].usp_event_create 'metrc_import', @id_batch, @id_area, @quantity, @notes, @id_user
		ELSE
			EXEC [log].usp_event_create 'biotrack_import', @id_batch, @id_area, @quantity, @notes, @id_user
	END

	SELECT
		i.id_item,
		ig.name AS item_name,
		@id_batch AS id_batch
	FROM inventory.item i
	LEFT JOIN inventory.item_group ig ON ig.id_item_group=i.id_item_group
	WHERE i.id_item=@id_item
go

