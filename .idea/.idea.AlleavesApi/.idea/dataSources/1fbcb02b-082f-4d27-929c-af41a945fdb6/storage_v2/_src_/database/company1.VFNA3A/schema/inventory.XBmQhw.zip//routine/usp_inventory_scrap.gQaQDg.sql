CREATE PROCEDURE [inventory].[usp_inventory_scrap]
	@id_area_destination INT,
	@id_scrap_reason INT,
	@scrap_reason VARCHAR(MAX) = NULL,
	@list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	SET NOCOUNT ON;

	/* get scrap reason text. */
	IF (@scrap_reason IS NULL)
		SET @scrap_reason = (SELECT name FROM inventory.scrap_reason WHERE id_scrap_reason=@id_scrap_reason)

	/* loop through batch list and update inventory. */
	DECLARE @id_batch INT,
			@id_area INT,
			@quantity DECIMAL(18,4), 
			@quantity_neg DECIMAL(18,4)

	DECLARE item_cursor CURSOR FAST_FORWARD FOR 
	SELECT * FROM OPENJSON(@list)
	WITH (
		id_batch INT,
		id_area INT,
		quantity DECIMAL(18,4)
	)
	WHERE quantity>0
		
	OPEN item_cursor
	FETCH NEXT FROM item_cursor INTO @id_batch, @id_area, @quantity
		
	WHILE(@@FETCH_STATUS = 0)
	BEGIN
		SET @quantity_neg = -@quantity

		/* move item. */
		EXEC [log].usp_event_create 'inventory_scrap', @id_batch, @id_area, @quantity_neg, @scrap_reason, @id_user
		EXEC [log].usp_event_create 'inventory_scrap', @id_batch, @id_area_destination, @quantity, @scrap_reason, @id_user

		FETCH NEXT FROM item_cursor INTO @id_batch, @id_area, @quantity
	END

	CLOSE item_cursor
	DEALLOCATE item_cursor

	/* create move log. */
go

