
CREATE PROCEDURE [base].[usp_location_area_list]
	@id_location BIGINT = NULL
AS
	SET NOCOUNT ON;
--DECLARE @id_location BIGINT = 1000

	;WITH areas_cte ([type],id_area, id_parent, [name], deleted, returnable) as (
	SELECT 
		 t.[name] 'type'
		,a.id_area as 'id_area'
		,a.id_parent as 'id_parent'
		,a.[name] as 'name'
		,a.deleted
		,a.returnable
	FROM inventory.area a 
	LEFT OUTER JOIN inventory.area_type t ON a.id_area_type = t.id_area_type
	WHERE a.id_location = @id_location
	),hierarchy_cte ([type],id_area, id_parent, [name], [parents], [level], [path], deleted, returnable) as (
	SELECT 
		 [type]
		,[id_area]
		,[id_parent]
		,[name]
		,CAST([id_area] as VARCHAR(255)) as [parents]
		,1 as [level]
		,CAST([name] as VARCHAR(400)) as [path]
		,deleted
		,returnable
	FROM areas_cte
	WHERE id_parent IS NULL
	UNION ALL
	SELECT 
		 c.[type]
		,c.id_area
		,c.id_parent
		,c.[name]
		,CAST(CONCAT(p.[parents], ',', CAST(c.id_area as VARCHAR(50))) as VARCHAR(255))
		,p.[level] + 1
		,CAST(CONCAT(p.[path], ' > ', c.[name]) as VARCHAR(400))
		,c.deleted
		,c.returnable
	FROM areas_cte c
	INNER JOIN hierarchy_cte p on p.id_area = c.id_parent
	)
	SELECT * FROM hierarchy_cte
	ORDER BY parents
	OPTION(maxrecursion 0)
go

