CREATE PROCEDURE [inventory].[usp_status_list]
	
AS
	SELECT s.id_status
			, s.name AS status
	FROM inventory.status s
go

