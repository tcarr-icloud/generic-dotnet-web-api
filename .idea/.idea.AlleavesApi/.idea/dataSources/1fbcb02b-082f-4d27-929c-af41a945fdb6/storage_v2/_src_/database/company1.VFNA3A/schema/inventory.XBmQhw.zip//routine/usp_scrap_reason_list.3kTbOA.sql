CREATE PROCEDURE [inventory].[usp_scrap_reason_list]
	@id_scrap_reason INT = NULL
AS
	SET NOCOUNT ON;

	SELECT id_scrap_reason
			, name AS scrap_reason
			, system
	FROM inventory.scrap_reason
	WHERE id_scrap_reason=ISNULL(@id_scrap_reason, id_scrap_reason)
	ORDER BY (CASE WHEN name = 'Other' THEN 1 ELSE 0 END), name
go

