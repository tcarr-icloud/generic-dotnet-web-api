CREATE PROCEDURE [weedmaps].[usp_get_category_default]
AS
	IF EXISTS(SELECT 1 FROM weedmaps.default_category)
		SELECT TOP 1 [default] FROM weedmaps.default_category
	ELSE 
		RETURN 0
go

