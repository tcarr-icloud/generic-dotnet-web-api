CREATE PROCEDURE [process].[usp_process_abandon]
	@id_process INT,
	@input_list VARCHAR(MAX) = '[]',
	@id_user INT
AS

	/* update process status. */
	UPDATE process.process
	SET cancelled=1
		, id_status=4
		, updated_by=@id_user
		, date_updated=getutcdate()
	WHERE id_process=@id_process

	/* add back inventory for returned items. */
	DROP TABLE IF EXISTS #return_list 
	SELECT * INTO #return_list FROM (
		SELECT i.id_batch
				, i.id_area
				, i.quantity AS adjustment
		FROM OPENJSON(@input_list) WITH (
			id_process_input INT,
			action VARCHAR(32)
		) l
		JOIN process.process_input i ON i.id_process_input=l.id_process_input
		WHERE l.action='return'
	) t

	DECLARE @return_list VARCHAR(MAX) = (SELECT * FROM #return_list FOR JSON PATH)

	EXEC [log].usp_event_create_bulk 'process_input_return', NULL, @return_list, @id_user

	/* return updated process. */
	EXEC process.usp_process_list @id_process
go

