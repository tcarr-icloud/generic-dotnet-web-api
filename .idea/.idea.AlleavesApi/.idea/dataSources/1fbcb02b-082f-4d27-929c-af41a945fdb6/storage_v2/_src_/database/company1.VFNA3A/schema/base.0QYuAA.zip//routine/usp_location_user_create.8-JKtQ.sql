CREATE PROCEDURE [base].[usp_location_user_create] @id_user INT, @id_location INT, @metrc_api_user_key VARCHAR(256),
                                                   @biotrack_api_user_key VARCHAR(256), @is_accessible BIT,
                                                   @biotrack_username VARCHAR(256), @biotrack_password VARCHAR(256),
                                                   @biotrack_employee_id VARCHAR(256)
AS
INSERT [base].[user_location] (id_user, id_location, metrc_api_user_key, biotrack_api_user_key, is_accessible,
                               biotrack_username, biotrack_password, biotrack_employee_id)
VALUES (@id_user, @id_location, @metrc_api_user_key, @biotrack_api_user_key, @is_accessible, @biotrack_username,
        @biotrack_password, @biotrack_employee_id)

SELECT id_user_location,
       id_user,
       id_location,
       metrc_api_user_key,
       biotrack_api_user_key,
       is_accessible,
       biotrack_username,
       biotrack_password,
       biotrack_employee_id,
       ts
FROM [base].[user_location]
WHERE id_user_location = SCOPE_IDENTITY()
go

