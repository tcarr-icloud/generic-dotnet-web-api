CREATE PROCEDURE [order].[usp_queue_list]
	@id_customer INT = NULL,
	@id_location INT = NULL
AS

--DECLARE
--	@id_customer INT = NULL,
--	@id_location INT = NULL

-- CTE for Resolving Merged Customer Profiles
;WITH MergedCustomerProfile_CTE AS (
    SELECT id_customer AS effective_customer_id, id_merging_customer as id_customer
    FROM [order].customer_merge
    WHERE deleted_merge = 0 AND id_customer NOT IN (
        SELECT id_merging_customer FROM [order].customer_merge WHERE deleted_merge = 0
    )

    UNION ALL

    SELECT cc.effective_customer_id, cm.id_merging_customer
    FROM MergedCustomerProfile_CTE cc
    INNER JOIN [order].customer_merge cm ON cc.id_customer = cm.id_customer
    WHERE cm.deleted_merge = 0
)
SELECT * INTO #MergedCustomerProfile FROM MergedCustomerProfile_CTE
OPTION (MAXRECURSION 100)

-- Customer Orders
SELECT 
    o.id_order, 
    o.id_customer, 
    o.[type], 
    o.total, 
    o.void, 
    o.cancel, 
    o.paid_in_full,
    COUNT(i.id_item) AS line_item_count,
	ROW_NUMBER() OVER (PARTITION BY o.id_customer ORDER BY o.id_order DESC) AS order_rank
	INTO #CustomerOrders
FROM [order].[order] o
LEFT JOIN [order].[item] i ON o.id_order = i.id_order
WHERE 
	cancel = 0
AND void = 0
AND paid_in_full = 0	
GROUP BY o.id_order, o.id_customer, o.[type], o.total, o.void, o.cancel, o.paid_in_full


-- Main Query
SELECT 
    q.id_customer,
    q.id_queue,
    q.id_location,
    c.name_first,
    c.name_last,
    c.patient_number,
    c.date_of_birth,
    (
        SELECT
			co.id_order,
            co.[type],
            co.total,
            co.line_item_count,
            pu.pickup_customer_arrived,
            pu.pickup_order_incoming,
            pu.pickup_vehicle_make,
            pu.pickup_vehicle_color
        FROM #CustomerOrders co
        LEFT JOIN [order].pickup pu ON pu.id_order=co.id_order
        LEFT OUTER JOIN #MergedCustomerProfile mcp ON co.id_customer = mcp.id_customer
        WHERE 
			(
				co.id_customer = q.id_customer
				OR mcp.effective_customer_id = q.id_customer
			)
            AND co.void = 0 
            AND co.cancel = 0 
            AND co.paid_in_full = 0
			AND co.order_rank <= 6
        FOR JSON PATH, INCLUDE_NULL_VALUES
    ) AS orders,
    l.[name] AS [location],
    CONVERT(VARCHAR, q.time_in, 100) AS time_entry,
    q.time_in,
    q.time_out 
FROM [order].queue q
JOIN [base].location l ON l.id_location=q.id_location
JOIN [order].customer c ON c.id_customer=q.id_customer
WHERE 
    (q.id_customer=ISNULL(@id_customer,q.id_customer)) AND
	(q.id_customer NOT IN (SELECT id_customer FROM #MergedCustomerProfile)) AND
    (q.id_location=ISNULL(@id_location, q.id_location)) AND
    q.time_out IS NULL
ORDER BY q.time_in
go

