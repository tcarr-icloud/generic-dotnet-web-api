CREATE PROCEDURE [order].[usp_driver_go_upsert]
	@id_driver INT = NULL,
	@id_user_alleaves INT = NULL,
	@lat VARCHAR(250) = NULL,
	@long VARCHAR(250) = NULL,
	@journey_started BIT = 0
AS
		UPDATE [order].driver SET lat=isnull(@lat,lat),long=isnull(@long,long),
		                          journey_started = isnull(@journey_started,journey_started)
		WHERE id_driver=@id_driver OR id_user = @id_user_alleaves
go

