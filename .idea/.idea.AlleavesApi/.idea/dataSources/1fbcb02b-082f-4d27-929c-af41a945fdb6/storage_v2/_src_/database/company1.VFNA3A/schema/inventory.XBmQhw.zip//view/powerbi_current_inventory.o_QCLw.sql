create view inventory.powerbi_current_inventory as (
select item.date_created as date,
       inv.product,
       inv.category,
       sum(inv.available) as available
from [order].item
join inventory.vw_current_inventory inv on item.id_inventory_item = inv.id_item
group by inv.product,inv.category,item.date_created )
go

