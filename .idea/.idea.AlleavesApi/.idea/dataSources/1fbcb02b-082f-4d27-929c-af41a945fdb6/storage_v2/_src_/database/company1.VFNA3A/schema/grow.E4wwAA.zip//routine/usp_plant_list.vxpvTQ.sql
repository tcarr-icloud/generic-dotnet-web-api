CREATE PROCEDURE [grow].[usp_plant_list]
	@id_plant BIGINT = NULL,
	@id_location INT = NULL,	
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL,
	@plant_list VARCHAR(MAX) = NULL
AS
   
	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = '	
	SELECT * FROM (
		SELECT p.id_plant
				, s.id_strain
				, st.id_strain_type
				, l.id_location
				, a.id_area
				, p.id_mother
				, l.name AS location
				, p.name AS plant
				, p.source
				, s.name AS strain
				, st.name AS strain_type
				, CAST(ph.date_birth AS VARCHAR(16)) AS date_birth
				, ph.phase_current
				, CAST(ph.phase_current_date AS VARCHAR(16)) AS phase_current_date
				, (CASE WHEN ph.phase_current_date IS NOT NULL THEN DATEDIFF(day, ph.phase_current_date, GETUTCDATE()) ELSE NULL END) AS phase_current_days
				, p.date_seedling
				, p.date_germination
				, p.date_vegetative
				, p.date_preflower
				, p.date_flower
				, p.date_harvest
				, p.id_harvest
				, p.harvested
				, p.harvest_weight_g
				, p.destroyed
				, p.date_destroyed
				, p.id_destroy_reason
				, dr.name AS destroy_reason
				, p.destroy_description
				, a.name AS area
				, a.path AS area_path
				, p.[row]
				, p.[column]
				, CONCAT(ISNULL(CAST(p.[row] AS VARCHAR(16)), ''-''), 
							''-'',
							CASE WHEN p.[column] IS NOT NULL AND (p.[column] - ((p.[column] - 1) % 26)) / 26 > 0 THEN NCHAR(UNICODE(N''A'') + (((p.[column] - ((p.[column] - 1) % 26)) / 26 - 1) % 26) ) ELSE '''' END,
							CASE WHEN p.[column] IS NOT NULL THEN NCHAR(UNICODE(N''A'') + ((p.[column] - 1) % 26)) ELSE ''-'' END
					) AS grid
				, CAST((CASE WHEN t.id_plant IS NOT NULL THEN 1 ELSE 0 END) AS BIT) AS is_in_transfer
				, t.id_transfer
				, p.is_mother
				, m.name AS mother
				, ms.name AS mother_strain
				, p.packaged
				, p.is_medical
				, p.is_adult
				, p.metrc_batch
				, mb.metrc_batch_count
				, p.metrc_id
				, p.metrc_label
				, CONCAT(u.FirstName, '' '', u.LastName) AS user_updated
		FROM grow.plant p
		JOIN grow.strain s ON s.id_strain=p.id_strain
		JOIN grow.strain_type st ON st.id_strain_type=s.id_strain_type
		LEFT JOIN grow.plant m ON m.id_plant=p.id_mother
		LEFT JOIN grow.strain ms ON ms.id_strain=m.id_strain
		LEFT JOIN inventory.vw_area_list a ON a.id_area=p.id_area
		LEFT JOIN base.location l ON l.id_location=a.id_location	
		LEFT JOIN grow.destroy_reason dr ON dr.id_destroy_reason=p.id_destroy_reason
		JOIN base.[user] u ON u.id_user=p.id_user_updated
		JOIN (
			SELECT id_plant
					, CASE WHEN harvested = 1 THEN ''Harvested''
							WHEN destroyed = 1 THEN ''Destroyed''
							WHEN date_flower IS NOT NULL THEN ''Flowering''
							WHEN date_preflower IS NOT NULL THEN ''Pre-Flowering''
							WHEN date_vegetative IS NOT NULL THEN ''Vegetative''
							WHEN date_germination IS NOT NULL THEN ''Germination''
							WHEN date_seedling IS NOT NULL THEN ''Seedling''
							ELSE NULL END AS phase_current
					, CASE WHEN harvested = 1 THEN NULL
							ELSE COALESCE(date_flower, date_preflower, date_vegetative, date_germination, date_seedling) END 
						AS phase_current_date
					, COALESCE(date_seedling, date_germination, date_vegetative, date_preflower, date_flower) AS date_birth
			FROM grow.plant
		) ph ON ph.id_plant=p.id_plant
		LEFT JOIN (
			SELECT tp.id_plant
					, tr.id_transfer
			FROM grow.transfer_plant tp
			JOIN grow.transfer tr ON tr.id_transfer=tp.id_transfer
			WHERE tr.received=0 AND tr.cancelled=0
		) t ON t.id_plant=p.id_plant
		LEFT JOIN (
			SELECT metrc_batch, COUNT(*) AS metrc_batch_count
			FROM grow.plant
			WHERE metrc_batch IS NOT NULL AND metrc_id IS NULL
			GROUP BY metrc_batch
		) mb ON mb.metrc_batch=p.metrc_batch
	) plant
	'

	SET @where = 'WHERE id_location = '+ ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location')
	SET @where = @where + ' AND id_plant = '+ ISNULL(CAST(@id_plant AS VARCHAR(16)), 'id_plant')
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)
	IF (@plant_list IS NOT NULL)
		SET @where = @where + CONCAT(' AND id_plant in (', (SELECT STRING_AGG(value, ',') FROM OPENJSON(@plant_list)), ')')

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'plant')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DROP TABLE IF EXISTS #plant_list
	SELECT * INTO #plant_list FROM ('+@base_sql+') t;

	SELECT 
		*, 
		(SELECT COUNT(1) FROM #plant_list) AS total_rows
	FROM #plant_list t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

