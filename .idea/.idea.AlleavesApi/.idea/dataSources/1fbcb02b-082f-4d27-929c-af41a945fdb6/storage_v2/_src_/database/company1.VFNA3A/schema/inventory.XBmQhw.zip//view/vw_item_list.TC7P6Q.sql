
CREATE VIEW [inventory].[vw_item_list]
	AS
SELECT id.id_item_group
		, i.id_item
		, id.id_location
		, id.id_category
		, id.id_delivery_route
		, id.id_uom
		, id.id_uom_receiving
		, id.id_brand
        , id.id_strain
        , id.id_vendor
		, id.units_per_received
		, id.name AS item_group
		, RTRIM(CONCAT(id.name, ' ', (
					SELECT STRING_AGG(av.name, ' ')
					FROM inventory.item_attribute_value iav
					LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
					WHERE iav.id_item=i.id_item)
				)) AS item
		, l.name AS location
		, c.name AS category
		, c.path AS category_path
		, i.sku
		, i.barcode AS item_barcode
		, base.fn_barcode_human_readable(i.barcode) AS item_barcode_split
		, u.name AS uom
		, u.name_short AS uom_short
		, id.batch_required
		, id.has_shelf_life
		, id.shelf_life_days
		, id.threshold_low_quantity
		, id.is_low_thc
		, id.is_medicated
		, id.is_smoking
		, id.is_low_thc_and_medical
		, id.is_cannabis
		, id.is_adult_use
		, id.is_medical_use
		, uc.multiplier * i.weight_useable as weight_useable_g
		, i.weight_useable
		, id.id_uom_weight_useable
		, w.name AS weight_useable_uom
		, w.name_short AS weight_useable_uom_short
		, ucc.multiplier * i.gross_weight_useable as gross_weight_useable_g
		, i.weight_net
		, i.id_uom_weight_net
		, nw.name AS net_weight_uom
		, nw.name_short AS net_weight_uom_short
		, i.gross_weight_useable
		, i.id_uom_gross_weight_useable
		, wu.name AS gross_weight_useable_uom
		, wu.name_short AS gross_weight_useable_uom_short
		, id.dosage_recommended
		, dr.name AS delivery_route
		, id.is_product
		, br.name AS brand
        , vd.name as vendor
        , st.name as strain
		, id.id_tax_category
		, tc.name AS tax_category
		, id.product_description
		, i.use_otd_price
		, i.cost_of_good
		, i.price_wholesale
		, i.price_retail
		, i.price_otd
		, i.price_retail_adult_use
		, i.price_otd_adult_use
		, i.price_retail_medical_use
		, i.price_otd_medical_use
		, NULL as price_sale
		, i.external_id
		, i.metrc_item_id
		, i.metrc_category
		, i.biotrack_barcode_id
		, i.biotrack_inventory_type_id
		, biot.name as biotrack_inventory_type_name
		, id.id_ommu_form
		, ommuf.name as ommu_form_name
		, id.is_ommu_delivery_device
		, i.date_created
		, CASE WHEN i.deleted=1 OR id.deleted=1 THEN 1 ELSE 0 END AS deleted
FROM inventory.item_group id
LEFT JOIN inventory.item i ON i.id_item_group=id.id_item_group
LEFT JOIN inventory.uom u ON u.id_uom=id.id_uom
LEFT JOIN inventory.uom w ON w.id_uom=id.id_uom_weight_useable
LEFT JOIN inventory.uom nw ON nw.id_uom=i.id_uom_weight_net
LEFT JOIN inventory.uom_convert uc on 
	uc.id_uom_from = id.id_uom_weight_useable AND
	uc.id_uom_to = (SELECT id_uom FROM inventory.uom WHERE name_short = 'g')
LEFT JOIN inventory.uom wu ON wu.id_uom=i.id_uom_gross_weight_useable
LEFT JOIN inventory.uom_convert ucc on 
	ucc.id_uom_from = i.id_uom_gross_weight_useable AND
	ucc.id_uom_to = (SELECT id_uom FROM inventory.uom WHERE name_short = 'g')
LEFT JOIN inventory.delivery_route dr ON dr.id_delivery_route=id.id_delivery_route
LEFT JOIN inventory.vw_category_list c ON c.id_category=id.id_category
LEFT JOIN base.location l ON l.id_location=id.id_location
LEFT JOIN inventory.brand br ON br.id_brand=id.id_brand
LEFT JOIN inventory.vendor vd ON vd.id_vendor=id.id_vendor
LEFT JOIN grow.strain st ON st.id_strain=id.id_strain
LEFT JOIN tax.category tc ON tc.id_tax_category=id.id_tax_category
LEFT JOIN ommu.form ommuf ON ommuf.id_form=id.id_ommu_form
LEFT JOIN biotrack.inventory_type biot ON biot.id_inventory_type=i.biotrack_inventory_type_id
go

