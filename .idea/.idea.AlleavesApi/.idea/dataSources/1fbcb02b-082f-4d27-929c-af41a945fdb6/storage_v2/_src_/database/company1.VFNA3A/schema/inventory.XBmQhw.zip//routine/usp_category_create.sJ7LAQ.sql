CREATE PROCEDURE [inventory].[usp_category_create]
	@name VARCHAR(128),
	@id_parent INT = NULL,
	@id_category_image INT = NULL,
	@id_delivery_route INT,
	@id_user INT,
	@system BIT = 0
AS
	SET NOCOUNT ON;

	IF EXISTS (SELECT * FROM inventory.category WHERE deleted=0 AND name=@name AND ((@id_parent IS NULL AND id_parent IS NULL) OR id_parent=@id_parent))
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A category with this name under the same parent already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	INSERT INTO inventory.category (name, id_parent, id_category_image, id_delivery_route, updated_by, system) VALUES
		(@name, @id_parent,@id_category_image, @id_delivery_route, @id_user, @system)

	DECLARE @id_category INT = SCOPE_IDENTITY()

	EXEC inventory.usp_category_list @id_category
go

