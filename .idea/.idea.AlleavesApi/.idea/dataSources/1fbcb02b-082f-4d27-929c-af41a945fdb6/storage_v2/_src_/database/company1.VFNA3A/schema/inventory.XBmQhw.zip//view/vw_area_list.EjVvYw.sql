
CREATE VIEW [inventory].[vw_area_list]
	AS 
WITH	area_path AS (
			SELECT 
				a.id_area,
				a.id_parent,
				a.id_location,
				a.id_area_type,
				a.id_status, 
				a.name, 
				a.rows,
				a.columns,
				a.canopy_sqft,
				a.metrc_id,
				a.internal_id_area, 
				a.deleted,
				a.updated_by,
				a.date_updated,
				a.date_created,
				CAST(a.name AS VARCHAR(MAX)) AS path,
				a.returnable,
				a.priority,
				a.mobile
			FROM inventory.area a
			WHERE a.id_parent IS NULL
			UNION ALL
			SELECT 
				b.id_area, 
				b.id_parent, 
				b.id_location, 
				b.id_area_type, 
				b.id_status, 
				b.name, 
				b.rows, 
				b.columns, 
				b.canopy_sqft, 
				b.metrc_id, 
				b.internal_id_area, 
				b.deleted, 
				b.updated_by, 
				b.date_updated, 
				b.date_created, 
				CONCAT(p.path, ' > ', b.name) AS path, 
				b.returnable, 
				b.priority,
				b.mobile
			FROM inventory.area b
			JOIN area_path p ON p.id_area=b.id_parent
		)
SELECT * FROM area_path
go

