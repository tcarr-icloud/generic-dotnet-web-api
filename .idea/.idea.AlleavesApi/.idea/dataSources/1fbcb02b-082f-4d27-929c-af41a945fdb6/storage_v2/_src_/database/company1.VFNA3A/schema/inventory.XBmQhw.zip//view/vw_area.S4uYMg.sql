CREATE VIEW [inventory].[vw_area]

AS

SELECT
	 i.id_area
	,i.id_batch
	,atp.[name] AS area
FROM [inventory].inventory i
JOIN [inventory].area a ON a.id_area = i.id_area
JOIN [inventory].area_type atp ON atp.id_area_type = a.id_area_type
go

