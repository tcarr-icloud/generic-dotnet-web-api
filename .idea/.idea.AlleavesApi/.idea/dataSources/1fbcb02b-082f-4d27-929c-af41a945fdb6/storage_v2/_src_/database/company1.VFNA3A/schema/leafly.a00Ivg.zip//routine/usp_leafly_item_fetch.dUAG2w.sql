CREATE PROCEDURE [leafly].[usp_leafly_item_fetch]
	@id_location INT,
	@id_batch INT = NULL
AS
	SELECT 
	id_item,
	CASE WHEN COUNT(id_item)>1 THEN 1 ELSE 0 END as has_multiple_batches,
	MAX(name) as name,
	MAX(leafly_type) as leafly_type,
	MAX(strain) as strain,
	MAX(brand) as brand,
	MAX(id_batch) as id_batch,
	MAX(id_batch_parent) as id_batch_parent,
	MAX(sku) as sku,
	MAX(thc) as thc,
	MAX(cbd) as cbd,
	MAX(thc_mg) as thc_mg,
	MAX(cbd_mg) as cbd_mg,
	MAX(CASE WHEN is_cannabis=1 THEN 1 ELSE 0 END) as is_cannabis,
	MAX(CASE WHEN is_adult_use=1 THEN 1 ELSE 0 END) as is_adult_use,
	MAX(CASE WHEN is_medical_use=1 THEN 1 ELSE 0 END) as is_medical_use,
	MAX(CASE WHEN is_tax_exempt=1 THEN 1 ELSE 0 END) as is_tax_exempt,
	MAX(price_retail) as price_retail,
	MAX(price_retail_adult_use) as price_retail_adult_use,
	MAX(price_retail_medical_use) as price_retail_medical_use,
	MAX(price_otd) as price_otd,
	MAX(price_otd_adult_use) as price_otd_adult_use,
	MAX(price_otd_medical_use) as price_otd_medical_use,
	MAX(uom) as uom,
	MAX(uom_short) as uom_short,
	MAX(weight_useable) as weight_useable,
	MAX(weight_useable_g) as weight_useable_g,
	MAX(weight_useable_uom) as weight_useable_uom,
	MAX(weight_useable_uom_short) as weight_useable_uom_short,
	SUM(on_hand) as on_hand,
	SUM(available) as available,
	MAX(CASE WHEN has_inventory=1 THEN 1 ELSE 0 END) as has_inventory,
	MAX(product_description) as product_description,
	MAX(content) as content

FROM (
SELECT ib.id_item,
		ib.id_batch,
		iig.id_item_group,
		RTRIM(CONCAT(iig.name, ' ', (
						SELECT STRING_AGG(av.name, ' ') 
						FROM inventory.item_attribute_value iav
						LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
						WHERE iav.id_item=ib.id_item)
					)) AS name,
		lt.leafly_type,
		s.[name] as strain,
		br.[name] as brand,
		ibh.id_batch_parent,
		ii.sku,
		-- COMPOUNDS
		ISNULL(CAST((SELECT TOP 1 trcp.[value]
			FROM inventory.test_result_chemical_profile trcp
			LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
			WHERE icp.id_chemical_profile=2 AND trcp.id_test_result=t.id_test_result) / 100.0 AS DECIMAL(6, 5)), NULL) as thc,
		ISNULL(CAST((SELECT TOP 1 trcp.[value]
			FROM inventory.test_result_chemical_profile trcp
			LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
			WHERE icp.id_chemical_profile=1 AND trcp.id_test_result=t.id_test_result) / 100.0 AS DECIMAL(6, 5)), NULL) as cbd,
		ISNULL(CAST((SELECT TOP 1 trcp.[value]
			FROM inventory.test_result_chemical_profile trcp
			LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
			WHERE icp.id_chemical_profile = 60 AND trcp.id_test_result=t.id_test_result) AS DECIMAL(18,3)), NULL) as thc_mg,
		ISNULL(CAST((SELECT TOP 1 trcp.[value]
			FROM inventory.test_result_chemical_profile trcp
			LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
			WHERE icp.id_chemical_profile = 61 AND trcp.id_test_result=t.id_test_result) AS DECIMAL(18,3)), NULL) as cbd_mg,
	-- VARIANTS
		iig.is_cannabis,
		iig.is_adult_use,
		iig.is_medical_use,
		iig.is_tax_exempt,
		-- PRICES (WE WILL ALWAYS USE OTD)
		COALESCE(il.price_retail, ii.price_retail, 0) as price_retail,
		COALESCE(il.price_retail_adult_use, ii.price_retail_adult_use, 0) as price_retail_adult_use,
		COALESCE(il.price_retail_medical_use, ii.price_retail_medical_use, 0) as price_retail_medical_use,
		COALESCE(il.price_otd, ii.price_otd, 0) as price_otd,
		COALESCE(il.price_otd_adult_use, ii.price_otd_adult_use, 0) as price_otd_adult_use,
		COALESCE(il.price_otd_medical_use, ii.price_otd_medical_use, 0) as price_otd_medical_use,
		-- AMOUNT AND UNIT
		u.[name] as uom,
		u.name_short as uom_short,
		ii.weight_useable,
		uc.multiplier * ii.weight_useable as weight_useable_g,
		iu.[name] as weight_useable_uom,
		iu.name_short as weight_useable_uom_short,
		-- INVENTORY LEVELS
		inv.on_hand,
		inv.available,
		CASE WHEN ISNULL(inv.on_hand, 0) > 0 THEN 1 ELSE 0 END AS has_inventory,
		iig.product_description,
		im.content
	FROM [inventory].[batch] ib
	LEFT JOIN [inventory].[item] ii ON ib.id_item = ii.id_item
	LEFT JOIN [inventory].[item_location] il ON il.id_item = ii.id_item AND il.id_location = @id_location
	LEFT JOIN [inventory].[item_group] iig ON ii.id_item_group = iig.id_item_group
	LEFT JOIN [inventory].[category] c ON iig.id_category = c.id_category
	LEFT JOIN [leafly].[category] lt ON c.id_category = lt.id_category
	LEFT JOIN [inventory].[batch_history] ibh ON ib.id_batch = ibh.id_batch
	LEFT JOIN [grow].[strain] s ON s.id_strain=iig.id_strain
    LEFT JOIN [inventory].[brand] br ON br.id_brand = iig.id_brand
	LEFT JOIN [inventory].[test_result] t ON t.id_batch = ib.id_batch
	LEFT JOIN [inventory].[uom] u ON u.id_uom = iig.id_uom
	LEFT JOIN [inventory].[uom] iu ON iu.id_uom = iig.id_uom_weight_useable
	LEFT JOIN [inventory].[item_media] im ON im.id_item_group = iig.id_item_group
	LEFT JOIN inventory.uom_convert uc on 
		uc.id_uom_from = iig.id_uom_weight_useable AND
		uc.id_uom_to = (SELECT id_uom FROM inventory.uom WHERE name_short = 'g')
	LEFT JOIN (
		SELECT id_batch
				, SUM(on_hand) AS on_hand
				, SUM(available) AS available
		FROM inventory.vw_current_inventory iv
		WHERE iv.id_area IN 
			(SELECT id_area
				FROM [leafly].[menu_retail_area] mra
				WHERE mra.id_location = @id_location
				AND mra.active = 1)
		GROUP BY id_batch
	) inv ON inv.id_batch=ib.id_batch
	WHERE ib.id_item IN (
		SELECT invb.id_item
		FROM [inventory].[batch] invb
		WHERE invb.id_batch=ISNULL(@id_batch, invb.id_batch))
	) as at
	GROUP BY id_item
go

