CREATE PROCEDURE [base].[usp_location_group_upsert]
	@id_location_group INT = NULL,
    @name VARCHAR (128), 
	@location_list VARCHAR(MAX) = '[]',
	@deleted BIT = 0,
	@id_user INT
AS
	IF EXISTS (SELECT * FROM base.location_group WHERE deleted=0 AND @deleted<>1 AND name=@name AND (@id_location_group IS NULL OR id_location_group <> @id_location_group))
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A location group with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	IF (@id_location_group IS NULL)
	BEGIN
		INSERT INTO [base].[location_group] (    
				[name],
				id_user_created,
				id_user_updated) 
	
		VALUES(   
				@name,
				@id_user,
				@id_user)

		SET @id_location_group=SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		UPDATE [base].[location_group]
		SET [name] = @name,
			deleted = @deleted,
			id_user_updated = @id_user,
			date_updated=GETUTCDATE()
			WHERE id_location_group = @id_location_group
	END

	;WITH location_list AS (
		SELECT @id_location_group AS id_location_group
				, id_location
		FROM OPENJSON(@location_list)
		WITH (
			  id_location INT 
		)
	)
	MERGE [base].[location_group_value] AS lg
	USING location_list AS ll
	ON ll.id_location = lg.id_location AND ll.id_location_group = lg.id_location_group  
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_location_group, id_location, id_user_created, id_user_updated) VALUES (ll.id_location_group, ll.id_location, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND lg.id_location_group = @id_location_group THEN
	DELETE
	;
		
	EXEC [base].[usp_location_group_list] @id_location_group, 1
go

