CREATE    PROCEDURE [inventory].[usp_transfer_list]
	@id_transfer INT = NULL,
	@id_location INT = NULL
AS

	SELECT
			  t.date_created
			, t.id_transfer
			, t.id_external
			, t.id_location_source
			, t.id_vendor_source
			, t.id_location_destination
			, t.id_vendor_destination
			, t.id_driver1
			, t.id_driver2
			, t.id_vehicle
			, t.recipient
			, ISNULL(sl.name, sv.name) AS sender_name
			, ISNULL(dl.name, dv.name) AS recipient_name
			, ISNULL(dl.phone, dv.phone) AS recipient_phone
			, t.address
			, t.city
			, t.state
			, t.postal_code
			, ISNULL(sl.phone, sv.phone) AS sender_phone
			, ISNULL(sl.address, sv.shipping_address) AS sender_address
			, ISNULL(sl.city, sv.shipping_city) AS sender_city
			, ISNULL(sl.state, sv.shipping_state) AS sender_state
			, ISNULL(sl.postal_code, sv.shipping_postal_code) AS sender_postal_code
			, t.tracking_number
			, t.internal_reference
			, t.notes
			, CASE WHEN t.id_driver1 IS NULL THEN NULL ELSE CONCAT(d1u.FirstName, ' ', d1u.LastName) END AS driver1_name
			, CASE WHEN t.id_driver2 IS NULL THEN NULL ELSE CONCAT(d2u.FirstName, ' ', d2u.LastName) END AS driver2_name
			, d1.license AS driver1_license
			, d2.license AS driver2_license
			, v.name AS vehicle
			, v.company AS vehicle_company
			, v.phone AS vehicle_phone
			, v.make AS vehicle_make
			, v.model AS vehicle_model
			, v.color AS vehicle_color
			, v.license AS vehicle_license
			, t.is_return
			, t.id_transfer_return
			, t.date_created
			, t.date_updated
			, t.complete
			, t.cancelled
			,(select top 1 id_delivery_route from [order].ride_transfer_delivery_route where id_transfer=t.id_transfer order by id_ride_transfer_delivery_route desc) as id_delivery_route
			,(select top 1 position from [order].[ride_transfer_delivery_route] where id_transfer=t.id_transfer order by id_ride_transfer_delivery_route desc) as position
			, ISNULL((SELECT tsh.id_transfer_status
							, tsh.id_transfer
							, tsh.id_user_verified
							, ts.name AS transfer_status
							, ts.reference AS transfer_status_reference
							, CONCAT(uv.FirstName, ' ', uv.LastName) AS verified_by
							, uv.FirstName AS verified_name_first
							, uv.LastName AS verified_name_last
							, tsh.date_verified
					  FROM inventory.transfer_status_history tsh
					  JOIN inventory.transfer_status ts ON ts.id_transfer_status=tsh.id_transfer_status
					  JOIN base.[user] uv ON uv.id_user=tsh.id_user_verified
					  WHERE tsh.id_transfer=t.id_transfer
					  ORDER BY tsh.date_verified
					  FOR JSON PATH
			), '[]') AS status_list
	     , ISNULL((SELECT rsh.id_ride_status_history
							, rsh.id_transfer
							, rsh.id_user_verified
							, rs.name AS ride_status
							, rs.reference AS ride_status_reference
							, CONCAT(uv.FirstName, ' ', uv.LastName) AS verified_by
							, uv.FirstName AS verified_name_first
							, uv.LastName AS verified_name_last
							, rsh.date_verified
					  FROM inventory.ride_status_history rsh
					  JOIN inventory.ride_status rs ON rs.id_ride_status=rsh.id_ride_status
					  JOIN base.[user] uv ON uv.id_user=rsh.id_user_verified
					  WHERE rsh.id_transfer=t.id_transfer
					  ORDER BY rsh.date_verified
					  FOR JSON PATH
			), '[]') AS ride_status_list
	     ,(SELECT top 1  rs.name AS transfer_status
					  FROM inventory.transfer_status_history rsh
					  JOIN inventory.transfer_status rs ON rs.id_transfer_status=rsh.id_transfer_status
					  WHERE rsh.id_transfer=t.id_transfer
					  ORDER BY rsh.date_verified desc ) as last_ride_status
			, ISNULL((SELECT ti.id_transfer_item
							, ti.id_transfer
							, i.id_item_group
							, ti.id_item
							, ti.id_batch
							, ti.id_area
							, st.id_strain
							, ISNULL(bc.name, c.name) AS category
							, ISNULL(bc.path, c.path) AS category_path
							, ISNULL(bi.item, i.item) AS item
							, i.batch_required
							, b.name AS batch
							, base.fn_barcode_human_readable(b.name) AS batch_split
			                , isnull(i.item_barcode,'') as item_barcode
							, a.path AS area_path
							, aa.name AS area_type
							, st.name AS strain
							, ISNULL(bu.name, u.name) AS uom
							, ISNULL(bu.name_short, u.name_short) AS uom_short
							, ti.quantity
							, ti.cost
							, ti.batch_name
					  FROM inventory.transfer_item ti
					  LEFT JOIN inventory.vw_item_list i ON i.id_item=ti.id_item
					  LEFT JOIN inventory.vw_category_list c ON c.id_category=i.id_category
					  LEFT JOIN inventory.uom u ON u.id_uom=i.id_uom
					  LEFT JOIN inventory.batch b ON b.id_batch=ti.id_batch
					  LEFT JOIN inventory.vw_item_list bi ON bi.id_item=b.id_item
					  LEFT JOIN inventory.vw_category_list bc ON bc.id_category=bi.id_category
					  LEFT JOIN inventory.uom bu ON bu.id_uom=bi.id_uom
					  LEFT JOIN inventory.vw_area_list a ON a.id_area=ti.id_area
					  LEFT JOIN inventory.area_type aa ON aa.id_area_type=a.id_area_type
					  LEFT JOIN grow.strain st ON st.id_strain=b.id_strain
					  WHERE ti.id_transfer=t.id_transfer
					  ORDER BY i.item, bi.item, b.name
					  FOR JSON PATH
			), '[]') AS pick_list
			, ISNULL((SELECT ti.id_transfer
							, ISNULL(ti.id_item, bi.id_item) AS id_item
							, ti.id_batch
							, st.id_strain
							, ISNULL(bc.name, c.name) AS category
							, ISNULL(bc.path, c.path) AS category_path
							, ISNULL(bi.item, i.item) AS item
							, b.name AS batch
							, base.fn_barcode_human_readable(b.name) AS batch_split
							, st.name AS strain
							, ISNULL(bu.name, u.name) AS uom
							, ISNULL(bu.name_short, u.name_short) AS uom_short
							, ISNULL(bi.is_cannabis, i.is_cannabis) AS is_cannabis
							, ISNULL(bi.batch_required, i.batch_required) AS batch_required
							, SUM(ti.quantity) AS quantity
							, SUM(ti.quantity_received) AS quantity_received
							, SUM(ti.quantity_refused) AS quantity_refused
							, MAX(ti.id_refuse_reason) AS id_refuse_reason
							, CASE WHEN MAX(ISNULL(ti.id_refuse_reason, rr.name)) IS NOT NULL THEN MAX(ISNULL(ti.refuse_reason, rr.name)) ELSE NULL END AS refuse_reason
							, SUM(ti.cost) AS cost
							, ti.batch_name
					  FROM inventory.transfer_item ti
					  LEFT JOIN inventory.vw_item_list i ON i.id_item=ti.id_item
					  LEFT JOIN inventory.vw_category_list c ON c.id_category=i.id_category
					  LEFT JOIN inventory.uom u ON u.id_uom=i.id_uom
					  LEFT JOIN inventory.batch b ON b.id_batch=ti.id_batch
					  LEFT JOIN inventory.vw_item_list bi ON bi.id_item=b.id_item
					  LEFT JOIN inventory.vw_category_list bc ON bc.id_category=bi.id_category
					  LEFT JOIN inventory.uom bu ON bu.id_uom=bi.id_uom
					  LEFT JOIN grow.strain st ON st.id_strain=b.id_strain
					  LEFT JOIN inventory.refuse_reason rr ON rr.id_refuse_reason=ti.id_refuse_reason
					  WHERE ti.id_transfer=t.id_transfer
					  GROUP BY ti.id_transfer, ti.id_item, bi.id_item, ti.id_batch, st.id_strain, bc.name, c.name, bc.path, c.path, bi.item, i.item, b.name, st.name, bu.name, u.name, bu.name_short, u.name_short, bi.is_cannabis, i.is_cannabis, bi.batch_required, i.batch_required, ti.batch_name
					  ORDER BY i.item, bi.item, b.name
					  FOR JSON PATH
			), '[]') AS manifest
	FROM inventory.transfer t
	LEFT JOIN base.location sl ON sl.id_location=t.id_location_source
	LEFT JOIN base.location dl ON dl.id_location=t.id_location_destination
	LEFT JOIN inventory.vendor sv ON sv.id_vendor=t.id_vendor_source
	LEFT JOIN inventory.vendor dv ON dv.id_vendor=t.id_vendor_destination
	LEFT JOIN [order].driver d1 ON d1.id_driver=t.id_driver1
	LEFT JOIN [order].driver d2 ON d2.id_driver=t.id_driver2
	LEFT JOIN base.[user] d1u ON d1u.id_user=d1.id_user
	LEFT JOIN base.[user] d2u ON d2u.id_user=d2.id_user
	LEFT JOIN [order].vehicle v ON v.id_vehicle=t.id_vehicle
	WHERE t.id_transfer=ISNULL(@id_transfer, t.id_transfer)
	AND ( @id_location is null OR t.id_location_source=@id_location OR t.id_location_destination=@id_location)
    order by t.date_created desc
go

