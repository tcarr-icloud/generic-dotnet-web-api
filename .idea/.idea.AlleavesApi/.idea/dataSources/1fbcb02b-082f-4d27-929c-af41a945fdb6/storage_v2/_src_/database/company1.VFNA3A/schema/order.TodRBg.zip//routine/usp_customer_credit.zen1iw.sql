-- =============================================
-- Author:		Jeff Hanes
-- Create date: 2/12/21
-- Description:	add credit debit entry
-- =============================================
CREATE PROCEDURE [order].[usp_customer_credit]
	-- Add the parameters for the stored procedure here
	@id_order int = null,
	@id_customer int,
	@amount decimal(18,2),
	@reason nvarchar(255),
	@notes  VARCHAR(MAX),
	@id_user int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    INSERT INTO [order].customer_credit_debit (id_customer, id_order, amount, reason, notes, created_by)
	VALUES(@id_customer, @id_order, @amount, @reason, @notes, @id_user);
END
go

