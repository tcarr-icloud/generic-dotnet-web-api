CREATE PROCEDURE [process].[usp_process_start]
	@id_form INT,
	@id_location INT,
	@input_list VARCHAR(MAX) = '[]',
	@attribute_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	SET NOCOUNT ON;
	
	/* create process. */
	INSERT INTO process.process (id_form, id_location, date_process, id_status, created_by, updated_by)
		VALUES (@id_form, @id_location, dbo.fn_utc_to_local(getutcdate(), @id_location), 2, @id_user, @id_user)

	DECLARE @id_process INT=SCOPE_IDENTITY()

	/* add attributes. */
	INSERT INTO process.process_attribute (id_process, id_form_attribute, value, created_by, updated_by)
	SELECT @id_process AS id_process
			, id_form_attribute
			, value
			, @id_user AS created_by
			, @id_user AS updated_by
	FROM OPENJSON(@attribute_list)
	WITH (
		id_form_attribute INT '$.id_form_attribute',
		value VARCHAR(MAX) '$.value'
	)
	WHERE value IS NOT NULL

	/* add inputs. */
	EXEC process.usp_process_update_input @id_process, @input_list, @id_user
go

