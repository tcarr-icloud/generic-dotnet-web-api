CREATE PROCEDURE [grow].[usp_destroy_reason_list]
	@id_destroy_reason INT = NULL
AS
	SELECT id_destroy_reason
			, name AS destroy_reason
			, destroy_reason_required
			, system
	FROM grow.destroy_reason
	WHERE (@id_destroy_reason IS NULL OR id_destroy_reason=@id_destroy_reason)
	ORDER BY (CASE WHEN name = 'Other' THEN 1 ELSE 0 END), name
go

