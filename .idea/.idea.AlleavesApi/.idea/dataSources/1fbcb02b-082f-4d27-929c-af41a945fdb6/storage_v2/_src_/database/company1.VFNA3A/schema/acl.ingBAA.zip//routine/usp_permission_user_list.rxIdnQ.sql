CREATE PROCEDURE [acl].[usp_permission_user_list]
	@id_permission INT
AS
BEGIN
	SELECT rp.id_permission
			, rp.allowed
			, p.reference
			, p.label
			, u.id_user
			, u.FirstName AS name_first
			, u.LastName AS name_last
	FROM acl.permission p
	JOIN acl.role_permission rp ON rp.id_permission=p.id_permission
	JOIN acl.role r ON r.id_role=rp.id_role
	JOIN acl.user_role ur ON ur.id_role=r.id_role
	JOIN base.[user] u ON u.id_user=ur.id_user
	WHERE rp.id_permission=@id_permission
	AND u.deleted = 0
	AND u.accountDisabled = 0
END
go

