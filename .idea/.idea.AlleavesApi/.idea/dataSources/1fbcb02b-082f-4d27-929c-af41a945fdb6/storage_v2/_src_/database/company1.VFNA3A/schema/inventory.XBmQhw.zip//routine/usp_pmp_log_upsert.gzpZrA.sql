CREATE PROCEDURE [inventory].[usp_pmp_log_upsert]
@id_pmp_log INT = NULL,
    @id_item INT = NULL,
	@id_order INT = NULL,
	@id_location INT = NULL,
	@id_user INT
AS
	BEGIN
		-- Insert new record
		INSERT INTO [inventory].[pmp_log] ([id_item], [id_order], [id_location], [id_user_created], [id_user_updated], [date_created], [date_updated])
		VALUES (@id_item, @id_order, @id_location, @id_user, @id_user, GETUTCDATE(), GETUTCDATE())

		SET @id_pmp_log = SCOPE_IDENTITY()
	END
go

