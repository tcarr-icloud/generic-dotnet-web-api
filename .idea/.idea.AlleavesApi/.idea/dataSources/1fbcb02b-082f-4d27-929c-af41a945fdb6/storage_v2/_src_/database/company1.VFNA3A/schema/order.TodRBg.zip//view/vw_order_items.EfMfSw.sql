CREATE VIEW [order].[vw_order_items] as (
SELECT
	 r.id_register
	,r.[name] as register_name
	,s.id_session
	,o.id_order
	,o.use_type
	,o.metrc_receipt_id
	,o.date_created as order_date_utc
	,o.date_created AT TIME ZONE 'UTC' AT TIME ZONE 'US Eastern Standard Time' as order_date_est
	,CAST(o.date_created AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as local_order_datetime
	,o.paid_in_full
	,o.verified
	,o.packed
	,o.scheduled
	,o.complete
	,o.cancel
	,o.void
	,o.id_status
	,o.id_customer
	,o.id_location
	,o.id_user_working
	,UPPER(SUBSTRING(o.[type], 1,1)) + LOWER(SUBSTRING(o.[type], 2, LEN(o.[type]))) as [type]
	,i.id_item_group
	,oi.id_inventory_item
	,i.weight_useable_g
	,i.weight_useable
	,i.weight_useable_uom
	,CONVERT(DECIMAL(10,4),i.weight_useable_g * oi.quantity)  as sold_weight_usable_g
	,oi.quantity
	,i.item as inventory_item
	,ic.id_category
	,ic.[name] as inventory_category
	,ic.[path] as inventory_category_path
	,i.item as product
	,ISNULL(ic.[name], 'Uncategorized') as product_category
	,ISNULL(ic.[path], 'Uncategorized') as product_category_path
	,i.cost_of_good as current_cost_of_good
	,b.cost_of_good as batch_cost_of_good
	,i.price_retail as current_retail_price
	,b.[name] as batch_number
	,oi.id_batch
	,oi.is_medicated
	,oi.id_item as id_order_item
	,oi.id_item_return
	,oi.price
	,oi.price_override
	,oi.discount
	,oi.price_post_item_discount
	,oi.price_post_order_discount
	,oi.price_post_item_loyalty
	,oi.price_post_order_loyalty
	,oi.price_post_round
	,oi.price_post_all_adjustments
	,oi.price_post_tax
	,oi.item_state_excise_tax_percentage
	,oi.item_state_sales_tax_percentage
	,oi.item_state_category_tax_percentage
	,oi.item_local_excise_tax_percentage
	,oi.item_local_sales_tax_percentage
	,oi.item_local_category_tax_percentage
	,oi.ommu_order_type_name
	,oi.ommu_form_name
	,oi.thc_mg
	,oi.thc
	,oi.weight_useable as order_item_weight_useable
FROM [order].[order] o
INNER JOIN [order].[item] oi on oi.id_order = o.id_order
LEFT OUTER JOIN [pos].[session] s on o.id_session = s.id_session
LEFT OUTER JOIN [pos].register r on r.id_register = s.id_register
INNER JOIN inventory.batch b on b.id_batch = oi.id_batch 
INNER JOIN inventory.vw_item_list i on i.id_item = b.id_item
LEFT OUTER JOIN inventory.vw_category_list ic on ic.id_category = i.id_category
LEFT OUTER JOIN [base].[location] l on l.id_location = o.id_location
LEFT OUTER JOIN [dbo].[tz_lookup] as tl ON l.[timezone] = tl.[tz_iana]
WHERE o.void = 0
AND o.cancel =0
)
go

