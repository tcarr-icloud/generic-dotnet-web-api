CREATE PROCEDURE [inventory].[usp_batch_auto_close_list]
    @id_item INT = NULL,
    @id_batch INT = NULL
AS
BEGIN
    ;WITH BatchRankings AS (
        SELECT 
            ac.id_batch,
            ac.id_item,
            ara.id_location,
            cfg.auto_close,
            DATEDIFF(hour, ac.date_updated, GETUTCDATE()) AS hours_since_last_update,
            ROW_NUMBER() OVER (
                PARTITION BY ac.id_batch 
                ORDER BY 
                    CASE 
                        WHEN ISNUMERIC(REPLACE(cfg.auto_close, 'h', '')) = 1 
                        THEN CAST(REPLACE(cfg.auto_close, 'h', '') AS int) 
                        ELSE NULL 
                    END DESC
            ) AS RowNum
        FROM inventory.batch_auto_close ac
        INNER JOIN [inventory].[inventory] inv ON ac.id_batch = inv.id_batch
        INNER JOIN [inventory].[area] ara ON inv.id_area = ara.id_area
        INNER JOIN pos.configuration cfg ON ara.id_location = cfg.id_location
        WHERE 
            (ac.id_batch = @id_batch OR @id_batch IS NULL) AND
            (ac.id_item = @id_item OR @id_item IS NULL)
    )
    SELECT 
        id_batch,
        id_item,
        auto_close,
        hours_since_last_update
    FROM 
        BatchRankings
    WHERE 
        RowNum = 1
    ORDER BY 
        id_batch;
END
go

