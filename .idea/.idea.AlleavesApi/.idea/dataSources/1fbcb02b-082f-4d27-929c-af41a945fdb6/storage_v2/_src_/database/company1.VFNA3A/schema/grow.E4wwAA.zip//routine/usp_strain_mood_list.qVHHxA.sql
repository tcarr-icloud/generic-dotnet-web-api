CREATE PROCEDURE [grow].[usp_strain_mood_list]
AS
	SELECT    st.id_strain_mood
			, st.name AS strain_mood
	FROM grow.strain_mood st
go

