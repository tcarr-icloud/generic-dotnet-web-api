CREATE PROCEDURE [grow].[usp_transfer_receive]
	@id_transfer INT,
	@plant_list VARCHAR(MAX) = '[]',
	@id_user INT
AS

	DECLARE @id_location INT = (SELECT id_location_destination FROM grow.transfer WHERE id_transfer=@id_transfer),
			@id_area INT
			

	DROP TABLE IF EXISTS #plant_list
	SELECT p.id_plant
			, p.id_area
			, p.id_strain
			, p.plant
			, p.phase
			, p.phase_date
			, NULL AS [row]
			, NULL AS [column]
			, CONCAT('TransferID: ', @id_transfer) AS notes
			, ROW_NUMBER() OVER (ORDER BY id_strain) AS sequence
	INTO #plant_list
	FROM OPENJSON(@plant_list)
	WITH (
		id_plant INT,
		id_area INT '$.id_area_destination',
		plant VARCHAR(128),
		id_strain INT,
		phase VARCHAR(256),
		phase_date DATE
	) p
	JOIN inventory.vw_area_list a ON a.id_area=p.id_area

	/* if transfer is a purchase order. **************************************************************************/
	IF(SELECT id_vendor_source FROM grow.transfer WHERE id_transfer=@id_transfer) IS NOT NULL
	BEGIN
		DECLARE @id_plant INT,
				@id_strain INT,
				@plant VARCHAR(128),
				@phase VARCHAR(64),
				@phase_date DATE,
				@sequence INT				

		DECLARE @year VARCHAR(4),
				@date VARCHAR(4),
				@curr VARCHAR(32),
				@sequ VARCHAR(8),
				@num INT

		DECLARE c CURSOR FOR
		SELECT id_area, id_strain, plant, phase, phase_date, sequence FROM #plant_list

		OPEN c

		FETCH NEXT FROM c INTO @id_area, @id_strain, @plant, @phase, @phase_date, @sequence
		WHILE @@FETCH_STATUS = 0 BEGIN
			IF @plant IS NULL
			BEGIN
				/* create plant id. */
				SET @year = YEAR(@phase_date)
				SET @date = CONCAT(RIGHT('00'+CAST(MONTH(@phase_date) AS VARCHAR(2)), 2), RIGHT('00'+CAST(DAY(@phase_date) AS VARCHAR(2)), 2))
				SET @curr = (SELECT MAX(name) FROM grow.plant WHERE name LIKE CONCAT('P', @year, @date, '%'))
				SET @sequ = CASE WHEN @curr IS NULL THEN '00000000' ELSE RIGHT(@curr, 8) END
				SET @num = @sequ + 1
				SET @plant = CONCAT('P', @year, @date, RIGHT('00000000' + CONVERT(VARCHAR(32), @num), 8))
			END

			DECLARE @row INT,
					@column INT	

			/* get grid locations. */
			;WITH grid ([row], [column], sequence) AS (
				SELECT b.[row], a.[column], ROW_NUMBER() OVER(ORDER BY b.[row] ASC) + @num - 1 AS sequence
				FROM (
					SELECT [column] = number 
					FROM master..[spt_values] 
					WHERE type='P' AND number BETWEEN 1 AND (SELECT columns FROM inventory.area WHERE id_area=@id_area)
				) a
				CROSS JOIN (
					SELECT [row] = number 
					FROM master..[spt_values] 
					WHERE type='P' AND number BETWEEN 1 AND (SELECT rows FROM inventory.area WHERE id_area=@id_area)
				) b
				LEFT JOIN grow.plant p ON p.[row]=b.[row] AND 
										  p.[column]=a.[column] AND 
										  p.harvested = 0 AND
										  p.destroyed = 0 AND
										  p.id_area=@id_area
				WHERE p.id_plant IS NULL
			)
			SELECT TOP 1 @row=[row], @column=[column] FROM grid

			/* create plant. */
			INSERT INTO grow.plant (name, source, id_strain, id_area, row, [column], date_seedling, date_germination, date_vegetative, date_preflower, date_flower, id_user_created, id_user_updated) 
			VALUES (
				@plant,
				'seed',
				@id_strain,
				@id_area,
				@row,
				@column,
				CASE WHEN @phase='seedling' THEN @phase_date ELSE NULL END,
				CASE WHEN @phase='germination' THEN @phase_date ELSE NULL END,
				CASE WHEN @phase='vegetative' THEN @phase_date ELSE NULL END,
				CASE WHEN @phase='preflower' THEN @phase_date ELSE NULL END,
				CASE WHEN @phase='flower' THEN @phase_date ELSE NULL END,
				@id_user,
				@id_user
			)

			SET @id_plant = SCOPE_IDENTITY()
			
			/* add plant to strain receipt. */
			INSERT INTO grow.transfer_strain_receipt (id_transfer, id_plant, id_area_destination, [destination_row], destination_column)
			VALUES (@id_transfer, @id_plant, @id_area, @row, @column)
			
			/* update plant list. */
			UPDATE #plant_list 
			SET id_plant=@id_plant 
				, [row]=@row
				, [column]=@column
			WHERE sequence=@sequence

			FETCH NEXT FROM c INTO @id_area, @id_strain, @plant, @phase, @phase_date, @sequence
		END

		CLOSE c
		DEALLOCATE c
	END

	/* if transfer is from internal source. *********************************************************************/
	BEGIN
		DECLARE c CURSOR FOR
		SELECT DISTINCT id_area FROM #plant_list

		OPEN c

		FETCH NEXT FROM c INTO @id_area
		WHILE @@FETCH_STATUS = 0 BEGIN
			/* get table of available grid spaces. --------------------------------------- */
			;WITH grid ([row], [column], sequence) AS (
				SELECT b.[row], a.[column], ROW_NUMBER() OVER(ORDER BY b.[row] ASC) AS sequence
				FROM (
					SELECT [column] = number 
					FROM master..[spt_values] 
					WHERE type='P' AND number BETWEEN 1 AND (SELECT columns FROM inventory.area WHERE id_area=@id_area)
				) a
				CROSS JOIN (
					SELECT [row] = number 
					FROM master..[spt_values] 
					WHERE type='P' AND number BETWEEN 1 AND (SELECT rows FROM inventory.area WHERE id_area=@id_area)
				) b
				LEFT JOIN grow.plant p ON p.[row]=b.[row] AND 
										  p.[column]=a.[column] AND 
										  p.harvested = 0 AND
										  p.destroyed = 0 AND
										  p.id_area=@id_area
				WHERE p.id_plant IS NULL
			)

			/* update transfer item. */
			UPDATE t
			SET t.id_area_destination=@id_area
				, t.destination_row=g.[row]
				, t.destination_column=g.[column]
			FROM grow.transfer_plant t
			JOIN (
				SELECT p.*
						, ROW_NUMBER() OVER(ORDER BY p.id_plant ASC) AS sequence
				FROM grow.plant p
				WHERE p.id_plant IN (
					SELECT id_plant 
					FROM #plant_list
					WHERE id_area=@id_area
				)
			) l ON l.id_plant=t.id_plant
			LEFT JOIN grid g ON g.sequence=l.sequence

			FETCH NEXT FROM c INTO @id_area
		END

		CLOSE c
		DEALLOCATE c

		/* update plants. */
		UPDATE p
		SET p.id_area=t.id_area_destination
			, p.[row]=t.destination_row
			, p.[column]=t.destination_column
		FROM grow.plant p
		JOIN grow.transfer_plant t ON t.id_plant=p.id_plant
		WHERE t.id_transfer=@id_transfer

		/* add grid locations to plant list. */
		UPDATE l
		SET l.[row]=p.[row]
			, l.[column]=p.[column]
		FROM #plant_list l
		JOIN grow.plant p ON p.id_plant=l.id_plant
	END

	

	/* add plant events. */
	DECLARE @list VARCHAR(MAX) = (SELECT * FROM #plant_list FOR JSON PATH)
	EXEC grow.usp_event_create_bulk 'transfer_receive', NULL, NULL, NULL, NULL, @list, @id_user


	/* set transfer to received. */
	UPDATE grow.transfer
	SET date_updated=GETUTCDATE()
		, id_user_updated=@id_user
		, received=1
		, date_received=GETUTCDATE()
	WHERE id_transfer=@id_transfer

	INSERT INTO grow.transfer_status_history (id_transfer, id_transfer_status, id_user_verified)
	VALUES (@id_transfer, 4, @id_user)

	/* return updated transfer. */
	EXEC grow.usp_transfer_fetch @id_transfer
go

