CREATE PROCEDURE [order].[usp_save_vehicle_internal_id]
	@id_vehicle INT = NULL,
	@internal_vehicle_id INT = NULL,
	@biotrack_transaction_id VARCHAR(128) = NULL
AS
	BEGIN
		UPDATE [order].vehicle
		SET 
			internal_vehicle_id=@internal_vehicle_id,
			biotrack_transaction_id=@biotrack_transaction_id
		WHERE id_vehicle=@id_vehicle
	END
go

