CREATE PROCEDURE [pos].[usp_payment_method_create]
	@name VARCHAR(256),
	@id_location INT,
	@id_user INT,
	@enabled BIT
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [pos].[payment_methods] ([name], id_location, enabled, id_user_created_by, id_user_modified_by)
	VALUES (@name, @id_location, @enabled, @id_user, @id_user)
	DECLARE @id_payment_method INT = SCOPE_IDENTITY()
	EXEC pos.usp_payment_method_list @id_payment_method
END
go

