CREATE PROCEDURE [inventory].[usp_pmp_log_list]
 @id_pmp_log INT = NULL,
 @id_item  INT = NULL,
 @id_order INT = NULL,
 @id_location INT = null,
 @per_page INT = 100,
 @page INT = 1
AS
BEGIN
	SET @page = 1
	SET @per_page = 1
    IF @id_pmp_log IS NULL
    BEGIN
        SELECT p.id_pmp_log
            , p.id_item 
            , p.id_order
			, p.id_location
			, p.date_created
        FROM [inventory].[pmp_log] p
        WHERE id_item = @id_item and id_order = @id_order or id_location = @id_location
    END
    ELSE
    BEGIN
      SELECT p.id_pmp_log
            , p.id_item 
            , p.id_order
			, p.id_location
			, p.date_created
        FROM [inventory].[pmp_log] p
        WHERE p.id_pmp_log = @id_pmp_log
  ORDER BY p.id_pmp_log DESC OFFSET(@page - 1) * @per_page ROWS

FETCH NEXT @per_page ROWS ONLY
    END
END
go

