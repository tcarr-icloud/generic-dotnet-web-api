CREATE PROCEDURE [order].[usp_queue_history_list]
	@id_customer INT = NULL,
	@id_location INT = NULL
AS
	SELECT q.id_customer
		, q.id_queue
		, q.id_location
		, c.name_first
		, c.name_last
		, c.patient_number
		, l.name AS 'location'
		, q.time_in
		, q.time_out 
	FROM [order].queue q
	JOIN [base].location l ON l.id_location=q.id_location
	JOIN [order].customer c ON c.id_customer=q.id_customer
	WHERE (@id_customer IS NULL OR q.id_customer=@id_customer) AND
	      (@id_location IS NULL OR q.id_location=@id_location) AND
		  q.time_out IS NOT NULL
	ORDER BY q.time_in
go

