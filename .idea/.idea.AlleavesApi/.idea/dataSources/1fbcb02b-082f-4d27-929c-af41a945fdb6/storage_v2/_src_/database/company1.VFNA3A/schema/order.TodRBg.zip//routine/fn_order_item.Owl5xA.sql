CREATE FUNCTION [order].[fn_order_item] (@id_order INT)
RETURNS TABLE
AS
RETURN (
		SELECT oi.id_item
			,oi.id_inventory_item
			,ISNULL(oi.id_inventory_item_category, (
					SELECT TOP 1 id_category
					FROM inventory.category
					WHERE LOWER([name]) = 'uncategorized'
					)) AS id_inventory_item_category
			,i.item_group
			,i.item
			,u.name AS uom
			,u.name_short AS uom_short
			,i.weight_useable_uom
			,i.weight_useable_uom_short
			,oi.id_batch
			,oi.id_area
			,a.[name] AS area
			,b.[name] AS batch
			,b.metrc_package_label
			,base.fn_barcode_human_readable(b.name) AS batch_split
			,oi.id_item_return
			,oi.discount
			,oi.taxable_discount
			,oi.sku
			,ISNULL(oi.loyalty, 0) AS loyalty
			,oi.quantity
			,oi.price
			,ISNULL(iil.cost_of_good, i.cost_of_good) as cost_of_good
			,oi.price_override
			,oi.price_override_reason
			,oi.price_post_item_discount
			,oi.price_post_item_loyalty
			,oi.price_post_order_discount
			,oi.price_post_order_loyalty
			,oi.price_post_round
			,oi.price_post_all_adjustments
			,oi.price_post_tax
			,oi.item_state_excise_tax_percentage
			,oi.item_local_excise_tax_percentage
			,oi.item_state_sales_tax_percentage
			,oi.item_local_sales_tax_percentage
			,oi.item_state_category_tax_percentage
			,oi.item_local_category_tax_percentage
			,oi.is_tax_exempt
			,i.is_cannabis
			,ISNULL(i.is_adult_use, 0) AS is_adult_use
			,ISNULL(i.is_medical_use, 0) AS is_medical_use
			,oi.id_tax_category
			,oi.strain
			,oi.inventory_category
			,oi.inventory_brand
			,CAST(CASE 
					WHEN EXISTS (
							SELECT TOP 1 *
							FROM [order].[order] AS _o
							INNER JOIN [order].item _oi ON _o.id_order = _oi.id_order
							WHERE _o.void = 0
								AND _o.cancel = 0
								AND _o.id_status <> (
									SELECT id_status
									FROM [order].[status]
									WHERE [name] = 'Cancelled'
									)
								AND _oi.id_item_return = oi.id_item
							)
						THEN 1
					ELSE 0
					END AS BIT) AS returned
			,[order].fn_order_item_discount_json(oi.id_item) AS discounts
			,ISNULL((
					SELECT li.id_loyalty_item
						,li.id_offer_reward
						,li.id_order_item
						,li.amount
						,li.redemption_type
						,li.loyalty_vender
						,li.loyalty_name
						,li.expiry_date
						,li.discount_type
						,li.redeemed
						,li.item_value
					FROM [loyalty].[item] li
					WHERE li.id_order_item = oi.id_item
					FOR json path
					), '[]') AS loyalties
			,oi.thc
			,oi.cbd
			,oi.thc_mg
			,oi.cbd_mg
			,i.id_brand
			,i.id_vendor
			,oi.inventory_vendor
			,i.weight_useable
			,oi.inventory_uom_type
			,i.id_delivery_route
			,dr.[name] AS delivery_route
			,ISNULL(i.is_low_thc, 0) AS is_low_thc
			,ISNULL(i.is_medicated, 0) AS is_medicated
			,ISNULL(i.is_smoking, 0) AS is_smoking
			,ISNULL(i.is_low_thc_and_medical, 0) AS is_low_thc_and_medical
			,i.id_ommu_form
			,ISNULL(i.is_ommu_delivery_device, 0) AS is_ommu_delivery_device
			,CASE
				WHEN i.id_ommu_form IS NULL OR oi.ommu_form_name IS NOT NULL THEN oi.ommu_form_name
				ELSE i.ommu_form_name
			 END AS ommu_form_name
			,oi.ommu_order_type_name
			,b.date_expire
		FROM [order].[item] oi
		LEFT OUTER JOIN inventory.vw_item_list i ON oi.id_inventory_item = i.id_item
		LEFT OUTER JOIN inventory.uom u ON u.id_uom = i.id_uom
		LEFT OUTER JOIN inventory.area a ON a.id_area = oi.id_area
		LEFT OUTER JOIN inventory.batch b ON b.id_batch = oi.id_batch
		LEFT OUTER JOIN inventory.delivery_route dr ON dr.id_delivery_route = i.id_delivery_route
		LEFT OUTER JOIN [inventory].[item_location] iil ON iil.id_item = oi.id_inventory_item AND iil.id_location = a.id_location
		WHERE oi.id_order = @id_order
		)
go

