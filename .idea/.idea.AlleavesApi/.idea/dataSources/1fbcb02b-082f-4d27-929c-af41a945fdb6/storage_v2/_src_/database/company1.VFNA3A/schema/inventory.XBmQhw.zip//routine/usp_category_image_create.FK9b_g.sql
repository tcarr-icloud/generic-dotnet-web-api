CREATE PROCEDURE [inventory].[usp_category_image_create]
	@name VARCHAR(256),
	@image_path VARCHAR(256),
	@deleted INT = 0,
	@id_user INT
AS
	SET NOCOUNT ON;
	INSERT INTO inventory.category_image(name,image_path,deleted, id_user_created_by, id_user_modified_by) 
	VALUES (@name,@image_path, @deleted, @id_user,@id_user)
	DECLARE @id_category_image INT = SCOPE_IDENTITY()
	EXEC inventory.usp_category_image_list @id_category_image
go

