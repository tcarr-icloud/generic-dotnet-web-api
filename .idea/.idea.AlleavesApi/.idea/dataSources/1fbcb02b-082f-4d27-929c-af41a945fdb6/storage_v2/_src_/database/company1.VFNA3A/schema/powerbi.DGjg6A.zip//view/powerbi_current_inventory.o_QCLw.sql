create   view powerbi.powerbi_current_inventory as
(
select
    dbo.fn_utc_to_local(item.date_created,inv.id_location) as date,
       inv.product,
       inv.category,
       sum(inv.available)                                       as available,
       IIF(item.is_medicated = 1, 'Medicated', 'Non Medicated') as IsMedicated,
       ig.threshold_low_quantity
from [order].item
         join inventory.vw_current_inventory inv on item.id_inventory_item = inv.id_item
         inner join inventory.item_group ig on ig.id_item_group = inv.id_item_group
group by inv.product, inv.category, item.date_created, item.is_medicated, ig.threshold_low_quantity,inv.id_location)
go

