
CREATE 
 PROCEDURE [dbo].[usp_login] @u VARCHAR(128)
AS
    SET NOCOUNT ON;

	UPDATE [base].[user]
		SET AccessFailedCount	=	0,
		LockoutEnabled			=	0,
		LockoutEndDateUtc		=	NULL
	WHERE UserName = @u
	AND LockoutEndDateUtc < getutcdate()

	SELECT 
		
		  u.id_user
		, u.id_company
		, r.id_role
		, u.FirstName AS name_first
		, u.LastName AS name_last
		, u.UserName AS username
		, u.EmailUpdate AS email_update
		, u.EmailConfirmed AS email_confirmed
		, u.PasswordHash AS hash
		, r.name AS role
		, u.WorkSpaceId AS workspace
		, u.PasswordReset AS reset_password			
		, u.LockoutEndDateUtc
		, u.LockoutEnabled
		, u.PasswordResetDate
		, u.employee_role
		, u.employee_department
		, u.employee_id
		, u.badge_number
	FROM [base].[user] u
	LEFT JOIN acl.user_role ur ON ur.id_user=u.id_user
	LEFT JOIN acl.role r ON r.id_role=ur.id_role
	WHERE u.UserName=@u
		AND u.accountDisabled=0
		AND u.deleted=0
go

