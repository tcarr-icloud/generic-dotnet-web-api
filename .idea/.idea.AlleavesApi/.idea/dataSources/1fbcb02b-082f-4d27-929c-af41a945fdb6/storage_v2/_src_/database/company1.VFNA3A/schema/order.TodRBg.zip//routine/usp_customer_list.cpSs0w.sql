
CREATE PROCEDURE [order].[usp_customer_list]
	@show_deleted BIT = 0,
	@start_row INT = 0,
	@end_row INT = 100,
	@sort_model VARCHAR(max) = '[]',
	@filter_model VARCHAR(max) = '[]'
AS

	--DECLARE @show_deleted BIT = 0
	--DECLARE @start_row INT = 0
	--DECLARE @end_row INT = 100
	--DECLARE @sort_model VARCHAR(max) = '[{"field":"name_first","sort":"asc"},{"field":"name_last","sort":"asc"},{"field":"patient_number","sort":"asc"},{"field":"date_of_birth","sort":"desc"}]'
	--DECLARE @filter_model VARCHAR(max) = '[]'
	
	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
		SELECT
			 c.id_customer
			,c.name_first
			,c.name_middle
			,c.name_last
			,c.date_of_birth
			,c.patient_number
			,c.phone
			,c.email
			,c.address1
			,c.address2
			,c.city
			,c.state
			,c.zip
			,c.id_user_online
			,c.deleted
		FROM [order].[customer] c
	) records'

	SET @where = 'WHERE deleted >= '+ CAST(@show_deleted AS VARCHAR(10))
	SET @where = @where + ISNULL((SELECT STUFF((SELECT ' AND QUOTENAME(LTRIM(RTRIM('+field+'))) LIKE ''%'+[filter]+'%''' FROM OPENJSON(@filter_model)
	WITH (
		field VARCHAR(512) '$.field',
		[filter] VARCHAR(512) '$.filter'
	) FOR XML PATH('')), 1,1,'')),'')	

	SET @order = 'ORDER BY '
	SET @order = @order + ISNULL((SELECT STUFF((	
	SELECT  CONCAT(', '+QUOTENAME(field), ' ' + sort) FROM OPENJSON(@sort_model)
	WITH (
		field VARCHAR(512) '$.field',
		sort VARCHAR(4) '$.sort'
	)
	FOR XML PATH(''))
	, 1,1, '')), 'id_customer')
	

	DECLARE @sql VARCHAR(max) = @select + ' ' + @where + ' ' + @order
	SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(@end_row  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

