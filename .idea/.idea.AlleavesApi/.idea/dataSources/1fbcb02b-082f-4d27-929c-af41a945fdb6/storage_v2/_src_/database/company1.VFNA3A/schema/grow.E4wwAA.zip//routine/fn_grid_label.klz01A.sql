CREATE FUNCTION [grow].[fn_grid_label]
(
	@row int = NULL,
	@column int = NULL
)
RETURNS VARCHAR(32)
AS
BEGIN
	RETURN CONCAT(ISNULL(CAST(@row AS VARCHAR(16)), '-'), 
			'-',
			CASE WHEN @column IS NOT NULL AND (@column - ((@column - 1) % 26)) / 26 > 0 THEN NCHAR(UNICODE(N'A') + (((@column - ((@column - 1) % 26)) / 26 - 1) % 26) ) ELSE '' END,
			CASE WHEN @column IS NOT NULL THEN NCHAR(UNICODE(N'A') + ((@column - 1) % 26)) ELSE '-' END)
END
go

