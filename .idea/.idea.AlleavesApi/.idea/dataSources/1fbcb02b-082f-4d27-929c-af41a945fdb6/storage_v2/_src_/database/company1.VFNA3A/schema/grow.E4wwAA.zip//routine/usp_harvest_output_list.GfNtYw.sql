CREATE PROCEDURE [grow].[usp_harvest_output_list]
	@id_strain INT
AS
	SELECT r.id_raw_material
			, g.id_item_group
			, i.id_item
			, RTRIM(CONCAT(g.name, ' ', (
					SELECT STRING_AGG(av.name, ' ')
					FROM inventory.item_attribute_value iav
					LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
					WHERE iav.id_item=i.id_item)
				)) AS item
			, r.name AS raw_material
			, u.name AS uom
			, CAST(CASE WHEN r.harvest_output_wet=0 AND r.harvest_output_dry=0 AND r.harvest_output_waste=0 THEN 1 ELSE r.harvest_output_wet END AS BIT) AS harvest_output_wet
			, r.harvest_output_dry
			, r.harvest_output_waste
	FROM inventory.raw_material r
	LEFT JOIN inventory.item_group g ON g.id_raw_material=r.id_raw_material AND g.id_strain=@id_strain
	LEFT JOIN inventory.item i ON i.id_item_group=g.id_item_group
	LEFT JOIN inventory.uom u ON u.id_uom=g.id_uom
	WHERE r.is_harvest_output=1 AND r.deleted=0
go

