CREATE PROCEDURE [base].[usp_insert_donation]
    @name NVARCHAR(128),
    @location NVARCHAR(128),
    @type NVARCHAR(50),
    @value DECIMAL(18, 2),
    @order_id INT,
    @location_id INT,
    @customer_id INT,
    @id_session INT
AS
BEGIN
    INSERT INTO [base].[donation] (name, location, type, value, order_id, location_id, customer_id, id_session)
    VALUES (@name, @location, @type, @value, @order_id, @location_id, @customer_id, @id_session)
END;
go

