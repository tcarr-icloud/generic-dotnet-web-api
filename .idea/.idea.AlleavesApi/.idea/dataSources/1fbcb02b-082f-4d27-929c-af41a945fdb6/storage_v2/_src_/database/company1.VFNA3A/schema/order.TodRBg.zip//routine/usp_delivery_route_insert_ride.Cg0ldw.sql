CREATE PROCEDURE [order].[usp_delivery_route_insert_ride]
	                    @id_delivery_route INT,
	                    @id_ride INT = NULL,
	                    @id_transfer INT = NULL,
	                    @eta VARCHAR(MAX) = NULL
    AS
    BEGIN
        DECLARE @position INT = (SELECT TOP 1 ride_list.position from (
        						 SELECT position
                                 FROM [order].ride_delivery_route
                                 WHERE id_delivery_route = @id_delivery_route
                                 UNION 
                                 SELECT position
                                 FROM [order].ride_transfer_delivery_route
                                 WHERE id_delivery_route = @id_delivery_route
                                 ) as ride_list ORDER BY position DESC)
        
      	IF (@id_ride IS NOT NULL)
	    BEGIN
	    	INSERT INTO [order].ride_delivery_route(id_ride, id_delivery_route, position, eta)
                VALUES (@id_ride,@id_delivery_route,@position+1, @eta)
                SET @position=@position+1
				declare @id_driver int = (select id_driver from [order].[delivery_route] where id_delivery_route =@id_delivery_route)
				if(@id_driver IS NOT NULL)
				begin
				update [order].[ecommerce_ride] set id_driver=@id_driver where id_ride=@id_ride
				end
	    END
	    IF (@id_transfer IS NOT NULL)
	    BEGIN
	    	INSERT INTO [order].ride_transfer_delivery_route(id_transfer, id_delivery_route, position, eta)
                VALUES (@id_transfer,@id_delivery_route,@position+1, @eta)
                SET @position=@position+1
	    END    
     END
go

