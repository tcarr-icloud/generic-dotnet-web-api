CREATE PROCEDURE [metrc].[usp_queued_adjustment_create]
	@id_adjust_reason INT,
	@adjust_reason VARCHAR(MAX) = NULL,
	@list VARCHAR(MAX) = '[]',
	@id_user INT,
	@sent_to_metrc BIT = 0
AS
	SET NOCOUNT ON;

	/* get adjust reason text. */
	DECLARE @notes VARCHAR(MAX)
	SET @notes = (SELECT name FROM inventory.adjust_reason WHERE id_adjust_reason=@id_adjust_reason)

	IF(@adjust_reason IS NOT NULL)
		SET @notes = CONCAT(@notes, '; ', @adjust_reason)

	/* loop through batch list and update inventory. */
	DECLARE @id_batch INT, 
			@id_area INT,
			@adjustment DECIMAL(18,4),
			@curr_val DECIMAL(18, 4),
			@metrc_package_label VARCHAR(64),
			@id_uom INT,
			@id_log_event INT

	DECLARE item_cursor CURSOR FAST_FORWARD FOR 
	SELECT * FROM OPENJSON(@list)
	WITH (
		id_batch INT,
		id_area INT,
		adjustment DECIMAL(18,4)
	)
	WHERE adjustment<>0
		
	OPEN item_cursor
	FETCH NEXT FROM item_cursor INTO @id_batch, @id_area, @adjustment
		
	WHILE(@@FETCH_STATUS = 0)
	BEGIN
		/* get current value. */
		SET @curr_val = (SELECT TOP 1 quantity FROM inventory.inventory WHERE id_batch=@id_batch AND id_area=@id_area)
		SET @metrc_package_label = (SELECT TOP 1 metrc_package_label FROM inventory.batch WHERE id_batch=@id_batch)

		/* get current uom. */
		SET @id_uom = (
			SELECT TOP 1 ig.id_uom
			FROM inventory.batch b
			JOIN inventory.item i ON i.id_item=b.id_item
			JOIN inventory.item_group ig ON ig.id_item_group=i.id_item_group
			WHERE b.id_batch=@id_batch
		)

		/* update item quantity in Alleaves and get the event id */
		EXEC [log].usp_event_create 'inventory_adjust', @id_batch, @id_area, @adjustment, @notes, @id_user

		SET @id_log_event = (SELECT TOP 1 id_event FROM [log].[event] WHERE id_batch=@id_batch AND id_area=@id_area AND adjustment=@adjustment AND id_type=3 AND id_user_created=@id_user ORDER BY date_created DESC)


		IF (@metrc_package_label IS NOT NULL)
		BEGIN
			/* insert queued adjustment. */
			INSERT INTO [metrc].[queued_adjustment] (
					[id_batch],
					[id_area],
					[original_quantity], 
					[adjustment],
					[id_uom], 
					[id_adjust_reason], 
					[notes],
					[sent_to_metrc],
					[ignored], 
					[id_log_event],
					[created_by], 
					[updated_by], 
					[date_created],
					[date_updated])
			VALUES(   
					@id_batch,
					@id_area,
					ISNULL(@curr_val , 0),
					@adjustment,
					@id_uom,
					@id_adjust_reason,
					@adjust_reason,
					@sent_to_metrc,
					0,
					@id_log_event,
					@id_user,
					@id_user,
					GETUTCDATE(),
					GETUTCDATE())
		END

		FETCH NEXT FROM item_cursor INTO @id_batch, @id_area, @adjustment
	END

	CLOSE item_cursor
	DEALLOCATE item_cursor
go

