CREATE PROCEDURE [customer].[usp_file_save_meta]
	@id_customer INT,
	@filename VARCHAR(100),
	@key VARCHAR(1024),
	@id_user INT
AS
	INSERT INTO [customer].[file] (id_customer, [filename], [key], id_user_created, id_user_updated)
	VALUES (@id_customer, @filename, @key, @id_user, @id_user)
	SELECT SCOPE_IDENTITY() AS [id_file];
go

