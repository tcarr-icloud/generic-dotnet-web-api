CREATE PROCEDURE [inventory].[usp_area_save_priority]
    @areas VARCHAR(MAX) = '[]',
    @id_location INT,
    @area_priority BIT = 0
AS
BEGIN
    UPDATE base.[location]
    SET area_priority=@area_priority
    WHERE id_location=@id_location
    
    SELECT *
    INTO #areas
    FROM OPENJSON(@areas)
    WITH (
        [id_area] INT,
        [priority] INT
    )

    DECLARE @id_area INT,
            @priority INT

    DECLARE areas_cursor CURSOR FAST_FORWARD FOR
        SELECT id_area, [priority]
        FROM #areas

    OPEN areas_cursor

    FETCH NEXT FROM areas_cursor INTO @id_area, @priority

    WHILE (@@FETCH_STATUS = 0)
    BEGIN
        UPDATE inventory.area
        SET priority = @priority
        WHERE id_area = @id_area

        FETCH NEXT FROM areas_cursor INTO @id_area, @priority
    END

    CLOSE areas_cursor
    DEALLOCATE areas_cursor

    DROP TABLE #areas
END
go

