CREATE PROCEDURE [order].[usp_customer_delivery_date]
    @delivery_date VARCHAR(250) = NULL
AS
SELECT er.*,
       o.id_order,
       o.id_customer,
       o.sms_enabled,
       cd.id_customer,
       cd.name_first,
       cd.name_last,
       cd.phone,
       cd.phone2,
       cd.email,
       cd.address1,
       cd.address2,
       cd.city,
       cd.state,
       cd.zip
FROM [order].[ecommerce_ride] AS er
LEFT JOIN [order].[order] o ON o.id_order = er.id_order
LEFT JOIN [order].customer cd ON cd.id_customer = o.id_customer
WHERE er.delivery_date = @delivery_date
go

