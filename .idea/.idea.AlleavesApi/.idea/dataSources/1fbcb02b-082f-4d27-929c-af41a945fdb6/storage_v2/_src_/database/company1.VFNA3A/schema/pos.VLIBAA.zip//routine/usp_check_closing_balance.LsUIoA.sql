CREATE PROCEDURE [pos].[usp_check_closing_balance]
	@id_user INT,
	@id_register INT,
	@balance_ending decimal(18,2)
AS
	--DECLARE @id_user INT = 2
	--DECLARE @id_register INT = 1000
	--DECLARE @balance_ending decimal(18,2) = 243243


	DECLARE @id_session INT = (SELECT TOP 1 id_session FROM [pos].[session] WHERE id_register = @id_register ORDER BY date_start DESC)
	PRINT @id_session
	SELECT s.id_session
			, s.balance_starting
			, COALESCE(@balance_ending, s.balance_ending, s.balance_starting) AS balance_ending
			, ISNULL(s.balance_starting + SUM(a.amount), s.balance_starting) AS cash_expected

	FROM pos.session s
	OUTER APPLY (
		SELECT tendered AS amount
		FROM [order].payment p
		JOIN pos.session s ON s.id_register=p.id_register AND s.id_session=@id_session
		WHERE p.date_created BETWEEN s.date_start AND ISNULL(s.date_end, getutcdate()) AND p.method IN ('cash', 'change')
		UNION ALL
		SELECT w.amount * -1 AS amount
		FROM pos.withdrawal w
		WHERE w.id_session=@id_session
	) a
	WHERE s.id_session=@id_session
	GROUP BY s.id_session, s.balance_starting, s.balance_ending
go

