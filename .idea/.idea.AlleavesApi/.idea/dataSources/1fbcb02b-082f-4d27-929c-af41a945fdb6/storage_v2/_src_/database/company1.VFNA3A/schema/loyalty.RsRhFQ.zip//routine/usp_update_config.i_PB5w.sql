CREATE PROCEDURE [loyalty].[usp_update_config]	
	@springbig_active BIT = NULL,
	@alpineiq_active BIT = NULL
AS

	IF NOT EXISTS (SELECT 1 FROM loyalty.config)
	BEGIN
		INSERT INTO loyalty.config (springbig_active, alpineiq_active)
		SELECT 0,0
	END

	UPDATE loyalty.config
	SET 
		springbig_active = ISNULL(@springbig_active, springbig_active),
		alpineiq_active = ISNULL(@alpineiq_active, alpineiq_active)
go

