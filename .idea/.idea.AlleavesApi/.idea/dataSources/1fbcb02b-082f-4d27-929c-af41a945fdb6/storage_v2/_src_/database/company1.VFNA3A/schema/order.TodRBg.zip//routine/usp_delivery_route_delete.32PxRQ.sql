CREATE PROCEDURE [order].[usp_delivery_route_delete]
	@id_delivery_route INT = NULL
AS
	DELETE FROM [order].delivery_route
    WHERE id_delivery_route = @id_delivery_route
go

