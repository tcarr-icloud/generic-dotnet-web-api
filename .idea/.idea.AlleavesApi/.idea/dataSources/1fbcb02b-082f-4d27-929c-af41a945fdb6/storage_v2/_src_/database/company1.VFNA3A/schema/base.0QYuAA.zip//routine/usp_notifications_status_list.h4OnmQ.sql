CREATE PROCEDURE [base].[usp_notifications_status_list]
	@id_user int = null
AS
	SELECT *
	FROM base.user_notifications n
	WHERE (@id_user IS NULL OR id_user = @id_user) AND [status] = 0
	ORDER BY n.id DESC
go

