CREATE PROCEDURE [inventory].[usp_transfer_upsert]
	@id_transfer INT = NULL,
	@id_external VARCHAR(128),
	@id_location_source INT,
	@id_vendor_source INT,
	@id_location_destination INT,
	@id_vendor_destination INT,
	@recipient VARCHAR(256),
	@address VARCHAR(256),
	@city VARCHAR(256),
	@state VARCHAR(256),
	@postal_code VARCHAR(32),
	@tracking_number VARCHAR(256),
	@internal_reference VARCHAR(256),
	@notes VARCHAR(MAX),
	@id_driver1 INT,
	@id_driver2 INT,
	@id_vehicle INT,
	@pick_list VARCHAR(MAX) = '[]',
	@id_transfer_return INT = NULL,
	@id_user INT
AS
	/* create new transfer. */
	IF(@id_transfer IS NULL)
	BEGIN
		/* insert new transfer into database. */
		INSERT INTO inventory.transfer (id_external, id_location_source, id_vendor_source, id_location_destination, id_vendor_destination, recipient, address, city, state, postal_code, tracking_number, internal_reference, notes, id_driver1, id_driver2, id_vehicle, is_return, id_transfer_return, id_user_created, id_user_updated)
		VALUES (@id_external, @id_location_source, @id_vendor_source, @id_location_destination, @id_vendor_destination, @recipient, @address, @city, @state, @postal_code, @tracking_number, @internal_reference, @notes, @id_driver1, @id_driver2, @id_vehicle, (CASE WHEN @id_transfer_return IS NOT NULL THEN 1 ELSE 0 END), @id_transfer_return, @id_user, @id_user)

		SET @id_transfer=SCOPE_IDENTITY()

		/* insert status. */
		DECLARE @id_status INT = (SELECT id_transfer_status FROM inventory.transfer_status WHERE reference='pending')
		
		INSERT INTO inventory.transfer_status_history (id_transfer, id_transfer_status, id_user_verified)
		VALUES (@id_transfer, @id_status, @id_user)

		/* insert ride status. */
		DECLARE @id_ride_status INT = (SELECT id_ride_status FROM inventory.ride_status WHERE reference='upcoming')

		IF (@id_ride_status IS NOT NULL)
			INSERT INTO inventory.ride_status_history (id_transfer, id_ride_status, id_user_verified)
			VALUES (@id_transfer, @id_ride_status, @id_user)

	END
	/* update transfer. */
	ELSE
	BEGIN
		UPDATE inventory.transfer
		SET id_location_source=@id_location_source
			, id_vendor_source=@id_vendor_source
			, id_location_destination=@id_location_destination
			, id_vendor_destination=@id_vendor_destination
			, recipient=@recipient
			, address=@address
			, city=@city
			, state=@state
			, postal_code=@postal_code
			, tracking_number=@tracking_number
			, internal_reference=@internal_reference
			, notes=@notes
			, id_driver1=@id_driver1
			, id_driver2=@id_driver2
			, id_vehicle=@id_vehicle
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_transfer=@id_transfer
	END

	/* create line items table. */
	DROP TABLE IF EXISTS #pick_list
	SELECT l.*
			, ISNULL(t.id_transfer_item, NULL) AS id_transfer_item_orig
			, t.id_batch AS id_batch_orig
			, t.id_area AS id_area_orig
			, t.id_item AS id_item_orig
			, t.quantity AS quantity_orig
	INTO #pick_list
	FROM (
		SELECT @id_transfer AS id_transfer
				, *
		FROM OPENJSON(@pick_list)
		WITH (
			id_transfer_item INT,
			id_item INT,
			id_batch INT,
			id_area INT,
			batch_name VARCHAR(256),
			quantity DECIMAL(18,4),
			cost DECIMAL(18,4)
		)
		WHERE (id_batch IS NOT NULL OR id_item IS NOT NULL) AND quantity>0
	) l
	FULL OUTER JOIN inventory.transfer_item t ON t.id_transfer_item=l.id_transfer_item
	WHERE ISNULL(t.id_transfer, @id_transfer)=@id_transfer


	/* adjust inventory and add log events. ------------------------------------------------------------------------------------------ */

	/* create list of inventory return (increment) events. */
	DROP TABLE IF EXISTS #return_list
	SELECT id_batch_orig AS id_batch
			, id_area_orig AS id_area
			, CASE WHEN id_transfer_item IS NOT NULL AND id_batch=id_batch_orig AND id_area=id_area_orig AND quantity<>quantity_orig
					THEN quantity_orig-quantity
					ELSE quantity_orig END
					AS adjustment
	INTO #return_list
	FROM #pick_list
	WHERE (id_transfer_item IS NULL AND id_transfer_item_orig IS NOT NULL AND id_item_orig IS NULL) OR -- deleted item
		  (id_transfer_item IS NOT NULL AND id_item IS NOT NULL AND id_item_orig IS NULL) OR -- change from internal to external
		  (id_transfer_item IS NOT NULL AND id_item IS NULL AND (id_batch<>id_batch_orig OR id_area<>id_area_orig)) OR -- batch/area changed (return original quantity)
		  (id_transfer_item IS NOT NULL AND id_item IS NULL AND id_batch=id_batch_orig AND id_area=id_area_orig AND quantity_orig-quantity>0) -- original quantity is higher than new quantity

	/* create list of inventory use (decrement) events. */
	DROP TABLE IF EXISTS #add_list
	SELECT id_batch AS id_batch
			, id_area AS id_area
			, CASE WHEN id_transfer_item IS NOT NULL AND id_batch=id_batch_orig AND id_area=id_area_orig AND quantity<>quantity_orig
					THEN quantity_orig-quantity
					ELSE -quantity END
					AS adjustment
	INTO #add_list
	FROM #pick_list
	WHERE (id_transfer_item IS NULL AND id_transfer_item_orig IS NULL AND id_item IS NULL) OR -- new input
		  (id_transfer_item IS NOT NULL AND id_item IS NULL AND id_item_orig IS NOT NULL) OR -- changed from external to internal
		  (id_transfer_item IS NOT NULL AND id_item IS NULL AND (id_batch<>ISNULL(id_batch_orig, -1) OR id_area<>ISNULL(id_area_orig, -1))) OR -- batch/area changed (add new quantity)
		  (id_transfer_item IS NOT NULL AND id_item IS NULL AND id_batch=id_batch_orig AND id_area=id_area_orig AND quantity_orig-quantity<0) -- original quantity is lower than new quantity

	DECLARE @return_list VARCHAR(MAX) = (SELECT * FROM #return_list FOR JSON PATH), 
			@add_list VARCHAR(MAX) = (SELECT * FROM #add_list FOR JSON PATH)
			
	/* add log events and update inventory. */
	DECLARE @note VARCHAR(64) = CONCAT('TransferID: ', @id_transfer)
	EXEC [log].usp_event_create_bulk 'transfer_manifest_remove', @note, @return_list, @id_user
	EXEC [log].usp_event_create_bulk 'transfer_manifest_add', @note, @add_list, @id_user

	
	/* merge transfer item table. ------------------------------------------------------------------------------------------ */

	DELETE FROM #pick_list WHERE id_transfer_item IS NULL AND id_transfer_item_orig IS NOT NULL

	MERGE inventory.transfer_item t
	USING #pick_list s
	ON t.id_transfer_item=s.id_transfer_item
	WHEN MATCHED THEN 
		UPDATE SET t.quantity=s.quantity, t.cost=s.cost, t.batch_name=s.batch_name
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_transfer, id_item, id_batch, id_area, quantity, cost, batch_name) VALUES (s.id_transfer, s.id_item, s.id_batch, s.id_area, s.quantity, cost, batch_name)
	WHEN NOT MATCHED BY SOURCE AND t.id_transfer=@id_transfer THEN DELETE
	;

	/* return newly created/updated transfer. */
	EXEC inventory.usp_transfer_list @id_transfer
go

