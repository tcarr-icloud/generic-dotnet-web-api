create    view  powerbi.Powerbi_product_details as (
select
o.id_order,
employee_name,
category.name as category,
item_group.name as product,
oi.price_post_tax,
CONVERT( varchar, o.date_created , 101) as date_created
from powerbi.Powerbi_table_employee
join [order].[order] o on Powerbi_table_employee.employee_id = o.created_by
inner join  [order].item oi  on oi.id_order = o.id_order
inner join inventory.item on oi.id_inventory_item = item.id_item
inner join inventory.item_group on item.id_item_group = item_group.id_item_group
inner join inventory.category on item_group.id_category = category.id_category
)
go

