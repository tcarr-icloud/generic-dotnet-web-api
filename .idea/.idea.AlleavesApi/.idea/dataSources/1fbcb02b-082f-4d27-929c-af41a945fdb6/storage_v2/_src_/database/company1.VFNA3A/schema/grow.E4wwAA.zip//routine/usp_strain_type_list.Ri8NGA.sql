CREATE PROCEDURE [grow].[usp_strain_type_list]
AS
	SELECT st.id_strain_type
			, st.name AS strain_type
			, st.system
	FROM grow.strain_type st
go

