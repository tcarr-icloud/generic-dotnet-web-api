CREATE VIEW [cash].[vw_cash_management]

AS

SELECT se.id_safe_event
	, se.id_safe
	, se.previous_amount
	, se.adjustment
	, se.reason
	, se.note
	, se.date_created
	, s.[name] AS 'safe_name'
	, s.amount
	, l.id_location
    , l.name AS 'location'
	, lg.name AS location_group
	, u.FirstName + ' ' + u.LastName AS 'user'
	, CASE WHEN se.reason = 'Deposit' AND s.id_safe=se.id_safe THEN  se.adjustment END AS 'deposit_amount'
	, CASE WHEN se.reason = 'Withdrawal' AND s.id_safe=se.id_safe THEN se.adjustment END AS 'withdrawal_amount'
	, ISNULL(
				(
					SELECT r.name 
					FROM [cash].[safe_event_session] ses
					JOIN [pos].[session] sn ON sn.id_session = ses.id_session
					JOIN [pos].[register] r ON r.id_register = sn.id_register
					WHERE ses.id_safe_event = se.id_safe_event
				), null  
			) AS register
	, ISNULL(
				(
					SELECT ses.id_session
					FROM [cash].[safe_event_session] ses
					JOIN [pos].[session] sn ON sn.id_session = ses.id_session
					JOIN [pos].[register] r ON r.id_register = sn.id_register
					WHERE ses.id_safe_event = se.id_safe_event
				), null  
			) AS id_session
FROM cash.safe_event se
JOIN [cash].[safe] s ON s.id_safe=se.id_safe AND s.deleted <= 0 
JOIN [base].[location] l ON l.id_location=s.id_location
JOIN [base].[location_group_value] lgv ON lgv.id_location=l.id_location
JOIN [base].[location_group] lg ON lg.id_location_group=lgv.id_location_group AND lg.deleted=0
JOIN [base].[user] u ON u.id_user=se.id_user_created
go

