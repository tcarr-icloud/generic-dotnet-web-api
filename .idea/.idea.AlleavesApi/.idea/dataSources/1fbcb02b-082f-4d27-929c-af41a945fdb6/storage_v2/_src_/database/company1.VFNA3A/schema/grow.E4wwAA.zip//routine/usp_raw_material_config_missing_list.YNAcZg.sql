CREATE PROCEDURE [grow].[usp_raw_material_config_missing_list]
	@id_strain INT = NULL
AS
	SELECT c.*, r.id_strain, r.strain
	FROM (
		SELECT c.id_raw_material_config
			, c.id_raw_material
			, s.id_strain
			, c.item_name
			, s.name AS strain
		FROM grow.raw_material_config c
		CROSS JOIN grow.strain s
		WHERE s.deleted=0 AND c.deleted=0
	) r
	LEFT JOIN inventory.item_group i ON i.id_raw_material=r.id_raw_material AND i.id_strain=r.id_strain AND i.name LIKE '%'+r.item_name
	JOIN grow.raw_material_config c ON c.id_raw_material_config=r.id_raw_material_config
	WHERE r.id_strain=ISNULL(@id_strain, r.id_strain) AND i.id_item_group IS NULL
go

