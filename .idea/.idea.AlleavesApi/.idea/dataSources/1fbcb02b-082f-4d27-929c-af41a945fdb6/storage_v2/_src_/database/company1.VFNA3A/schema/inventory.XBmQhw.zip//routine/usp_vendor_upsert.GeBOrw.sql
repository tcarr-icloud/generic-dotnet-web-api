CREATE PROCEDURE [inventory].[usp_vendor_upsert]
	@id_vendor INT = NULL,
    @name VARCHAR (128),
    @dba VARCHAR (128),
    @account_number VARCHAR (128),
    @phone VARCHAR (32),
    @fax VARCHAR (32),
    @website VARCHAR (32),
	@billing_address VARCHAR(256),
	@billing_city VARCHAR(256),
	@billing_state VARCHAR(256),
	@billing_postal_code VARCHAR(256),
	@is_same_as_billing BIT = 0,
	@shipping_address VARCHAR(256),
	@shipping_city VARCHAR(256),
	@shipping_state	VARCHAR(256),
	@shipping_postal_code VARCHAR(256),
    @external_id VARCHAR(128) = NULL,
	@metrc_facility_license_number VARCHAR(255) = NULL,
	@brand_list	VARCHAR(MAX) = '[]',
    @note VARCHAR(MAX),
    @po_terms VARCHAR(MAX), 
	@contact_list VARCHAR(MAX) = '[]',
	@deleted BIT = 0,
	@id_user INT,
	@payment_method VARCHAR(512)

AS
	IF EXISTS (SELECT * FROM inventory.vendor WHERE deleted=0 AND @deleted<>1 AND name=@name AND (@id_vendor IS NULL OR id_vendor <> @id_vendor))
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A vendor with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	IF (@id_vendor IS NULL)
	BEGIN
		INSERT INTO inventory.vendor (    
				[name],					    
				dba,					    
				account_number,             
				phone,					   
				fax,					   
				website,				   
				billing_address,	       
				billing_city,		       
				billing_state,		       
				billing_postal_code,   
				is_same_as_billing,
				shipping_address,	       
				shipping_city,		       
				shipping_state,		       
				shipping_postal_code,       
				external_id,
				po_terms,
				note,
				payment_method,
				metrc_facility_license_number,
				id_user_created,
				id_user_updated) 
	
		VALUES(   
				@name,					    
				@dba,					    
				@account_number,					   
				@phone,	
				@fax,
				@website,				   
				@billing_address,	       
				@billing_city,		       
				@billing_state,		       
				@billing_postal_code,    
				@is_same_as_billing,
				CASE WHEN @is_same_as_billing=1 THEN NULL ELSE @shipping_address END,	       
				CASE WHEN @is_same_as_billing=1 THEN NULL ELSE @shipping_city END,		       
				CASE WHEN @is_same_as_billing=1 THEN NULL ELSE @shipping_state END,		       
				CASE WHEN @is_same_as_billing=1 THEN NULL ELSE @shipping_postal_code END,       
				@external_id,
				@po_terms,
				@note,
				@payment_method,
				@metrc_facility_license_number,
				@id_user,
				@id_user)

		SET @id_vendor=SCOPE_IDENTITY()
	END
	ELSE
	BEGIN
		UPDATE [inventory].[vendor]
		SET [name] = @name,					    
			dba = @dba,					    
			account_number = @account_number,			   
			phone = @phone,
			fax = @fax, 					   
			website = @website, 				   
			billing_address = @billing_address, 	       
			billing_city = @billing_city, 		       
			billing_state = @billing_state, 		       
			billing_postal_code = @billing_postal_code,  
			is_same_as_billing = @is_same_as_billing,
			shipping_address = CASE WHEN @is_same_as_billing=1 THEN NULL ELSE @shipping_address END, 	       
			shipping_city = CASE WHEN @is_same_as_billing=1 THEN NULL ELSE @shipping_city END,  		       
			shipping_state = CASE WHEN @is_same_as_billing=1 THEN NULL ELSE @shipping_state END,	 		       
			shipping_postal_code = CASE WHEN @is_same_as_billing=1 THEN NULL ELSE @shipping_postal_code END,        
			external_id = @external_id,
			note = @note,
			payment_method = @payment_method,
			po_terms = @po_terms,
			metrc_facility_license_number = @metrc_facility_license_number,
			deleted = @deleted,
			id_user_updated = @id_user,
			date_updated=GETUTCDATE()
			WHERE id_vendor = @id_vendor
	END

	;WITH brand_list AS (
		SELECT @id_vendor AS id_vendor
				, id_brand
		FROM OPENJSON(@brand_list)
		WITH (
			id_brand INT 
		)
	)
	MERGE [inventory].[vendor_brand] AS vb
	USING brand_list AS bl
	ON bl.id_brand = vb.id_brand AND bl.id_vendor = vb.id_vendor	
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_vendor, id_brand) VALUES (bl.id_vendor, bl.id_brand)
	WHEN NOT MATCHED BY SOURCE AND vb.id_vendor = @id_vendor THEN
	DELETE
	;

	;WITH contact_list AS (
		SELECT * FROM OPENJSON(@contact_list)
		WITH (
			  id_vendor_contact			INT           '$.id_vendor_contact'
			, name_first				VARCHAR (128) '$.name_first'
			, name_last					VARCHAR (128) '$.name_last'
			, title						VARCHAR (128) '$.title'
			, email						VARCHAR (128) '$.email'
			, phone1					VARCHAR (32)  '$.phone1'
			, phone2					VARCHAR (32)  '$.phone2'
		)
		WHERE name_first IS NOT NULL AND name_last IS NOT NULL
	)
	MERGE [inventory].[vendor_contact] AS vc
	USING contact_list AS cl
	ON vc.id_vendor_contact = cl.id_vendor_contact  
	WHEN MATCHED AND (vc.name_first <> cl.name_first OR vc.name_last <> cl.name_last OR vc.title <> cl.title OR vc.email <> cl.email OR vc.phone1 <> cl.phone1 OR vc.phone2 <> cl.phone2) 
	THEN 
		UPDATE SET vc.name_first = cl.name_first, vc.name_last = cl.name_last, vc.title = cl.title, vc.email = cl.email, vc.phone1 = cl.phone1, vc.phone2 = cl.phone2, vc.id_user_updated = @id_user, vc.date_updated = getutcdate()
	WHEN NOT MATCHED BY TARGET 
	THEN
		INSERT (id_vendor, name_first, name_last, title, email, phone1, phone2, id_user_created, id_user_updated) 
		VALUES (@id_vendor, cl.name_first, cl.name_last, cl.title, cl.email, cl.phone1, cl.phone2, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND vc.id_vendor = @id_vendor 
	THEN
		UPDATE SET vc.deleted=1, vc.id_user_updated=@id_user, vc.date_updated=GETUTCDATE()
	;
		
	EXEC [inventory].[usp_vendor_list] @id_vendor, 1
go

