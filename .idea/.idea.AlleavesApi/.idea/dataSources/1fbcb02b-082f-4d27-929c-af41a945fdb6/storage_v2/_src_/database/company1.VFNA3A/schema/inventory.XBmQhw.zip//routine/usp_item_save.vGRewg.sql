CREATE PROCEDURE [inventory].[usp_item_save]
	@id_item_group INT = NULL,
	@is_global INT = NULL,
	@id_location INT = NULL,
	-- general
	@name VARCHAR(512),
	@id_category INT = NULL,
	@id_raw_material INT = NULL,
	@id_brand INT = NULL,
	@id_vendor INT = -1,
	-- storage
	@id_uom INT,
	@id_uom_receiving INT = NULL,
	@units_per_received DECIMAL(18,4) = NULL,
	@batch_required BIT = 0,
	@has_shelf_life BIT = 0,
	@shelf_life_days INT = NULL,
	@threshold_low_quantity DECIMAL(18,4) = NULL,
	@threshold_low_quantity_selected BIT = 0,
	@location_threshold_low_quantity VARCHAR(MAX) = '[]',
	-- cannabis
	@is_cannabis BIT = 0,
	@is_plant BIT = 0,
	@is_seed BIT = 0,
	@id_strain INT = -1,
	@id_uom_weight_useable INT = NULL,
	@id_delivery_route INT = NULL,
	@thc DECIMAL(18,5) = NULL,
	@cbd DECIMAL(18,5) = NULL,
	@thc_mg DECIMAL(18,5) = NULL,
	@cbd_mg DECIMAL(18,5) = NULL,
	@dosage_recommended VARCHAR(MAX) = NULL,
	@allergens VARCHAR(MAX) = NULL,
	@servings INT = NULL,
	@extraction_method VARCHAR(512) = NULL,
	@solvent_type VARCHAR(512) = NULL,
	@nutritional_information VARCHAR(MAX) = NULL,
	@ingredients_list VARCHAR(MAX) = NULL,
	-- ommu (cannabis)
	@is_low_thc BIT = 0,
	@is_medicated BIT = 0,
	@is_smoking BIT = 0,
	@is_low_thc_and_medical BIT = 0,
	@id_ommu_form INT = NULL,
	@is_ommu_delivery_device BIT = 0,
	-- plant nutrient
	@is_plant_nutrient BIT = 0,
	@nutrient_type VARCHAR(64) = NULL,
	@nutrient_application_device VARCHAR(255) = NULL,
	@nutrient_ingredient_list VARCHAR(MAX) = '[]',
	-- product
	@is_product BIT = 0,
	@product_description VARCHAR(MAX) = NULL,
	@is_tax_exempt BIT = 0,
	@id_tax_category INT = NULL,
	@is_adult_use BIT = 0,
	@is_medical_use BIT = 0,
	@item_list VARCHAR(MAX) = '[]',
	@attribute_list VARCHAR(MAX) = '[]',
	-- metadata
	@deleted BIT = 0,
	@id_user INT
AS
	IF @id_category IS NULL
		SET @id_category = (SELECT TOP 1 id_category FROM inventory.category WHERE LOWER([name]) = 'uncategorized')

	/* insert new item detail. */
	IF(@id_item_group IS NULL)
	BEGIN
		INSERT INTO [inventory].[item_group]
			   ([name]
			   ,[id_location]
			   ,[is_global]
			   ,[id_uom]
			   ,[id_uom_receiving]
			   ,[id_uom_weight_useable]
			   ,[units_per_received]
			   ,[id_category]
			   ,[id_raw_material]
			   ,[id_tax_category]
			   ,[id_brand]
			   ,[id_vendor]
			   ,[batch_required]
			   ,[has_shelf_life]
			   ,[shelf_life_days]
			   ,[threshold_low_quantity]
			   ,[threshold_low_quantity_selected]
			   ,[is_product]
			   ,[product_description]
			   ,[is_tax_exempt]
			   ,[is_cannabis]
			   ,[is_plant]
			   ,[is_seed]
			   ,[id_strain]
			   ,[is_adult_use]
			   ,[is_medical_use]
			   ,[id_delivery_route]
			   ,[dosage_recommended]
			   ,[is_low_thc]
			   ,[is_medicated]
			   ,[is_smoking]
			   ,[is_low_thc_and_medical]
			   ,[thc]
			   ,[cbd]
			   ,[thc_mg]
			   ,[cbd_mg]
			   ,[id_ommu_form]
			   ,[is_ommu_delivery_device]
			   ,[allergens]
			   ,[nutritional_information]
			   ,[servings]
			   ,[extraction_method]
			   ,[solvent_type]
			   ,[ingredients_list]
			   ,[is_plant_nutrient]
			   ,[nutrient_type]
			   ,[nutrient_application_device]
			   ,[id_user_created]
			   ,[id_user_updated])
		VALUES (
			@name,
			@id_location,
			@is_global,
			@id_uom,
			@id_uom_receiving,
			@id_uom_weight_useable,
			@units_per_received,
			@id_category,
			@id_raw_material,
			@id_tax_category,
			@id_brand,
			@id_vendor,
			@batch_required,
			@has_shelf_life,
			@shelf_life_days,
			@threshold_low_quantity,
			@threshold_low_quantity_selected,
			@is_product,
			@product_description,
			@is_tax_exempt,
			@is_cannabis,
			@is_plant,
			@is_seed,
			@id_strain,
			@is_adult_use,
			@is_medical_use,
			@id_delivery_route,
			@dosage_recommended,
			@is_low_thc,
			@is_medicated,
			@is_smoking,
			@is_low_thc_and_medical,
			@thc,
			@cbd,
			@thc_mg,
			@cbd_mg,
			@id_ommu_form,
			@is_ommu_delivery_device,
			@allergens,
			@nutritional_information,
			@servings,
			@extraction_method,
			@solvent_type,
			@ingredients_list,
			@is_plant_nutrient,
			@nutrient_type,
			@nutrient_application_device,
			@id_user,
			@id_user
		)

		SET @id_item_group=SCOPE_IDENTITY()

	END

	/* update existing item detail. */
	ELSE
	BEGIN
		UPDATE [inventory].[item_group]
		   SET [name] = @name
		   	  ,[id_location] = @id_location
			  ,[is_global] = @is_global
			  ,[id_uom] = @id_uom
			  ,[id_uom_receiving] = @id_uom_receiving
			  ,[id_uom_weight_useable] = @id_uom_weight_useable
			  ,[units_per_received] = @units_per_received
			  ,[id_category] = @id_category
			  ,[id_raw_material] = @id_raw_material
			  ,[id_tax_category] = @id_tax_category
			  ,[id_brand] = @id_brand
			  ,[id_vendor] = @id_vendor
			  ,[batch_required] = @batch_required
			  ,[has_shelf_life] = @has_shelf_life
			  ,[shelf_life_days] = @shelf_life_days
			  ,[threshold_low_quantity] = @threshold_low_quantity
			  , [threshold_low_quantity_selected] = @threshold_low_quantity_selected
			  ,[is_product] = @is_product
			  ,[product_description] = @product_description
			  ,[is_tax_exempt] = @is_tax_exempt
			  ,[is_cannabis] = @is_cannabis
			  ,[is_plant] = @is_plant
			  ,[is_seed] = @is_seed
			  ,[id_strain] = @id_strain
			  ,[is_adult_use] = @is_adult_use
			  ,[is_medical_use] = @is_medical_use
			  ,[thc] = @thc
			  ,[cbd] = @cbd
			  ,[thc_mg] = @thc_mg
			  ,[cbd_mg] = @cbd_mg
			  ,[id_delivery_route] = @id_delivery_route
			  ,[dosage_recommended] = @dosage_recommended
			  ,[is_low_thc] = @is_low_thc
			  ,[is_medicated] = @is_medicated
			  ,[is_smoking] = @is_smoking
			  ,[is_low_thc_and_medical] = @is_low_thc_and_medical
			  ,[id_ommu_form] = @id_ommu_form
			  ,[is_ommu_delivery_device] = @is_ommu_delivery_device
			  ,[allergens] = @allergens
			  ,[nutritional_information] = @nutritional_information
			  ,[servings] = @servings
			  ,[extraction_method] = @extraction_method
			  ,[solvent_type] = @solvent_type
			  ,[ingredients_list] = @ingredients_list
			  ,[is_plant_nutrient] = @is_plant_nutrient
			  ,[nutrient_type] = @nutrient_type
			  ,[nutrient_application_device] = @nutrient_application_device
			  ,[deleted] = @deleted
			  ,[id_user_updated] = @id_user
			  ,[date_updated] = GETUTCDATE()
		 WHERE id_item_group=@id_item_group
	END
	


	/* upsert attributes. */
	;WITH attribute_list AS (
		SELECT @id_item_group AS id_item_group
				, id_attribute
		FROM OPENJSON(@attribute_list)
		WITH (
			id_attribute INT
		)
	)
	MERGE inventory.item_group_attribute t
	USING attribute_list s
	ON t.id_item_group=s.id_item_group AND t.id_attribute=s.id_attribute
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_item_group, id_attribute) VALUES (s.id_item_group, s.id_attribute)
	WHEN NOT MATCHED BY SOURCE AND t.id_item_group=@id_item_group THEN
		DELETE
	;

	/* upsert nutrient ingredients. */
	;WITH nutrient_list AS (
		SELECT @id_item_group AS id_item_group
				, id_nutrient_ingredient
				, name
				, percentage
		FROM OPENJSON(@nutrient_ingredient_list)
		WITH (
			id_nutrient_ingredient INT,
			name VARCHAR(255),
			percentage DECIMAL(5,2)
		)
	)
	MERGE inventory.item_group_nutrient_ingredient t
	USING nutrient_list s
	ON t.id_nutrient_ingredient=s.id_nutrient_ingredient
	WHEN MATCHED THEN
		UPDATE SET t.name=s.name, t.percentage=s.percentage, t.id_user_updated=@id_user, t.date_updated=GETUTCDATE()
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_item_group, name, percentage, id_user_created, id_user_updated) VALUES (s.id_item_group, s.name, s.percentage, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND t.id_item_group=@id_item_group THEN
		DELETE
	;

	/* upsert items. */
	SELECT * INTO #item_list
	FROM (
		SELECT *
		FROM OPENJSON(@item_list)
		WITH (
			id_item INT,
			sku VARCHAR(512),
			cost_of_good DECIMAL(12,4),
			price_wholesale DECIMAL(12, 4),
			price_retail DECIMAL(12,4),
			price_retail_medical_use DECIMAL(12,4),
			price_retail_adult_use DECIMAL(12,4),
			price_otd DECIMAL(12,4),
			price_otd_medical_use DECIMAL(12,4),
			price_otd_adult_use DECIMAL(12,4),
			use_otd_price BIT,
			use_tiered_pricing BIT,
			tiered_pricing  NVARCHAR(MAX) AS JSON,
			tiered_pricing_option VARCHAR(64),
			id_preset_tiered_pricing INT,
			show_price_total bit,
			flat_excise DECIMAL(12,4),
			weight_useable DECIMAL(14,6),
			gross_weight_useable DECIMAL(14,6),
			id_uom_gross_weight_useable INT,
			weight_net DECIMAL(14,6),
			id_uom_weight_net INT,
			external_id VARCHAR(128),
			biotrack_barcode_id VARCHAR(256),
			biotrack_inventory_type_id INT,
			vt_product_number VARCHAR(64),
			vt_product_name VARCHAR(255),
			vt_product_type VARCHAR(512),
			vt_business_name VARCHAR(255),
			location_list NVARCHAR(MAX) AS JSON,
			attribute_value_list NVARCHAR(MAX) AS JSON,
			bom_list NVARCHAR(MAX) AS JSON
		)
	) t

	/* delete items not in list. */
	UPDATE inventory.item
	SET deleted=1
		, id_user_updated=@id_user
		, date_updated=GETUTCDATE()
	WHERE id_item_group=@id_item_group AND id_item NOT IN (SELECT l.id_item FROM #item_list l WHERE l.id_item IS NOT NULL)



	DECLARE @id_item INT, 
			@sku VARCHAR(512), 
			@cost_of_good DECIMAL(12,4),
			@price_wholesale DECIMAL(12, 4),
			@price_retail DECIMAL(12,4), 
			@price_retail_medical_use DECIMAL(12,4), 
			@price_retail_adult_use DECIMAL(12,4), 
			@price_otd DECIMAL(12,4),
			@price_otd_medical_use DECIMAL(12,4),
			@price_otd_adult_use DECIMAL(12,4),
			@use_otd_price BIT,
			@use_tiered_pricing BIT,
			@tiered_pricing NVARCHAR(MAX),
			@tiered_pricing_option VARCHAR(64),
			@id_preset_tiered_pricing INT,
			@show_price_total bit,
			@flat_excise DECIMAL(12,4), 
			@weight_useable_g DECIMAL(14,6), 
			@weight_useable DECIMAL(14,6), 
			@gross_weight_useable DECIMAL(14,6),
			@id_uom_gross_weight_useable INT,
			@weight_net DECIMAL(14,6),
			@id_uom_weight_net INT,
			@external_id VARCHAR(128), 
			@biotrack_barcode_id VARCHAR(256),
			@biotrack_inventory_type_id INT,
			@vt_product_number VARCHAR(64),
			@vt_product_name VARCHAR(255),
			@vt_product_type VARCHAR(512),
			@vt_business_name VARCHAR(255),
			@location_list NVARCHAR(MAX),
			@attribute_value_list NVARCHAR(MAX), 
			@bom_list NVARCHAR(MAX),

			@id_bom_group INT,
			@bom_quantity DECIMAL(18,4),
			@bom_item_list NVARCHAR(MAX)

	/* upsert item item values. */
	DECLARE c CURSOR FOR (SELECT id_item
								, sku
								, cost_of_good
								, price_wholesale
								, price_retail
								, price_retail_medical_use
								, price_retail_adult_use
								, price_otd
								, price_otd_medical_use
								, price_otd_adult_use
								, use_otd_price
								,use_tiered_pricing
								,tiered_pricing
								,tiered_pricing_option
								,id_preset_tiered_pricing
								, show_price_total
								, flat_excise
								, weight_useable
								, gross_weight_useable
								, id_uom_gross_weight_useable
								, weight_net
								, id_uom_weight_net
								, external_id
								, biotrack_barcode_id
								, biotrack_inventory_type_id
								, vt_product_number
								, vt_product_name
								, vt_product_type
								, vt_business_name
								, location_list
								, attribute_value_list
								, bom_list 
						 FROM #item_list)
	OPEN c
	FETCH NEXT FROM c INTO @id_item, @sku, @cost_of_good, @price_wholesale, @price_retail, @price_retail_medical_use, @price_retail_adult_use, @price_otd, @price_otd_medical_use, @price_otd_adult_use, @use_otd_price,@use_tiered_pricing, @tiered_pricing, @tiered_pricing_option, @id_preset_tiered_pricing,  @show_price_total, @flat_excise, @weight_useable, @gross_weight_useable, @id_uom_gross_weight_useable, @weight_net, @id_uom_weight_net, @external_id, @biotrack_barcode_id, @biotrack_inventory_type_id, @vt_product_number, @vt_product_name, @vt_product_type, @vt_business_name, @location_list, @attribute_value_list, @bom_list
	WHILE @@FETCH_STATUS = 0 BEGIN

		/* insert new item. */
		IF(@id_item IS NULL)
		BEGIN
			INSERT INTO inventory.item (
				id_item_group
				, sku
				, cost_of_good
				, price_wholesale
				, price_retail
				, price_retail_medical_use
				, price_retail_adult_use
				, price_otd
				, price_otd_medical_use
				, price_otd_adult_use
				, use_otd_price
				, flat_excise
				, use_tiered_pricing
				, tiered_pricing
				, tiered_pricing_option
				, id_preset_tiered_pricing
				, show_price_total
				, weight_useable
				, gross_weight_useable
				, id_uom_gross_weight_useable
				, weight_net
				, id_uom_weight_net
				, external_id
				, biotrack_barcode_id
				, biotrack_inventory_type_id
				, vt_product_number
				, vt_product_name
				, vt_product_type
				, vt_business_name
				, id_user_created
				, id_user_updated
			)
			VALUES (
				@id_item_group
				, @sku
				, @cost_of_good
				, @price_wholesale
				, @price_retail
				, @price_retail_medical_use
				, @price_retail_adult_use
				, @price_otd
				, @price_otd_medical_use
				, @price_otd_adult_use
				, @use_otd_price
				, @flat_excise
				, @use_tiered_pricing
				, @tiered_pricing
				, @tiered_pricing_option
				, @id_preset_tiered_pricing
				, @show_price_total
				, @weight_useable
				, @gross_weight_useable
				, @id_uom_gross_weight_useable
				, @weight_net
				, @id_uom_weight_net
				, @external_id
				, @biotrack_barcode_id
				, @biotrack_inventory_type_id
				, @vt_product_number
				, @vt_product_name
				, @vt_product_type
				, @vt_business_name
				, @id_user
				, @id_user
			)

			SET @id_item=SCOPE_IDENTITY()
		END
		/* update existing item. */
		ELSE
			UPDATE inventory.item
			SET sku=@sku
				, cost_of_good=@cost_of_good
				, price_wholesale=@price_wholesale
				, price_retail=@price_retail
				, price_retail_medical_use=@price_retail_medical_use
				, price_retail_adult_use=@price_retail_adult_use
				, price_otd=@price_otd
				, price_otd_medical_use=@price_otd_medical_use
				, price_otd_adult_use=@price_otd_adult_use
				, use_otd_price=@use_otd_price
				, flat_excise=@flat_excise
				, use_tiered_pricing=@use_tiered_pricing
				, tiered_pricing=@tiered_pricing
				, tiered_pricing_option=@tiered_pricing_option
				, id_preset_tiered_pricing=@id_preset_tiered_pricing
				, show_price_total = @show_price_total
				, weight_useable=@weight_useable
				, gross_weight_useable=@gross_weight_useable
				, id_uom_gross_weight_useable=@id_uom_gross_weight_useable
				, weight_net=@weight_net
				, id_uom_weight_net=@id_uom_weight_net
				, external_id=@external_id
				, biotrack_barcode_id=ISNULL(@biotrack_barcode_id, biotrack_barcode_id)
				, biotrack_inventory_type_id=ISNULL(@biotrack_inventory_type_id, biotrack_inventory_type_id)
				, vt_product_number=@vt_product_number
				, vt_product_name=@vt_product_name
				, vt_product_type=@vt_product_type
				, vt_business_name=@vt_business_name
				, id_user_updated=@id_user
				, date_updated=GETUTCDATE()
			WHERE id_item=@id_item

		/* upsert location values. */
		;WITH location_list AS (
			SELECT @id_item AS id_item
					, id_location
					, cost_of_good
					, price_wholesale
					, price_retail
					, price_retail_medical_use
					, price_retail_adult_use
					, price_otd
					, price_otd_medical_use
					, price_otd_adult_use
					, use_location_otd_price
					, use_tiered_pricing
			        , tiered_pricing 
					, tiered_pricing_option
					, id_preset_tiered_pricing
					, show_price_total
					, flat_excise
					, metrc_item_id
					, metrc_name
					, metrc_category
					, metrc_brand
					, biotrack_barcode_id
					, biotrack_inventory_type_id
			FROM OPENJSON(@location_list)
			WITH (
				id_location INT,
				cost_of_good DECIMAL(18,4),
				price_wholesale DECIMAL(18,4),
				price_retail DECIMAL(18,4),
				price_retail_medical_use DECIMAL(18,4),
				price_retail_adult_use DECIMAL(18,4),
				price_otd DECIMAL(18,4),
				price_otd_medical_use DECIMAL(18,4),
				price_otd_adult_use DECIMAL(18,4),
				use_location_otd_price BIT,
				use_tiered_pricing BIT,
			    tiered_pricing  NVARCHAR(MAX) AS JSON,
				tiered_pricing_option VARCHAR(64),
			    id_preset_tiered_pricing INT,
				show_price_total BIT,
				flat_excise DECIMAL(18,4),
				metrc_item_id BIGINT,		
				metrc_name VARCHAR(512),
				metrc_category VARCHAR(512),
				metrc_brand VARCHAR(512),
				biotrack_barcode_id BIGINT,
				biotrack_inventory_type_id INT
			)
		)
		MERGE inventory.item_location t
		USING location_list s
		ON t.id_item=s.id_item AND t.id_location=s.id_location
		WHEN MATCHED THEN
			UPDATE SET t.cost_of_good=s.cost_of_good
					, t.price_wholesale=s.price_wholesale
					, t.price_retail=s.price_retail
					, t.price_retail_medical_use=s.price_retail_medical_use
					, t.price_retail_adult_use=s.price_retail_adult_use
					, t.price_otd=s.price_otd
					, t.price_otd_medical_use=s.price_otd_medical_use
					, t.price_otd_adult_use=s.price_otd_adult_use
					, t.use_location_otd_price=s.use_location_otd_price
					, t.use_tiered_pricing = s.use_tiered_pricing
					, t.tiered_pricing = s.tiered_pricing
					, tiered_pricing_option = s.tiered_pricing_option
					, id_preset_tiered_pricing = s.id_preset_tiered_pricing
					, show_price_total = s.show_price_total
					, t.flat_excise=s.flat_excise
					, t.metrc_item_id=s.metrc_item_id
					, t.metrc_name=s.metrc_name
					, t.metrc_category=s.metrc_category
					, t.metrc_brand=s.metrc_brand
					, t.biotrack_barcode_id=s.biotrack_barcode_id
					, t.biotrack_inventory_type_id=s.biotrack_inventory_type_id
					, t.deleted=0
					, t.id_user_updated=@id_user
					, t.date_updated=GETUTCDATE()
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_item, id_location, cost_of_good, price_wholesale, price_retail, price_retail_medical_use, price_retail_adult_use, price_otd, price_otd_medical_use, price_otd_adult_use, use_location_otd_price,  use_tiered_pricing, tiered_pricing, tiered_pricing_option, id_preset_tiered_pricing, show_price_total, flat_excise, metrc_item_id, metrc_name, metrc_category, metrc_brand, id_user_created, id_user_updated, biotrack_barcode_id, biotrack_inventory_type_id) 
			VALUES (@id_item
					, s.id_location
					, s.cost_of_good
					, s.price_wholesale
					, s.price_retail
					, s.price_retail_medical_use
					, s.price_retail_adult_use
					, s.price_otd
					, s.price_otd_medical_use
					, s.price_otd_adult_use
					, s.use_location_otd_price
					, s.use_tiered_pricing
					, s.tiered_pricing
					, s.tiered_pricing_option
					, s.id_preset_tiered_pricing
					, s.show_price_total
					, s.flat_excise
					, s.metrc_item_id
					, s.metrc_name
					, s.metrc_category
					, s.metrc_brand
					, s.biotrack_barcode_id
					, s.biotrack_inventory_type_id
					, @id_user, @id_user)

		WHEN NOT MATCHED BY SOURCE AND t.id_item=@id_item THEN
			UPDATE SET t.deleted=1
					, t.id_user_updated=@id_user
					, t.date_updated=GETUTCDATE()
		;	

		-- Create a temp table to store parsed data.
CREATE TABLE #tempThresholds
(
    id_location INT,
	id_item INT,
    location_threshold_low_quantity_value FLOAT,
	location_threshold_low_quantity_selected BIT
);

-- Parse the JSON to populate the temp table.
INSERT INTO #tempThresholds (id_location, id_item, location_threshold_low_quantity_value, location_threshold_low_quantity_selected)
SELECT 
    JSON_VALUE(value, '$.id_location'),
	JSON_VALUE(value, '$.id_item'),
    JSON_VALUE(value, '$.location_threshold_low_quantity_value'),
	JSON_VALUE(value, '$.location_threshold_low_quantity_selected')
FROM OPENJSON(@location_threshold_low_quantity);
		

		MERGE INTO inventory.item_location AS target
USING #tempThresholds AS source
ON target.id_location = source.id_location AND target.id_item = source.id_item

WHEN MATCHED THEN 
    UPDATE SET 
        target.location_threshold_low_quantity_value = source.location_threshold_low_quantity_value, 
        target.location_threshold_low_quantity_selected = source.location_threshold_low_quantity_selected


WHEN NOT MATCHED BY TARGET THEN 
    INSERT (location_threshold_low_quantity_value, location_threshold_low_quantity_selected)
    VALUES (source.location_threshold_low_quantity_value, source.location_threshold_low_quantity_selected);

	DROP TABLE #tempThresholds	


		/* upsert item values. */
		;WITH attribute_value_list AS (
			SELECT @id_item AS id_item
					, id_attribute_value
			FROM OPENJSON(@attribute_value_list)
			WITH (
				id_attribute_value INT 
			)
		)
		MERGE inventory.item_attribute_value t
		USING attribute_value_list s
		ON t.id_item=s.id_item AND t.id_attribute_value=s.id_attribute_value
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_item, id_attribute_value) VALUES (s.id_item, s.id_attribute_value)
		WHEN NOT MATCHED BY SOURCE AND t.id_item=@id_item THEN
			DELETE
		;		
		
		/* delete bom groups not present in list. */
		UPDATE process.bom_group
		SET deleted=1
		WHERE id_item=@id_item AND id_bom_group NOT IN (SELECT id_bom_group FROM OPENJSON(@bom_list) WITH (id_bom_group INT) WHERE id_bom_group IS NOT NULL)

		/* loop through bill of materials. */
		DECLARE b CURSOR FOR (SELECT id_bom_group
									, quantity
									, item_list
							  FROM OPENJSON(@bom_list)
							  WITH (
								id_bom_group INT,
								quantity DECIMAL(18,4),
								item_list NVARCHAR(MAX) AS JSON
							  )
							)
		OPEN b
		FETCH NEXT FROM b INTO @id_bom_group, @bom_quantity, @bom_item_list
		WHILE @@FETCH_STATUS = 0 BEGIN

			/* insert new bom group. */
			IF (@id_bom_group IS NULL)
			BEGIN
				INSERT INTO process.bom_group (id_item, quantity)
				VALUES (@id_item, @bom_quantity)

				SET @id_bom_group = SCOPE_IDENTITY()
			END
			/* update existing bom group. */
			ELSE
			BEGIN			
				UPDATE process.bom_group
				SET quantity = @bom_quantity
				WHERE id_bom_group = @id_bom_group
			END
			/* upsert bom items. */
			;WITH item_list AS (
				SELECT id_bom_item
						, @id_bom_group AS id_bom_group
						, id_item
				FROM OPENJSON(@bom_item_list)
				WITH (
					id_bom_item INT '$.id_bom_item',
					id_item INT '$.id_item'
				)
			)
			
			MERGE process.bom_item t
			USING item_list s
			ON t.id_bom_item=s.id_bom_item
			WHEN MATCHED THEN UPDATE SET t.id_item=s.id_item
			WHEN NOT MATCHED BY TARGET THEN INSERT (id_bom_group, id_item) VALUES (s.id_bom_group, s.id_item)
			WHEN NOT MATCHED BY SOURCE AND t.id_bom_group=@id_bom_group THEN UPDATE SET t.deleted=1
			;
		
			UPDATE inventory.item 
			SET inventory.item.cost_of_good=item_list.cost_of_good
			FROM OPENJSON(@bom_item_list) 
			WITH (
				id_item INT '$.id_item',
				cost_of_good DECIMAL(10,2) '$.cost_of_good'
			) as item_list
			WHERE item_list.id_item=inventory.item.id_item

			FETCH NEXT FROM b INTO @id_bom_group, @bom_quantity, @bom_item_list
		END

		CLOSE b
		DEALLOCATE b

		FETCH NEXT FROM c INTO @id_item, @sku, @cost_of_good, @price_wholesale, @price_retail, @price_retail_medical_use, @price_retail_adult_use, @price_otd, @price_otd_medical_use, @price_otd_adult_use, @use_otd_price, @use_tiered_pricing, @tiered_pricing, @tiered_pricing_option, @id_preset_tiered_pricing, @show_price_total, @flat_excise, @weight_useable, @gross_weight_useable, @weight_net, @id_uom_weight_net, @id_uom_gross_weight_useable, @external_id, @biotrack_barcode_id, @biotrack_inventory_type_id, @vt_product_number, @vt_product_name, @vt_product_type, @vt_business_name, @location_list, @attribute_value_list, @bom_list
	END

	CLOSE c
	DEALLOCATE c

	/* add barcode to all items that are missing one. */
	UPDATE inventory.item
	SET barcode = inventory.fn_generate_item_barcode(id_item)
	WHERE barcode IS NULL OR barcode <> inventory.fn_generate_item_barcode(id_item)

	/* return new/updated item_detail. */
	EXEC inventory.usp_item_fetch @id_item_group
go

