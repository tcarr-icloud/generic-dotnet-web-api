CREATE PROCEDURE [order].[usp_order_add_onfleet]
	@id_order INT,
	@id_onfleet VARCHAR(128)
AS
	SET NOCOUNT ON;

	UPDATE [order].[order] 
	SET id_onfleet=@id_onfleet
	WHERE id_order=@id_order
go

