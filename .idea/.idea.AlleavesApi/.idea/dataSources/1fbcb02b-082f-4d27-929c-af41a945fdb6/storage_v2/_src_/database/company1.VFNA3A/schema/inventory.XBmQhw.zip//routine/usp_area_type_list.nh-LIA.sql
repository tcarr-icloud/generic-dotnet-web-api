CREATE PROCEDURE [inventory].[usp_area_type_list]
	@id_area_type INT = NULL
AS
	SET NOCOUNT ON;

	SELECT a.id_area_type
			, a.name AS area_type
			, a.reference AS area_type_reference
			, a.system
	FROM inventory.area_type a
	WHERE a.id_area_type=ISNULL(@id_area_type, a.id_area_type)
go

