CREATE PROCEDURE [grow].[usp_plant_aggregate_strain]
	@id_location INT = NULL,
	@id_area INT = NULL,
	@id_strain INT = NULL
AS
	SELECT s.name AS strain
				, COUNT(*) AS count_strain
	FROM grow.plant p
	JOIN inventory.area a ON a.id_area=p.id_area
	JOIN grow.strain s ON s.id_strain=p.id_strain
	WHERE p.harvested = 0 AND p.destroyed = 0 AND p.packaged = 0 AND
		(@id_location IS NULL OR a.id_location = @id_location) AND
		(@id_area IS NULL OR a.id_area = @id_area) AND
		(@id_strain IS NULL OR s.id_strain = @id_strain)
	GROUP BY s.name
	ORDER BY s.name
go

