CREATE PROCEDURE [order].[usp_sale_limit_list2]
	@id_sale_limit INT = NULL,
	@id_state VARCHAR(4) = NULL,
	@include_deleted BIT = 0
AS
	SELECT    s.id_sale_limit as id_sale_limit
			, s.[id_state]
			, st.[name] as [state]
			, s.limits
			, s.deleted
			, c.FirstName + ' ' + c.LastName as created_by
			, s.date_created
			, m.FirstName + ' ' + m.LastName as last_updated_by
			, s.date_updated
	FROM [order].sale_limit2 s
	INNER JOIN [base].[user] c on c.id_user = s.id_user_created
	INNER JOIN [base].[user] m on m.id_user = s.id_user_updated
	INNER JOIN [base].[states] as st on st.id_state = s.id_state
	WHERE (@id_sale_limit IS NULL OR s.id_sale_limit=@id_sale_limit) AND
		  (@id_state IS NULL OR s.[id_state]=@id_state) AND
		  (@include_deleted IS NULL OR s.deleted<=@include_deleted)
go

