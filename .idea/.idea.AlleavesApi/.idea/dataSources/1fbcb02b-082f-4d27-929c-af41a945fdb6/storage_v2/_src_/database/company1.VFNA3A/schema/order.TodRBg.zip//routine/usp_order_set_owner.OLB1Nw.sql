CREATE PROCEDURE [order].[usp_order_set_owner]
	@id_order INT,
	@id_user INT,
	@takeover BIT = 0
AS
	DECLARE @claimed INT
	SET @claimed=(SELECT id_user_working FROM [order].[order]
					WHERE id_order=@id_order)

	if(@claimed IS NOT NULL AND @takeover=0) 
	BEGIN
		SELECT 0 AS rtn
		RETURN
	END
	
	UPDATE [order].[order] 
	SET id_user_working=@id_user,
		date_updated=getutcdate()
	WHERE id_order=@id_order

	SELECT 1 AS rtn
go

