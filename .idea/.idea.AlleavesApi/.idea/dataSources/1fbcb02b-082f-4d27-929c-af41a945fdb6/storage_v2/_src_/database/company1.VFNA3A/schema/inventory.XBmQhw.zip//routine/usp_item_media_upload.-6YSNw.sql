CREATE PROCEDURE [inventory].[usp_item_media_upload]
	@id_item INT,
	@type VARCHAR(32),
	@content VARCHAR(500)
AS
	INSERT INTO inventory.item_media (id_item, type, content) 
	VALUES (@id_item, @type, @content)

	DECLARE @id_media INT = SCOPE_IDENTITY()

	SELECT * FROM inventory.item_media 
	WHERE id_media = @id_media
go

