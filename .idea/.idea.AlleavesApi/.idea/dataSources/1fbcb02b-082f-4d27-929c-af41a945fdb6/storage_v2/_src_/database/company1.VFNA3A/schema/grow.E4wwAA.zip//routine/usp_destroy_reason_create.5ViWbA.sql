CREATE PROCEDURE [grow].[usp_destroy_reason_create]
	@destroy_reason VARCHAR(256),
	@destroy_reason_required BIT = 0,
	@id_user INT
AS
	DECLARE @id_reason INT = (SELECT TOP 1 id_destroy_reason FROM grow.destroy_reason WHERE name=@destroy_reason)

	IF @id_reason IS NULL
	BEGIN
		INSERT INTO grow.destroy_reason (name, destroy_reason_required, created_by, updated_by) 
		VALUES (@destroy_reason, @destroy_reason_required, @id_user, @id_user)

		SET @id_reason = SCOPE_IDENTITY()
	END

	EXEC grow.usp_destroy_reason_list @id_reason
go

