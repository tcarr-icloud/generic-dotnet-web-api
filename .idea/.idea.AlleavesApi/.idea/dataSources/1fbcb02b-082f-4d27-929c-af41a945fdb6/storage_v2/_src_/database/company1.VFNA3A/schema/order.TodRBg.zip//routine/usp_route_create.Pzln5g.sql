CREATE PROCEDURE [order].usp_route_create
              @id_driver INT,
              @id_order INT,
              @delivery_date DATE,
              @route_index VARCHAR(250),
              @id_ride INT,
              @eta VARCHAR(250),
              @latitude VARCHAR(250),
              @longitude VARCHAR(250)
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [order].routes (id_driver, id_order, delivery_date, route_index,
	                           id_ride,eta ,latitude, longitude)
    VALUES (@id_driver, @id_order, @delivery_date, @route_index,@id_ride,@eta ,@latitude, @longitude)
	DECLARE @id_routes INT = SCOPE_IDENTITY()

	EXEC [order].usp_route_list @id_routes
END
go

