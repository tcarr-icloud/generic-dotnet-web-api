CREATE PROCEDURE [inventory].[usp_chemical_profile_upsert]
	@id_chemical_profile INT = NULL,
	@name VARCHAR(512),
	@type VARCHAR(32),
	@chemical_profile_value_list VARCHAR(MAX) = '[]',
	@id_user INT,
	@deleted BIT = 0
AS
	IF EXISTS (SELECT * FROM inventory.chemical_profile WHERE deleted=0 AND @deleted<>1 AND name=@name AND (@id_chemical_profile IS NULL OR id_chemical_profile <> @id_chemical_profile))
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A chemical profile with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	/* add new chemical_profile. */
	IF (@id_chemical_profile IS NULL) 
	BEGIN
		INSERT INTO inventory.chemical_profile ([name], [type], id_user_created, id_user_updated) 
		VALUES (@name, @type, @id_user, @id_user)

		SET @id_chemical_profile=SCOPE_IDENTITY()
	END
	/* update chemical_profile. */
	ELSE
	BEGIN
		UPDATE inventory.chemical_profile
		SET [name]=@name
			, [type]=@type
			, deleted=@deleted
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_chemical_profile=@id_chemical_profile
	END

	/* return updated/created chemical_profile. */
	EXEC inventory.usp_chemical_profile_list @id_chemical_profile, 1
go

