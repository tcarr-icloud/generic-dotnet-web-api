CREATE PROCEDURE [grow].[usp_plant_destroyed_list]
	@day_range INT = 30
AS
	;WITH	area_path AS (
			SELECT a.*, CAST(a.name AS VARCHAR(MAX)) AS path
			FROM inventory.area a
			JOIN inventory.area_type t ON t.id_area_type=a.id_area_type
			WHERE a.id_parent IS NULL AND t.reference='grow'
			UNION ALL
			SELECT b.*, CONCAT(p.path, ' > ', b.name) AS path
			FROM inventory.area b
			JOIN area_path p ON p.id_area=b.id_parent
		)
	SELECT p.id_plant
			, s.id_strain
			, st.id_strain_type
			, l.id_location
			, ph.id_phase
			, l.name AS location
			, p.name AS plant
			, p.source
			, s.name AS strain
			, st.name AS strain_type
			, ph.name AS phase
			, p.[row]
			, p.[column]
			, p.date_destroyed
			, p.id_destroy_reason
			, d.name AS destroy_reason
			, p.destroy_description
			
	FROM grow.plant p
	JOIN grow.strain s ON s.id_strain=p.id_strain
	JOIN grow.strain_type st ON st.id_strain_type=s.id_strain_type
	LEFT JOIN area_path a ON a.id_area=p.id_area
	LEFT JOIN base.location l ON l.id_location=a.id_location
	LEFT JOIN grow.destroy_reason d ON d.id_destroy_reason=p.id_destroy_reason
	LEFT JOIN (
		SELECT pp.id_plant
				, MAX(phs.sequence) AS sequence
		FROM grow.plant_phase pp
		JOIN grow.phase phs ON pp.id_phase=phs.id_phase
		GROUP BY pp.id_plant
	) ps ON ps.id_plant=p.id_plant
	LEFT JOIN grow.phase ph ON ph.sequence=ps.sequence
	LEFT JOIN grow.plant_phase pph ON pph.id_phase=ph.id_phase AND pph.id_plant=p.id_plant
	WHERE p.destroyed=1 AND p.date_destroyed>=DATEADD(day, -1*@day_range, getutcdate())
	ORDER BY p.date_destroyed DESC, p.name
go

