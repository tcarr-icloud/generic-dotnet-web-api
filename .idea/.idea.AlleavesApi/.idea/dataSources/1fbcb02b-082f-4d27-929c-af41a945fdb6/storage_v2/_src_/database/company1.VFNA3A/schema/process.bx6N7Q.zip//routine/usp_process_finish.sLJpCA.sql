CREATE PROCEDURE [process].[usp_process_finish]
	@id_process INT,
	@id_user INT
AS
	SET NOCOUNT ON
	
	DECLARE @id_batch INT
	DECLARE @id_item INT
	DECLARE @id_strain INT
	DECLARE @batch_label VARCHAR(128)
	DECLARE @id_location INT = (SELECT TOP 1 a.id_location FROM process.process_session ps JOIN process.process_session_output pso ON ps.id_process_session=pso.id_process_session JOIN inventory.area a ON a.id_area=pso.id_area)
	DECLARE @metrc_item_id BIGINT
	DECLARE @metrc_state VARCHAR(16) = (SELECT TOP 1 state FROM base.location WHERE id_location=@id_location)

	/* update base process data. */
	UPDATE process.process
	SET process_stop=getutcdate()
		, complete=1
		, id_status=3
		, updated_by=@id_user
		, date_updated=getutcdate()
	WHERE id_process=@id_process

	/* delete null output rows. */
	DELETE o
	FROM process.process_session_output o
	JOIN process.process_session s ON s.id_process_session=o.id_process_session
	WHERE s.id_process=@id_process AND o.quantity IS NULL


	/* loop through output item types and create batches and inventory. */
	DECLARE cur CURSOR FOR 
	SELECT DISTINCT pso.id_item, pso.batch_label
	FROM process.process_session_output pso
	JOIN process.process_session ps ON ps.id_process_session=pso.id_process_session
	WHERE ps.id_process=@id_process

	OPEN cur

	FETCH NEXT FROM cur INTO @id_item, @batch_label

	WHILE @@FETCH_STATUS = 0 BEGIN

		/* get strain for new batch. */
		SELECT TOP 1 @id_strain=b.id_strain
		FROM process.process c
		LEFT JOIN process.process_input inp ON inp.id_process=c.id_process
		LEFT JOIN inventory.batch b ON b.id_batch=inp.id_batch
		LEFT JOIN inventory.vw_item_list i ON i.id_item=b.id_item
		WHERE c.id_process=@id_process
		GROUP BY b.id_strain
		--ORDER BY SUM(inp.quantity * i.weight_useable_g) DESC
		ORDER BY SUM(inp.quantity) DESC

		/* create batch for item. */
		EXEC @id_batch = inventory.usp_batch_create @id_item, @id_strain, NULL, NULL, NULL, NULL, @batch_label

		/* set metrc fields if necessary. */
		SET @metrc_item_id = (SELECT TOP 1 metrc_item_id FROM inventory.item_location WHERE id_item=@id_item AND id_location=@id_location)
		IF (@metrc_item_id IS NOT NULL)
			UPDATE inventory.batch SET metrc_package_label=@batch_label, metrc_item_id=@metrc_item_id, metrc_state=@metrc_state WHERE id_batch=@id_batch

		/* add batch history. */
		INSERT INTO inventory.batch_history (id_batch, id_batch_parent)
		SELECT DISTINCT @id_batch AS id_batch, i.id_batch AS id_batch_parent
		FROM process.process c
		LEFT JOIN process.process_input i ON i.id_process=c.id_process
		LEFT JOIN inventory.batch b ON b.id_batch=i.id_batch
		WHERE c.id_process=@id_process AND b.id_item=@id_item
		GROUP BY i.id_batch
		HAVING COUNT(i.id_batch)>0

		/* add plant lineage to new batch. */
		EXEC inventory.usp_batch_inherit_plant_lineage @id_batch
		

		/* set process outputs to new batch id. */
		UPDATE o
		SET o.id_batch=@id_batch
		FROM process.process_session_output o
		JOIN process.process_session s ON s.id_process_session=o.id_process_session
		WHERE s.id_process=@id_process AND o.id_item=@id_item AND o.batch_label=@batch_label


		/* add log event and add output quantities to inventory storage locations. */
		DECLARE @event_list VARCHAR(MAX) = (
			   SELECT pso.id_area
					, pso.id_batch
					, SUM(pso.quantity) AS adjustment
			   FROM process.process_session_output pso
			   JOIN process.process_session ps ON ps.id_process_session=pso.id_process_session
			   WHERE ps.id_process=@id_process AND pso.id_batch=@id_batch
			   GROUP BY pso.id_area, pso.id_batch
			   FOR JSON PATH
		)
		EXEC [log].usp_event_create_bulk 'process_output', NULL, @event_list, @id_user		

		FETCH NEXT FROM cur INTO @id_item, @batch_label
	END

	CLOSE cur
	DEALLOCATE cur


	EXEC process.usp_process_list @id_process
go

