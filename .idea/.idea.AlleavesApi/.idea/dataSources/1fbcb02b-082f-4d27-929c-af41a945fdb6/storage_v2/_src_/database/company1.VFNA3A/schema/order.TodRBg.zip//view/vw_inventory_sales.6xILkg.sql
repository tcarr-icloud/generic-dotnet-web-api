
CREATE VIEW [order].[vw_inventory_sales]

AS

WITH order_CTE as (
SELECT 
     o.id_order
	,o.subtotal
    ,o.discount
    ,o.tax
    ,o.total
    ,o.discount / o.subtotal as order_discount_percent
    ,o.tax / (o.subtotal - o.discount) as order_tax_percent
    ,o.date_created as 'date'
	,l.name AS 'location'
	,pr.item as item_name
	,oi.id_inventory_item
	,c.id_category
	,c.[name] as category 
	,oi.price
	,oi.discount as item_discount
	,oi.price_post_tax
	,COALESCE(oi.price_override, oi.price - oi.discount) as price_post_discount
	,b.id_batch
FROM [order].[order] o 
INNER JOIN [order].[item] oi on o.id_order = oi.id_order AND oi.id_item_return IS NULL
LEFT JOIN [base].[location] l on l.id_location=o.id_location
LEFT JOIN [order].[payment] p ON p.id_order=oi.id_order
LEFT JOIN inventory.vw_item_list pr ON pr.id_item=oi.id_inventory_item
LEFT JOIN inventory.category c ON c.id_category = pr.id_category 
JOIN [inventory].[batch] b ON b.id_item = pr.id_item 
WHERE o.void = 0 AND o.cancel = 0 AND o.paid_in_full = 1
)
SELECT
	 [date]
	,id_order
	,location
	,id_inventory_item
	,id_category
	,category
	,item_name
	,COUNT(id_inventory_item) as quantity_sold
	,SUM(price) as gross_sales
    ,SUM(price_post_tax) as price_post_tax
	,CAST(SUM(price_post_discount) / COUNT(id_inventory_item) AS decimal(18,2)) AS average_price_per_unit
	,id_batch
FROM order_CTE
group by [date] ,location ,id_inventory_item ,item_name ,id_batch ,id_order ,id_category ,category
go

