
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [metrc].[usp_sale_failure_upsert]
	-- Add the parameters for the stored procedure here
	@id_order INT,
	@fail_reason VARCHAR(MAX) = NULL,
	@remediated BIT = 0,
	@id_user INT
AS
BEGIN
	/* change values based on whether or not the order exists already. We will assume that the order does not exist
	if the order has not been remediated/is not in the process of being remediated. */
	IF (@remediated IS NULL OR @remediated = 0)
		IF (SELECT id_order FROM [metrc].[sale_failure] WHERE id_order=@id_order) IS NOT NULL
			UPDATE [metrc].[sale_failure]
			SET remediated = @remediated
				, fail_reason = @fail_reason
				, updated_by = @id_user
				, date_updated = GETUTCDATE()
			WHERE id_order=@id_order
		ELSE
			INSERT INTO [metrc].[sale_failure] (id_order, fail_reason, remediated, created_by, updated_by)
			VALUES (@id_order, @fail_reason, 0, @id_user, @id_user)
	ELSE
		/* update the values because we have now remediated the order */
		UPDATE [metrc].[sale_failure]
		SET remediated = @remediated
			, updated_by = @id_user
			, date_updated = GETUTCDATE()
		WHERE id_order=@id_order
END
go

