CREATE PROCEDURE [acl].[usp_permission_list] 
	@id_permission int = NULL 
AS
	SET NOCOUNT ON;

	SELECT p.id_permission
			, p.id_parent
			, m.id_module
			, ISNULL(m.name, 'Uncategorized') AS module
			, p.reference
			, p.label 
	FROM acl.permission p 
	LEFT JOIN acl.module m ON m.id_module=p.id_module
	WHERE p.id_permission=ISNULL(@id_permission, p.id_permission) AND p.active=1
	ORDER BY m.id_module, p.id_permission
go

