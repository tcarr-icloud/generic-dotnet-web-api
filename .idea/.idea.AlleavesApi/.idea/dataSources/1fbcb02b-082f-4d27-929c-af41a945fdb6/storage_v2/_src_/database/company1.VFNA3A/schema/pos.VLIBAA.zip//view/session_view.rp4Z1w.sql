CREATE VIEW [pos].[session_view]

as

SELECT s.balance_starting 
	, s.balance_ending 
	, (SUM(p.tendered) + s.balance_starting) AS 'cash_expected'
	, (s.balance_ending - s.balance_starting) AS 'deposit'
	, SUM(s.balance_ending - s.balance_starting) AS 'total_deposit'
	, (s.balance_ending - (SUM(p.tendered) + s.balance_starting)) AS 'difference'
	, l.name AS 'location'
	, l.id_location
	, s.id_session
	, s.id_register AS 'terminal_number'
	, r.name AS 'terminal_name'
	, s.id_user_start
	, (us.FirstName + ' ' + us.LastName) AS 'user_opening'
	, s.id_user_end
	, (ue.FirstName + ' ' + ue.LastName) AS 'user_closing'
	, s.date_start
	, s.date_end
	, p.date_created
	, COUNT(p.id_payment) AS Transactions
FROM [pos].session s
JOIN [order].[payment] p ON p.id_register=s.id_register
JOIN [order].[order] o ON o.id_order=p.id_order
JOIN [base].[location] l ON l.id_location=o.id_location
JOIN [pos].register r ON r.id_register=s.id_register
JOIN [base].[user] us ON us.id_user=s.id_user_start
JOIN [base].[user] ue ON ue.id_user=s.id_user_end
WHERE (p.method = 'cash' OR p.method = 'change')AND p.date_created BETWEEN s.date_start AND ISNULL(s.date_end,GETUTCDATE())
GROUP BY l.name, s.balance_starting, s.balance_ending, s.id_register, s.id_user_start, s.id_user_end, r.name, 
         us.FirstName, us.LastName, ue.FirstName, ue.LastName, s.date_start, l.id_location, s.date_end, p.date_created, s.id_session
go

