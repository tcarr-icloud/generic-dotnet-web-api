CREATE PROCEDURE [dbo].[usp_set_reset_token]
	-- Add the parameters for the stored procedure here
	@id_user INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Insert statements for procedure here
	UPDATE base.[user]
	SET ResetToken = NEWID()
		,ResetTokenExpire = DATEADD(hour, 1, GETUTCDATE())
	WHERE id_user = @id_user

	SELECT ResetToken FROM base.[user]
	WHERE id_user = @id_user
END
go

