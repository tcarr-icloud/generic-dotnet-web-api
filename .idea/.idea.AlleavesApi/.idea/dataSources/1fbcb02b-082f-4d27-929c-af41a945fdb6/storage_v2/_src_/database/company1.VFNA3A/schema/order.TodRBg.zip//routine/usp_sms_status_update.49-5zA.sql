CREATE PROCEDURE [order].usp_sms_status_update
    @id_order INT
AS
    BEGIN
    SELECT id_order
	FROM [order].[order]
	WHERE id_order = @id_order
    DECLARE @id_order_from_table INT = (select @id_order
                      from [order].[order]
                      where id_order = @id_order)
    IF(@id_order_from_table IS NOT NULL)
    BEGIN
	    UPDATE [order].[order]
	    SET sms_enabled = 0
	    WHERE id_order = @id_order
    END
    END
go

