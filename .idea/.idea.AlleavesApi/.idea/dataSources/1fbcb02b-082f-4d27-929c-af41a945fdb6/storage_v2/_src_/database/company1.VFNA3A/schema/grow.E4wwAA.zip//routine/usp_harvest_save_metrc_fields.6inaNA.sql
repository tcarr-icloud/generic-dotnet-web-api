CREATE PROCEDURE [grow].[usp_harvest_save_metrc_fields]
	@id_harvest INT,
	@metrc_id INT,
	@metrc_harvest VARCHAR(255)
AS
	UPDATE grow.harvest
	SET metrc_id=@metrc_id
		, metrc_harvest=@metrc_harvest
	WHERE id_harvest=@id_harvest

	EXEC grow.usp_harvest_fetch @id_harvest
go

