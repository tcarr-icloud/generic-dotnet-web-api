CREATE PROCEDURE [ommu].[usp_order_type_list]
	
AS

SELECT o.id_order_type 
		,o.[name] as ommu_order_type
FROM [ommu].[order_type] o
ORDER BY o.[name]
go

