CREATE PROCEDURE [inventory].[usp_inventory_add]
	@id_area INT,
	@vendor VARCHAR(512) = NULL,
	@item_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	CREATE TABLE #manifest (
		id_item INT,
		id_batch INT,
		sku VARCHAR(512),
		item VARCHAR(512),
		category_path VARCHAR(512),
		batch VARCHAR(512),
		quantity DECIMAL(18,4),
		uom VARCHAR(64)
	)


	DECLARE @id_item INT,
			@quantity DECIMAL(18,4),
			@id_batch INT,
			@batch VARCHAR(512),
			@cost_of_good DECIMAL(18,8),
			@biotrack_barcode_id VARCHAR(256) = NULL,
			@biotrack_inventory_type_id INT = NULL,
			@id_item_group INT,
			@note VARCHAR(512) = 'Vendor: ' + ISNULL(@vendor, 'None')

	/* loop through items in list. */
	DECLARE c CURSOR FOR (SELECT id_item, quantity, id_batch, batch, cost_of_good, biotrack_barcode_id, biotrack_inventory_type_id FROM OPENJSON(@item_list)
							WITH (
								id_item INT,
								quantity DECIMAL(18,4),
								id_batch INT,
								batch VARCHAR(512),
								cost_of_good DECIMAL(18,8),
								biotrack_barcode_id VARCHAR(256),
								biotrack_inventory_type_id INT

							))
	OPEN c
	FETCH NEXT FROM c INTO @id_item, @quantity, @id_batch, @batch, @cost_of_good, @biotrack_barcode_id, @biotrack_inventory_type_id
	WHILE @@FETCH_STATUS = 0 BEGIN

		/* manage batch. */
		IF(@id_batch IS NULL)
		BEGIN
			IF(@batch IS NOT NULL AND EXISTS(SELECT * FROM inventory.batch WHERE name=@batch))
				SET @id_batch = (SELECT TOP 1 id_batch FROM inventory.batch WHERE name=@batch)
			ELSE
				BEGIN
				/* create new batch id or get default batch id if no batch is required. */
				EXEC @id_batch = inventory.usp_batch_create @id_item, NULL, NULL, NULL, NULL, NULL, NULL, @cost_of_good, @biotrack_barcode_id, @biotrack_inventory_type_id, NULL, NULL, @id_user
		
				/* update batch name if value is passd in. */
				IF(@batch IS NOT NULL)
					UPDATE inventory.batch SET name=@batch WHERE id_batch=@id_batch
			END
		END

		SET @id_item_group = (SELECT TOP 1 ig.id_item_group FROM inventory.item_group ig LEFT JOIN inventory.item ii ON ii.id_item_group=ig.id_item_group WHERE ii.id_item=@id_item)

		/* add item to inventory. */
		EXEC [log].usp_event_create 'inventory_add', @id_batch, @id_area, @quantity, @note, @id_user

		/* add to manifest. */
		INSERT INTO #manifest (id_item, id_batch, sku, item, category_path, batch, quantity, uom)
		SELECT @id_item AS id_item
				, @id_batch AS id_batch
				, i.sku
				, i.item
				, i.category_path
				, b.name AS batch
				, @quantity AS quantity
				, i.uom AS uom
		FROM inventory.batch b
		JOIN inventory.vw_item_list i ON i.id_item=b.id_item
		WHERE b.id_batch=@id_batch

	FETCH NEXT FROM c INTO @id_item, @quantity, @id_batch, @batch, @cost_of_good, @biotrack_barcode_id, @biotrack_inventory_type_id
	END

	CLOSE c
	DEALLOCATE c

	/* return manifest. */
	SELECT * FROM #manifest
go

