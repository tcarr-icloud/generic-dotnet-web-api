CREATE PROCEDURE [base].[usp_dashboard_reporting_list_today]

	AS
-- Create a temporary table that will be dropped at the end of this stored procedure to hold a list of customers that existed prior to the current time period.
CREATE TABLE #returnCustomerList (id_customer INT);

INSERT INTO #returnCustomerList (id_customer)
SELECT DISTINCT vwo.id_customer
FROM [order].[vw_orders] vwo
LEFT OUTER JOIN [base].[location] l ON vwo.id_location = l.id_location
LEFT OUTER JOIN dbo.tz_lookup AS tz ON l.timezone = tz.tz_iana
WHERE vwo.paid_in_full = 1 AND
    vwo.cancel = 0 AND
    vwo.void = 0 AND
    CAST(vwo.date_paid_order_local AS DATE) < DATEADD(DAY, DATEDIFF(DAY, 0, GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows), 0);

SELECT 
	aa.net_revenue/NULLIF(aa.total_tickets, 0) AS average_ticket_price,
	(aa.gross_revenue - aa.net_revenue)/NULLIF(aa.gross_revenue, 0) * 100 AS discount_rate_percentage,
	aa.gross_revenue/NULLIF(aa.units_sold, 0) AS average_unit_retail,
	aa.net_revenue/NULLIF(aa.units_sold, 0) AS average_unit_net_retail,
	aa.total_tickets,
	aa.total_customers,
	aa.new_customers,
	aa.total_customers-aa.new_customers AS returning_customers,
	aa.total_customers/NULLIF(aa.total_customers, 0) * 100 AS total_customers_percentage,
	(CAST(aa.new_customers AS DECIMAL)/NULLIF(aa.total_customers, 0)) * 100 AS new_customers_percentage,
	(aa.total_customers-aa.new_customers)/NULLIF(CAST(aa.total_customers AS DECIMAL), 0) * 100 AS returning_customers_percentage,
	aa.units_sold,
	aa.deliveries_today,
	aa.pickups_today,
	aa.gross_revenue,
	aa.net_revenue,
	aa.units_per_transaction,
	aa.net_revenue_delivery,
	aa.net_revenue_retail,
	aa.net_revenue_pickup
FROM (
	SELECT
		(SUM(vwoi.quantity) / COUNT(DISTINCT vwo.id_order)) AS units_per_transaction,
		COUNT(DISTINCT vwo.id_order) AS total_tickets,
		COUNT(DISTINCT vwo.id_customer) AS total_customers,
		COUNT(DISTINCT CASE WHEN rcl.id_customer IS NULL THEN vwo.id_customer END) AS new_customers,
		SUM(vwoi.quantity) AS units_sold,
		SUM(vwoi.price_post_all_adjustments) as net_revenue,
		SUM(vwoi.price) AS gross_revenue,
		COUNT(DISTINCT vwo_delivery.id_order) AS deliveries_today,
		COUNT(DISTINCT vwo_pickup.id_order) AS pickups_today,
		SUM(CASE WHEN (vwo.type = 'Delivery') THEN vwoi.price_post_all_adjustments
			ELSE 0
			END) AS net_revenue_delivery,
		SUM(CASE WHEN (vwo.type = 'Retail') THEN vwoi.price_post_all_adjustments
			ELSE 0
			END) AS net_revenue_retail,
		SUM(CASE WHEN (vwo.type = 'Pickup') THEN vwoi.price_post_all_adjustments
			ELSE 0
			END) AS net_revenue_pickup
	FROM [order].[vw_orders] vwo
	LEFT JOIN [order].[vw_order_items] vwoi ON vwo.id_order = vwoi.id_order
	LEFT JOIN [order].[vw_orders] vwo_delivery ON vwo_delivery.id_order = vwo.id_order AND vwo_delivery.type='Delivery'
	LEFT JOIN [order].[vw_orders] vwo_pickup ON vwo_pickup.id_order = vwo.id_order AND vwo_pickup.type='Pickup'
	LEFT OUTER JOIN [base].[location] l on vwo.id_location = l.id_location
	LEFT OUTER JOIN [dbo].[tz_lookup] tz on l.timezone = tz.tz_iana
	LEFT OUTER JOIN #returnCustomerList rcl ON vwo.id_customer = rcl.id_customer
	WHERE vwo.paid_in_full = 1 AND 
		vwo.cancel = 0 AND 
		vwo.void = 0 AND
		CAST(vwo.date_paid_order_local AS DATE) >= DATEADD(DAY, DATEDIFF(DAY, 0, GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows), 0)
) aa

-- Drop the temporary table
DROP TABLE #returnCustomerList;
go

