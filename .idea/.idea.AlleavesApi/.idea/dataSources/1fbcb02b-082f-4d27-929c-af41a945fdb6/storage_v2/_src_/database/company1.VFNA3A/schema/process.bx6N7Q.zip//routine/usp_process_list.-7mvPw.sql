CREATE PROCEDURE [process].[usp_process_list]
	@id_process INT = NULL
AS
	WITH	area_path AS (
				SELECT a.*, CAST(a.name AS VARCHAR(MAX)) AS path
				FROM inventory.area a
				WHERE a.id_parent IS NULL
				UNION ALL
				SELECT b.*, CONCAT(p.path, ' > ', b.name) AS path
				FROM inventory.area b
				JOIN area_path p ON p.id_area=b.id_parent
			)

	SELECT p.id_process
			, p.id_form
			, p.id_location
			, p.id_status
			, l.name AS location
			, f.name AS process
			, p.date_process
			, dbo.fn_utc_to_local(p.process_start, l.id_location) AS process_start
			, p.process_start AS process_start_utc
			, dbo.fn_utc_to_local(p.process_stop, l.id_location) AS process_stop
			, p.process_stop AS process_stop_utc
			, s.name AS status
			, s.reference AS status_reference
			, p.complete
			, p.cancelled
			, ISNULL((SELECT pri.id_process_input
							, pri.id_process
							, pri.id_form_input
							, pri.id_batch
							, pri.id_area
							, i.id_item_group
							, i.id_item
							, s.id_strain
							, rm.id_raw_material
							, g.name AS item
							, rm.name AS raw_material
							, b.name AS batch
							, a.path AS area_path
							, u.name AS uom
							, u.name_short AS uom_short
							, s.name AS strain
							, pri.quantity
							, ci.available
							, ISNULL(pri.quantity, 0)+ISNULL(ci.available, 0) AS max_available
							, b.metrc_package_label
					  FROM process.process_input pri
					  JOIN inventory.batch b ON b.id_batch=pri.id_batch
					  JOIN inventory.item i ON i.id_item=b.id_item
					  JOIN inventory.item_group g ON g.id_item_group=i.id_item_group
					  JOIN inventory.uom u ON u.id_uom=g.id_uom
					  JOIN inventory.raw_material rm ON rm.id_raw_material=g.id_raw_material
					  JOIN area_path a ON a.id_area=pri.id_area
					  LEFT JOIN grow.strain s ON s.id_strain=b.id_strain
					  LEFT JOIN inventory.vw_current_inventory ci ON ci.id_batch=pri.id_batch AND ci.on_hand>0 AND ci.area_type<>'scrap'
					  WHERE pri.id_process=p.id_process
					  FOR JSON PATH
			), '[]') AS input_list
			, ISNULL((SELECT pa.id_process_attribute
							, pa.id_process
							, pa.id_form_attribute
							, fa.input_type
							, fa.name AS attribute
							, pa.value
					  FROM process.process_attribute pa
					  JOIN process.form_attribute fa ON fa.id_form_attribute=pa.id_form_attribute
					  WHERE pa.id_process=p.id_process
					  FOR JSON PATH
			), '[]') AS attribute_list
			, ISNULL((SELECT ps.id_process_session
							, ps.id_process
							, ps.session_started
							, ps.session_stopped
							, ps.session_started_by
							, ps.session_stopped_by
							, ps.num_workers
							, ps.labor_hours
							, CONCAT(u1.FirstName, ' ', u1.LastName) AS session_started_by_name
							, CONCAT(u2.FirstName, ' ', u2.LastName) AS session_stopped_by_name
							, ISNULL((SELECT pso.id_process_session_output
											, psi.id_item_group
											, pso.id_item
											, pso.id_area
											, pso.id_batch
											, pso.batch_label
											, psi.item_group
											, psi.item
											, psi.is_cannabis
											, psa.path AS area_path
											, psu.name AS uom
											, psu.name_short AS uom_short
											, psb.name AS batch
											, pso.quantity
									  FROM process.process_session_output pso
									  LEFT JOIN inventory.vw_item_list psi ON psi.id_item=pso.id_item
									  LEFT JOIN inventory.uom psu ON psu.id_uom=psi.id_uom
									  LEFT JOIN inventory.batch psb ON psb.id_batch=pso.id_batch
									  LEFT JOIN area_path psa ON psa.id_area=pso.id_area
									  WHERE pso.id_process_session=ps.id_process_session
									  FOR JSON PATH
							), '[]') AS output_list
					  FROM process.process_session ps
					  LEFT JOIN base.[user] u1 ON u1.id_user=ps.session_started_by
					  LEFT JOIN base.[user] u2 ON u2.id_user=ps.session_stopped_by
					  WHERE ps.id_process=p.id_process
					  FOR JSON PATH
			), '[]') AS session_list
	FROM process.process p
	JOIN process.form f ON f.id_form=p.id_form
	JOIN process.status s ON s.id_status=p.id_status
	JOIN base.location l ON l.id_location=p.id_location
	WHERE p.id_process=ISNULL(@id_process, p.id_process)
go

