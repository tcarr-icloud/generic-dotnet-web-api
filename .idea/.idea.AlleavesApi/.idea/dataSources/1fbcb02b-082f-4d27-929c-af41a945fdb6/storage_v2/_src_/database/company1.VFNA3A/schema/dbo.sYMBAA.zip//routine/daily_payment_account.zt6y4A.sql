CREATE PROCEDURE [dbo].[daily_payment_account]
AS
	SET NOCOUNT ON;

SELECT ptab.[name], SUM(ptab.[total]) AS postdiscount, SUM(ptab.[subtotal]) prediscount, SUM(ptab.[Cash]) AS Cash,
SUM(ptab.[Change]) AS Change, SUM(ptab.[CanPay]) AS CanPay FROM
(SELECT orders.*,  a.tendered AS Cash, b.tendered AS CanPay, c.tendered AS Change FROM
			(SELECT [order].[order].[id_order], [order].date_created as [order_date], [order].[order].id_location, [base].[location].[name], 
			[order].[order].complete, [order].[order].total, [order].[order].subtotal, ([order].[order].total / [order].[order].subtotal) AS disc_rat FROM [order].[order]
			LEFT JOIN [base].[location]
			ON [order].[order].id_location = [base].[location].id_location) orders
		Left JOIN 
			(SELECT [order].[payment].[id_order], [order].[payment].[method],
			[order].[payment].[tendered] FROM [order].[payment] WHERE [order].[payment].[method] = 'Cash') a
		ON orders.[id_order] = a.[id_order]
		Left JOIN
			(SELECT [order].[payment].[id_order], [order].[payment].[method],
			[order].[payment].[tendered] FROM [order].[payment] WHERE [order].[payment].[method] = 'CanPay') b
		ON orders.[id_order] = b.[id_order]
		Left JOIN
			(SELECT [order].[payment].[id_order], [order].[payment].[method],
			[order].[payment].[tendered] FROM [order].[payment] WHERE [order].[payment].[method] = 'Change') c
		ON orders.[id_order] = c.[id_order]) ptab
		WHERE ISNULL(ptab.[CanPay], 0.0) + ISNULL(ptab.[Cash], 0.0) + ISNULL(ptab.[Change], 0.0) = ptab.[total]
	GROUP BY ptab.[name]
go

