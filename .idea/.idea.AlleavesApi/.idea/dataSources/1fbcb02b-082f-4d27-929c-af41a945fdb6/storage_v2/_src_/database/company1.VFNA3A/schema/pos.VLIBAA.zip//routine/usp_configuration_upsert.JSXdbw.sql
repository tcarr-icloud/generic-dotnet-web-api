CREATE PROCEDURE [pos].[usp_configuration_upsert]
	@id_location INT,
    @order_auto_expire_timeframe VARCHAR(64),
	@alleaves_pay_rounding_method VARCHAR(10),
	@cashless_atm_rounding_method VARCHAR(10),
	@auto_close VARCHAR(64),
    @auto_print_receipt BIT,
    @auto_print_patient_label BIT,
    @cash_payment BIT,
    @credit_payment BIT,
    @canpay_payment BIT,
    @hypur_payment BIT,
    @alleaves_pay_payment BIT,
	@gift_card_payment BIT,
    @cashless_atm_payment BIT,
	@pay_cloud_payment BIT,
	@other_payment BIT,
	@rounding_enabled BIT,
	@rounding_method VARCHAR(10),
	@rounding_unit DECIMAL(3,2),
	@scale_rounding_enabled BIT,
	@scale_rounding_method VARCHAR(10),
	@scale_rounding_unit DECIMAL(5,3),
	@enable_tiered_pricing_rounding BIT,
	@tiered_pricing_rounding VARCHAR(10),
	@donations_enabled BIT,
	@donations VARCHAR(MAX),
	@require_checkout_pin BIT,
	@require_checkout_username_password BIT = 0,
	@prevent_underage_sale BIT,
	@prevent_underage_account BIT,
	@sale_age_limit_adult SMALLINT,
	@sale_age_limit_medical SMALLINT,
	@account_age_limit_adult SMALLINT,
	@account_age_limit_medical SMALLINT,
	@use_sales_limit_2 BIT,
	@sales_limit_2_prevent_sale BIT,
	@sales_limit_2_patient_override BIT,
	@metrc_inactive_patient_override BIT,
	@sales_hours VARCHAR(MAX),
	@sales_hours_active BIT,
	@enable_scan_address BIT = 0,
	@id_user INT,
    @email_header NVARCHAR(1500),
    @email_footer NVARCHAR(1500),
    @email_subject NVARCHAR(1500),
    @email_logo VARCHAR(256),
    @email_template VARCHAR(256),
    @email_id_logo INT,
    @email_id_template INT,
	@receipt_header VARCHAR(500),
	@receipt_footer VARCHAR(500),
	@receipt_logo VARCHAR(200),
	@receipt_print_customer_name BIT,
	@receipt_print_customer_address BIT,
	@receipt_print_customer_balance BIT = 0,
	@receipt_print_cannabis_form BIT,
	@receipt_print_location_info BIT,
	@receipt_print_tax_breakdown BIT
AS

INSERT INTO [pos].[configuration] (id_location, order_auto_expire_timeframe, alleaves_pay_rounding_method, cashless_atm_rounding_method, created_by, updated_by)
SELECT id_location, 'no-expiration', '10', '10', @id_user, @id_user FROM [base].[location] WHERE id_location NOT IN (SELECT id_location FROM [pos].[configuration])

IF NOT EXISTS (SELECT id_location FROM [pos].[configuration] WHERE id_location=@id_location)
BEGIN
	INSERT INTO [pos].[configuration](
		 [id_location]
		,[order_auto_expire_timeframe]
		,[alleaves_pay_rounding_method]
		,[cashless_atm_rounding_method]
		,[auto_close]
		,[auto_print_receipt]
		,[auto_print_patient_label]
		,[cash_payment]
		,[credit_payment]
		,[canpay_payment]
		,[hypur_payment]
		,[alleaves_pay_payment]
		,[gift_card_payment]
		,[cashless_atm_payment]
		,[pay_cloud_payment]
		,[other_payment]
		,[rounding_enabled]
		,[rounding_method]
		,[rounding_unit]
		,[scale_rounding_enabled]
		,[scale_rounding_method]
		,[scale_rounding_unit]
		,[enable_tiered_pricing_rounding]
		,[tiered_pricing_rounding]
		,[donations_enabled]
		,[donations]
		,[require_checkout_pin]
		,[require_checkout_username_password]
		,[prevent_underage_sale]
		,[sale_age_limit_adult]
		,[sale_age_limit_medical]
		,[use_sales_limit_2]
		,[sales_limit_2_patient_override]
		,[sales_limit_2_prevent_sale]
		,[metrc_inactive_patient_override]
		,[sales_hours]
		,[sales_hours_active]
		,[enable_scan_address]
		,[receipt_header]
		,[receipt_footer]
		,[receipt_logo]
		,[receipt_print_customer_name]
		,[receipt_print_customer_address]
		,[receipt_print_customer_balance]
		,[receipt_print_cannabis_form]
		,[created_by]
		,[updated_by]
	)
	VALUES (
		 @id_location
		,@order_auto_expire_timeframe
		,@alleaves_pay_rounding_method
		,@cashless_atm_rounding_method
		,@auto_close
		,@auto_print_receipt
		,@auto_print_patient_label
		,@cash_payment
		,@credit_payment
		,@canpay_payment
		,@hypur_payment
		,@alleaves_pay_payment
		,@gift_card_payment
		,@cashless_atm_payment
		,@pay_cloud_payment
		,@other_payment
		,@rounding_enabled
		,@rounding_method
		,@rounding_unit
		,@scale_rounding_enabled
		,@scale_rounding_method
		,@scale_rounding_unit
		,@enable_tiered_pricing_rounding
		,@tiered_pricing_rounding
		,@donations_enabled
		,@donations
		,@require_checkout_pin
		,@require_checkout_username_password
		,@prevent_underage_sale
		,@sale_age_limit_adult
		,@sale_age_limit_medical
		,@use_sales_limit_2
		,@sales_limit_2_patient_override
		,@sales_limit_2_prevent_sale
		,@metrc_inactive_patient_override
		,@sales_hours
		,@sales_hours_active
		,@enable_scan_address
		,@receipt_header
		,@receipt_footer
		,@receipt_logo
		,@receipt_print_customer_name
		,@receipt_print_customer_address
		,@receipt_print_customer_balance
		,@receipt_print_cannabis_form
		,@id_user
		,@id_user
	)
END
ELSE
BEGIN
	UPDATE [pos].[configuration]
	SET order_auto_expire_timeframe=@order_auto_expire_timeframe,
		alleaves_pay_rounding_method=@alleaves_pay_rounding_method,
		cashless_atm_rounding_method=@cashless_atm_rounding_method,
		[auto_close]=@auto_close,
		auto_print_receipt=@auto_print_receipt, 
		auto_print_patient_label=@auto_print_patient_label,
		cash_payment=@cash_payment,
		credit_payment=@credit_payment,
		canpay_payment=@canpay_payment,
		hypur_payment=@hypur_payment,
		alleaves_pay_payment=@alleaves_pay_payment,
		gift_card_payment=@gift_card_payment,
		cashless_atm_payment=@cashless_atm_payment,
		pay_cloud_payment=@pay_cloud_payment,
		other_payment=@other_payment,
		rounding_enabled= @rounding_enabled,
		rounding_method = @rounding_method,
		rounding_unit = @rounding_unit,
		scale_rounding_enabled = @scale_rounding_enabled,
		scale_rounding_method = @scale_rounding_method,
		scale_rounding_unit = @scale_rounding_unit,
		enable_tiered_pricing_rounding = @enable_tiered_pricing_rounding,
		tiered_pricing_rounding = @tiered_pricing_rounding,
		donations_enabled=@donations_enabled, 
		donations=@donations,
		require_checkout_pin = @require_checkout_pin,
		require_checkout_username_password = @require_checkout_username_password,
		prevent_underage_sale =@prevent_underage_sale,
		sale_age_limit_adult = @sale_age_limit_adult,
		sale_age_limit_medical = @sale_age_limit_medical,
		use_sales_limit_2=@use_sales_limit_2,
		sales_limit_2_prevent_sale=@sales_limit_2_prevent_sale,
		sales_limit_2_patient_override=@sales_limit_2_patient_override,
		metrc_inactive_patient_override=@metrc_inactive_patient_override,
		sales_hours = @sales_hours,
		sales_hours_active = @sales_hours_active,
		enable_scan_address = @enable_scan_address,
		receipt_header=@receipt_header,
		receipt_footer=@receipt_footer,
		receipt_logo=@receipt_logo,
		receipt_print_customer_name=@receipt_print_customer_name,
		receipt_print_customer_address=@receipt_print_customer_address,
		receipt_print_customer_balance=@receipt_print_customer_balance,
		receipt_print_cannabis_form=@receipt_print_cannabis_form,
		receipt_print_location_info=@receipt_print_location_info,
		receipt_print_tax_breakdown=@receipt_print_tax_breakdown,
		updated_by=@id_user,
		date_updated=getutcdate()
	WHERE id_location = @id_location
END

UPDATE [pos].[configuration]
SET 
	prevent_underage_account = @prevent_underage_account,
	account_age_limit_adult = @account_age_limit_adult,
	account_age_limit_medical = @account_age_limit_medical,
	updated_by=@id_user,
	date_updated=getutcdate()




EXEC [pos].[usp_email_receipt_save] 
	@id_user = @id_user,  
	@id_location = @id_location,  
	@email_header = @email_header,  
	@email_footer = @email_footer,  
	@email_subject = @email_subject,  
	@email_logo = @email_logo,  
	@email_id_logo = @email_id_logo,  
	@email_template = @email_template,
	@email_id_template = @email_id_template

EXEC [pos].[usp_configuration_list] @id_location = @id_location
go

