CREATE PROCEDURE [base].[usp_email_update]
	@id_user INT = NULL,
	@email_update VARCHAR(256) = NULL,
	@email_confirmed BIT = 0

AS
SET NOCOUNT ON;

	IF(@email_confirmed = 1)
	BEGIN
		UPDATE [base].[user]
	    SET UserName=EmailUpdate,
			Email=EmailUpdate,
			EmailUpdate=NULL,
			EmailConfirmed=@email_confirmed
		WHERE id_user=@id_user
	END

	IF(@email_update IS NULL AND @email_confirmed = 0)
	BEGIN
		UPDATE [base].[user]
	    SET EmailUpdate=NULL,
			EmailConfirmed=1
		WHERE id_user=@id_user
	END
go

