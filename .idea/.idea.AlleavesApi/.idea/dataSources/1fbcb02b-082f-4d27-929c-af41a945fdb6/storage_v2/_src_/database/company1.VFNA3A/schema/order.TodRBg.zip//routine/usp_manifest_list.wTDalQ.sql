
CREATE PROCEDURE [order].[usp_manifest_list]
	@id_manifest INT = NULL,
	@id_order_lookup INT = NULL
AS
	SET NOCOUNT ON;

	SELECT m.id_manifest
			, m.id_order_lookup
			, ol.id_order_online
			, ol.id_checkin
			, m.origin_name
			, m.origin_address
			, m.origin_city
			, m.origin_state
			, m.origin_postal_code
			, m.stop_number
			, m.customer_name
			, m.customer_patient_number
			, m.customer_address
			, m.customer_city
			, m.customer_state
			, m.customer_postal_code
			, m.customer_phone
			, m.driver_1_name
			, m.driver_1_license
			, m.driver_2_name
			, m.driver_2_license
			, m.vehicle_make
			, m.vehicle_model
			, m.vehicle_plate
			, CONVERT(VARCHAR(32), dbo.fn_utc_to_local(m.date_updated, NULL), 120) AS last_update
			, (SELECT mi.description
						, mi.quantity
						, mi.weight
			   FROM [order].[manifest_item] mi
			   WHERE mi.id_manifest=m.id_manifest
			   FOR JSON PATH
			) AS item_list
	FROM [order].[manifest] m
	JOIN [order].order_lookup ol ON ol.id_order_lookup=m.id_order_lookup
	WHERE ISNULL(m.id_manifest, -1)=COALESCE(@id_manifest, m.id_manifest, -1) AND 
		  ISNULL(m.id_order_lookup, -1)=COALESCE(@id_order_lookup, m.id_order_lookup, -1) AND 
		  m.deleted=0
go

