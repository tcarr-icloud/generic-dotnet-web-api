CREATE PROCEDURE [process].[usp_production_create]
	@id_location INT,
	@id_item INT,
	@id_area_destination INT,
	@quantity DECIMAL(18,4),
	@id_batch INT = null,
	@bom_list VARCHAR(MAX) = '[]',
	@id_user INT,
	@cost_of_good  DECIMAL(10,2)
AS
	SET NOCOUNT ON;

	DECLARE @prod_date DATE
	DECLARE @id_production INT
	DECLARE @id_strain INT
	DECLARE @actual_weight_useable DECIMAL(18,4)

	/* IF batch is rolled into existing batch. */
	IF (@id_batch IS NOT NULL)
	BEGIN
		/* recalculate actual useable weight. */
		SET @actual_weight_useable=(
			SELECT SUM(weight_useable) / SUM(quantity) 
			FROM (
				SELECT SUM(bom.quantity * i.weight_useable) AS weight_useable
						, @quantity AS quantity
				FROM OPENJSON(@bom_list)
				WITH (
					id_batch INT,
					quantity DECIMAL(18,4)
				) bom
				JOIN inventory.batch b ON b.id_batch=bom.id_batch
				JOIN inventory.vw_item_list i ON i.id_item=b.id_item
				UNION 
				SELECT SUM(pc.quantity * i.weight_useable) AS weight_useable
						, p.quantity
				FROM process.production p
				JOIN process.production_component pc ON pc.id_production=p.id_production AND id_production_component_type=1
				JOIN inventory.batch b ON b.id_batch=pc.id_batch
				JOIN inventory.vw_item_list i ON i.id_item=b.id_item
				WHERE p.id_batch=@id_batch
				GROUP BY p.quantity, p.id_production
			) x
		)

		/* update useable weight for batch. */
		UPDATE inventory.batch
		SET actual_weight_useable_g=@actual_weight_useable
			, updated_by=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_batch=@id_batch
	END
	/* IF new batch needs to be created. */
	ELSE
	BEGIN
		/* get strain based off of highest quantity of used strains. */
		SELECT TOP 1 @id_strain=s.id_strain
		FROM OPENJSON(@bom_list)
		WITH (
			id_batch INT,
			quantity DECIMAL(18,4)
		) a
		JOIN inventory.batch b ON b.id_batch=a.id_batch
		JOIN grow.strain s ON s.id_strain=b.id_strain
		JOIN inventory.vw_item_list i ON i.id_item=b.id_item
		GROUP BY s.id_strain
		ORDER BY SUM(a.quantity * ISNULL(i.weight_useable, 0)) DESC

		/* calculate actual useable weight. */
		SET @actual_weight_useable=(
			SELECT SUM(bom.quantity * i.weight_useable) / @quantity
			FROM OPENJSON(@bom_list)
			WITH (
				id_batch INT,
				quantity DECIMAL(18,4)
			) bom
			JOIN inventory.batch b ON b.id_batch=bom.id_batch
			JOIN inventory.vw_item_list i ON i.id_item=b.id_item
		)
		IF @actual_weight_useable=0
			SET @actual_weight_useable=NULL

		/* create batch. */
		SET @prod_date = dbo.fn_utc_to_local(getutcdate(), @id_location)
		EXEC @id_batch = inventory.usp_batch_create @id_item, @id_strain, @actual_weight_useable, @cost_of_good_price = @cost_of_good
	END

	/* create production item. */
	INSERT INTO process.production (id_batch, quantity, updated_by, production_date) VALUES
		(@id_batch, @quantity, @id_user, @prod_date)

	SET @id_production=SCOPE_IDENTITY()

	/* add elog event and add production item to inventory. */
	EXEC [log].usp_event_create 'production_output', @id_batch, @id_area_destination, @quantity, NULL, @id_user


	/* open cursor for loop through bom list. */
	DECLARE @bom_id_batch INT
	DECLARE @bom_id_area INT
	DECLARE @bom_quantity DECIMAL(18,4)
	DECLARE @bom_waste DECIMAL(18,4)

	DECLARE cur CURSOR FOR 
	SELECT * FROM OPENJSON(@bom_list) 
	WITH (
		id_batch INT '$.id_batch',
		id_area INT '$.id_area',
		quantity DECIMAL(18,4) '$.quantity',
		waste DECIMAL(18,4) '$.waste'
	)

	OPEN cur

	FETCH NEXT FROM cur INTO @bom_id_batch, @bom_id_area, @bom_quantity, @bom_waste

	WHILE @@FETCH_STATUS = 0 BEGIN

		EXEC process.usp_production_add_component @id_production, @bom_id_batch, @bom_id_area, @bom_quantity, @bom_waste, @id_user

		FETCH NEXT FROM cur INTO @bom_id_batch, @bom_id_area, @bom_quantity, @bom_waste
	END

	CLOSE cur
	DEALLOCATE cur

	/* add batch history to new product. */
	EXEC inventory.usp_batch_inherit_plant_lineage @id_batch

	/* return new production. */
	SELECT p.id_production
			, p.id_batch
			, p.quantity
			, p.production_date
			, b.name AS batch
	FROM process.production p
	JOIN inventory.batch b ON b.id_batch=p.id_batch
	WHERE id_production=@id_production
go

