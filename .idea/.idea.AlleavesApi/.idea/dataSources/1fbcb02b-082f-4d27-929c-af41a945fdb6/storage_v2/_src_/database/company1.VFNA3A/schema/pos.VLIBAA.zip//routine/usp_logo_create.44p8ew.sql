CREATE PROCEDURE [pos].[usp_logo_create]
	@name VARCHAR(256),
	@path VARCHAR(256),
	@id_location INT,
	@id_user INT
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO pos.logos ([name],[path],id_location,id_user_created_by,id_user_modified_by) 
	VALUES (@name,@path,@id_location,@id_user,@id_user)
	DECLARE @id_logo INT = SCOPE_IDENTITY()
	EXEC pos.usp_logo_list @id_logo
END
go

