CREATE PROCEDURE [grow].[usp_harvest_trim_start]
	@id_harvest INT,
	@id_user INT
AS
	/* validation. */
	DECLARE @msg VARCHAR(MAX)

	IF (SELECT date_trim_end FROM grow.harvest WHERE id_harvest=@id_harvest) IS NOT NULL
	BEGIN
		SET @msg = 'Cannot start a trim for a harvest that has already been completed.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END


	IF (SELECT date_trim_start FROM grow.harvest WHERE id_harvest=@id_harvest) IS NULL
	BEGIN
		UPDATE grow.harvest
		SET date_trim_start=GETUTCDATE()
			, id_user_trim_start=@id_user
		WHERE id_harvest=@id_harvest
	END

	EXEC grow.usp_harvest_fetch @id_harvest
go

