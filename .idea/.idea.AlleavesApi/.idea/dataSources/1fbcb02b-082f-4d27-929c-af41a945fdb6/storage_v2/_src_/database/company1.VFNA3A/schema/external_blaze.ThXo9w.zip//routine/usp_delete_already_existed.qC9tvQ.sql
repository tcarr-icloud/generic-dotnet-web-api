CREATE PROCEDURE external_blaze.usp_delete_already_existed
                               @id_order int
AS
Begin
    delete from external_blaze.item where id_order=@id_order
    delete from external_blaze.[order] where id_order=@id_order
end
go

