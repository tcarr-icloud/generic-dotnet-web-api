CREATE PROCEDURE [order].[usp_manifest_upsert]
	@id_order INT,
	@id_driver1 INT,
	@id_driver2 INT,
	@id_vehicle INT,
	@id_user INT,
	@biotrack_manifest_id BIGINT = NULL
AS
	UPDATE [order].[address]
	SET id_driver1=@id_driver1
		, id_driver2=@id_driver2
		, id_vehicle=@id_vehicle
		, id_user_updated=@id_user
		, date_updated=getutcdate()
	WHERE id_order=@id_order

	UPDATE [order].[order]
	SET biotrack_manifest_id=@biotrack_manifest_id
	WHERE id_order=@id_order

	EXEC [order].usp_order_status_list @id_order
go

