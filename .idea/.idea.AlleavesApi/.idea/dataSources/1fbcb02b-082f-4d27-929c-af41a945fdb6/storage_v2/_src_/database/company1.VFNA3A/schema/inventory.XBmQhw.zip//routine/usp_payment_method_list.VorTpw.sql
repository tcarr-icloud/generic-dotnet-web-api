CREATE PROCEDURE [inventory].[usp_payment_method_list]
	@id_payment_method INT = NULL,
	@deleted BIT = 0
AS
	SELECT p.id_payment_method
	   ,p.[name] AS payment_method
	   ,p.deleted
	FROM [inventory].[payment_method] p
	WHERE p.id_payment_method=ISNULL(@id_payment_method, p.id_payment_method) AND p.deleted <= @deleted
	ORDER BY p.[name]
go

