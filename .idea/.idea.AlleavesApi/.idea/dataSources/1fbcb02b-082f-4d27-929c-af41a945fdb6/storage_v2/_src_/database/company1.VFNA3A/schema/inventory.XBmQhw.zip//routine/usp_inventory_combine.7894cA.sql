CREATE PROCEDURE [inventory].[usp_inventory_combine]
	@id_area INT,
	@id_item INT,
	@batch VARCHAR(128) = NULL,
	@quantity DECIMAL(18,4),
	@id_strain INT = NULL,
	@biotrack_barcode_id VARCHAR(256) = NULL,
	@biotrack_inventory_type_id INT = NULL,
	@inventory_list VARCHAR(MAX) = '[]',
	@date_use_by DATE = NULL,
    @date_expire DATE = NULL,
	@id_user INT
AS
	DECLARE @id_batch INT,
			@id_location INT = (SELECT TOP 1 id_location FROM inventory.area WHERE id_area=@id_area)
			
	DECLARE @metrc_item_id BIGINT = (SELECT TOP 1 metrc_item_id FROM inventory.item_location WHERE id_item=@id_item AND id_location=@id_location),
			@metrc_state VARCHAR(16) = (SELECT TOP 1 state FROM base.location WHERE id_location=@id_location)

	/* create new batch id or get default batch id if no batch is required. */
	EXEC @id_batch = inventory.usp_batch_create @id_item, @id_strain, NULL, NULL, NULL, NULL, @biotrack_barcode_id, NULL, @biotrack_barcode_id, @biotrack_inventory_type_id, @date_use_by, @date_expire
		
	/* update batch name if value is passed in. */
	IF(@batch IS NOT NULL)
		UPDATE inventory.batch SET name=@batch WHERE id_batch=@id_batch

	/* add metrc data if needed. */
	IF (@metrc_item_id IS NOT NULL)
		UPDATE inventory.batch SET metrc_package_label=@batch, metrc_item_id=@metrc_item_id, metrc_state=@metrc_state WHERE id_batch=@id_batch


	/* add parent history to batch and decrement component quantities. */
	DECLARE @id_batch_parent INT,
			@id_area_parent INT,
			@qty_parent DECIMAL(18,4)

	DECLARE cur CURSOR FOR 
	SELECT * FROM OPENJSON(@inventory_list) 
	WITH (
		id_batch INT,
		id_area INT,
		quantity DECIMAL(18,4)
	)

	OPEN cur

	FETCH NEXT FROM cur INTO @id_batch_parent, @id_area_parent, @qty_parent

	DECLARE @note VARCHAR(64) = CONCAT('BatchID: ', @id_batch)
	WHILE @@FETCH_STATUS = 0 BEGIN

		/* add batch history. */
		IF NOT EXISTS (SELECT * FROM inventory.batch_history WHERE id_batch=@id_batch AND id_batch_parent=@id_batch_parent)
			INSERT INTO inventory.batch_history (id_batch, id_batch_parent) VALUES (@id_batch, @id_batch_parent)

		/* add plant lineage history. */
		EXEC inventory.usp_batch_inherit_plant_lineage @id_batch, @id_batch_parent

		/* decrement component quantity and add event to log. */
		SET @qty_parent=-@qty_parent
		EXEC [log].usp_event_create 'inventory_combine_use', @id_batch_parent, @id_area_parent, @qty_parent, @note, @id_user

		FETCH NEXT FROM cur INTO @id_batch_parent, @id_area_parent, @qty_parent
	END

	CLOSE cur
	DEALLOCATE cur


	/* add new batch quantity to inventory and add event. */
	EXEC [log].usp_event_create 'inventory_combine_create', @id_batch, @id_area, @quantity, NULL, @id_user


	/* return newly created inventory data. */
	EXEC inventory.usp_batch_fetch @id_batch
go

