CREATE PROCEDURE [customer].[usp_customer_save] @id_customer INT
	,@name_first VARCHAR(128)
	,@name_middle VARCHAR(128)
	,@name_last VARCHAR(128)
	,@name_preferred VARCHAR(128)
	,@gender VARCHAR(32)
	,@patient_number VARCHAR(128)
	,@expiration_date DATE
	,@address1 VARCHAR(128)
	,@address2 VARCHAR(128)
	,@city VARCHAR(128)
	,@state VARCHAR(128)
	,@zip VARCHAR(128)
	,@zip_four VARCHAR(128)
	,@phone VARCHAR(128)
	,@phone2 VARCHAR(128)
	,@email VARCHAR(128)
	,@password VARCHAR(1000)
	,@date_of_birth DATE
	,@id_list VARCHAR(MAX) = '[]'
	,@id_user INT = - 1
	,@deleted BIT = 0
	,@is_banned BIT
	,@ban_reason VARCHAR(MAX)
	,@ban_expires DATE
	,@id_caregiver INT = NULL
	,@id_physician INT = NULL
	,@caregiver_license_number VARCHAR(128)
	,@id_referral_method INT
	,@id_customer_referral INT
	,@id_physician_referral INT
	,@referral_description VARCHAR(128)
	,@customer_type_list VARCHAR(MAX) = '[]'
	,@drivers_license VARCHAR(128)
	,@drivers_license_st VARCHAR(50)
	,@drivers_license_expires DATE
	,@passport VARCHAR(128)
	,@weedmaps_id VARCHAR(128) = NULL
	,@dispense_id VARCHAR(128) = NULL
	,@iheartjane_id VARCHAR(128) = NULL
	,@springbig_user_code VARCHAR(128) = NULL
	,@springbig_signature_url VARCHAR(128) = NULL
	,@referral_expiration_date DATE = NULL
	,@referral_date DATE = NULL
AS

	IF(@id_customer IS NULL)
	BEGIN
		INSERT INTO [order].customer ([caregiver_license_number], [name_first], [name_middle], [name_last], [name_preferred],  [gender], [id_physician],
		                              [id_caregiver], [id_referral_method], [id_customer_referral], [id_physician_referral],
		                              [referral_description], [patient_number], [phone], [phone2], [email], [address1],
		                              [address2], [city], [state], [zip], [zip_four], [date_of_birth], [created_by],
		                              [updated_by], [drivers_license], [drivers_license_st], [drivers_license_expires], [passport], [springbig_user_code],
		                              [springbig_signature_url],  [expiration_date], [PasswordHash], [referral_expiration_date],  [referral_date],
									  [weedmaps_id],[dispense_id],[iheartjane_id])
		VALUES(@caregiver_license_number, @name_first, @name_middle, @name_last, @name_preferred, @gender, @id_physician, @id_caregiver, @id_referral_method,
		       @id_customer_referral, @id_physician_referral, @referral_description, @patient_number, @phone, @phone2, @email, @address1,
		       @address2, @city, @state, @zip, @zip_four, @date_of_birth, @id_user, @id_user, @drivers_license, @drivers_license_st,
			   @drivers_license_expires, @passport,@springbig_user_code, @springbig_signature_url, @expiration_date, @password,
			   @referral_expiration_date, @referral_date,@weedmaps_id,@dispense_id,@iheartjane_id)
		SET @id_customer = SCOPE_IDENTITY();
	END
	ELSE
	BEGIN	
		UPDATE [order].customer
	SET name_first = @name_first
		,name_middle=@name_middle
		,name_last = @name_last
		,name_preferred = @name_preferred
		,gender = @gender
		,patient_number = @patient_number
		,expiration_date = @expiration_date
		,address1 = @address1
		,address2 = @address2
		,city = @city
		,STATE = @state
		,zip = @zip
		,zip_four = @zip_four
		,phone = @phone
		,phone2 = @phone2
		,email = @email
		,PasswordHash = @password
		,date_of_birth = @date_of_birth
		,updated_by = @id_user
		,date_updated = GETUTCDATE()
		,deleted = @deleted
		,is_banned = ISNULL(@is_banned, is_banned)
		,ban_reason = CASE WHEN @is_banned = 0 THEN NULL ELSE ISNULL(@ban_reason, ban_reason) END
		,ban_expires = ISNULL(@ban_expires, ban_expires)
		,id_physician = @id_physician
		,id_caregiver = @id_caregiver
		,caregiver_license_number = @caregiver_license_number
		,id_referral_method = @id_referral_method
		,id_customer_referral = @id_customer_referral
		,id_physician_referral = @id_physician_referral
		,referral_description = @referral_description
		,drivers_license = @drivers_license
		,drivers_license_st = @drivers_license_st
		,drivers_license_expires = @drivers_license_expires
		,passport = @passport
		,springbig_user_code = @springbig_user_code
		,springbig_signature_url = @springbig_signature_url
		,referral_expiration_date = @referral_expiration_date
		,referral_date=@referral_date
		,weedmaps_id = ISNULL(@weedmaps_id, weedmaps_id)
		,dispense_id = ISNULL(@dispense_id, dispense_id)
		,iheartjane_id = ISNULL(@iheartjane_id, iheartjane_id)
	WHERE id_customer = @id_customer;
	END


	;WITH id_list
	AS (
		SELECT @id_customer AS id_customer
			,id_identification
			,[label]
			,[value]
		FROM OPENJSON(@id_list) WITH (
				id_identification INT '$.id_identification'
				,[label] VARCHAR(128) '$.label'
				,[value] VARCHAR(128) '$.value'
				)
		)
	MERGE [order].identification AS t
	USING id_list AS s
		ON s.id_identification = t.id_identification
			AND s.id_customer = t.id_customer
	WHEN MATCHED
		AND (
			t.value <> s.value
			OR t.label <> s.label
			)
		THEN
			UPDATE
			SET t.value = s.value
				,t.label = s.label
				,t.updated_by = @id_user
				,t.date_updated = getutcdate()
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				id_customer
				,label
				,value
				,updated_by
				,created_by
				)
			VALUES (
				s.id_customer
				,s.label
				,s.value
				,@id_user
				,@id_user
				)
	WHEN NOT MATCHED BY SOURCE
		AND t.id_customer = @id_customer
		THEN
			DELETE;

	;WITH customer_type_list
	AS (
		SELECT @id_customer AS id_customer
			,id_customer_type
		FROM OPENJSON(@customer_type_list) WITH (
				id_customer_type INT '$.id_customer_type'
				)
		)
	MERGE [order].customer_type_selected AS ct
	USING customer_type_list AS tl
		ON tl.id_customer_type = ct.id_customer_type
			AND tl.id_customer = ct.id_customer
	WHEN MATCHED
		AND (ct.id_customer_type <> tl.id_customer_type)
		THEN
			UPDATE
			SET ct.id_customer_type = tl.id_customer_type
				,ct.updated_by = @id_user
				,ct.date_updated = getutcdate()
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				id_customer
				,id_customer_type
				,updated_by
				,created_by
				)
			VALUES (
				tl.id_customer
				,tl.id_customer_type
				,@id_user
				,@id_user
				)
	WHEN NOT MATCHED BY SOURCE
		AND ct.id_customer = @id_customer
		THEN
			DELETE;

	-- Toggle Caregiver
	IF (EXISTS (SELECT TOP 1 1 FROM [order].customer_type ct
				INNER JOIN (
					SELECT 
							@id_customer AS id_customer
						,id_customer_type
					FROM OPENJSON(@customer_type_list) 
					WITH (
						id_customer_type INT '$.id_customer_type'
					)
				) sel_type on sel_type.id_customer_type = ct.id_customer_type
				WHERE LOWER(ct.[name]) = 'caregiver'
			)
	)
		UPDATE [order].customer SET is_caregiver = 1 WHERE id_customer = @id_customer
	ELSE 
		UPDATE [order].customer SET is_caregiver = 0 WHERE id_customer = @id_customer

	-- Toggle Employee	
	IF (EXISTS (SELECT TOP 1 1 FROM [order].customer_type ct
				INNER JOIN (
					SELECT 
							@id_customer AS id_customer
						,id_customer_type
					FROM OPENJSON(@customer_type_list) 
					WITH (
						id_customer_type INT '$.id_customer_type'
					)
				) sel_type on sel_type.id_customer_type = ct.id_customer_type
				WHERE LOWER(ct.[name]) = 'employee'
			)
	)
		UPDATE [order].customer SET is_employee = 1 WHERE id_customer = @id_customer
	ELSE 
		UPDATE [order].customer SET is_employee = 0 WHERE id_customer = @id_customer

	SELECT @id_customer as id_customer;
go

