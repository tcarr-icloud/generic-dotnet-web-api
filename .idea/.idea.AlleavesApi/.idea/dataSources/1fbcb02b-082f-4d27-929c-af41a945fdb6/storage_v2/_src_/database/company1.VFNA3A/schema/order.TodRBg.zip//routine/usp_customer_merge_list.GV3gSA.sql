CREATE PROCEDURE [order].[usp_customer_merge_list]
    @id_customer INT = NULL,
    @id_merging_customer INT = NULL,
    @deleted_merge INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT cm.id_customer, cm.id_merging_customer
    FROM [order].customer_merge cm
    WHERE (cm.id_customer = ISNULL(@id_customer, cm.id_customer))
      AND (cm.id_merging_customer = ISNULL(@id_merging_customer, cm.id_merging_customer))
      AND (cm.deleted_merge = ISNULL(@deleted_merge, cm.deleted_merge));
END
go

