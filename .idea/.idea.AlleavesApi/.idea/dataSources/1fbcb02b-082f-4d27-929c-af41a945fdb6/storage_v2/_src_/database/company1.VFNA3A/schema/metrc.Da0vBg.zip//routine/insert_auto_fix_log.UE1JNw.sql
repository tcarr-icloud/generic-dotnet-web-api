CREATE PROCEDURE [metrc].[insert_auto_fix_log]
	@id_order INT
AS
    INSERT INTO [metrc].auto_fix_log(id_order)
    VALUES (@id_order)
go

