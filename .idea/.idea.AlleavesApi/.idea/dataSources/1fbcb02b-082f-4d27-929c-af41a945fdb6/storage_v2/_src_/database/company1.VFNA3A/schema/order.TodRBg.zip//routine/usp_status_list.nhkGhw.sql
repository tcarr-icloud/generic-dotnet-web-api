CREATE PROCEDURE [order].[usp_status_list]
AS
	SET NOCOUNT ON

	SELECT id_status
			, name AS status
	FROM [order].status
go

