CREATE PROCEDURE [inventory].[usp_transfer_cancel]
	@id_transfer INT,
	@pick_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	/* update transfer status. */
	DECLARE @id_status INT = (SELECT id_transfer_status FROM inventory.transfer_status WHERE reference='cancelled')

	INSERT INTO inventory.transfer_status_history (id_transfer, id_transfer_status, id_user_verified)
	VALUES (@id_transfer, @id_status, @id_user)

	UPDATE inventory.transfer
	SET cancelled=1
		, id_user_updated=@id_user
		, date_updated=GETUTCDATE()
	WHERE id_transfer=@id_transfer

	/* return items to inventory if transfer source is internal. */
	IF EXISTS (SELECT * FROM inventory.transfer WHERE id_transfer=@id_transfer AND id_location_source IS NOT NULL)
	BEGIN
		DROP TABLE IF EXISTS #return_list
		SELECT * INTO #return_list
		FROM (
			SELECT i.id_batch
					, ISNULL(l.id_area, i.id_area) AS id_area
					, i.quantity AS adjustment
			FROM inventory.transfer_item i
			LEFT JOIN OPENJSON(@pick_list) 
			WITH (
				id_transfer_item INT,
				id_area INT
			) l ON l.id_transfer_item=i.id_transfer_item
			WHERE i.id_transfer=@id_transfer
		) t

		DECLARE @return_list VARCHAR(MAX) = (SELECT * FROM #return_list FOR JSON PATH)

		DECLARE @note VARCHAR(64) = CONCAT('TransferID: ', @id_transfer)
		EXEC [log].usp_event_create_bulk 'transfer_manifest_remove', @note, @return_list, @id_user
	END

	/* return updated transfer. */
	EXEC inventory.usp_transfer_list @id_transfer
go

