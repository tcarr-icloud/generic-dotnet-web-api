CREATE   VIEW powerbi.powerbi_table_view
AS

SELECT ISNULL(ic.[name], 'Uncategorized') as category,
       i.item                                                as product,
       COUNT(oi.id_inventory_item)                           AS Quantity,
       avg(oi.price)                                         as [standard price],
       avg(o.total)                                          AS [Sales Total],
       COUNT(DISTINCT oi.id_order)                           AS [Number of Tickets],

       dbo.fn_utc_to_local(oi.date_created,
                           (select location.id_location from base.location where location.name = l.name))
                                                             as order_date_utc,
       l.name                                                as location,
       IIF(i.is_medicated = 1, 'Medicated', 'Non Medicated') as IsMedicated,
       i.threshold_low_quantity
FROM [order].item oi
         INNER JOIN inventory.batch b on b.id_batch = oi.id_batch
         INNER JOIN inventory.vw_item_list i on i.id_item = b.id_item
         INNER JOIN inventory.vw_category_list ic on ic.id_category = i.id_category
         INNER JOIN [order].[order] AS o ON oi.id_order = o.id_order
         LEFT OUTER JOIN [base].[location] l on l.id_location = o.id_location
GROUP BY ic.[name], i.item, oi.date_created, l.name, i.threshold_low_quantity,i.is_medicated
go

