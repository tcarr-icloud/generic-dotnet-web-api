
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [metrc].[usp_finish_package_failure_upsert]
	-- Add the parameters for the stored procedure here
	@id_batch INT,
	@fail_reason VARCHAR(MAX) = NULL,
	@remediated BIT = 0,
	@id_user INT
AS
BEGIN
	/* change values based on whether or not the order exists already. We will assume that the order does not exist
	if the order has not been remediated/is not in the process of being remediated. */
	IF (@remediated IS NULL OR @remediated = 0)
		INSERT INTO [metrc].[finish_package_failure] (id_batch, fail_reason, remediated, created_by, updated_by)
		VALUES (@id_batch, @fail_reason, 0, @id_user, @id_user)
	ELSE
		/* update the values because we have now remediated the order */
		UPDATE [metrc].[finish_package_failure]
		SET remediated = @remediated
			, updated_by = @id_user
			, date_updated = GETUTCDATE()
		WHERE id_batch=@id_batch
END
go

