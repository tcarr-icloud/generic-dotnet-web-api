CREATE PROCEDURE [inventory].[usp_uom_update]
	@id_uom INT,
	@name VARCHAR(64),
	@name_short VARCHAR(64),
	@deleted BIT = 0,
	@id_user INT,
	@id_uom_move INT = NULL
AS
	SET NOCOUNT ON

	UPDATE inventory.uom 
	SET name=@name
		, name_short=ISNULL(@name_short, @name)
		, deleted=@deleted
		, id_user_updated=@id_user
		, date_updated=getutcdate()
	WHERE id_uom=@id_uom

	IF(@deleted=1 AND @id_uom_move IS NOT NULL)
	BEGIN
		UPDATE inventory.item_group
		SET id_uom=@id_uom_move
		WHERE id_uom=@id_uom
	END

	SELECT u.id_uom
			, u.name AS uom
			, u.name_short AS uom_short
			, deleted
	FROM inventory.uom u
	WHERE u.id_uom=@id_uom
go

