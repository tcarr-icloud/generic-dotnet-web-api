CREATE PROCEDURE [dbo].[usp_get_reset_token] 
	-- Add the parameters for the stored procedure here
	@id_user INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT ResetToken, ResetTokenExpire FROM base.[user]
	WHERE id_user = @id_user
END
go

