create view powerbi.order_view_local_tz
as
select o.*,
dbo.fn_utc_to_local(o.date_created,o.id_location) as date_created_local
from [order].[order] o
go

