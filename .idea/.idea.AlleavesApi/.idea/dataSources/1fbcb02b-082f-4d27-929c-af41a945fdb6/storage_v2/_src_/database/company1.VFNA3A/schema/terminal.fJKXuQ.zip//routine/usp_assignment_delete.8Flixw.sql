CREATE PROCEDURE terminal.usp_assignment_delete
               @id_assignment INT
AS
BEGIN
  DELETE FROM terminal.assignment
  WHERE id_assignment = @id_assignment
END
go

