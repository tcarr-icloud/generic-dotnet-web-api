CREATE PROCEDURE [base].[usp_user_list]
	@id_user INT = NULL,
	@include_deleted BIT = 0
AS
	SELECT a.id_user
			, r.id_role
			, ISNULL(r.name, 'None') AS role
			, a.UserName AS username
			, a.FirstName AS name_first
			, a.LastName AS name_last
			, a.id_user_modified_by
			, CONCAT(a.FirstName, ' ', a.Lastname) AS name_full
			, a.WorkSpaceId AS workspace
			, a.PhoneNumber AS phone
			, a.accountDisabled
			, a.id_company
			, a.PIN AS pin
			, a.employee_id
			, a.internal_employee_id
			, a.birth_date
			, a.hire_date
			, a.EmailUpdate AS email_update
			, a.EmailConfirmed AS email_confirmed
			, a.employee_role
			, a.employee_department
			, a.badge_number
			, a.theme
			, ISNULL((SELECT ul.id_user_location
							, ul.id_user
							, ul.id_location
							, bl.[name] as location
							, bl.is_metrc
							, bl.is_ommu
							, bl.is_biotrack
							, ul.metrc_api_user_key
							, ul.biotrack_username
							, ul.biotrack_password
							, ul.biotrack_employee_id
							, ul.is_accessible
					  FROM [base].[user_location] ul
					  LEFT JOIN [base].[location] bl ON ul.id_location = bl.id_location
					  WHERE ul.id_user=ISNULL(@id_user, a.id_user)
					  AND bl.active = 1
					  ORDER BY bl.[name]
					  FOR JSON PATH
			), '[]') AS user_location_list
	FROM [base].[user] a
	LEFT JOIN acl.user_role ur ON ur.id_user=a.id_user
	LEFT JOIN acl.role r On r.id_role=ur.id_role
	WHERE a.id_user <> -1
	AND a.id_user=ISNULL(@id_user, a.id_user)
	AND a.deleted <= @include_deleted
go

