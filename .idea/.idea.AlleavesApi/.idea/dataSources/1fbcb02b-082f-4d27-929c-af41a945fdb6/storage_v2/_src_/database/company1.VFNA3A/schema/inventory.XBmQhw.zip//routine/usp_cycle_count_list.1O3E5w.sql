CREATE PROCEDURE [inventory].[usp_cycle_count_list]
	@id_location INT = NULL,
	@id_cycle_count INT = NULL,
    @in_progress BIT = NULL,
    @date VARCHAR(32) = NULL,
    @start_date DATETIME = NULL,
    @end_date DATETIME = NULL
AS
	SELECT id_cycle_count
		   , cycle_count.id_area
		   , cycle_count.id_user
		   , location.name AS location
		   , ar.name AS adjust_reason_name
		   , cycle_count.adjust_reason_note
		   , [user].FirstName + ' ' + [user].LastName AS user_name
		   , start_date
		   , end_date
		   , in_progress
		   , completed
		   , cancelled
		   , cycle_count.deleted
		   , isnull((SELECT cycle_count_item.*
						, ii.item
						, c.name AS category
						, ii.sku
						, b.name AS batch
					 FROM inventory.cycle_count_item
					 LEFT JOIN inventory.vw_item_list ii ON cycle_count_item.id_inventory_item=ii.id_item
					 LEFT JOIN inventory.category c ON c.id_category = ii.id_category
					 LEFT JOIN inventory.batch b ON cycle_count_item.id_batch = b.id_batch
					 WHERE cycle_count_item.id_cycle_count = cycle_count.id_cycle_count
					 FOR JSON PATH,INCLUDE_NULL_VALUES
			),'[]') AS cycle_count_items
	FROM inventory.cycle_count
	JOIN base.[user] on [user].id_user = cycle_count.id_user
	JOIN base.location on cycle_count.id_location = location.id_location
	LEFT JOIN [inventory].[adjust_reason] ar ON ar.id_adjust_reason = cycle_count.id_adjust_reason
	WHERE id_cycle_count = ISNULL(@id_cycle_count, id_cycle_count) AND
		  cycle_count.id_location = ISNULL(@id_location, cycle_count.id_location) AND
		  in_progress = ISNULL(@in_progress, in_progress) AND cycle_count.deleted<=0 OR cycle_count.deleted=NULL  AND
		  CONVERT(varchar, start_date , 23) = ISNULL(@date,CONVERT(varchar, start_date , 23)) AND
		  ((@start_date IS NULL AND @end_date IS NULL) OR (start_date >= @start_date AND end_date<=@end_date) )
	ORDER BY start_date
go

