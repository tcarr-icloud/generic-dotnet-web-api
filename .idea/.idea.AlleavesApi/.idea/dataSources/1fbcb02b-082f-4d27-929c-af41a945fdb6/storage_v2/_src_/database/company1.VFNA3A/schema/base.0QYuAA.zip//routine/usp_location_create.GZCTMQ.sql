CREATE PROCEDURE [base].[usp_location_create]
	@custom_id VARCHAR(128),
	@name VARCHAR(64),
	@legal_name VARCHAR(64) = NULL,
	@license VARCHAR(128) = NULL,
	@dea VARCHAR(128) = NULL,
	@npi VARCHAR(128) = NULL,
	@phone VARCHAR(128) = NULL,
	@address VARCHAR(128) = NULL,
	@city VARCHAR(128) = NULL,
	@state VARCHAR(128) = NULL,
	@postal_code VARCHAR(128) = NULL,
	@country VARCHAR(128) = 'US',
	@timezone VARCHAR(64) = 'US Eastern Standard Time',
	@metrc_facility_license_number VARCHAR(128) = NULL,
	@metrc_system_api_key VARCHAR(128) = NULL,
	@ommu_api_security_token VARCHAR(128) = NULL,
	@ommu_api_user_id VARCHAR(128) = NULL,
	@biotrack_license_number VARCHAR(128) = NULL,
	@biotrack_ubi VARCHAR(128) = NULL,
	@is_adult_use BIT = 0,
	@is_medical_use BIT = 0,
	@is_metrc BIT = 0,
	@is_ommu BIT = 0,
	@is_biotrack BIT = 0,
	@is_vermont_ccb BIT = 0,
	@vt_facility_license VARCHAR(64),
	@vt_client_id VARCHAR(512),
	@vt_client_secret VARCHAR(512),
	@id_user INT,
	@retail BIT = 0,
	@pickup BIT = 0,
	@delivery BIT = 0,
	@express_delivery BIT = 0,
	@delivery_zipcodes VARCHAR(MAX) = NULL,
	@tax_group_list VARCHAR(MAX) = '[]'
AS
	SET NOCOUNT ON;

	DECLARE @id_location INT

	/* create location reference based on name and company. */
	DECLARE @match VARCHAR(32)
	DECLARE @reference VARCHAR(64)
	DECLARE @id_state INT

	SET @match = '%[^a-z0-9 ]%'
	SET @reference = @name
	SET @id_state=(SELECT TOP 1 id_state FROM [base].[states] where abbreviation=@state)

	WHILE PATINDEX(@match, @reference) > 0
		SET @reference = STUFF(@reference, PATINDEX(@match, @reference), 1, '')
	SET @reference = LOWER(REPLACE(@reference, ' ', '_'))

	/* insert into database. */
	INSERT INTO base.location (custom_id, name, legal_name, reference, license, dea, npi, phone, address, city, state, postal_code, country, timezone, metrc_facility_license_number, metrc_system_api_key, ommu_api_security_token, ommu_api_user_id, biotrack_license_number, biotrack_ubi, is_adult_use, is_medical_use, is_metrc, is_ommu, is_biotrack, is_vermont_ccb, vt_facility_license, vt_client_id, vt_client_secret, created_by, updated_by, retail, pickup, delivery, express_delivery, delivery_zipcodes) VALUES
		(@custom_id, @name, @legal_name, @reference, @license, @dea, @npi, @phone, @address, @city, @state, @postal_code, @country, @timezone, @metrc_facility_license_number, @metrc_system_api_key, @ommu_api_security_token, @ommu_api_user_id, @biotrack_license_number, @biotrack_ubi, @is_adult_use, @is_medical_use, @is_metrc, @is_ommu, @is_biotrack, @is_vermont_ccb, @vt_facility_license, @vt_client_id, @vt_client_secret, @id_user, @id_user, @retail, @pickup, @delivery, @express_delivery, @delivery_zipcodes)
	SET @id_location = SCOPE_IDENTITY()

	/* insert new location taxes into database. */
	;WITH tax_list AS (
		SELECT @id_location AS id_location
			, id_tax_group
		FROM OPENJSON(@tax_group_list)
		WITH (
			  id_tax_group INT
		)
	)
	MERGE [tax].[location_group] AS tl
	USING tax_list AS taxl
	ON taxl.id_location = tl.id_location AND taxl.id_tax_group = tl.id_tax_group
	WHEN MATCHED THEN
	UPDATE SET tl.updated_by=@id_user, tl.date_updated=getutcdate(), tl.active=1
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_tax_group, id_location, active, created_by, updated_by) VALUES(taxl.id_tax_group, taxl.id_location, 1, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND tl.id_location = @id_location THEN
	UPDATE SET tl.active=0, tl.updated_by=@id_user, tl.date_updated=getutcdate()
	;

	IF NOT EXISTS (SELECT id_location FROM [pos].[configuration] WHERE id_location=@id_location)
	BEGIN
		INSERT INTO [pos].[configuration](
			[id_location],
			[order_auto_expire_timeframe],
			[alleaves_pay_rounding_method],
			[cashless_atm_rounding_method],
			[auto_close],
			[auto_print_receipt],
			[auto_print_patient_label],
			[cash_payment],
			[credit_payment],
			[canpay_payment],
			[hypur_payment],
			[alleaves_pay_payment],
			[pay_cloud_payment],
			[other_payment],
			[cashless_atm_payment],
			[gift_card_payment],
			[created_by],
			[updated_by]
		)
		VALUES (
			@id_location, 
			'no-expiration',
			'10',
			'10',
			NULL,
			0, 
			0, 
			1, 
			1, 
			1, 
			1, 
			1, 
			1, 
			1, 
			1,
			1,
			@id_user, 
			@id_user
		)
	END
		
	SELECT DISTINCT l.id_location
			, l.name AS location
			, l.legal_name
			, l.reference
			, l.license
			, l.dea
			, l.npi
			, l.address
			, l.city
			, l.state
			, sta.[name] AS full_state_name
			, l.postal_code
			, l.country
			, l.phone
			, l.timezone
			, l.retail
			, l.pickup
			, l.delivery
			, l.express_delivery
			, l.delivery_zipcodes
			, l.local_tax_percentage
			, l.active
			, l.custom_id
			, l.metrc_facility_license_number
			, l.metrc_system_api_key
			, l.ommu_api_security_token
			, l.ommu_api_user_id
			, l.biotrack_license_number
			, l.biotrack_ubi
			, l.vt_facility_license
			, l.vt_client_id
			, l.vt_client_secret
			, l.is_adult_use
			, l.is_medical_use
			, l.is_metrc
			, l.is_ommu
			, l.is_biotrack
			, l.is_vermont_ccb
			, l.active
			, retail
			, pickup
			, delivery
			, delivery_zipcodes
			, ISNULL((SELECT id_safe, [name] FROM cash.[safe] WHERE id_location = l.id_location AND deleted = 0 FOR JSON AUTO),'[]') as safe_list
			, ISNULL((
				SELECT
					bl.id_location,
					pc.order_auto_expire_timeframe,
					pc.alleaves_pay_rounding_method,
					pc.cashless_atm_rounding_method,
					pc.[auto_close],
					pc.auto_print_receipt,
					pc.auto_print_patient_label,
					pc.cash_payment,
					pc.credit_payment,
					pc.canpay_payment,
					pc.hypur_payment,
					pc.alleaves_pay_payment,
					pc.gift_card_payment,
					pc.cashless_atm_payment,
					pc.other_payment,
					pc.pay_cloud_payment,
					pc.require_checkout_pin,
					pc.require_checkout_username_password,
					pc.prevent_underage_account,
					pc.account_age_limit_adult,
					pc.account_age_limit_medical,
					pc.sale_age_limit_adult,
					pc.sale_age_limit_medical,
					pc.prevent_underage_sale,
					pc.use_sales_limit_2,
					pc.metrc_inactive_patient_override,
					pc.scale_rounding_enabled,
					pc.donations_enabled,
					pc.donations
				FROM [base].[location] bl
				LEFT JOIN [pos].[configuration] pc ON bl.id_location = pc.id_location
				WHERE bl.active=1 AND bl.id_location = pc.id_location
				FOR JSON PATH), '[]') as pos_configuration_list
			, ISNULL((
				SELECT tlg.id_tax_group,
					tg.[name]
				FROM [tax].[location_group] tlg
				LEFT JOIN [tax].[group] tg ON tg.id_tax_group = tlg.id_tax_group
				WHERE tlg.id_location =ISNULL(@id_location,l.id_location) AND tlg.active=1 AND tg.active=1
				FOR JSON PATH), '[]') as tax_group_list
	FROM base.location l
	LEFT OUTER JOIN base.[states] sta ON l.state = sta.abbreviation
	WHERE l.id_location=@id_location
go

