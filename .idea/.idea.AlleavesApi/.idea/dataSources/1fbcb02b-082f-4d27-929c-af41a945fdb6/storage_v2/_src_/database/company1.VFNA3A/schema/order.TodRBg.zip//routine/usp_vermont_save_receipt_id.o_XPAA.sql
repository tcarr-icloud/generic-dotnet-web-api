CREATE PROCEDURE [order].[usp_vermont_save_receipt_id]
	@id_order INT,
	@vermont_receipt_id VARCHAR(64)
AS
	UPDATE [order].[order] 
	SET vermont_receipt_id=@vermont_receipt_id
	WHERE id_order=@id_order
go

