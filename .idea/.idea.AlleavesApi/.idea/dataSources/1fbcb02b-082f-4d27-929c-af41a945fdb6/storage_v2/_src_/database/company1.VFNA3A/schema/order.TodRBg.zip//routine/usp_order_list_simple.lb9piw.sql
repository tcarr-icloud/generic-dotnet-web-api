CREATE PROCEDURE [order].[usp_order_list_simple] 
--DECLARE
	@paid_in_full BIT = 1,
	@void BIT = NULL,
	@date_paid DATE = NULL,
	@date_created DATE = NULL,
	@date_updated DATE = NULL,
	@id_location INT = NULL,
	@id_batch INT = NULL,
	@id_inventory_item INT = NULL,
	@metrc_package_label VARCHAR(128) = NULL
AS
	IF(@id_batch IS NULL AND @metrc_package_label IS NOT NULL)
	BEGIN
		SET @id_batch = (SELECT id_batch FROM inventory.batch WHERE metrc_package_label = @metrc_package_label)
	END

	SELECT
		 o.id_order
		,o.id_location
		,o.id_customer
		,o.id_session
		,o.[type]
		,o.subtotal
		,o.discount
		,o.apply_delivery_fee
		,o.delivery_fee
		,o.tax
		,o.[returns]
		,o.total
		,o.paid_in_full
		,o.date_paid AT TIME ZONE 'UTC' as date_paid
		,o.complete
		,o.cancel
		,o.void
		,o.verified
		,o.scheduled
		,o.packed
		,vu.FirstName + ' ' + vu.LastName as verifed_by
		,su.FirstName + ' ' + su.LastName as scheduled_by
		,pu.FirstName + ' ' + pu.LastName as packed_by
		,o.metrc_receipt_id
		,o.biotrack_receipt_id
		,o.ommu_dispensed
		,o.caregiver_purchase
		,o.id_caregiver
		,o.caregiver_name
		,o.caregiver_card_number
		,o.id_physician
		,o.physician_name
		,cu.FirstName + ' ' + cu.LastName as created_by
		,uu.FirstName + ' ' + uu.LastName as updated_by
		,o.date_created AT TIME ZONE 'UTC' as date_created
		,o.date_updated AT TIME ZONE 'UTC' date_updated
		,o.excise_tax
		,o.sales_tax
		,o.category_tax
		,o.state_tax
		,o.local_tax
		,o.void_reason
		,o.use_type
		,o.springbig_points_allocated
	FROM [order].[order] o
	LEFT OUTER JOIN [base].[location] l on o.id_location = l.id_location
	LEFT OUTER JOIN dbo.tz_lookup as tz on l.timezone = tz.tz_iana
	LEFT OUTER JOIN [base].[user] as vu on vu.id_user = o.verified_by
	LEFT OUTER JOIN [base].[user] as su on su.id_user = o.scheduled_by
	LEFT OUTER JOIN [base].[user] as pu on pu.id_user = o.packed_by
	LEFT OUTER JOIN [base].[user] as cu on cu.id_user = o.created_by
	LEFT OUTER JOIN [base].[user] as uu on uu.id_user = o.updated_by
	WHERE 
		(@date_paid IS NULL OR CAST(o.date_paid AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows as DATE) = @date_paid) AND
		(@date_created IS NULL OR CAST(o.date_created AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows as DATE) = @date_created) AND
		(@date_updated IS NULL OR CAST(o.date_updated AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows as DATE) = @date_updated) AND
		(@paid_in_full IS NULL OR o.paid_in_full = @paid_in_full) AND
		(@void IS NULL OR o.void = @void) AND
		(@id_location IS NULL OR l.id_location = @id_location) AND
		(@id_batch IS NULL OR o.id_order In (SELECT id_order FROM [order].item WHERE id_batch = @id_batch)) AND
		(@id_inventory_item IS NULL OR o.id_order In (SELECT id_order FROM [order].item WHERE id_item = @id_inventory_item))
	OPTION(RECOMPILE)
go

