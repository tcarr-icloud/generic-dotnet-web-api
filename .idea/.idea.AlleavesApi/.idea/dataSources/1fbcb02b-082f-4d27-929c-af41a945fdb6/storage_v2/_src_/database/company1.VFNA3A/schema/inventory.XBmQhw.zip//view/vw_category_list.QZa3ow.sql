CREATE VIEW [inventory].[vw_category_list]
	AS 
WITH category_path AS (
			SELECT a.id_category, a.id_parent, a.[name], a.id_delivery_route, a.[system], a.deleted, a.updated_by, a.date_updated, a.date_created, a.xero_sales_account_code, a.id_category_image, CAST(a.name AS VARCHAR(MAX)) AS path
			FROM inventory.category a
			WHERE a.id_parent IS NULL
			UNION ALL
			SELECT b.id_category, b.id_parent, b.[name], b.id_delivery_route, b.[system], b.deleted, b.updated_by, b.date_updated, b.date_created, b.xero_sales_account_code, b.id_category_image, CONCAT(p.path, ' > ', b.name) AS path
			FROM inventory.category b
			JOIN category_path p ON p.id_category=b.id_parent
		)
SELECT * FROM category_path
go

