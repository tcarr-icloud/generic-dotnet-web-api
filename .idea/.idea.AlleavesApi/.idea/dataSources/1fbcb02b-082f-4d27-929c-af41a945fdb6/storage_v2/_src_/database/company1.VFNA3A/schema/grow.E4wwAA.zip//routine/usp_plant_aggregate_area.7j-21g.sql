CREATE PROCEDURE [grow].[usp_plant_aggregate_area]
	@id_location INT,
	@id_area INT = NULL
AS
	SELECT a.id_area
			, a.path AS area_path
			, SUM(CASE WHEN p.id_plant IS NOT NULL THEN 1 ELSE 0 END) AS count_all
			, SUM(CASE WHEN p.is_mother=1 THEN 1 ELSE 0 END) AS count_mother
	FROM inventory.vw_area_list a 
	LEFT JOIN grow.plant p ON a.id_area=p.id_area AND p.harvested = 0 AND p.destroyed = 0 AND p.packaged = 0
	WHERE a.id_location=@id_location AND
		  a.id_area_type=1002 AND
			(@id_area IS NULL OR a.id_area=@id_area) AND
			a.deleted = 0
	GROUP BY a.id_area, a.path
	ORDER BY a.path
go

