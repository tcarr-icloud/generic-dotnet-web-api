CREATE PROCEDURE [metrc].[get_auto_fix_attempt_log]
    @id_location INT
AS
        WITH logGroup AS (SELECT logs.*,
                row_number() OVER (PARTITION BY logs.id_order ORDER BY logs.updated_at DESC ) AS RowNum
        FROM metrc.auto_fix_log AS logs)
        SELECT lg.*,
        (SELECT count(a.id_order) FROM logGroup AS a WHERE a.id_order = lg.id_order) AS attempts,
        vwo.id_location
        FROM logGroup AS lg
        INNER JOIN [order].vw_orders AS vwo ON vwo.id_order = lg.id_order

        WHERE RowNum = 1
        AND vwo.id_location = @id_location
go

