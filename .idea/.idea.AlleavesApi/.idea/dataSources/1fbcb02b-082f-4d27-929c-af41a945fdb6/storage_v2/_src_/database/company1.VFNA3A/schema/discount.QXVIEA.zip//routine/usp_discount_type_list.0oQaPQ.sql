CREATE PROCEDURE [discount].[usp_discount_type_list]
AS
SELECT 
	[id], 
	[name], 
	[category],
	[columnName], 
	[createdAt],
	CASE category
		WHEN 'Simple' THEN 1
		WHEN 'Bulk' THEN 2
		WHEN 'BOGO' THEN 3
		ELSE 4
	END as TypeOrder
FROM [discount].[discount_types] AS [discount_types]
WHERE 
	[discount_types].[deletedAt] IS NULL
	and [enabled] = 1
ORDER BY TypeOrder, category, [name]
go

