CREATE VIEW [inventory].[vw_current_inventory] AS (
	SELECT
		 it.id_item_group
		,it.id_item
		,c.[name] as category
		,c.[path] as category_path
		,it.item as product 
		,it.item
		,l.id_location
		,l.[name] as [location]
		,a.[name] as area
		,a.[path] as area_path
		,b.id_batch
		,a.id_area
		,atp.id_area_type
		,atp.[name] as area_type
		,b.[name] as batch
		,it.is_cannabis
		,it.is_medicated
		,it.weight_useable_g
		, ISNULL(CAST((SELECT TOP 1 CAST(trcp.[value] as decimal(10,5))
			FROM inventory.test_result_chemical_profile trcp
			LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
			WHERE icp.id_chemical_profile=2 AND trcp.id_test_result=tr.id_test_result)/ 100.0 AS DECIMAL(10, 5)), NULL) as thc
		, ISNULL(CAST((SELECT TOP 1 CAST(trcp.[value] as decimal(10,5))
			FROM inventory.test_result_chemical_profile trcp
			LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
			WHERE icp.id_chemical_profile=1 AND trcp.id_test_result=tr.id_test_result)/ 100.0 AS DECIMAL(10, 5)), NULL) 
			as cbd
		, ISNULL(CAST((SELECT TOP 1 trcp.[value]
			FROM inventory.test_result_chemical_profile trcp
			LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
			WHERE icp.id_chemical_profile = 60 AND trcp.id_test_result=tr.id_test_result) AS DECIMAL(18,5)), NULL) as thc_mg
		, ISNULL(CAST((SELECT TOP 1 trcp.[value]
			FROM inventory.test_result_chemical_profile trcp
			LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile=trcp.id_chemical_profile
			WHERE icp.id_chemical_profile = 61 AND trcp.id_test_result=tr.id_test_result) AS DECIMAL(18,5)), NULL) as cbd_mg
		,i.quantity
		,ISNULL(ord.ordered,0) as ordered
		,(CASE WHEN atp.reference='retail' THEN i.quantity ELSE 0 END) AS ready_to_sell
		,tx.quantity AS pending_transfer
		,ISNULL(ord.ordered,0) - ISNULL(ord.packed,0) AS ordered_not_packed
		,i.quantity as available
		,i.quantity + ISNULL(tx.quantity, 0) + ISNULL(ord.ordered, 0) - ISNULL(ord.paid,0) as on_hand
	FROM inventory.inventory i 
	INNER JOIN inventory.batch b on b.id_batch = i.id_batch
	LEFT JOIN inventory.test_result tr on tr.id_batch = b.id_batch
	INNER JOIN inventory.vw_area_list a on a.id_area = i.id_area
	INNER JOIN inventory.area_type atp ON atp.id_area_type=a.id_area_type
	INNER JOIN base.[location] l on l.id_location = a.id_location
	INNER JOIN inventory.vw_item_list it on b.id_item = it.id_item
	LEFT JOIN inventory.vw_category_list c on c.id_category  = it.id_category
	/* transfer items not packed yet. */
	LEFT OUTER JOIN (
		SELECT    ti.id_batch
				, ti.id_area
				, SUM(ti.quantity) AS quantity
		FROM inventory.transfer t
		JOIN inventory.transfer_item ti ON ti.id_transfer=t.id_transfer
		CROSS APPLY (SELECT TOP 1 id_transfer_status FROM inventory.transfer_status_history h WHERE h.id_transfer=t.id_transfer ORDER BY h.date_verified DESC) x 
		WHERE x.id_transfer_status = 1
		GROUP BY ti.id_batch, ti.id_area		
	) as tx ON tx.id_batch=b.id_batch AND tx.id_area=a.id_area
	/* order items not packed yet. */
	LEFT OUTER JOIN (
		SELECT oi.id_batch
				, oi.id_area
				, SUM(oi.quantity) AS ordered
				, SUM(CASE WHEN o.packed = 1 THEN oi.quantity END) as packed
				, SUM(CASE WHEN o.paid_in_full = 1 THEN oi.quantity END) as paid
		FROM [order].[order] o
		JOIN [order].item oi ON oi.id_order=o.id_order
		WHERE o.void=0 AND o.cancel = 0
		AND oi.id_inventory_item IS NOT NULL
		GROUP BY oi.id_batch, oi.id_area
	) ord ON ord.id_batch=b.id_batch AND ord.id_area=a.id_area
)
go

