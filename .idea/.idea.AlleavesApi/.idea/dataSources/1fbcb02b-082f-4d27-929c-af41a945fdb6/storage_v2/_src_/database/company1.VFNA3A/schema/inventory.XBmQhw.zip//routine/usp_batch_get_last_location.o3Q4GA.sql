CREATE PROCEDURE [inventory].[usp_batch_get_last_location]
	@id_batch INT
AS
	SELECT TOP 1 ia.id_location
	FROM [log].[event] le
	LEFT JOIN inventory.area ia ON ia.id_area = le.id_area
	WHERE le.id_batch = @id_batch
	ORDER BY le.date_created DESC
go

