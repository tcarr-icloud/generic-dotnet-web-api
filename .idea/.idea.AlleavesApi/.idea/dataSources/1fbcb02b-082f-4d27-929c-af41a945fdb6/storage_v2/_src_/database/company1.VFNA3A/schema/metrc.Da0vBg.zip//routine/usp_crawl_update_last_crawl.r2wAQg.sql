CREATE PROCEDURE [metrc].[usp_crawl_update_last_crawl]
	@id_location INT,
	@metrc_last_crawl DATETIME
AS
	UPDATE base.location
	SET metrc_last_crawl = @metrc_last_crawl
	WHERE id_location=@id_location
go

