CREATE PROCEDURE [order].usp_get_transfer_route_by_id
 @id_route INT= NULL
AS
BEGIN
	SELECT *
			 FROM [order].ride_transfer_delivery_route rtdr
			 JOIN [inventory].transfer tr ON tr.id_transfer = rtdr.id_transfer
			 JOIN [order].delivery_route dr ON dr.id_delivery_route = @id_route
			 WHERE rtdr.id_delivery_route = @id_route
END
go

