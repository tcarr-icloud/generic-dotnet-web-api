CREATE PROCEDURE [inventory].[usp_item_location_otd_list]
	@id_location INT
AS
	SET NOCOUNT ON;

	SELECT il.id_item_location,
		il.id_item,
		iig.name,
		il.id_location,
		COALESCE(il.cost_of_good, ii.cost_of_good, NULL) as cost_of_good,
		COALESCE(il.price_retail, ii.price_retail, NULL) as price_retail,
		COALESCE(il.price_retail_adult_use, ii.price_retail_adult_use, NULL) as price_retail_adult_use,
		COALESCE(il.price_retail_medical_use, ii.price_retail_medical_use, NULL) as price_retail_medical_use,
		COALESCE(il.price_otd, ii.price_otd, NULL) as price_otd,
		COALESCE(il.price_otd_adult_use, ii.price_otd_adult_use, NULL) as price_otd_adult_use,
		COALESCE(il.price_otd_medical_use, ii.price_otd_medical_use, NULL) as price_otd_medical_use,
		il.use_location_otd_price,
		iig.is_cannabis
	FROM [inventory].[item_location] il
	LEFT JOIN [inventory].[item] ii ON ii.id_item = il.id_item
	LEFT JOIN [inventory].[item_group] iig ON iig.id_item_group = ii.id_item_group
	LEFT JOIN [tax].[category] tc ON tc.id_tax_category = iig.id_tax_category AND tc.active = 1
	WHERE il.id_location = @id_location AND il.deleted = 0 AND tc.id_tax_category IS NULL
go

