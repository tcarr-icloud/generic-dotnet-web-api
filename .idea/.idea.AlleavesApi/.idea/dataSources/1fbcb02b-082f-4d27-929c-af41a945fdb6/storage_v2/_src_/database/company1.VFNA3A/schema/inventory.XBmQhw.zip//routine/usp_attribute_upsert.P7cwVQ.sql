CREATE PROCEDURE [inventory].[usp_attribute_upsert]
	@id_attribute INT = NULL,
	@name VARCHAR(512),
	@attribute_value_list VARCHAR(MAX) = '[]',
	@id_user INT,
	@deleted BIT = 0
AS
	IF EXISTS (SELECT * FROM inventory.attribute WHERE deleted=0 AND @deleted<>1 AND name=@name AND (@id_attribute IS NULL OR id_attribute <> @id_attribute))
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'An attribute with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	/* add new attribute. */
	IF (@id_attribute IS NULL) 
	BEGIN
		INSERT INTO inventory.attribute (name, id_user_created, id_user_updated) 
		VALUES (@name, @id_user, @id_user)

		SET @id_attribute=SCOPE_IDENTITY()
	END
	/* update attribute. */
	ELSE
	BEGIN
		UPDATE inventory.attribute
		SET name=@name
			, deleted=@deleted
			, id_user_updated=@id_user
			, date_updated=GETUTCDATE()
		WHERE id_attribute=@id_attribute
	END

	/* merge attribute values. */
	;WITH attribute_value_list AS (
		SELECT * FROM OPENJSON(@attribute_value_list)
		WITH (
			id_attribute_value INT,
			name VARCHAR(512)
		)
	)
	MERGE inventory.attribute_value t
	USING attribute_value_list s
	ON t.id_attribute_value=s.id_attribute_value AND t.id_attribute=@id_attribute
	WHEN MATCHED THEN
		UPDATE SET t.name=s.name, t.id_user_updated=@id_user, t.date_updated=GETUTCDATE()
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_attribute, name, id_user_created, id_user_updated) VALUES (@id_attribute, s.name, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND t.id_attribute=@id_attribute THEN 
		UPDATE SET t.deleted=1, t.id_user_updated=@id_user, t.date_updated=GETUTCDATE()
	;

	/* return updated/created attribute. */
	EXEC inventory.usp_attribute_list @id_attribute, 1
go

