
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [order].[fn_order_payment]
(	
	-- Add the parameters for the function here
	@id_order INT
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT
		 p.id_payment
		,p.method
		,p.tendered
	FROM [order].[payment] p
	WHERE p.id_order = @id_order
	AND p.deleted = 0		 
)
go

