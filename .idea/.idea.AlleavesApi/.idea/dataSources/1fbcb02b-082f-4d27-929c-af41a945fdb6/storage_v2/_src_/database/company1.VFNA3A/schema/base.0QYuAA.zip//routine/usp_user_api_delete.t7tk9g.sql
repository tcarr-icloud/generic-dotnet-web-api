CREATE PROCEDURE base.usp_user_api_delete
               @id_user INT
AS
BEGIN
  DELETE FROM base.user_api
  WHERE id_user = @id_user
  EXEC base.usp_user_api_list
END
go

