CREATE PROCEDURE [metrc].[usp_export_fetch]
	@id_export INT
AS
	SELECT e.id_export
			, e.id_location_source
			, e.id_location_destination
			, e.id_vendor_destination
			, e.biotrack_barcode_id
			, e.biotrack_barcode_pickup_id
			, e.id_driver_2
			-- source
			, l.name AS source_name
			, e.source_use_address_on_file
			, e.source_address
			, e.source_city
			, e.source_state
			, e.source_postal_code
			, e.source_facility_license
			-- recipient
			, ISNULL(ld.name, vd.name) AS destination_name
			, e.recipient
			, e.destination_use_address_on_file
			, e.destination_address
			, e.destination_city
			, e.destination_state
			, e.destination_postal_code
			, e.destination_facility_license
			-- transportation
			, e.transfer_type
			, e.id_driver
			, e.id_vehicle
			, CONCAT(u.FirstName, ' ', u.LastName) AS driver
			, COALESCE(u.badge_number, u.employee_id) AS driver_badge_number
			, d.license AS driver_license
			, v.name AS vehicle
			, v.make AS vehicle_make
			, v.model AS vehicle_model
			, v.color AS vehicle_color
			, v.license AS vehicle_license
			, e.phone
			, e.planned_route
			, e.datetime_depart
			, e.datetime_arrive
			, e.tracking_number
			, e.internal_reference
			, e.notes
			-- status/metadata
			, e.metrc_id
			, e.metrc_name
			, e.completed
			, e.cancelled
			, e.date_completed
			, CAST(e.date_completed AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as local_datetime_completed
			, e.date_cancelled
			, CAST(e.date_cancelled AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as local_datetime_cancelled
			, e.date_created
			, CAST(e.date_created AT TIME ZONE 'UTC' AT TIME ZONE tl.[tz_windows] as datetime) as local_datetime_created
			-- batch list (distinct list of package labels)
			, ISNULL((SELECT ei.id_batch
							, g.id_item_group
							, ei.price
							, i.id_item
							, RTRIM(CONCAT(g.name, ' ', (
								SELECT STRING_AGG(av.name, ' ') 
								FROM inventory.item_attribute_value iav
								LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
								WHERE iav.id_item=i.id_item)
							)) AS item
							, b.name AS batch
							, b.metrc_package_label
							, SUM(ei.quantity) AS quantity
							, u.name AS uom
							, b.biotrack_barcode_id
							, i.price_retail_adult_use
							, i.price_retail_medical_use
							, ei.[stop]
					  FROM metrc.export_item ei
					  JOIN inventory.batch b ON b.id_batch=ei.id_batch
					  JOIN inventory.vw_area_list a ON a.id_area=ei.id_area
					  JOIN inventory.item i ON i.id_item=b.id_item
					  JOIN inventory.item_group g ON g.id_item_group=i.id_item_group
					  JOIN inventory.uom u ON u.id_uom=g.id_uom
					  WHERE ei.id_export=e.id_export
					  GROUP BY ei.id_batch, g.id_item_group, i.id_item, b.name, b.metrc_package_label, g.name, u.name, b.biotrack_barcode_id, i.price_retail_adult_use, i.price_retail_medical_use, ei.[stop], ei.price
					  FOR JSON PATH
			), '[]') AS batch_list
			-- item list (batches with area and quantity)
			, ISNULL((SELECT ei.id_batch
							, ei.id_area
							, RTRIM(CONCAT(g.name, ' ', (
								SELECT STRING_AGG(av.name, ' ') 
								FROM inventory.item_attribute_value iav
								LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
								WHERE iav.id_item=i.id_item)
							)) AS item
							, b.name AS batch
							, b.metrc_package_label
							, a.name AS area
							, a.path AS area_path
							, ei.quantity
							, u.name AS uom
							, ei.[stop]
					  FROM metrc.export_item ei
					  JOIN inventory.batch b ON b.id_batch=ei.id_batch
					  JOIN inventory.vw_area_list a ON a.id_area=ei.id_area
					  JOIN inventory.item i ON i.id_item=b.id_item
					  JOIN inventory.item_group g ON g.id_item_group=i.id_item_group
					  JOIN inventory.uom u ON u.id_uom=g.id_uom
					  WHERE ei.id_export=e.id_export
					  FOR JSON PATH
			), '[]') AS item_list
				, ISNULL((SELECT *
					  FROM metrc.stops st
					  WHERE st.id_export=e.id_export
					  FOR JSON PATH
			), '[]') AS stops
	FROM metrc.export e
	JOIN base.location l ON l.id_location=e.id_location_source
	LEFT JOIN base.location ld ON ld.id_location=e.id_location_destination
	LEFT JOIN inventory.vendor vd ON vd.id_vendor=e.id_vendor_destination
	JOIN [order].driver d ON d.id_driver=e.id_driver
	JOIN base.[user] u ON u.id_user=d.id_user
	JOIN [order].vehicle v ON v.id_vehicle=e.id_vehicle
	LEFT OUTER JOIN [dbo].[tz_lookup] as tl ON l.[timezone] = tl.[tz_iana]
	WHERE e.id_export = @id_export
go

