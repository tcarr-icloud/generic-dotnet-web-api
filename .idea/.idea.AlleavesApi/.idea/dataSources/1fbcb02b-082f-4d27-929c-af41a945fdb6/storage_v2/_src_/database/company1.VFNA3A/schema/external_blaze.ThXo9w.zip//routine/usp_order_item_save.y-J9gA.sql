CREATE PROCEDURE [external_blaze].[usp_order_item_save]
	@items VARCHAR(max) ,
	@id_order INT
AS
	SET NOCOUNT ON

	DECLARE @items_t TABLE (id INT PRIMARY KEY IDENTITY(1,1), [id_item] INT,[id_order] INT,[id_batch] INT,
	item_name VARCHAR(200),item_category VARCHAR(200),[quantity] DECIMAL(18,4),[reg_price] DECIMAL(18,4),
	[sale_price] DECIMAL(18,4),[id_blaze_item] VARCHAR(200),item_index INT)

	INSERT INTO @items_t
	SELECT
		  id_item
		, @id_order
		, id_batch
	    , item_name
	    , item_category
	    , quantity
	    , reg_price
	    , sale_price
	    , id_blaze_item
		, ROW_NUMBER() OVER(ORDER BY id_item) as item_index
	FROM OPENJSON(@items)
	WITH (
		id_item INT '$.id_item',
		id_batch INT '$.id_inventory_item',
		quantity DECIMAL(18,4) '$.quantity',
	    reg_price DECIMAL(18,4) '$.reg_price',
	    sale_price DECIMAL(18,4) '$.sale_price',
	    item_name VARCHAR(200) '$.item_name',
	    item_category VARCHAR(200) '$.item_category',
	    id_blaze_item VARCHAR(200) '$.id_blaze_item'
	)

	DECLARE @item_index INT = (SELECT MIN(item_index) FROM @items_t WHERE id_item IS NULL)

	/* Insert new items so we can capture PK */
	WHILE(EXISTS (SELECT * FROM @items_t WHERE item_index = @item_index))
	BEGIN
		INSERT INTO [external_blaze].item (id_order,id_batch,item_name,item_category,quantity,reg_price,sale_price,id_blaze_item)
		SELECT @id_order,id_batch,item_name,item_category,quantity,reg_price,sale_price,id_blaze_item FROM @items_t WHERE item_index = @item_index

	    DECLARE @id_item INT = SCOPE_IDENTITY();

		UPDATE @items_t
		SET id_item = @id_item
		WHERE item_index = @item_index
		SET @item_index = (SELECT MIN(item_index) FROM @items_t WHERE id_item IS NULL AND item_index > @item_index)

	END
go

