CREATE    procedure [dbo].[usp_get_location_fcm_tokens] @id_location int
AS
  SET NOCOUNT ON;

    select isnull(fcm_tokens,'[]')  as fcm_tokens ,id_user from base.[user]
    where id_user in (select id_user from base.user_location where id_location = @id_location)
go

