CREATE PROCEDURE [vt].[usp_record_failure]
	@id_location INT,
	@method VARCHAR(8),
	@endpoint VARCHAR(255),
	@payload VARCHAR(MAX),
	@message VARCHAR(MAX)
AS
	INSERT INTO vt.failure_log (id_location, method, endpoint, payload, message)
	VALUES (@id_location, @method, @endpoint, @payload, @message)
go

