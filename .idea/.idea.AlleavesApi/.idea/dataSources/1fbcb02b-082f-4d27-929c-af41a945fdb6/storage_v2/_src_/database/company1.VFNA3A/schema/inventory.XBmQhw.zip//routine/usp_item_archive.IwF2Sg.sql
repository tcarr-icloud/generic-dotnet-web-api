CREATE PROCEDURE [inventory].[usp_item_archive]
	@id_item_group INT = NULL,
	@id_item INT = NULL,
	@deleted BIT = 1,
	@id_user INT
AS
	IF (@id_item_group IS NULL)
		SET @id_item_group = (SELECT TOP 1 id_item_group FROM inventory.item WHERE id_item=@id_item)

	UPDATE inventory.item_group
	SET deleted = @deleted
		, id_user_updated = @id_user
		, date_updated = GETUTCDATE()
	WHERE id_item_group = @id_item_group

	EXEC inventory.usp_item_fetch @id_item_group
go

