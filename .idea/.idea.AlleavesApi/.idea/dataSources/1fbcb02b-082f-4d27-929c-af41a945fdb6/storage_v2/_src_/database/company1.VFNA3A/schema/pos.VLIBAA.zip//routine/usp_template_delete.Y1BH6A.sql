CREATE PROCEDURE [pos].[usp_template_delete]
	@id_template INT
AS
	DELETE FROM pos.templates WHERE id_template = @id_template
go

