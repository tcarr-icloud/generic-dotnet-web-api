CREATE PROCEDURE [biotrack].[usp_fl_dispensation_route_list]
	@id_inventory_type INT = NULL
AS

SELECT fdr.*,
	it.[name] AS biotrack_inventory_type_name,
	orf.[name] AS ommu_order_form_name
FROM [biotrack].[fl_dispensation_route] fdr
LEFT JOIN [biotrack].[inventory_type] it ON it.id_inventory_type = fdr.id_inventory_type
LEFT JOIN [biotrack].[order_form] orf ON orf.id_form = fdr.id_form
WHERE @id_inventory_type IS NULL OR fdr.id_inventory_type=@id_inventory_type
ORDER BY fdr.id_inventory_type
go

