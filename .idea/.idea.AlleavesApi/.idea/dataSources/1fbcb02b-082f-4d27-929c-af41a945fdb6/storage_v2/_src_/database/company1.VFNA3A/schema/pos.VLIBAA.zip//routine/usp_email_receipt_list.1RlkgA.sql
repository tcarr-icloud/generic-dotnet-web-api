CREATE PROCEDURE [pos].[usp_email_receipt_list]
	@id_email_receipt INT = NULL
AS
BEGIN
	SET NOCOUNT ON;
	SELECT 
		id_location,
		email_header,
		email_footer,
		email_subject,
		email_logo,
		email_template,
		id_user_created_by
	FROM pos.email_receipt 
	WHERE (@id_email_receipt IS NULL OR id_email_receipt = @id_email_receipt)
END
go

