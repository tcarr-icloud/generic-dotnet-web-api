CREATE PROCEDURE [metrc].[usp_queued_adjustment_list]
	@id_location INT = NULL,
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
		SELECT qua.id_adjustment
				, qua.id_batch
				, ib.name AS batch_name
				, ib.metrc_package_label
				, ig.name AS item_name
				, qua.id_area
				, qua.original_quantity
				, qua.adjustment
				, (qua.original_quantity + qua.adjustment) AS new_quantity
				, ia.name AS area_name
				, bl.id_location
				, bl.name AS location
				, bl.metrc_facility_license_number
				, qua.id_uom
				, iu.name AS uom
				, qua.id_adjust_reason
				, iar.name AS adjust_reason_name
				, qua.notes AS adjust_reason_notes
				, qua.sent_to_metrc
				, qua.ignored
				, qua.id_log_event
				, qua.created_by
				, CONCAT(u.FirstName, '' '', u.LastName) AS user_created
				, qua.updated_by
				, CONCAT(uu.FirstName, '' '', uu.LastName) AS user_updated
				, qua.date_created
				, CAST(qua.date_created AT TIME ZONE ''UTC'' AT TIME ZONE tl.[tz_windows] as datetime) AS local_datetime_created
				, qua.date_updated
				, CAST(qua.date_updated AT TIME ZONE ''UTC'' AT TIME ZONE tl.[tz_windows] as datetime) AS local_datetime_updated
		FROM metrc.queued_adjustment qua
		LEFT JOIN [inventory].[uom] iu ON iu.id_uom = qua.id_uom
		LEFT JOIN [inventory].[batch] ib ON ib.id_batch = qua.id_batch
		LEFT JOIN [inventory].[item] ii ON ii.id_item = ib.id_item
		LEFT JOIN [inventory].[item_group] ig ON ig.id_item_group = ii.id_item_group
		LEFT JOIN [inventory].[area] ia ON ia.id_area = qua.id_area
		LEFT JOIN [inventory].[adjust_reason] iar ON iar.id_adjust_reason = qua.id_adjust_reason
		LEFT JOIN [base].[location] bl ON bl.id_location = ia.id_location
		LEFT JOIN [base].[user] u ON u.id_user = qua.created_by
		LEFT JOIN [base].[user] uu ON uu.id_user = qua.updated_by
		LEFT JOIN [dbo].[tz_lookup] as tl ON bl.[timezone] = tl.[tz_iana]
	) metrc_logs'

	SET @where = 'WHERE sent_to_metrc <> 1 AND ignored <> 1 AND id_location = '+ ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location')

	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'date_created DESC')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

