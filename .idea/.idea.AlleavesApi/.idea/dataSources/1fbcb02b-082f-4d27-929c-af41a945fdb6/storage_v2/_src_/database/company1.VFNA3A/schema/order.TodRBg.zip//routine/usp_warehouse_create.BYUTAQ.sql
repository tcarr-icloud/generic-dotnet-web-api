Create PROCEDURE [order].[usp_warehouse_create] 
	@name varchar(max) = null,
	@longitude varchar(max) =null,
	@latitude varchar(max)= null,
	@address varchar(max)= null
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [order].[warehouse] (name, address, longitude, latitude)
	values(@name, @address, @longitude, @latitude)
	
	DECLARE @id_warehouse INT = scope_identity()
	
	EXEC [order].usp_warehouse_list @id_warehouse
END
go

