CREATE PROCEDURE [inventory].[usp_batch_save]
	@id_batch INT,
	@id_item INT = NULL,
	@name VARCHAR(64) = NULL,
	--TODO Remove @allow_duplicate_name after all COA migration is complete for all clients
	@allow_duplicate_name BIT = 0,
	-- general
	@id_status INT,
	@qc_hold BIT = 0,
	@cost_of_good DECIMAL(16,4),
	@date_closed DATE = NULL,
	@date_harvest DATE = NULL,
	@date_production DATE = NULL,
	@date_expire DATE = NULL,
	@date_use_by DATE = NULL,
	@date_packed DATE = NULL,
	@harvest_batch VARCHAR(512) = NULL,
	@initial_quantity DECIMAL(18,4) = NULL,
	@vendor_batch_id VARCHAR(128) = NULL,
	@external_id VARCHAR(128) = NULL,
	@biotrack_scheduled_destroyed BIT = NULL,
	@biotrack_destroyed BIT = NULL,
	-- cannabis
	@id_strain INT = NULL,
	@cultivator VARCHAR(256) = NULL,
	@cultivator_license VARCHAR(256) = NULL,
	@manufactured_by VARCHAR(256) = NULL,
	@packager VARCHAR(256) = NULL,
	@thc DECIMAL(7,5) = NULL,
	@cbd DECIMAL(7,5) = NULL,
	@thc_mg DECIMAL(18, 3) = NULL,
	@cbd_mg DECIMAL(18, 3) = NULL,
	@coa_s3_key VARCHAR(256) = NULL,
	@test_name  VARCHAR(256) = NULL,
	@test_lab VARCHAR(256) = NULL,
	@test_batch VARCHAR(256) = NULL,
	@test_date VARCHAR(256) = NULL,
	@chemical_profile_list VARCHAR(MAX) = '[]',
	@extraction_method  VARCHAR(256) = NULL,
	@solvent_type  VARCHAR(256) = NULL,
	@activation_time VARCHAR(128) = NULL,
	-- metrc
	@metrc_package_label VARCHAR(128) = NULL,
	@id_uom_metrc INT = NULL,
	@metrc_finished BIT = 0,
	@id_user INT = -1
AS
	DECLARE @id_status_orig INT = (SELECT TOP 1 id_status FROM inventory.batch WHERE id_batch=@id_batch)
	DECLARE @qc_hold_orig BIT = (SELECT TOP 1 qc_hold FROM inventory.batch WHERE id_batch=@id_batch)

	DECLARE @msg VARCHAR(MAX)

	/* throw error if creating duplicate batch name. */
	IF @allow_duplicate_name = 0 AND EXISTS (SELECT * FROM inventory.batch WHERE (@name IS NOT NULL AND name=@name) AND ((@id_batch IS NOT NULL AND @id_batch<>id_batch) OR @id_batch IS NULL))
	BEGIN
		SET @msg = 'Batch name already exists'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	/* create new batch. */
	IF(@id_batch IS NULL)
	BEGIN
		/* throw error if no item id is supplied. */
		IF (@id_item IS NULL)
		BEGIN
			SET @msg = 'Must supply a valid item ID if creating a new batch'
			RAISERROR(@msg, 11, 1)
			RETURN
		END

		DECLARE @id_location INT = (SELECT TOP 1 ig.id_location 
									FROM inventory.item_group ig
									JOIN inventory.item i ON i.id_item_group=ig.id_item_group
									WHERE i.id_item=@id_item)
		DECLARE @batch VARCHAR(128) = inventory.fn_generate_batch_num(@id_item, @id_location)

		/* return existing batch if trying to create batch from non-batch tracked item. */
		IF(@batch IS NULL) AND EXISTS (SELECT * FROM inventory.batch WHERE id_item=@id_item)
		BEGIN
			SET @id_batch = (SELECT TOP 1 id_batch FROM inventory.batch WHERE id_item=@id_item)
			EXEC inventory.usp_batch_fetch @id_batch
			RETURN
		END

		INSERT INTO [inventory].[batch]
           ([id_item]
           ,[id_status]
           ,[id_strain]
           ,[name]
           ,[initial_quantity]
		   ,[cost_of_good]
           ,[date_closed]
           ,[date_harvest]
           ,[date_production]
           ,[date_expire]
		   ,[date_use_by]
		   ,[date_packed]
		   ,[harvest_batch]
           ,[cultivator]
           ,[cultivator_license]
		   ,[manufactured_by]
           ,[packager]
           ,[metrc_package_label]
           ,[metrc_finished]
           ,[id_uom_metrc]
		   ,[vendor_batch_id]
           ,[external_id]
           ,[created_by]
           ,[updated_by]
		   ,[extraction_method]
		   ,[solvent_type]
		   ,[activation_time]
		   ,[biotrack_scheduled_destroyed]
		   ,[biotrack_destroyed]
		   )
		 VALUES (
			@id_item,
			ISNULL(@id_status, 1),
			@id_strain,
			@batch,
			ISNULL(@initial_quantity, 0),
			@cost_of_good,
			@date_closed,
			@date_harvest,
			ISNULL(@date_production, getutcdate()),
			@date_expire,
			@date_use_by,
			@date_packed,
			@harvest_batch,
			@cultivator,
			@cultivator_license,
			@manufactured_by,
			@packager,
			@metrc_package_label,
			@metrc_finished,
			@id_uom_metrc,
			@vendor_batch_id,
			@external_id,
			@id_user,
			@id_user,
			@extraction_method,
			@solvent_type,
			@activation_time,
			@biotrack_scheduled_destroyed,
			@biotrack_destroyed
		 )

		 SET @id_batch = SCOPE_IDENTITY()
	END
	/* update batch information. */
	ELSE
	BEGIN
		UPDATE inventory.batch 
		SET id_strain=ISNULL(@id_strain, id_strain)
			, id_status=@id_status
			, qc_hold=ISNULL(@qc_hold, qc_hold)
			, cost_of_good=@cost_of_good
			, metrc_package_label=ISNULL(@metrc_package_label, metrc_package_label)
			, id_uom_metrc=ISNULL(@id_uom_metrc, id_uom_metrc)
			, metrc_finished=@metrc_finished
			, cultivator=ISNULL(@cultivator, cultivator)
			, cultivator_license=ISNULL(@cultivator_license, cultivator_license)
			, manufactured_by=ISNULL(@manufactured_by, manufactured_by)
			, packager=ISNULL(@packager, packager)
			, date_harvest=ISNULL(@date_harvest, date_harvest)
			, date_production=ISNULL(@date_production, date_production)
			, date_expire=ISNULL(@date_expire, date_expire)
			, date_use_by=ISNULL(@date_use_by, date_use_by)
			, date_packed=ISNULL(@date_packed, date_packed)
			, vendor_batch_id=@vendor_batch_id
			, harvest_batch=@harvest_batch
			, date_closed=ISNULL(@date_closed, date_closed)
			, updated_by=@id_user
			, date_updated=getutcdate()
			, extraction_method=ISNULL(@extraction_method, extraction_method)
			, solvent_type=ISNULL(@solvent_type, solvent_type)
			, activation_time=ISNULL(@activation_time, activation_time)
			, biotrack_scheduled_destroyed=ISNULL(@biotrack_scheduled_destroyed, biotrack_scheduled_destroyed)
			, biotrack_destroyed=ISNULL(@biotrack_destroyed, biotrack_destroyed)
			,name = ISNULL(@name, name)
		WHERE id_batch=@id_batch
	END

	/* add events for status/qc hold changes. */
	DECLARE @id_area INT = (SELECT TOP 1 id_area FROM inventory.inventory WHERE id_batch=@id_batch ORDER BY quantity DESC)
	IF (@id_area IS NOT NULL)
	BEGIN
		DECLARE @notes VARCHAR(256)
		/* status change event. */
		IF (@id_status_orig IS NOT NULL AND @id_status_orig<>@id_status)
		BEGIN
			SET @notes = 'Status: ' + (CASE WHEN @id_status = 1 THEN 'Open' WHEN @id_status=2 THEN 'QC Hold' WHEN @id_status=3 THEN 'Closed' ELSE 'N/A' END)
			EXEC [log].usp_event_create 'batch_status', @id_batch, @id_area, 0, @notes, @id_user
		END
		/* qc hold change event. */
		IF (@qc_hold_orig IS NOT NULL AND @qc_hold_orig<>@qc_hold)
		BEGIN
			SET @notes = 'QC Hold: ' + (CASE WHEN @qc_hold = 1 THEN 'True' ELSE 'False' END)
			EXEC [log].usp_event_create 'batch_status', @id_batch, @id_area, 0, @notes, @id_user
		END
	END

	;WITH batch_data AS (
		SELECT @id_batch AS id_batch
			, @thc AS thc
			, @cbd AS cbd
			, @thc_mg AS thc_mg
			, @cbd_mg AS cbd_mg
			, @coa_s3_key AS coa_s3_key
			, @test_name AS test_name
			, @test_lab AS test_lab
			, @test_batch AS test_batch
			, @test_date AS test_date
	)
	MERGE inventory.test_result t
	USING batch_data s
	ON t.id_batch=s.id_batch
	WHEN MATCHED THEN 
		UPDATE SET t.thc=s.thc, t.cbd=s.cbd, t.thc_mg=s.thc_mg, t.cbd_mg=s.cbd_mg, t.coa_s3_key=s.coa_s3_key,  t.test_name=s.test_name, t.test_lab=s.test_lab, t.test_batch=s.test_batch, t.test_date=s.test_date, t.date_updated=getutcdate(), t.updated_by=@id_user
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_batch, thc, cbd, thc_mg, cbd_mg, coa_s3_key, test_name,  test_lab, test_batch, test_date, created_by, updated_by, date_updated, date_created) VALUES
			   (s.id_batch, s.thc, s.cbd, s.thc_mg, s.cbd_mg, s.coa_s3_key, s.test_name, s.test_lab, s.test_batch, s.test_date, @id_user, @id_user, getutcdate(), getutcdate())
	;

	DECLARE @id_test_result INT = (SELECT id_test_result FROM inventory.test_result WHERE id_batch=@id_batch)

IF (@id_test_result IS NOT NULL)
BEGIN
    ;WITH chemical_profile AS (
        SELECT 
            cp.id_chemical_profile
            , cp.name AS chemical_profile_name
            , @id_test_result AS id_test_result
            , oj.[value]
            , ROW_NUMBER() OVER(PARTITION BY cp.name ORDER BY (SELECT NULL)) as rownum
        FROM OPENJSON(@chemical_profile_list)
        WITH (
            id_test_result_chemical_profile INT
            , id_chemical_profile INT
            , [value] VARCHAR(512)
        ) AS oj
        JOIN inventory.chemical_profile cp ON cp.id_chemical_profile = oj.id_chemical_profile
    )
    MERGE inventory.test_result_chemical_profile b
    USING (SELECT * FROM chemical_profile WHERE rownum = 1) c
    ON (b.id_chemical_profile=c.id_chemical_profile AND b.id_test_result = c.id_test_result)
    WHEN MATCHED AND (b.[value]<>c.[value]) THEN 
        UPDATE SET b.[value]=c.[value], b.date_updated=getutcdate(), b.id_user_updated=@id_user
    WHEN NOT MATCHED BY TARGET AND NOT EXISTS (
        SELECT 1 
        FROM inventory.test_result_chemical_profile trcp
        INNER JOIN inventory.chemical_profile cp ON trcp.id_chemical_profile = cp.id_chemical_profile
        WHERE cp.name = c.chemical_profile_name AND trcp.id_test_result = @id_test_result
    ) THEN
        INSERT (id_chemical_profile, id_test_result, [value], id_user_created, id_user_updated, date_updated, date_created) 
        VALUES (c.id_chemical_profile, c.id_test_result, c.[value], @id_user, @id_user, getutcdate(), getutcdate())
    WHEN NOT MATCHED BY SOURCE AND b.id_test_result=@id_test_result THEN DELETE
    ;
END

-- After everything, remove any duplicates that still exist
SELECT
    trcp.id_test_result_chemical_profile,
    ROW_NUMBER() OVER(PARTITION BY trcp.id_test_result, cp.name ORDER BY trcp.id_test_result) AS RowNumber
INTO #Duplicates
FROM
    inventory.test_result_chemical_profile trcp
JOIN 
    inventory.chemical_profile cp ON trcp.id_chemical_profile = cp.id_chemical_profile
WHERE
    trcp.id_test_result = @id_test_result;

DELETE FROM inventory.test_result_chemical_profile
WHERE id_test_result_chemical_profile IN (
    SELECT id_test_result_chemical_profile FROM #Duplicates WHERE RowNumber > 1
);

DROP TABLE #Duplicates;
	/* return updated batch data. */
	EXEC inventory.usp_batch_fetch @id_batch
go

