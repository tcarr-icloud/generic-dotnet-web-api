CREATE PROCEDURE [order].[usp_referral_method_list]
	@id_referral_method INT = NULL,
	@deleted BIT = 0

AS
	--DECLARE @id_referral_method INT = NULL
	SELECT  
	      r.id_referral_method
		, r.[name] AS referral_method
	FROM [order].referral_method r
	WHERE r.id_referral_method = ISNULL(@id_referral_method, r.id_referral_method) AND r.deleted <= @deleted
	ORDER BY r.[name]
go

