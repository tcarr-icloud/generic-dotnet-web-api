CREATE PROCEDURE [inventory].[usp_cycle_count_update]
	@id_cycle_count INT,
	@list VARCHAR(MAX),
	@end_date DATETIME,
	@in_progress BIT,
	@completed BIT,
	@deleted BIT
AS
BEGIN
	-- Update cycle count
	UPDATE inventory.cycle_count
	SET end_date = @end_date,
		in_progress = @in_progress,
		completed = @completed,
		deleted=@deleted
	WHERE id_cycle_count = @id_cycle_count;

	-- Insert the list data into a temporary table as other variables are out of scope
	DECLARE @tempList TABLE (
		id_item INT,
		id_area INT,
		id_inventory_item INT,
		id_batch INT,
		expected_count DECIMAL(18,4),
		actual_count DECIMAL(18,4)
	)

	INSERT INTO @tempList (id_item, id_area, id_inventory_item, id_batch, expected_count, actual_count)
	SELECT id_item, id_area, id_inventory_item, id_batch, expected_count, actual_count
	FROM OPENJSON(@list)
	WITH (
		id_item INT,
		id_area INT,
		id_inventory_item INT,
		id_batch INT,
		expected_count DECIMAL(18,4),
		actual_count DECIMAL(18,4)
	);

	-- Update cycle count items
	MERGE inventory.cycle_count_item AS target
	USING (
		SELECT @id_cycle_count AS id_cycle_count,
			id_item,
			id_area,
			id_inventory_item,
			id_batch,
			expected_count,
			actual_count
		FROM @tempList
		WHERE @id_cycle_count IS NOT NULL
	) AS source ON target.id_cycle_count = source.id_cycle_count
				  AND target.id_inventory_item = source.id_inventory_item
				  AND target.id_batch = source.id_batch
				  AND target.id_area = source.id_area
				  AND target.id_item = source.id_item
	WHEN MATCHED THEN
		UPDATE SET target.expected_count = source.expected_count,
				   target.actual_count = source.actual_count;
		SELECT @id_cycle_count AS id_cycle_count
END
go

