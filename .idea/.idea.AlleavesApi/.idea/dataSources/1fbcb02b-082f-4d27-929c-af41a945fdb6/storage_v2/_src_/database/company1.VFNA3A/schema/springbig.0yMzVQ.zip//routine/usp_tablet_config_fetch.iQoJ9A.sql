CREATE PROCEDURE [springbig].[usp_tablet_config_fetch]
AS
    SET NOCOUNT ON;
    SELECT
         [id_client_config]
        ,[logo_path]
        ,[header_message]
        ,[privacy_policy]
        ,[program_name]
        ,[opt_in_text]
    FROM [springbig].[tablet_config]
go

