CREATE PROCEDURE [loyalty].[usp_get_config]	
AS
	IF NOT EXISTS (SELECT 1 FROM loyalty.config)
	BEGIN
		INSERT INTO loyalty.config (springbig_active, alpineiq_active)
		SELECT 0,0
	END
	
	SELECT 
		springbig_active	as	[springbig_active],
		alpineiq_active		as	[alpineiq_active]
	FROM loyalty.config
go

