CREATE PROCEDURE [metrc].[usp_transfer_import_fetch]
	@id_transfer_import INT,
	@id_transfer INT = NULL
AS
	SELECT im.id_transfer_import
			, t.id_transfer
			, i.id_item
			, b.id_batch
			, l.name AS location
			, im.date_created AS date_accepted
			, CONCAT(u.FirstName, ' ', u.LastName) AS accepted_by
			, t.manifest_number
			, t.vendor
			, ti.excise
			, ti.cost
			, CASE WHEN i.price_retail IS NOT NULL THEN ti.quantity * i.price_retail 
				   WHEN i.price_retail_adult_use IS NOT NULL THEN ti.quantity * i.price_retail_adult_use
				   WHEN i.price_retail_medical_use IS NOT NULL THEN ti.quantity * i.price_retail_medical_use
				   ELSE NULL END AS retail_value
			, ti.quantity
			, ti.uom
			, ti.package_label
			, ti.vendor_batch_id
			, ti.item
			, ti.is_new_item
	        , ig.id_category
	        , c.category_parent
			, c.category_child
	FROM metrc.transfer_import im
	JOIN metrc.transfer_item ti ON ti.id_transfer_import=im.id_transfer_import
	JOIN metrc.transfer t ON t.id_transfer=ti.id_transfer
	JOIN base.[user] u ON u.id_user=im.id_user_created
	JOIN base.location l ON l.id_location=t.id_location
	LEFT JOIN inventory.batch b ON b.id_batch=ti.id_batch
	LEFT JOIN inventory.item i ON i.id_item=b.id_item
	LEFT JOIN inventory.item_group ig ON ig.id_item_group=i.id_item_group
	LEFT JOIN (
		SELECT id_category
				, CASE WHEN id_parent IS NULL 
					   THEN name
					   ELSE LEFT(path, CHARINDEX('>', path) - 1)
					   END AS category_parent
				, CASE WHEN id_parent IS NULL
					   THEN ''
					   ELSE name
					   END AS category_child
		FROM inventory.vw_category_list  
	) c ON c.id_category=ig.id_category
	WHERE im.id_transfer_import=@id_transfer_import AND
		  (@id_transfer IS NULL OR t.id_transfer=@id_transfer)
go

