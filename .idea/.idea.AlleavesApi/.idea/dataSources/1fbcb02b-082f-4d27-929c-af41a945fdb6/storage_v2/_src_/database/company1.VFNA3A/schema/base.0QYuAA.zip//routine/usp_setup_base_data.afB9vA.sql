CREATE PROCEDURE [base].[usp_setup_base_data]
	@is_move_client BIT = 0,
	@is_metrc BIT = 0
AS
	/********************************************************************************************************************
	 _   _       _         
	| \ | |     | |      _ 
	|  \| | ___ | |_ ___(_)
	| . ` |/ _ \| __/ _ \  
	| |\  | (_) | ||  __/_ 
	\_| \_/\___/ \__\___(_)

		All default data blocks are alphabetized by schema and table name. Unless required due to table dependency
		(which is unlikely to be necessary, aside from the first two [base] sections), please keep this ordering intact.

		Thank you,

				-- The Management


	*********************************************************************************************************************/


	

	/******************************************************************************************** BASE:	System User */

	SET IDENTITY_INSERT [base].[user] ON 


	/* insert system user. */
	IF NOT EXISTS (SELECT * FROM [base].[user] WHERE id_user=-1)
		INSERT [base].[user] ([id_user], [giud_user], [id_company], [WorkSpaceId], [FirstName], [LastName], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName], [PasswordReset], [PasswordResetDate]) 
		VALUES (-1, newid(), NULL, NULL, N'System', N'User', NULL, 1, N'asdf', NULL, NULL, 1, 0, NULL, 0, 0, N'System', 0, CAST(N'1970-01-01T00:00:00.000' AS DateTime))

	SET IDENTITY_INSERT [base].[user] OFF


	/******************************************************************************************** BASE:	 States */

	SET IDENTITY_INSERT [base].[states] ON 

	;WITH list AS (
		SELECT * FROM (VALUES
			(1,	'Alabama', 'AL'),
			(2,	'Alaska', 'AK'),
			(3,	'Arizona', 'AZ'),
			(4,	'Arkansas', 'AR'),
			(5,	'California', 'CA'),
			(6,	'Colorado', 'CO'),
			(7,	'Connecticut', 'CT'),
			(8,	'Delaware', 'DE'),
			(9,	'Florida', 'FL'),
			(10, 'Georgia', 'GA'),
			(11, 'Hawaii', 'HI'),
			(12, 'Idaho', 'ID'),
			(13, 'Illinois', 'IL'),
			(14, 'Indiana', 'IN'),
			(15, 'Iowa', 'IA'),
			(16, 'Kansas', 'KS'),
			(17, 'Kentucky', 'KY'),
			(18, 'Louisiana', 'LA'),
			(19, 'Maine', 'ME'),
			(20, 'Maryland', 'MD'),
			(21, 'Massachusetts', 'MA'),
			(22, 'Michigan', 'MI'),
			(23, 'Minnesota', 'MN'),
			(24, 'Mississippi', 'MS'),
			(25, 'Missouri', 'MO'),
			(26, 'Montana', 'MT'),
			(27, 'Nebraska', 'NE'),
			(28, 'Nevada', 'NV'),
			(29, 'New Hampshire', 'NH'),
			(30, 'New Jersey', 'NJ'),
			(31, 'New Mexico', 'NM'),
			(32, 'New York', 'NY'),
			(33, 'North Carolina', 'NC'),
			(34, 'North Dakota', 'ND'),
			(35, 'Ohio', 'OH'),
			(36, 'Oklahoma', 'OK'),
			(37, 'Oregon', 'OR'),
			(38, 'Pennsylvania', 'PA'),
			(39, 'Rhode Island', 'RI'),
			(40, 'South Carolina', 'SC'),
			(41, 'South Dakota', 'SD'),
			(42, 'Tennessee', 'TN'),
			(43, 'Texas', 'TX'),
			(44, 'Utah', 'UT'),
			(45, 'Vermont', 'VT'),
			(46, 'Virginia', 'VA'),
			(47, 'Washington', 'WA'),
			(48, 'West Virginia', 'WV'),
			(49, 'Wisconsin', 'WI'),
			(50, 'Wyoming', 'WY'),
			(51, 'Washington, D.C.', 'DC')
		) t(id_state, name, abbreviation)
	)
	MERGE [base].[states] t USING list s
	ON t.id_state=s.id_state
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name, t.abbreviation=s.abbreviation
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_state,name,abbreviation) VALUES (s.id_state, s.name, s.abbreviation)
	;

	SET IDENTITY_INSERT [base].[states] OFF



	/******************************************************************************************** ACL:	Modules */


	SET IDENTITY_INSERT [acl].[module] ON 

	IF (@is_move_client = 0)
	BEGIN
		;WITH list AS (
			SELECT * FROM (VALUES
				(1, 'Admin'),
				(2, 'General'),
				(3, 'Grow'),
				(4, 'Process'),
				(5, 'Move'),
				(6, 'Sell'),
				(7, 'Insights')
			) t(id_module, name)
		)
		MERGE [acl].[module] t USING list s
		ON t.id_module=s.id_module
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_module,name) VALUES (s.id_module, s.name)
		;
	END
	ELSE
	BEGIN
		;WITH list AS (
			SELECT * FROM (VALUES
				(1, 'Admin'),
				(2, 'General'),
				(4, 'Process'),
				(5, 'Move'),
				(6, 'Sell'),
				(7, 'Insights')
			) t(id_module, name)
		)
		MERGE [acl].[module] t USING list s
		ON t.id_module=s.id_module
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_module,name) VALUES (s.id_module, s.name)
		;
	END


	SET IDENTITY_INSERT [acl].[module] OFF 


	/******************************************************************************************** ACL:	Permissions */

	DROP TABLE IF EXISTS #acl_list

	SELECT TOP 10000 * INTO #acl_list FROM (
		SELECT ISNULL(m.id_module, 1) AS id_module
				, l.module
				, RIGHT(reference_path, charindex('.', REVERSE(reference_path) + '.') - 1) AS reference
				, l.reference_path
				, CASE WHEN LEN(reference_path) - LEN(REPLACE(reference_path, '.', '')) = 0 THEN NULL ELSE LEFT(reference_path, LEN(reference_path) - CHARINDEX('.', reverse(reference_path))) END AS reference_path_parent	
				, l.label
				, LEN(reference_path) - LEN(REPLACE(reference_path, '.', '')) AS path_depth
		FROM 
		(
			SELECT * FROM (VALUES
				-- ADMIN ----------------------------------------------------------
				('Admin',		'admin',								'Admin Panel Access', 1),
				('Admin',		'user',									'User Management', 1),
				('Admin',		'user.view',							'View', 1),
				('Admin',		'user.create',							'Create', 1),
				('Admin',		'user.modify',							'Modify', 1),
				('Admin',		'user.delete',							'Delete', 1),
				('Admin',		'role',									'Role Management', 1),
				('Admin',		'role.view',							'View', 1),
				('Admin',		'role.create',							'Create', 1),
				('Admin',		'role.modify',							'Modify', 1),
				('Admin',		'role.delete',							'Delete', 1),
				-- GENERAL ----------------------------------------------------------
				('General',		'location',								'Locations', 1),
				('General',		'location.view',						'View', 1),
				('General',		'location.create',						'Create', 1),
				('General',		'location.modify',						'Modify', 1),
				('General',		'location.delete',						'Delete', 1),
				('General',		'inventory',							'Inventory', 1),
				('General',		'inventory.view',						'View', 1),
				('General',		'inventory.adjust',						'Adjust Inventory', 1),
				('General',		'inventory.scrap',						'Scrap Inventory', 1),
				('General',		'inventory.move',						'Move Inventory', 1),
				('General',		'inventory.combine',					'Combine/Convert Inventory', 1),
				('General',		'inventory.batch',						'Batches', 1),
				('General',		'inventory.batch.modify',				'Modify', 1),
				('General',		'inventory.adjust_metrc',				'Send to Metrc', 0),
				('General',		'inventory.adjust_reason',				'Adjustment Reasons', 1),
				('General',		'inventory.adjust_reason.view',			'View', 1),
				('General',		'inventory.adjust_reason.create',		'Create', 1),
				('General',		'inventory.adjust_reason.modify',		'Modify', 1),
				('General',		'inventory.adjust_reason.delete',		'Delete', 1),
				('General',		'inventory.scrap_reason',				'Scrap Reasons', 1),
				('General',		'inventory.scrap_reason.view',			'View', 1),
				('General',		'inventory.scrap_reason.create',		'Create', 1),
				('General',		'inventory.scrap_reason.modify',		'Modify', 1),
				('General',		'inventory.scrap_reason.delete',		'Delete', 1),
				('General',		'inventory.status',						'Inventory Statuses', 1),
				('General',		'inventory.status.view',				'View', 1),
				('General',		'inventory.status.create',				'Create', 1),
				('General',		'inventory.status.modify',				'Modify', 1),
				('General',		'inventory.status.delete',				'Delete', 1),
				('General',		'area',									'Areas', 1),
				('General',		'area.view',							'View', 1),
				('General',		'area.create',							'Create', 1),
				('General',		'area.modify',							'Modify', 1),
				('General',		'area.delete',							'Delete', 1),
				('General',		'area.type',							'Area Types', 1),
				('General',		'area.type.view',						'View', 1),
				('General',		'area.type.create',						'Create', 1),
				('General',		'area.type.modify',						'Modify', 1),
				('General',		'area.type.delete',						'Delete', 1),
				('General',		'item',									'Items', 1),
				('General',		'item.view',							'View', 1),
				('General',		'item.create',							'Create', 1),
				('General',		'item.modify',							'Modify', 1),
				('General',		'item.delete',							'Delete', 1),
				('General',		'item.category',						'Categories', 1),
				('General',		'item.category.view',					'View', 1),
				('General',		'item.category.create',					'Create', 1),
				('General',		'item.category.modify',					'Modify', 1),
				('General',		'item.category.delete',					'Delete', 1),
				('General',		'item.chemical_profile',			'Test Result', 0),
				('General',		'item.chemical_profile.view',			'View', 0),
				('General',		'item.chemical_profile.create',			'Create', 0),
				('General',		'item.chemical_profile.modify',			'Modify', 0),
				('General',		'item.attribute',						'Attributes', 1),
				('General',		'item.attribute.view',					'View', 1),
				('General',		'item.attribute.create',				'Create', 1),
				('General',		'item.attribute.modify',				'Modify', 1),
				('General',		'item.attribute.delete',				'Delete', 1),
				('General',		'item.delivery_route',					'Cannabis Delivery Routes', 0),
				('General',		'item.delivery_route.view',				'View', 0),
				('General',		'item.delivery_route.create',			'Create', 0),
				('General',		'item.delivery_route.modify',			'Modify', 0),
				('General',		'item.delivery_route.delete',			'Delete', 0),
				('General',		'item.uom',								'Units of Measure', 1),
				('General',		'item.uom.view',						'View', 1),
				('General',		'item.uom.create',						'Create', 1),
				('General',		'item.uom.modify',						'Modify', 1),
				('General',		'item.uom.delete',						'Delete', 1),
				('General',		'pos.register.modify_payment.view',		'View', 1),
				('General',		'pos.register.modify_payment.create',	'Create', 1),
				('General',		'pos.register.modify_payment.modify',	'Modify', 1),
				('General',		'pos.register.modify_payment.delete',	'Delete', 1),
				('General',		'raw_material',							'Raw Materials', 1),
				('General',		'raw_material.view',					'View', 1),
				('General',		'raw_material.create',					'Create', 1),
				('General',		'raw_material.modify',					'Modify', 1),
				('General',		'raw_material.delete',					'Delete', 1),
				-- GROW ----------------------------------------------------------
				('Grow',		'plant',								'Plants', 0),
				('Grow',		'plant.view',							'View', 0),
				('Grow',		'plant.create',							'Create', 0),
				('Grow',		'plant.modify',							'Modify', 0),
				('Grow',		'plant.move',							'Move', 0),
				('Grow',		'plant.transfer',						'Transfer', 0),
				('Grow',		'plant.destroy',						'Destroy', 0),
				('Grow',		'plant.salvage',						'Salvage', 0),
				('Grow',		'plant.harvest',						'Harvest', 0),
				('Grow',		'plant.destroy_reason',					'Destroy Reasons', 0),
				('Grow',		'plant.destroy_reason.view',			'View', 0),
				('Grow',		'plant.destroy_reason.create',			'Create', 0),
				('Grow',		'plant.destroy_reason.modify',			'Modify', 0),
				('Grow',		'plant.destroy_reason.delete',			'Delete', 0),
				('Grow',		'strain',								'Strains', 0),
				('Grow',		'strain.view',							'View', 0),
				('Grow',		'strain.create',						'Create', 0),
				('Grow',		'strain.modify',						'Modify', 0),
				('Grow',		'strain.delete',						'Delete', 0),
				('Grow',		'strain_type',							'Strain Types', 0),
				('Grow',		'strain_type.view',						'View', 0),
				('Grow',		'strain_type.create',					'Create', 0),
				('Grow',		'strain_type.modify',					'Modify', 0),
				('Grow',		'strain_type.delete',					'Delete', 0),
				('Grow',		'strain_mood',							'Strain Moods', 0),
				('Grow',		'strain_mood.view',						'View', 0),
				('Grow',		'strain_mood.create',					'Create', 0),
				('Grow',		'strain_mood.modify',					'Modify', 0),
				('Grow',		'strain_mood.delete',					'Delete', 0),
				('Grow',		'raw_material_config',					'Strain: Item Auto-Create Config', 0),
				('Grow',		'raw_material_config.view',				'View', 0),
				('Grow',		'raw_material_config.create',			'Create', 0),
				('Grow',		'raw_material_config.modify',			'Modify', 0),
				('Grow',		'raw_material_config.delete',			'Delete', 0),
				-- PROCESS ----------------------------------------------------------
				('Process',		'bom',									'Bill of Materials', 1),
				('Process',		'bom.create',							'Create', 1),
				('Process',		'bom.modify',							'Modify', 1),
				('Process',		'process',								'Processing', 1),
				('Process',		'process.view',							'View', 1),
				('Process',		'process.work',							'Create and Work on a Production', 1),
				('Process',		'process.abandon',						'Abandon', 1),
				('Process',		'process.form',							'Process Forms', 1),
				('Process',		'process.form.create',					'Create', 1),
				('Process',		'process.form.modify',					'Modify', 1),
				('Process',		'process.form.delete',					'Delete', 1),
				('Process',		'process.form.category',				'Categories', 1),
				('Process',		'process.form.category.view',			'View', 1),
				('Process',		'process.form.category.create',			'Create', 1),
				('Process',		'process.form.category.modify',			'Modify', 1),
				('Process',		'process.form.category.delete',			'Delete', 1),
				('Process',		'production',							'Production', 1),
				('Process',		'production.create',					'Create', 1),
				-- MOVE ----------------------------------------------------------
				('Move',		'driver',								'Drivers', 1),
				('Move',		'driver.view',							'View', 1),
				('Move',		'driver.create',						'Create', 1),
				('Move',		'driver.modify',						'Modify', 1),
				('Move',		'driver.delete',						'Delete', 1),
				('Move',		'vehicle',								'Vehicles', 1),
				('Move',		'vehicle.view',							'View', 1),
				('Move',		'vehicle.create',						'Create', 1),
				('Move',		'vehicle.modify',						'Modify', 1),
				('Move',		'vehicle.delete',						'Delete', 1),
				('Move',		'transfer',								'Transfers', 1),
				('Move',		'transfer.view',						'View', 1),
				('Move',		'transfer.create',						'Create', 1),
				('Move',		'transfer.modify',						'Modify', 1),
				('Move',		'transfer.cancel',						'Cancel', 1),
				('Move',		'transfer.receive',						'Receive', 1),
				('Move',		'transfer.refuse_reason',				'Refusal Reasons', 1),
				('Move',		'transfer.refuse_reason.view',			'View', 1),
				('Move',		'transfer.refuse_reason.create',		'Create', 1),
				('Move',		'transfer.refuse_reason.modify',		'Modify', 1),
				('Move',		'transfer.refuse_reason.delete',		'Delete', 1),
				-- SELL ----------------------------------------------------------
				('Sell',		'brand',								'Brands', 1),
				('Sell',		'brand.view',							'View', 1),
				('Sell',		'brand.create',							'Create', 1),
				('Sell',		'brand.modify',							'Modify', 1),
				('Sell',		'brand.delete',							'Delete', 1),
				('Sell',		'queue',								'Queue', 0),
				('Sell',		'queue.view',							'View', 0),
				('Sell',		'queue.enqueue',						'Add to Queue', 0),
				('Sell',		'queue.dequeue',						'Remove from Queue', 0),
				('Sell',		'customer',								'Customers', 0),
				('Sell',		'customer.view',						'View', 0),
				('Sell',		'customer.create',						'Create', 0),
				('Sell',		'customer.modify',						'Modify', 0),
				('Sell',		'customer.delete',						'Delete', 0),
				('Sell',		'customer.note',						'Customer Notes', 0),
				('Sell',		'customer.note.create',					'Create', 0),
				('Sell',		'customer.note.modify',					'Modify', 0),
				('Sell',		'customer.note.delete',					'Delete', 0),
				('Sell',		'customer.type',						'Customer Types', 0),
				('Sell',		'customer.type.view',					'View', 0),
				('Sell',		'customer.type.create',					'Create', 0),
				('Sell',		'customer.type.modify',					'Modify', 0),
				('Sell',		'customer.type.delete',					'Delete', 0),
				('Sell',		'customer.referral_method',				'Referral Method', 0),
				('Sell',		'customer.referral_method.view',		'View', 0),
				('Sell',		'customer.referral_method.create',		'Create', 0),
				('Sell',		'customer.referral_method.modify',		'Modify', 0),
				('Sell',		'customer.referral_method.delete',		'Delete', 0),
				('Sell',		'physician',							'Physicians', 0),
				('Sell',		'physician.view',						'View', 0),
				('Sell',		'physician.create',						'Create', 0),
				('Sell',		'physician.modify',						'Modify', 0),
				('Sell',		'physician.delete',						'Delete', 0),
				('Sell',		'discount',								'Discounts', 0),
				('Sell',		'discount.view',						'View', 0),
				('Sell',		'discount.create',						'Create', 0),
				('Sell',		'discount.modify',						'Modify', 0),
				('Sell',		'discount.delete',						'Delete', 0),
				('Sell',		'discount.type',						'Discount Types', 0),
				('Sell',		'discount.type.view',					'View', 0),
				('Sell',		'discount.type.create',					'Create', 0),
				('Sell',		'discount.type.modify',					'Modify', 0),
				('Sell',		'discount.type.delete',					'Delete', 0),
				('Sell',		'discount.adjustment_type',				'Adjustment Types', 0),
				('Sell',		'discount.adjustment_type.view',		'View', 0),
				('Sell',		'discount.adjustment_type.create',		'Create', 0),
				('Sell',		'discount.adjustment_type.modify',		'Modify', 0),
				('Sell',		'discount.adjustment_type.delete',		'Delete', 0),
				('Sell',		'order',								'Orders', 0),
				('Sell',		'order.price_override',					'Price Override', 0),
				('Sell',		'order.return',							'Process Returns', 0),
				('Sell',		'order.store_credit',					'Process Store Credit', 0),
				('Sell',		'order.void',							'Void Orders', 0),
				('Sell',		'order.view',							'View', 0),
				('Sell',		'order.create',							'Create', 0),
				('Sell',		'order.modify',							'Modify', 0),
				('Sell',		'order.status',							'Statuses', 0),
				('Sell',		'order.status.view',					'View', 0),
				('Sell',		'order.status.create',					'Create', 0),
				('Sell',		'order.status.modify',					'Modify', 0),
				('Sell',		'order.status.delete',					'Delete', 0),
				('Sell',		'order_status',							'Order Status Screen', 0),
				('Sell',		'pos',									'POS', 0),
				('Sell',		'pos.access',							'Access to POS', 0),
				('Sell',		'pos.register',							'Register', 0),
				('Sell',		'pos.register.manage',					'Manage Register Settings', 0),
				('Sell',		'pos.register.open',					'Open Register', 0),
				('Sell',		'pos.register.close',					'Close Register', 0),
				('Sell',		'pos.register.payment',					'Take Payments', 0),
				('Sell',		'pos.register.modify_payment',			'Modify Payments', 0),
				('Sell',		'pos.register.withdrawal',				'Withdrawals', 0),
				('Sell',		'pos.register.balance_increase',		'Balance Increase', 0),
				('Sell',		'pos.register.print_pick_ticket',		'Print Pick Tickets', 0),
				('Sell',		'pos.register.reprint_receipt',			'Reprint Customer Receipt', 0),
				('Sell',		'pos.register.discount',				'Apply Discounts', 0),
				('Sell',		'pos.register.add_from_alternate_area',	'Add Items from Alternate Areas', 0),
				('Sell',		'pos.register.manual_add',				'Add Items manually from retail areas', 0),
				('Sell',		'pos.register.metrc_inactive_patient_override' , 'Metrc Inactive Patient Override', 0),
				('Sell',		'pos.register.checkout_pin',			'Bypass Checkout PIN', 0),
				('Sell',		'pos.register.round_item_weight',		'Round Item Weight', 0),
				('Sell',		'safe',									'Safes', 0),
				('Sell',		'safe.withdrawal',						'Withdrawals', 0),
				('Sell',		'safe.view',							'View', 0),
				('Sell',		'safe.create',							'Create', 0),
				('Sell',		'safe.modify',							'Modify', 0),
				('Sell',		'safe.delete',							'Delete', 0),
				('Sell',		'vendor',								'Vendors', 1),
				('Sell',		'vendor.view',							'View', 1),
				('Sell',		'vendor.create',						'Create', 1),
				('Sell',		'vendor.modify',						'Modify', 1),
				('Sell',		'vendor.delete',						'Delete', 1),
				('Sell',		'tiered_pricing',						'Tiered Pricing', 0),
				('Sell',		'tiered_pricing.view',					'View', 0),
				('Sell',		'tiered_pricing.create',				'Create', 0),
				('Sell',		'tiered_pricing.modify',				'Modify', 0),
				('Sell',		'tiered_pricing.delete',				'Delete', 0),
				-- INSIGHTS ----------------------------------------------------------
				('Insights',	'report',								'Report Groups', 1),
				('Insights',	'report.cultivation',					'Cultivation', 0),
				('Insights',	'report.human_capitol',					'Human Capital', 1),
				('Insights',	'report.inventory',						'Inventory', 1),
				('Insights',	'report.logistics',						'Logistics', 1),
				('Insights',	'report.marketing',						'Marketing', 0),
				('Insights',	'report.retail',						'Retail', 0),
				('Insights',	'report.sales',							'Sales', 1)
			) t(module, reference_path, label, include_in_MOVE)
			WHERE include_in_MOVE>=@is_move_client
		) l
		LEFT JOIN acl.module m ON m.name=l.module
	) t
	ORDER BY id_module, path_depth

	MERGE acl.permission t
	USING #acl_list s
	ON t.reference_path=s.reference_path
	WHEN MATCHED THEN UPDATE
		SET t.id_module=s.id_module
			, t.reference=s.reference
			, t.reference_path=s.reference_path
			, t.label=s.label
			, t.id_parent=(CASE WHEN s.reference_path_parent IS NULL THEN NULL ELSE (SELECT TOP 1 x.id_permission FROM acl.permission x WHERE x.reference_path=s.reference_path_parent) END)
			, t.active=1
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (reference, reference_path, label, id_module, id_parent) VALUES
		(s.reference, s.reference_path, s.label, s.id_module, (CASE WHEN s.reference_path_parent IS NULL THEN NULL ELSE (SELECT TOP 1 x.id_permission FROM acl.permission x WHERE x.reference_path=s.reference_path_parent) END))
	WHEN NOT MATCHED BY SOURCE THEN UPDATE
		SET active=0
	;
			


	/******************************************************************************************** ACL:	Default SuperAdmin Role */
	
	SET IDENTITY_INSERT [acl].[role] ON 

	IF NOT EXISTS (SELECT * FROM acl.role WHERE id_role=-1)
		INSERT INTO acl.role (id_role, name, id_user_created, id_user_updated) VALUES (-1, 'SuperAdmin', -1, -1)

	SET IDENTITY_INSERT [acl].[role] OFF

	
	;WITH list AS (
		SELECT -1 AS id_role
				, id_permission
		FROM [acl].[permission]
	)
	MERGE [acl].[role_permission] t USING list s 
	ON t.id_role=s.id_role AND t.id_permission=s.id_permission
	WHEN MATCHED THEN 
		UPDATE SET t.allowed=1
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_role, id_permission, allowed, id_user_created, id_user_updated) 
		VALUES (s.id_role, s.id_permission, 1, -1, -1) 
	WHEN NOT MATCHED BY SOURCE AND t.id_role=-1 THEN
		DELETE
	;



	/******************************************************************************************** GROW:	Destroy reasons */

	SET IDENTITY_INSERT [grow].[destroy_reason] ON 

	IF (@is_move_client = 0)
	BEGIN
		;WITH list AS (
			SELECT * FROM (VALUES
				(1, 'Dead',		0, 1, -1, -1),
				(2, 'Diseased', 0, 1, -1, -1),
				(3, 'Intersex',	0, 1, -1, -1),
				(4, 'Other',	1, 1, -1, -1)
			) t([id_destroy_reason],[name],[destroy_reason_required],[system],[created_by],[updated_by])
		)
		MERGE [grow].[destroy_reason] t USING list s
		ON t.[id_destroy_reason]=s.[id_destroy_reason]
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name, t.destroy_reason_required=s.destroy_reason_required
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT ([id_destroy_reason],[name],[destroy_reason_required],[system],[created_by],[updated_by]) VALUES (s.id_destroy_reason, s.name, s.destroy_reason_required, 1, -1, -1)
		;

	END

	SET IDENTITY_INSERT [grow].[destroy_reason] OFF 



	/******************************************************************************************** GROW:	Event Type */


	SET IDENTITY_INSERT [grow].[event_type] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1,		'create',					'Planting/Cloning',					'Planting or cloning a plant.'),
			(2,		'move',						'Moved',							'Transfer from one room or grid location to another.'),
			(3,		'phase_change',				'Phase Changed',					'Change the phase of a plant to a new phase and/or date.'),
			(4,		'harvest',					'Harvested',						'Harvesting a plant for further processing.'),
			(5,		'destroy',					'Destroyed',						'Destroying a plant.'),
			(6,		'salvage',					'Salvaged',							'Salvaging a plant from being previousl destroyed.'),
			(7,		'transfer_manifest_add',	'Transfer: Add to manifest',		'Adding a plant to a transfer manifest.'),
			(8,		'transfer_manifest_remove',	'Transfer: Remove from manifest',	'Removing a plant from a transfer manifest.'),
			(9,		'transfer_receive',			'Transfer: Receive',				'Receiving a plant into inventory from an incoming transfer.'),
			(10,	'transfer_cancel',			'Transfer: Cancel',					'Returning a plant to its original location after cancelling a transfer.'),
			(11,	'nutrient',					'Nutrient/Additive',				'Adding nutrient to a plant.'),
			(12,	'package',					'Packaged',						'Putting a plant into inventory.'),
			(13,	'manicure',					'Manicure',						'Manicuring a plant.')
		) t(id_type, reference, label, description)
	)
	MERGE [grow].[event_type] t USING list s
	ON t.id_type=s.id_type
	WHEN MATCHED THEN UPDATE
		SET t.reference=s.reference, t.label=s.label, t.description=s.description 
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_type, reference, label, description) VALUES (s.id_type, s.reference, s.label, s.description)
	;


	SET IDENTITY_INSERT [grow].[event_type] OFF 



	/******************************************************************************************** GROW:	Phases */

	SET IDENTITY_INSERT [grow].[phase] ON 

	IF (@is_move_client = 0)
	BEGIN
		;WITH list AS (
			SELECT * FROM (VALUES
				(1, 'Germination',		2),
				(2, 'Seedling',			1),
				(3, 'Vegetative',		3),
				(4, 'Pre-Flowering',	4),
				(5, 'Flowering',		5),
				(6, 'Harvested',		6)
			) t(id_phase, name, sequence)
		)
		MERGE [grow].[phase] t USING list s
		ON t.id_phase=s.id_phase
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name, t.sequence=s.sequence
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_phase, name, sequence) VALUES (s.id_phase, s.name, s.sequence)
		;
	END


	SET IDENTITY_INSERT [grow].[phase] OFF 


	/******************************************************************************************** GROW:	Strain types */


	SET IDENTITY_INSERT [grow].[strain_type] ON 

	IF (@is_move_client = 0)
	BEGIN
		;WITH list AS (
			SELECT * FROM (VALUES
				(1, 'Indica',	1),
				(2, 'Sativa',	1),
				(3, 'Hybrid',	1),
				(4,	'Indica Leaning Hybrid',	1),
				(5,	'Sativa Leaning Hybrid',	1),
				(6,	'Not Applicable',	1)
			) t(id_strain_type, name, system)
		)
		MERGE [grow].[strain_type] t USING list s
		ON t.id_strain_type=s.id_strain_type
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_strain_type, name, system, created_by, updated_by) VALUES (s.id_strain_type, s.name, 1, -1, -1)
		;
	END


	SET IDENTITY_INSERT [grow].[strain_type] OFF 


	/******************************************************************************************** GROW:	Transfer Status */


	SET IDENTITY_INSERT [grow].[transfer_status] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			   (1, 'Pending Transfer',	'pending',		1),
			   (2, 'Packed/Verified',	'packed',		2),
			   (3, 'In Transit',		'in_transit',	3),
			   (4, 'Received',			'received',		4),
			   (5, 'Cancelled',			'cancelled',	5)
		) t(id_transfer_status, name, reference, sequence)
	)
	MERGE [grow].[transfer_status] t USING list s
	ON t.id_transfer_status=s.id_transfer_status
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name, t.reference=s.reference
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_transfer_status, name, reference, sequence) VALUES (s.id_transfer_status, s.name, s.reference, s.sequence)
	;


	SET IDENTITY_INSERT [grow].[transfer_status] OFF 




	/******************************************************************************************** LOG:	Type */


	SET IDENTITY_INSERT [log].[type] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1,		'inventory_move',			'Moving inventory to/from a room'),
			(2,		'inventory_scrap',			'Discarding inventory from a storage area or to a scrap area'),
			(3,		'inventory_adjust',			'Adjusting inventory for a cycle count'),
			(4,		'harvest',					'Creating new inventory from a plant harvest'),
			(5,		'process_input_use',		'Removing inventory used as an input for a process'),
			(6,		'process_input_return',		'Adjusting items returned (not needed or used) for a process'),
			(7,		'process_output',			'Creating inventory as an output of a process'),
			(8,		'production_input',			'Removing inventory added as an input for a production'),
			(9,		'production_input_waste',	'Removing inventory marked as waste for a production'),
			(10,	'production_output',		'Creating inventory as an output of a production'),
			(11,	'transfer_manifest_add',	'Removing inventory as it is added to a manifest for a transfer'),
			(12,	'transfer_manifest_remove', 'Adjusting inventory as it is removed from a manifest'),
			(13,	'transfer_receive',			'Creating inventory received from a transfer'),
			(14,	'order_add',				'Removing inventory as it is added to a customer order'),
			(15,	'order_remove',				'Adjusting inventory as items are removed from a customer order'),
			(16,	'order_return',				'Customer returning a previously purchased item'),
			(17,	'order_void',				'Returning inventory as a order has been voided'),
			(22,	'order_cancel',				'Returning inventory as a order has been cancelled'),
			(18,	'inventory_combine_use',	'Consuming inventory in a combine/convert action'),
			(19,	'inventory_combine_create',	'Creating inventory from a combine/convert action'),
			(20,	'metrc_import',				'Importing items from Metrc into Alleaves'),
			(21,	'inventory_add',			'Generating new inventory'),
			(23,	'nutrient_apply',			'Applying nutrient item to plants'),
			(24,	'plant_package',			'Putting a plant item from cultivation into inventory'),
			(25,	'plant_cultivate',			'Putting a plant item from inventory into cultivation'),
			(26,	'batch_status',				'Changing the status of a batch'),
			(27,    'biotrack_import',          'Importing items from Biotrack into Alleaves')
		) t(id_type, reference, description)
	)
	MERGE [log].[type] t USING list s
	ON t.id_type=s.id_type
	WHEN MATCHED THEN UPDATE
		SET t.reference=s.reference, t.description=s.description 
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_type, reference, description) VALUES (s.id_type, s.reference, s.description)
	;


	SET IDENTITY_INSERT [log].[type] OFF 



	/******************************************************************************************** METRC:	Log Type */


	SET IDENTITY_INSERT [metrc].[log_type] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1,		'adjust_package',	'Adjust quantity of Metrc package(s)'),
			(2,		'finish_package',	'Finish Metrc package'),
			(3,		'unfinish_package',	'Unfinish Metrc package'),
			(4,		'record_sale',		'Record sale in Metrc'),
			(5,		'update_sale',		'Update sale in Metrc'),
			(6,		'void_sale',		'Void sale in Metrc'),
			(7,		'combine_convert',	'Combine and convert of Metrc packages'),
			(8,		'item_create',		'Create item in Metrc'),
			(9,		'process_package',	'Create Metrc packages through processing')
		) t(id_type, reference, description)
	)
	MERGE [metrc].[log_type] t USING list s
	ON t.id_type=s.id_type
	WHEN MATCHED THEN UPDATE
		SET t.reference=s.reference, t.description=s.description 
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_type, reference, description) VALUES (s.id_type, s.reference, s.description)
	;


	SET IDENTITY_INSERT [metrc].[log_type] OFF 

	/******************************************************************************************** METRC:	Error Remediation */


	SET IDENTITY_INSERT [metrc].[error_remediation] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'sale_failure', 'package_negative_quantity', 'package,negative quantity', 'Sale was recorded successfully but package quantity needs to be verified and adjustments made as needed', 0, 0),
			(2, 'sale_failure', 'http_401', '401,unauthorized', 'Verify user permissions in Metrc for user who attempted to record the sale', 1, 0),
			(3, 'sale_failure', 'http_404', '404,not found', '1. Re-attempt to record sale
2. If not resolved then submit a support ticket with Alleaves to resolve', 1, 0),
			(4, 'sale_failure', 'http_503', '503,unavailable', '1. Re-attempt to record sale
2. If not resolved then submit a support ticket with Alleaves to resolve', 1, 0),
			(5, 'sale_failure', 'http_520', '520,error', '1. Re-attempt to record sale
2. If not resolved then submit a support ticket with Alleaves to resolve', 1, 0),
			(6, 'sale_failure', 'metrc_receipt_exists', 'record sale,metrc receipt', 'Please verify Metrc receipt identified is accurate and update as needed', 0, 0),
			(7, 'sale_failure', 'package_finished', 'package,finished',	'1. Un-finish package
2. Adjust package inventory to accommodate this sale
3. Re-record sale
4. Finish package', 1, 0),
			(8, 'sale_failure', 'missing_api_key', 'no,api key', '1. Set User API key and verify user permissions
2. Make any necessary adjustments in Metrc', 1, 0),
			(9, 'finish_package_failure', 'missing_api_key', 'no,api key', '1. Set User API key and verify user permissions
2. Make any necessary adjustments in Metrc', 0, 0),
			
			(10, 'unfinish_package_failure', 'missing_api_key', 'no,api key', '1. Set User API key and verify user permissions
2. Make any necessary adjustments in Metrc', 0, 0),
			(11, 'sale_failure', 'connection_error', 'ECONNRESET', '1. Re-attempt to record sale
2. If not resolved then submit a support ticket with Alleaves to resolve', 1, 0),
			(12, 'sale_failure', 'uom_invalid', 'unit of measure,invalid', '1. Verify the stored UOM, usable weight UOM and usable weight value of the item
2. Re-attempt to record sale
3. If not resolved then submit a support ticket with Alleaves to resolve.', 1, 0),
			(13, 'finish_package_failure', 'package_already_finished', 		'package,already,finished',		'No action required.', 0, 0),
			(14, 'unfinish_package_failure', 'package_not_finished', 		'package,not,finished',	'No action required.', 0, 0),
			(15, 'package_failure', 'invalid_reason', 'Reason,selected,not valid', 'Please reach out to Alleaves support to update Metrc adjustment reasons.', 0, 0),
			(16, 'package_failure', '401_package', '401,unauthorized', 'Verify user permissions in Metrc for user who attempted to record the adjustments.', 0, 0),
			(17, 'package_failure', 'too_many_requests_package', '429,too,many,requests', 'Metrc server error. Reattempt adjustment at a later time.', 0, 0),
			(18, 'package_failure', 'finished_adjust_failure', 'cannot be Adjusted,finished',	'1. Un-finish package
2. Use the state inventory reconciliation tool to adjust the packages to the correct quantities.', 0, 0),
			(19, 'package_failure', 'http_520', '520,error', 'Metrc server error. Reattempt adjustment at a later time.', 0, 0)
		) t(id_remediation, [type], [name], error_keywords, remediation_steps, rerecord_sale, deleted)
	)

	MERGE [metrc].[error_remediation] t USING list s
	ON t.id_remediation=s.id_remediation
	WHEN MATCHED THEN UPDATE
		SET t.type=s.type, t.name=s.name, t.error_keywords=s.error_keywords, t.remediation_steps=s.remediation_steps, t.rerecord_sale=s.rerecord_sale, t.deleted=s.deleted 
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_remediation, [type], [name], error_keywords, remediation_steps, rerecord_sale, deleted) VALUES (s.id_remediation, s.[type], s.[name], s.error_keywords, s.remediation_steps, s.rerecord_sale, s.deleted)
	;


	SET IDENTITY_INSERT [metrc].[error_remediation] OFF 



	/******************************************************************************************** INVENTORY:	Adjustment Reason */


	SET IDENTITY_INSERT [inventory].[adjust_reason] ON 

	IF (@is_metrc = 0)
	BEGIN
			;WITH list AS (
			SELECT * FROM (VALUES
				(1, 'Cycle count correction', 1, 0, 0),
				(2, 'Other', 1, 1, 0),
				(3, 'Breakage/Damage', 1, 0, 0),
				(4, 'Sample/Display', 1, 0, 0)
			) t(id_adjust_reason, name, system, adjust_reason_required, deleted)
		)
		MERGE [inventory].[adjust_reason] t USING list s
		ON t.id_adjust_reason=s.id_adjust_reason
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name, t.adjust_reason_required=s.adjust_reason_required, t.deleted=s.deleted
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_adjust_reason,name,system, adjust_reason_required, deleted) VALUES (s.id_adjust_reason, s.name, 1, s.adjust_reason_required, 0)
		;
	END


	SET IDENTITY_INSERT [inventory].[adjust_reason] OFF 


	/******************************************************************************************** Biotrack:	Adjustment Reason */


	SET IDENTITY_INSERT [biotrack].[adjust_reason] ON 

	BEGIN
			;WITH list AS (
			SELECT * FROM (VALUES
				(2, 'Theft', 1, 1, 0),
				(3, 'Seizure by Federal, State, Local or Tribal Law Enforcement', 1, 1, 0),
				(4, 'Correcting a mistake', 1, 1, 0),
				(5, 'Moisture loss', 1, 1, 0)
			) t(id_adjust_reason, name, system, adjust_reason_required, deleted)
		)
		MERGE [biotrack].[adjust_reason] t USING list s
		ON t.id_adjust_reason=s.id_adjust_reason
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name, t.adjust_reason_required=s.adjust_reason_required, t.deleted=s.deleted
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_adjust_reason,name,system, adjust_reason_required, deleted) VALUES (s.id_adjust_reason, s.name, 1, s.adjust_reason_required, 0)
		;
	END


	SET IDENTITY_INSERT [biotrack].[adjust_reason] OFF 

	/******************************************************************************************** INVENTORY:	Area Types */


	SET IDENTITY_INSERT [inventory].[area_type] ON 

	IF (@is_move_client = 0)
	BEGIN
		;WITH list AS (
			SELECT * FROM (VALUES
				(1000, 'Storage',	'storage',		1),
				(1001, 'Receiving', 'receiving',	1),
				(1002, 'Grow',		'grow',			1),
				(1003, 'Scrap',		'scrap',		1),
				(1004, 'Staging',	'staging',		1),
				(1005, 'Shipping',	'shipping',		1),
				(1006, 'Retail',	'retail',		1),
				(1007, 'Damaged',	'damaged',		1)
			) t(id_area_type, name, reference, system)
		)
		MERGE [inventory].[area_type] t USING list s
		ON t.id_area_type=s.id_area_type
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name, t.reference=s.reference
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_area_type, name, reference, system) VALUES (s.id_area_type, s.name, s.reference, 1)
		;
	END
	ELSE
	BEGIN
		;WITH list AS (
			SELECT * FROM (VALUES
				(1000, 'Storage',	'storage',		1),
				(1001, 'Receiving', 'receiving',	1),
				(1003, 'Scrap',		'scrap',		1),
				(1004, 'Staging',	'staging',		1),
				(1005, 'Shipping',	'shipping',		1),
				(1006, 'Retail',	'retail',		1),
				(1007, 'Damaged',	'damaged',		1)
			) t(id_area_type, name, reference, system)
		)
		MERGE [inventory].[area_type] t USING list s
		ON t.id_area_type=s.id_area_type
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name, t.reference=s.reference
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_area_type, name, reference, system) VALUES (s.id_area_type, s.name, s.reference, 1)
		;
	END


	SET IDENTITY_INSERT [inventory].[area_type] OFF 

	/******************************************************************************************** INVENTORY:	Chemical Profile */
		
	SET IDENTITY_INSERT [inventory].[chemical_profile] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
				(1, 'CBD %', -1, -1),
				(2, 'THC %', -1, -1),
				(3, 'CBC', -1, -1),
				(4, 'CBCA', -1, -1),
				(5, 'CBCV', -1, -1),
				(6, 'CBDA', -1, -1),
				(7, 'CBDML', -1, -1),
				(8, 'CBDV', -1, -1),
				(9, 'CBDVA', -1, -1),
				(10, 'CBG', -1, -1),
				(11, 'CBGA', -1, -1),
				(12, 'CBL', -1, -1),
				(13, 'CBLA', -1, -1),
				(14, 'CBN', -1, -1),
				(15, 'CBNA', -1, -1),
				(16, 'CBT', -1, -1),
				(17, 'TAC', -1, -1),
				(18, 'THCA', -1, -1),
				(19, 'THC-D8', -1, -1),
				(20, 'THC-D9', -1, -1),
				(21, 'THCML', -1, -1),
				(22, 'THCV', -1, -1),
				(23, 'THCVA', -1, -1),
				(24, 'Terpenes', -1, -1),
				(25, 'Total Terpenes', -1, -1),
				(26, '3-Carene', -1, -1),
				(27, 'Alpha Pinene', -1, -1),
				(28, 'Alpha Terpinene', -1, -1),
				(29, 'Beta Caryophyllene', -1, -1),
				(30, 'Beta Eudesmol', -1, -1),
				(31, 'Beta Myrcene', -1, -1),
				(32, 'Beta Pinene', -1, -1),
				(33, 'Bisabolol', -1, -1),
				(34, 'Camphene', -1, -1),
				(35, 'Caryophyllene Oxide', -1, -1),
				(36, 'Eucalyptol', -1, -1),
				(37, 'Fenchol', -1, -1),
				(38, 'Geraniol', -1, -1),
				(39, 'Geraniol Acetate', -1, -1),
				(40, 'Guaiol', -1, -1),
				(41, 'Humulene', -1, -1),
				(42, 'Isopulegol', -1, -1),
				(43, 'Limonene', -1, -1),
				(44, 'Linalool', -1, -1),
				(45, 'Nerol', -1, -1),
				(46, 'Nerolidol', -1, -1),
				(47, 'Nerolidol-2', -1, -1),
				(48, 'Ocimene', -1, -1),
				(49, 'Ocimene-1', -1, -1),
				(50, 'Ocimene-2', -1, -1),
				(51, 'p-Cymene', -1, -1),
				(52, 'p-Isopropyltoluene', -1, -1),
				(53, 'Phytol', -1, -1),
				(54, 'Sabinene', -1, -1),
				(55, 'Terpinene', -1, -1),
				(56, 'Terpineol', -1, -1),
				(57, 'Terpinolene', -1, -1),
				(58, 'Trans-Nerolidol', -1, -1),
				(59, 'Valencene', -1, -1),
				(60, 'THC mg', -1, -1),
				(61, 'CBD mg', -1, -1),
				(62, 'Total Analyst', -1, -1),
				(63, 'TAC/PACKAGE', -1, -1),
				(64, 'TAC/SERVING', -1, -1),
				(65, 'Alpha Cedrene', -1, -1),
				(66, 'Alpha Phellandrene', -1, -1),
				(67, 'Alpha Terpinolene', -1, -1),
				(68, 'Borneol', -1, -1),			
				(69, 'Endo-Fenchyl-Alcohol', -1, -1),
				(70, 'Gamma Terpinene', -1, -1),
				(71, 'Menthol', -1, -1),
				(72, 'Pulegone', -1, -1),
				(73, 'CBD Per Package', -1, -1),
				(74, 'CBD Per Serving', -1, -1),
				(75, 'THC Per Package', -1, -1),
				(76, 'THC Per Serving', -1, -1),
				(77, 'CBC Per Package', -1, -1),
				(78, 'CBC Per Serving', -1, -1),
				(79, 'CBCA Per Package', -1, -1),
				(80, 'CBCA Per Serving', -1, -1),
				(81, 'CBCV Per Package', -1, -1),
				(82, 'CBCV Per Serving', -1, -1),
				(83, 'CBDA Per Package', -1, -1),
				(84, 'CBDA Per Serving', -1, -1),
				(85, 'CBDML Per Package', -1, -1),
				(86, 'CBDML Per Serving', -1, -1),
				(87, 'CBDV Per Package', -1, -1),
				(88, 'CBDV Per Serving', -1, -1),
				(89, 'CBDVA Per Package', -1, -1),
				(90, 'CBDVA Per Serving', -1, -1),
				(91, 'CBG Per Package', -1, -1),
				(92, 'CBG Per Serving', -1, -1),
				(93, 'CBGA Per Package', -1, -1),
				(94, 'CBGA Per Serving', -1, -1),
				(95, 'CBL Per Package', -1, -1),
				(96, 'CBL Per Serving', -1, -1),
				(97, 'CBLA Per Package', -1, -1),
				(98, 'CBLA Per Serving', -1, -1),
				(99, 'CBN Per Package', -1, -1),
				(100, 'CBN Per Serving', -1, -1),
				(101, 'CBNA Per Package', -1, -1),
				(102, 'CBNA Per Serving', -1, -1),
				(103, 'CBT Per Package', -1, -1),
				(104, 'CBT Per Serving', -1, -1),
				(105, 'TAC Per Package', -1, -1),
				(106, 'TAC Per Serving', -1, -1),
				(107, 'THCA Per Package', -1, -1),
				(108, 'THCA Per Serving', -1, -1),
				(109, 'THC-D8 Per Package', -1, -1),
				(110, 'THC-D8 Per Serving', -1, -1),
				(111, 'THC-D9 Per Package', -1, -1),
				(112, 'THC-D9 Per Serving', -1, -1),
				(113, 'THCML Per Package', -1, -1),
				(114, 'THCML Per Serving', -1, -1),
				(115, 'THCV Per Package', -1, -1),
				(116, 'THCV Per Serving', -1, -1),
				(117, 'THCVA Per Package', -1, -1),
				(118, 'THCVA Per Serving', -1, -1),
			    (119, 'Terpenes Per Package', -1, -1),
			    (120, 'Terpenes Per Serving', -1, -1),
			    (121, 'Total Terpenes Per Package', -1, -1),
			    (122, 'Total Terpenes Per Serving', -1, -1),
			    (123, '3-Carene Per Package', -1, -1),
			    (124, '3-Carene Per Serving', -1, -1),
			    (125, 'Alpha Pinene Per Package', -1, -1),
			    (126, 'Alpha Pinene Per Serving', -1, -1),
			    (127, 'Alpha Terpinene Per Package', -1, -1),
			    (128, 'Alpha Terpinene Per Serving', -1, -1),
			    (129, 'Beta Caryophyllene Per Package', -1, -1),
			    (130, 'Beta Caryophyllene Per Serving', -1, -1),
			    (131, 'Beta Eudesmol Per Package', -1, -1),
			    (132, 'Beta Eudesmol Per Serving', -1, -1),
			    (133, 'Beta Myrcene Per Package', -1, -1),
			    (134, 'Beta Myrcene Per Serving', -1, -1),
			    (135, 'Beta Pinene Per Package', -1, -1),
			    (136, 'Beta Pinene Per Serving', -1, -1),
			    (137, 'Bisabolol Per Package', -1, -1),
			    (138, 'Bisabolol Per Serving', -1, -1),
			    (139, 'Camphene Per Package', -1, -1),
			    (140, 'Camphene Per Serving', -1, -1),
			    (141, 'Caryophyllene Oxide Per Package', -1, -1),
			    (142, 'Caryophyllene Oxide Per Serving', -1, -1),
			    (143, 'Eucalyptol Per Package', -1, -1),
			    (144, 'Eucalyptol Per Serving', -1, -1),
			    (145, 'Fenchol Per Package', -1, -1),
			    (146, 'Fenchol Per Serving', -1, -1),
				(147, 'Geraniol Per Package', -1, -1),
				(148, 'Geraniol Per Serving', -1, -1),
				(149, 'Geraniol Acetate Per Package', -1, -1),
				(150, 'Geraniol Acetate Per Serving', -1, -1),
				(151, 'Guaiol Per Package', -1, -1),
				(152, 'Guaiol Per Serving', -1, -1),
				(153, 'Humulene Per Package', -1, -1),
				(154, 'Humulene Per Serving', -1, -1),
				(155, 'Isopulegol Per Package', -1, -1),
				(156, 'Isopulegol Per Serving', -1, -1),
				(157, 'Limonene Per Package', -1, -1),
				(158, 'Limonene Per Serving', -1, -1),
				(159, 'Linalool Per Package', -1, -1),
				(160, 'Linalool Per Serving', -1, -1),
				(161, 'Nerol Per Package', -1, -1),
				(162, 'Nerol Per Serving', -1, -1),
				(163, 'Nerolidol Per Package', -1, -1),
				(164, 'Nerolidol Per Serving', -1, -1),
				(165, 'Nerolidol-2 Per Package', -1, -1),
				(166, 'Nerolidol-2 Per Serving', -1, -1),
				(167, 'Ocimene Per Package', -1, -1),
				(168, 'Ocimene Per Serving', -1, -1),
				(169, 'Ocimene-1 Per Package', -1, -1),
				(170, 'Ocimene-1 Per Serving', -1, -1),
				(171, 'Ocimene-2 Per Package', -1, -1),
				(172, 'Ocimene-2 Per Serving', -1, -1),
				(173, 'p-Cymene Per Package', -1, -1),
				(174, 'p-Cymene Per Serving', -1, -1),
				(175, 'p-Isopropyltoluene Per Package', -1, -1),
				(176, 'p-Isopropyltoluene Per Serving', -1, -1),
				(177, 'Phytol Per Package', -1, -1),
				(178, 'Phytol Per Serving', -1, -1),
				(179, 'Sabinene Per Package', -1, -1),
				(180, 'Sabinene Per Serving', -1, -1),
				(181, 'Terpinene Per Package', -1, -1),
				(182, 'Terpinene Per Serving', -1, -1),
				(183, 'Terpineol Per Package', -1, -1),
				(184, 'Terpineol Per Serving', -1, -1),
				(185, 'Terpinolene Per Package', -1, -1),
				(186, 'Terpinolene Per Serving', -1, -1),
				(187, 'Trans-Nerolidol Per Package', -1, -1),
				(188, 'Trans-Nerolidol Per Serving', -1, -1),
				(189, 'Valencene Per Package', -1, -1),
				(190, 'Valencene Per Serving', -1, -1),
				(191, 'THC mg Per Package', -1, -1),
				(192, 'THC mg Per Serving', -1, -1),
				(193, 'CBD mg Per Package', -1, -1),
				(194, 'CBD mg Per Serving', -1, -1),
				(195, 'Total Analyst Per Package', -1, -1),
				(196, 'Total Analyst Per Serving', -1, -1),
				(197, 'Alpha Cedrene Per Package', -1, -1),
				(198, 'Alpha Cedrene Per Serving', -1, -1),
				(199, 'Alpha Phellandrene Per Package', -1, -1),
				(200, 'Alpha Phellandrene Per Serving', -1, -1),
				(201, 'Alpha Terpinolene Per Package', -1, -1),
				(202, 'Alpha Terpinolene Per Serving', -1, -1),
				(203, 'Borneol Per Package', -1, -1),
				(204, 'Borneol Per Serving', -1, -1),
				(205, 'Endo-Fenchyl-Alcohol Per Package', -1, -1),
				(206, 'Endo-Fenchyl-Alcohol Per Serving', -1, -1),
				(207, 'Gamma Terpinene Per Package', -1, -1),
				(208, 'Gamma Terpinene Per Serving', -1, -1),
				(209, 'Menthol Per Package', -1, -1),
				(210, 'Menthol Per Serving', -1, -1),
				(211, 'Pulegone Per Package', -1, -1),
				(212, 'Pulegone Per Serving', -1, -1),
				(213, 'Alpha Humulene', -1, -1),
				(214, 'Alpha Humulene Per Package', -1, -1),
				(215, 'Alpha Humulene Per Serving', -1, -1),
				(216, 'Trans Caryophyllene', -1, -1),
				(217, 'Trans Caryophyllene Per Package', -1, -1),
				(218, 'Trans Caryophyllene Per Serving', -1, -1)
		) t(id_chemical_profile, name, id_user_created, id_user_updated)
	)
	MERGE [inventory].[chemical_profile] t USING list s
	ON t.id_chemical_profile=s.id_chemical_profile
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_chemical_profile, name, id_user_created, id_user_updated) VALUES (s.id_chemical_profile, s.name, -1, -1)
	;


	SET IDENTITY_INSERT [inventory].[chemical_profile] OFF 




	/******************************************************************************************** INVENTORY:	Delivery Route */


	SET IDENTITY_INSERT [inventory].[delivery_route] ON 

	;WITH list AS (
		SELECT * FROM (VALUES
			(-1, 'N/A',					NULL,1),
			(1, 'Dried Marijuana',		NULL,1),
			(2, 'Bulk Flower',			1,1),
			(3, 'Whole Flower',			1,1),
			(4, 'Pre-Roll',				1,1),
			(5, 'Edible',				NULL,1),
			(6, 'Solid Form',			5,1),
			(7, 'Liquid Form',			5,1),
			(8, 'Concentrate',			NULL,1),
			(10, 'Extract',				8,1),
			(11, 'Immature Plant',		NULL,1),
			(12, 'Seed',				NULL,1),
			(13, 'Topical',				29,1),
			(14, 'Other',				NULL,1),
			(29, 'Non-Edible',			NULL,1),
			(30, 'Solid Form',			29,1),
			(31, 'Liquid Form',			29,1),
			(32, 'Infused Flower',	NULL,1)
		) t(id_delivery_route, name, id_parent, route_version)
	)
	MERGE [inventory].[delivery_route] t USING list s
	ON t.id_delivery_route=s.id_delivery_route
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name, t.id_parent=s.id_parent
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_delivery_route,name,id_parent,route_version) VALUES (s.id_delivery_route, s.name, s.id_parent, s.route_version)
	;

	SET IDENTITY_INSERT [inventory].[delivery_route] OFF


	/******************************************************************************************** INVENTORY:	Biotrack Inventory Types */



	IF (@is_move_client = 0)
	BEGIN
		;WITH list AS (
			SELECT * FROM (VALUES
				(0, 'Vegetation Trim', 1, NULL, NULL, 0),
				(1, 'Trim', 1, NULL, NULL, 0),
				(2, 'Stems', 1, NULL, NULL, 0),
				(3, 'Sugar Leaf', 1, NULL, NULL, 0),
				(4, 'Shake', 1, NULL, NULL, 0),
				(5, 'Kief', 3, NULL, NULL, 1),
				(6, 'Flower', 3, NULL, NULL, 1),
				(7, 'Clone', 2, NULL, NULL, 0),
				(8, 'Fan Leaf', 3, NULL, NULL, 0),
				(9, 'Other Material', 14, NULL, NULL, 1),
				(10, 'Seed', 12, NULL, NULL, 0),
				(11, 'Plant Tissue', 11, NULL, NULL, 0),
				(12, 'Mature PLant', 11, NULL, NULL, 0),
				(13, 'Flower Lot', 3, NULL, NULL, 1),
				(14, 'Other Material Lot', 3, NULL, NULL, 1),
				(15, 'Bubble Hash', 8, NULL, NULL, 1),
				(16, 'Hash', 2, NULL, NULL, 1),
				(17, 'Hydrocarbon Wax', 8, NULL, NULL, 1),
				(18, 'CO2 Hash Oil', 7, NULL, NULL, 1),
				(19, 'Food Grade Solvent Extract', 5, NULL, NULL, 1),
				(20, 'Infused Dairy Butter or Fat in Solid Form', 5, NULL, NULL, 1),
				(21, 'Infused Cooking Oil', 5, NULL, NULL, 1),
				(22, 'Solid Marijuana Infused Edible', 6, NULL, NULL, 0),
				(23, 'Liquid Marijuana Infused Edible', 7, NULL, NULL, 0),
				(24, 'Marijuana Extract for Inhalation', 10, NULL, NULL, 0),
				(25, 'Marijuana Infused Topicals', 7, NULL, NULL, 0),
				(26, 'Sample Jar', 1, NULL, NULL, 0),
				(27, 'Waste', 14, NULL, NULL, 1),
				(28, 'Usable Marijuana', 1, NULL, NULL, 0),
				(29, 'Wet Flower', 1, NULL, NULL, 0),
				(30, 'Marijuana Mix', 1, NULL, NULL, 1),
				(31, 'Marijuana Mix Packaged', 1, NULL, NULL, 0),
				(32, 'Marijuana Mix Infused', 32, NULL, NULL, 0),
				(34, 'Capsule/Pill/Tablet', 1, NULL, NULL, 0),
				(35, 'Tincture', 1, NULL, NULL, 0),
				(36, 'Transdermal', 1, NULL, NULL, 0),
				(42, 'Ethanol/Alcohol Extract', 1, NULL, NULL, 0),
				(45, 'Liquid Marijuana RSO', 10, NULL, NULL, 0),
				(46, 'CO2 Extract', 1, NULL, NULL, 0),
				(65, 'Pressed Extract', 1, NULL, NULL, 0),
				(66, 'Transmucosal Infused Extract', 1, NULL, NULL, 0),
				(67, 'Rosin/Resin', 1, NULL, NULL, 0),
				(68, 'Whole Flower', 1, NULL, NULL, 0),
				(69, 'Kief', 1, NULL, NULL, 0),
				(72, 'Delivery Device', 1, NULL, NULL, 0),
				(73, 'Usable Prerolled Cannabis', 1, NULL, NULL, 0),
				(74, 'Mechanical Extract', 1, NULL, NULL, 0),
				(75, 'Other Non-Volitile Solvent Extract', 1, NULL, NULL, 0)
			) t(id_inventory_type, name, delivery_route_id, date_created, date_updated, requires_weighing)
		)
		MERGE [biotrack].[inventory_type] t USING list s
		ON t.id_inventory_type=s.id_inventory_type
		WHEN MATCHED THEN UPDATE
			SET t.name=s.name, t.id_inventory_type=s.id_inventory_type, t.delivery_route_id=s.delivery_route_id, t.date_updated=GETUTCDATE(), t.requires_weighing=s.requires_weighing
		WHEN NOT MATCHED BY TARGET THEN 
			INSERT (id_inventory_type, name, delivery_route_id, date_updated, requires_weighing) VALUES (s.id_inventory_type, s.name, s.delivery_route_id, GETUTCDATE(), s.requires_weighing)
		;
	END



	/******************************************************************************************** INVENTORY:	Item category */


	SET IDENTITY_INSERT [inventory].[category] ON	

	SELECT * INTO #inventory_category FROM (VALUES
			(1, 'Uncategorized', 1),
			(1000, 'Raw Material', 1)
		) t(id_category, name, system)
	WHERE LOWER(t.[name]) NOT IN (SELECT LOWER([name]) FROM inventory.category)
	
	MERGE [inventory].[category] t USING #inventory_category s
	ON t.id_category=s.id_category
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_category, name, system, updated_by) VALUES (s.id_category, s.name, 1, -1);

	SET IDENTITY_INSERT [inventory].[category] OFF 




	/******************************************************************************************** INVENTORY:	Refuse Reason */


	SET IDENTITY_INSERT [inventory].[refuse_reason] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
				(1, 'Damaged goods',	1),
				(2, 'Expired',			1),
				(3, 'Other',			1)
		) t(id_refuse_reason, name, system)
	)
	MERGE [inventory].[refuse_reason] t USING list s
	ON t.id_refuse_reason=s.id_refuse_reason
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_refuse_reason, name, system) VALUES (s.id_refuse_reason, s.name, 1)
	;


	SET IDENTITY_INSERT [inventory].[refuse_reason] OFF 




	/******************************************************************************************** INVENTORY:	Scrap Reason */


	SET IDENTITY_INSERT [inventory].[scrap_reason] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1000, 'Expired',	1),
			(1001, 'Other',		1)
		) t(id_scrap_reason, name, system)
	)
	MERGE [inventory].[scrap_reason] t USING list s
	ON t.id_scrap_reason=s.id_scrap_reason
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_scrap_reason, name, system) VALUES (s.id_scrap_reason, s.name, 1)
	;


	SET IDENTITY_INSERT [inventory].[scrap_reason] OFF 




	/******************************************************************************************** INVENTORY:	Status */


	SET IDENTITY_INSERT [inventory].[status] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'open'),
			(2, 'qc_hold'),
			(3, 'closed')
		) t(id_status, name)
	)
	MERGE [inventory].[status] t USING list s
	ON t.id_status=s.id_status
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_status,name) VALUES (s.id_status, s.name)
	;


	SET IDENTITY_INSERT [inventory].[status] OFF 




	/******************************************************************************************** INVENTORY:	Transfer Status */


	SET IDENTITY_INSERT [inventory].[transfer_status] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			   (1, 'Pending Transfer',	'pending',		1),
			   (2, 'Packed/Verified',	'packed',		2),
			   (3, 'In Transit',		'in_transit',	3),
			   (4, 'Received',			'received',		4),
			   (5, 'Shipped',			'shipped',		5),
			   (6, 'Cancelled',			'cancelled',	6)
		) t(id_transfer_status, name, reference, sequence)
	)
	MERGE [inventory].[transfer_status] t USING list s
	ON t.id_transfer_status=s.id_transfer_status
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name, t.reference=s.reference
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_transfer_status, name, reference, sequence) VALUES (s.id_transfer_status, s.name, s.reference, s.sequence)
	;


	SET IDENTITY_INSERT [inventory].[transfer_status] OFF 




	/******************************************************************************************** INVENTORY:	UOM */


	SET IDENTITY_INSERT [inventory].[uom] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'Each', 'ea', 'count', 1),
			(2, 'Grams', 'g', 'weight', 1),
			(3, 'Kilograms', 'kg', 'weight', 1),
			(4, 'Milligrams', 'mg', 'weight', 1),
			(5, 'Ounces', 'oz', 'weight', 1),
			(6, 'Pounds', 'lb', 'weight', 1),
			(7, 'Fluid Ounces', 'fl oz', 'volume', 1),
			(8, 'Liters', 'L', 'volume', 1),
			(9, 'Milliliters', 'mL', 'volume', 1),
			(10, 'Gallons', 'gal', 'volume', 1),
			(11, 'Pints', 'pt', 'volume', 1),
			(12, 'Quarts', 'q', 'volume', 1)
		) t(id_uom, name, name_short, quantity_type, system)
	)
	MERGE [inventory].[uom] t USING list s
	ON t.id_uom=s.id_uom
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
			, t.name_short=s.name_short
			, t.quantity_type=s.quantity_type
			, t.system=1
			, t.deleted=0
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_uom, name, name_short, quantity_type, system, id_user_created, id_user_updated) 
		VALUES (s.id_uom, s.name, s.name_short, quantity_type, 1, -1, -1)
	;

	SET IDENTITY_INSERT [inventory].[uom] OFF 




	/******************************************************************************************** INVENTORY:	UOM Convert */

	;WITH list AS (
		SELECT * FROM (VALUES 
			/* weight-based. */
			(2, 2, 1.00000000),		-- Grams to Grams
			(2, 3, 0.00100000),		-- Grams to Kilograms
			(2, 4, 1000.00000000),		-- Grams to Milligrams
			(2, 5, 0.03527400),		-- Grams to Ounces
			(2, 6, 0.00220462),		-- Grams to Pounds
			(3, 2, 1000.00000000),		-- Kilograms to Grams
			(3, 3, 1.00000000),		-- Kilograms to Kilograms
			(3, 4, 1000000.00000000),		-- Kilograms to Milligrams
			(3, 5, 35.27400000),		-- Kilograms to Ounces
			(3, 6, 2.20462000),		-- Kilograms to Pounds
			(4, 2, 0.00100000),		-- Milligrams to Grams
			(4, 3, 0.00000100),		-- Milligrams to Kilograms
			(4, 4, 1.00000000),		-- Milligrams to Milligrams
			(4, 5, 0.00003527),		-- Milligrams to Ounces
			(4, 6, 0.00000220),		-- Milligrams to Pounds
			(5, 2, 28.34950000),		-- Ounces to Grams
			(5, 3, 0.02834950),		-- Ounces to Kilograms
			(5, 4, 28349.50000000),		-- Ounces to Milligrams
			(5, 5, 1.00000000),		-- Ounces to Ounces
			(5, 6, 0.06250000),		-- Ounces to Pounds
			(6, 2, 453.59200000),		-- Pounds to Grams
			(6, 3, 0.45359200),		-- Pounds to Kilograms
			(6, 4, 453592.00000000),		-- Pounds to Milligrams
			(6, 5, 16.00000000),		-- Pounds to Ounces
			(6, 6, 1.00000000),		-- Pounds to Pounds
			/* volume-based. */
			(7, 7, 1.00000000),		-- Fluid Ounces to Fluid Ounces
			(7, 8, 0.02957350),		-- Fluid Ounces to Liters
			(7, 9, 29.57350000),		-- Fluid Ounces to Milliliters
			(7, 10, 0.00781250),		-- Fluid Ounces to Gallons
			(7, 11, 0.06250000),		-- Fluid Ounces to Pints
			(7, 12, 0.03125000),		-- Fluid Ounces to Quarts
			(8, 7, 33.81400000),		-- Liters to Fluid Ounces
			(8, 8, 1.00000000),		-- Liters to Liters
			(8, 9, 1000.00000000),		-- Liters to Milliliters
			(8, 10, 0.26417200),		-- Liters to Gallons
			(8, 11, 2.11338000),		-- Liters to Pints
			(8, 12, 1.05669000),		-- Liters to Quarts
			(9, 7, 0.03381400),		-- Milliliters to Fluid Ounces
			(9, 8, 0.00100000),		-- Milliliters to Liters
			(9, 9, 1.00000000),		-- Milliliters to Milliliters
			(9, 10, 0.00026417),		-- Milliliters to Gallons
			(9, 11, 0.00211338),		-- Milliliters to Pints
			(9, 12, 0.00105669),		-- Milliliters to Quarts
			(10, 7, 128.00000000),		-- Gallons to Fluid Ounces
			(10, 8, 3.78541000),		-- Gallons to Liters
			(10, 9, 3785.41000000),		-- Gallons to Milliliters
			(10, 10, 1.00000000),		-- Gallons to Gallons
			(10, 11, 8.00000000),		-- Gallons to Pints
			(10, 12, 4.00000000),		-- Gallons to Quarts
			(11, 7, 16.00000000),		-- Pints to Fluid Ounces
			(11, 8, 0.47317600),		-- Pints to Liters
			(11, 9, 473.17600000),		-- Pints to Milliliters
			(11, 10, 0.12500000),		-- Pints to Gallons
			(11, 11, 1.00000000),		-- Pints to Pints
			(11, 12, 0.50000000),		-- Pints to Quarts
			(12, 7, 32.00000000),		-- Quarts to Fluid Ounces
			(12, 8, 0.94635300),		-- Quarts to Liters
			(12, 9, 946.35300000),		-- Quarts to Milliliters
			(12, 10, 0.25000000),		-- Quarts to Gallons
			(12, 11, 2.00000000),		-- Quarts to Pints
			(12, 12, 1.00000000)		-- Quarts to Quarts
		)t(id_uom_from, id_uom_to, multiplier)
	)
	MERGE [inventory].[uom_convert] t USING list s
	ON t.id_uom_from=s.id_uom_from AND t.id_uom_to=s.id_uom_to
	WHEN MATCHED THEN UPDATE
		SET t.multiplier=s.multiplier, t.system=1
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_uom_from, id_uom_to, multiplier, system) 
		VALUES (s.id_uom_from, s.id_uom_to, s.multiplier, 1)
	;


	/******************************************************************************************** OMMU:	Delivery State */


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'Not Delivered', -1, -1),
			(2, 'Delivered', -1, -1),
			(3, 'Failed', -1, -1)
		) t(id_delivery_state, name, created_by, updated_by)
	)
	MERGE [ommu].[delivery_state] t USING list s
	ON t.id_delivery_state=s.id_delivery_state
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_delivery_state, name, created_by, updated_by) VALUES (s.id_delivery_state, s.name, s.created_by, updated_by)
	;

	
	/******************************************************************************************** OMMU:	Forms */


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'Oral', -1, -1),
			(2, 'Topical', -1, -1),
			(3, 'Sublingual', -1, -1),
			(4, 'Inhalation', -1, -1),
			(5, 'Suppository', -1, -1),
			(6, 'Smoking', -1, -1),
			(7, 'Edibles', -1, -1),
			(8, 'Oral/Sublingual', -1, -1),
			(9, 'Oral/Inhalation', -1, -1)
		) t(id_form, name, created_by, updated_by)
	)
	MERGE [ommu].[form] t USING list s
	ON t.id_form=s.id_form
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_form, name, created_by, updated_by) VALUES (s.id_form, s.name, s.created_by, updated_by)
	;


	/******************************************************************************************** OMMU:	Order Status */


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'Open', -1, -1),
			(2, 'Completed', -1, -1),
			(3, 'Cancelled', -1, -1),
			(4, 'Expired', -1, -1),
			(5, 'Scheduled', -1, -1)
		) t(id_order_status, name, created_by, updated_by)
	)
	MERGE [ommu].[order_status] t USING list s
	ON t.id_order_status=s.id_order_status
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_order_status, name, created_by, updated_by) VALUES (s.id_order_status, s.name, s.created_by, updated_by)
	;
	

	/******************************************************************************************** OMMU:	Order Type */
	

	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'Low-THC Cannabis', -1, -1),
			(2, 'Medical Cannabis', -1, -1),
			(3, 'Smoking', -1, -1)
		) t(id_order_type, name, created_by, updated_by)
	)
	MERGE [ommu].[order_type] t USING list s
	ON t.id_order_type=s.id_order_type
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_order_type, name, created_by, updated_by) VALUES (s.id_order_type, s.name, s.created_by, updated_by)
	;


	/******************************************************************************************** BIOTRACK:	Forms */


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'Oral', -1, -1),
			(2, 'Topical', -1, -1),
			(3, 'Sublingual', -1, -1),
			(4, 'Inhalation', -1, -1),
			(5, 'Suppository', -1, -1),
			(6, 'Smoking', -1, -1),
			(7, 'Edibles', -1, -1)
		) t(id_form, name, created_by, updated_by)
	)
	MERGE [biotrack].[order_form] t USING list s
	ON t.id_form=s.id_form
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_form, name, created_by, updated_by) VALUES (s.id_form, s.name, s.created_by, updated_by)
	;


	/******************************************************************************************** BIOTRACK:	Order Type */
	

	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'Low-THC Cannabis', -1, -1),
			(2, 'Medical Cannabis', -1, -1),
			(3, 'Smoking', -1, -1)
		) t(id_order_type, name, created_by, updated_by)
	)
	MERGE [biotrack].[order_type] t USING list s
	ON t.id_order_type=s.id_order_type
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_order_type, name, created_by, updated_by) VALUES (s.id_order_type, s.name, s.created_by, updated_by)
	;


	/******************************************************************************************** BIOTRACK:	FL Dispensation Routes */
	

	;WITH list AS (
		SELECT * FROM (VALUES
			(34, 1, -1, -1),
			(35, 1, -1, -1),
			(45, 1, -1, -1),
			(67, 1, -1, -1),
			(25, 2, -1, -1),
			(36, 2, -1, -1),
			(45, 2, -1, -1),
			(66, 2, -1, -1),
			(35, 3, -1, -1),
			(45, 3, -1, -1),
			(5, 4, -1, -1),
			(24, 4, -1, -1),
			(67, 4, -1, -1),
			(66, 5, -1, -1),
			(5, 6, -1, -1),
			(68, 6, -1, -1),
			(22, 7, -1, -1),
			(72, 1, -1, -1),
			(72, 2, -1, -1),
			(72, 3, -1, -1),
			(72, 4, -1, -1),
			(72, 5, -1, -1),
			(72, 6, -1, -1),
			(72, 7, -1, -1)
		) t(id_inventory_type, id_form, created_by, updated_by)
	)
	MERGE [biotrack].[fl_dispensation_route] t USING list s
	ON t.id_inventory_type=s.id_inventory_type AND t.id_form=s.id_form
	WHEN MATCHED THEN UPDATE
		SET  t.id_inventory_type=s.id_inventory_type, t.id_form=s.id_form
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_inventory_type, id_form, created_by, updated_by) VALUES (s.id_inventory_type, s.id_form, s.created_by, updated_by)
	;


	/******************************************************************************************** ORDER:	Sale Type */


	SET IDENTITY_INSERT [order].[sale_type] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'Retail',	'retail'),
			(2, 'Pickup',	'pickup'),
			(3, 'Delivery', 'delivery')
		) t(id_sale_type, name, reference)
	)
	MERGE [order].[sale_type] t USING list s
	ON t.id_sale_type=s.id_sale_type
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_sale_type, name, reference) VALUES (s.id_sale_type, s.name, s.reference)
	;


	SET IDENTITY_INSERT [order].[sale_type] OFF 


	/******************************************************************************************** ORDER:	Status */


	SET IDENTITY_INSERT [order].[status] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'New',			1),
			(2, 'Processing',	1),
			(3, 'Cancelled',	1),
			(4, 'Completed',	1)
		) t(id_status, name, system)
	)
	MERGE [order].[status] t USING list s
	ON t.id_status=s.id_status
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name, t.system=s.system
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_status, name, system) VALUES (s.id_status, s.name, 1)
	;


	SET IDENTITY_INSERT [order].[status] OFF 


	/******************************************************************************************** CUSTOMER:	Type */

	
	INSERT [order].[customer_type] ([name],[system],created_by, updated_by)
	SELECT 'Caregiver', 1, -1,-1 WHERE LOWER('Caregiver') NOT IN (SELECT [name] FROM [order].[customer_type] WHERE LOWER([name]) = 'caregiver')
	
	INSERT [order].[customer_type] ([name],[system],created_by, updated_by)
	SELECT 'Employee', 1, -1,-1 WHERE LOWER('Employee') NOT IN (SELECT [name] FROM [order].[customer_type] WHERE LOWER([name]) = 'employee')

	UPDATE [order].[customer_type]
	SET [system] = 1
	WHERE [name] IN ('Caregiver','Employee')

	/******************************************************************************************** PROCESS:	Production Component Type */

	SET IDENTITY_INSERT [process].[production_component_type] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'component'),
			(2, 'waste')
		) t(id_production_component_type, name)
	)
	MERGE [process].[production_component_type] t USING list s
	ON t.id_production_component_type=s.id_production_component_type
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_production_component_type,name) VALUES (s.id_production_component_type, s.name)
	;


	SET IDENTITY_INSERT [process].[production_component_type] OFF 




	/******************************************************************************************** PROCESS:	Status */


	SET IDENTITY_INSERT [process].[status] ON 


	;WITH list AS (
		SELECT * FROM (VALUES
			(1, 'Ready', 'ready'),
			(2, 'In-Progress', 'in-progress'),
			(3, 'Complete', 'complete'),
			(4, 'Abandoned', 'cancelled')
		) t(id_status, name, reference)
	)
	MERGE [process].[status] t USING list s
	ON t.id_status=s.id_status
	WHEN MATCHED THEN UPDATE
		SET t.name=s.name, t.reference=s.reference
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_status,name,reference) VALUES (s.id_status, s.name, s.reference)
	;


	SET IDENTITY_INSERT [process].[status] OFF


	/******************************************************************************************** ORDER:  Ride Status */
	SET identity_insert [order].[ecommerce_ride_status] ON;
	
	WITH ride_status_cte as 
	(
		SELECT * FROM (
			VALUES
			(1000,'express_delivery_start_ride','In Transit','In Transit'),
			(1001,'order_create','Order placed','Upcoming'),
			(1002,'driver_accepted','Processing','Processing'),
			(1003,'driver_pickup','Picked up by the driver','In Transit'),
			(1004,'delivered','Delivered','Delivered'),
			(1005,'order_verified','Order verified','Order verified'),
			(1006,'order_scheduled','Order scheduled','Order scheduled'),
			(1007,'order_packed','Order packed','Order packed'),
			(1008,'delivery_aborted','Unable to delivery','Aborted'),
			(1009,'failed_delivery','Failed Delivery','Undelivered')
		)x([id_status], [reference], [customer_message], [driver_message])
	)
	MERGE [order].[ecommerce_ride_status] as t
	USING ride_status_cte as s ON t.id_status = s.id_status
	WHEN MATCHED THEN UPDATE
	SET
		 t.reference = s.reference
		,t.customer_message = s.customer_message
		,t.driver_message = s.driver_message
	WHEN NOT MATCHED THEN INSERT (id_status, reference, customer_message, driver_message)
	VALUES(s.id_status, s.reference, s.customer_message, s.driver_message);
	SET identity_insert [order].[ecommerce_ride_status] OFF;


	/******************************************************************************************** DISCOUNT:	Discount Types */


	MERGE [discount].[discount_types] as t
	USING (SELECT x.* FROM (VALUES
	('Cart Adjustment','Simple','cart_adjustments',1,GETUTCDATE(),GETUTCDATE()),
	('Product Adjustment','Simple','product_adjustments',1,GETUTCDATE(),GETUTCDATE()),
	('Bulk Product Discount','Bulk','bulk_adjustments',1,GETUTCDATE(),GETUTCDATE()),
	('Bundled Items Discount','Bulk','set_adjustments',1,GETUTCDATE(),GETUTCDATE()),
	('Buy X get Y','BOGO','buy_x_get_y_adjustments',1,GETUTCDATE(),GETUTCDATE()),
	('Buy X get X','BOGO','buy_x_get_x_adjustments',1,GETUTCDATE(),GETUTCDATE()),
	('Bundled Items Discount (item)','Bulk','set_adjustments_item',0,GETUTCDATE(),GETUTCDATE())
	)x([name], [category], [columnName], [enabled], [createdAt], [updatedAt])) as s
	ON  t.name = s.name AND 
		t.category = s.category AND
		t.columnName = s.columnName
	WHEN MATCHED THEN UPDATE
	SET 
		t.[enabled] = s.[enabled]
	WHEN NOT MATCHED BY TARGET THEN INSERT ([name], [category], [columnName], [enabled], [createdAt], [updatedAt])
	VALUES(s.[name], s.[category], s.[columnName], s.[enabled], GETUTCDATE(), GETUTCDATE());


	/* add IANA-to-Windows timezone lookup values. */
	IF NOT EXISTS (SELECT * FROM [dbo].[tz_lookup])
	INSERT INTO [dbo].[tz_lookup] (tz_iana, tz_windows) VALUES
	('Africa/Abidjan','Greenwich Standard Time'),
	('Africa/Accra','Greenwich Standard Time'),
	('Africa/Addis_Ababa','E. Africa Standard Time'),
	('Africa/Algiers','W. Central Africa Standard Time'),
	('Africa/Asmera','E. Africa Standard Time'),
	('Africa/Bamako','Greenwich Standard Time'),
	('Africa/Bangui','W. Central Africa Standard Time'),
	('Africa/Banjul','Greenwich Standard Time'),
	('Africa/Bissau','Greenwich Standard Time'),
	('Africa/Blantyre','South Africa Standard Time'),
	('Africa/Brazzaville','W. Central Africa Standard Time'),
	('Africa/Bujumbura','South Africa Standard Time'),
	('Africa/Cairo','Egypt Standard Time'),
	('Africa/Casablanca','Morocco Standard Time'),
	('Africa/Ceuta','Romance Standard Time'),
	('Africa/Conakry','Greenwich Standard Time'),
	('Africa/Dakar','Greenwich Standard Time'),
	('Africa/Dar_es_Salaam','E. Africa Standard Time'),
	('Africa/Djibouti','E. Africa Standard Time'),
	('Africa/Douala','W. Central Africa Standard Time'),
	('Africa/El_Aaiun','Morocco Standard Time'),
	('Africa/Freetown','Greenwich Standard Time'),
	('Africa/Gaborone','South Africa Standard Time'),
	('Africa/Harare','South Africa Standard Time'),
	('Africa/Johannesburg','South Africa Standard Time'),
	('Africa/Juba','E. Africa Standard Time'),
	('Africa/Kampala','E. Africa Standard Time'),
	('Africa/Khartoum','Sudan Standard Time'),
	('Africa/Kigali','South Africa Standard Time'),
	('Africa/Kinshasa','W. Central Africa Standard Time'),
	('Africa/Lagos','W. Central Africa Standard Time'),
	('Africa/Libreville','W. Central Africa Standard Time'),
	('Africa/Lome','Greenwich Standard Time'),
	('Africa/Luanda','W. Central Africa Standard Time'),
	('Africa/Lubumbashi','South Africa Standard Time'),
	('Africa/Lusaka','South Africa Standard Time'),
	('Africa/Malabo','W. Central Africa Standard Time'),
	('Africa/Maputo','South Africa Standard Time'),
	('Africa/Maseru','South Africa Standard Time'),
	('Africa/Mbabane','South Africa Standard Time'),
	('Africa/Mogadishu','E. Africa Standard Time'),
	('Africa/Monrovia','Greenwich Standard Time'),
	('Africa/Nairobi','E. Africa Standard Time'),
	('Africa/Ndjamena','W. Central Africa Standard Time'),
	('Africa/Niamey','W. Central Africa Standard Time'),
	('Africa/Nouakchott','Greenwich Standard Time'),
	('Africa/Ouagadougou','Greenwich Standard Time'),
	('Africa/Porto-Novo','W. Central Africa Standard Time'),
	('Africa/Sao_Tome','Sao Tome Standard Time'),
	('Africa/Tripoli','Libya Standard Time'),
	('Africa/Tunis','W. Central Africa Standard Time'),
	('Africa/Windhoek','Namibia Standard Time'),
	('America/Adak','Aleutian Standard Time'),
	('America/Anchorage','Alaskan Standard Time'),
	('America/Anguilla','SA Western Standard Time'),
	('America/Antigua','SA Western Standard Time'),
	('America/Araguaina','Tocantins Standard Time'),
	('America/Argentina/Buenos_Aires','Argentina Standard Time'),
	('America/Argentina/Catamarca','Argentina Standard Time'),
	('America/Argentina/Cordoba','Argentina Standard Time'),
	('America/Argentina/Jujuy','Argentina Standard Time'),
	('America/Argentina/La_Rioja','Argentina Standard Time'),
	('America/Argentina/Mendoza','Argentina Standard Time'),
	('America/Argentina/Rio_Gallegos','Argentina Standard Time'),
	('America/Argentina/Salta','Argentina Standard Time'),
	('America/Argentina/San_Juan','Argentina Standard Time'),
	('America/Argentina/San_Luis','Argentina Standard Time'),
	('America/Argentina/Tucuman','Argentina Standard Time'),
	('America/Argentina/Ushuaia','Argentina Standard Time'),
	('America/Aruba','SA Western Standard Time'),
	('America/Asuncion','Paraguay Standard Time'),
	('America/Atikokan','SA Pacific Standard Time'),
	('America/Bahia','Bahia Standard Time'),
	('America/Bahia_Banderas','Central Standard Time (Mexico)'),
	('America/Barbados','SA Western Standard Time'),
	('America/Belem','SA Eastern Standard Time'),
	('America/Belize','Central America Standard Time'),
	('America/Blanc-Sablon','SA Western Standard Time'),
	('America/Boa_Vista','SA Western Standard Time'),
	('America/Bogota','SA Pacific Standard Time'),
	('America/Boise','Mountain Standard Time'),
	('America/Buenos_Aires','Argentina Standard Time'),
	('America/Cambridge_Bay','Mountain Standard Time'),
	('America/Campo_Grande','Central Brazilian Standard Time'),
	('America/Cancun','Eastern Standard Time (Mexico)'),
	('America/Caracas','Venezuela Standard Time'),
	('America/Catamarca','Argentina Standard Time'),
	('America/Cayenne','SA Eastern Standard Time'),
	('America/Cayman','SA Pacific Standard Time'),
	('America/Chicago','Central Standard Time'),
	('America/Chihuahua','Mountain Standard Time (Mexico)'),
	('America/Coral_Harbour','SA Pacific Standard Time'),
	('America/Cordoba','Argentina Standard Time'),
	('America/Costa_Rica','Central America Standard Time'),
	('America/Creston','US Mountain Standard Time'),
	('America/Cuiaba','Central Brazilian Standard Time'),
	('America/Curacao','SA Western Standard Time'),
	('America/Danmarkshavn','UTC'),
	('America/Dawson','Pacific Standard Time'),
	('America/Dawson_Creek','US Mountain Standard Time'),
	('America/Denver','Mountain Standard Time'),
	('America/Detroit','Eastern Standard Time'),
	('America/Dominica','SA Western Standard Time'),
	('America/Edmonton','Mountain Standard Time'),
	('America/Eirunepe','SA Pacific Standard Time'),
	('America/El_Salvador','Central America Standard Time'),
	('America/Fort_Nelson','US Mountain Standard Time'),
	('America/Fortaleza','SA Eastern Standard Time'),
	('America/Glace_Bay','Atlantic Standard Time'),
	('America/Godthab','Greenland Standard Time'),
	('America/Goose_Bay','Atlantic Standard Time'),
	('America/Grand_Turk','Turks And Caicos Standard Time'),
	('America/Grenada','SA Western Standard Time'),
	('America/Guadeloupe','SA Western Standard Time'),
	('America/Guatemala','Central America Standard Time'),
	('America/Guayaquil','SA Pacific Standard Time'),
	('America/Guyana','SA Western Standard Time'),
	('America/Halifax','Atlantic Standard Time'),
	('America/Havana','Cuba Standard Time'),
	('America/Hermosillo','US Mountain Standard Time'),
	('America/Indiana/Indianapolis','US Eastern Standard Time'),
	('America/Indiana/Knox','Central Standard Time'),
	('America/Indiana/Marengo','US Eastern Standard Time'),
	('America/Indiana/Petersburg','Eastern Standard Time'),
	('America/Indiana/Tell_City','Central Standard Time'),
	('America/Indiana/Vevay','US Eastern Standard Time'),
	('America/Indiana/Vincennes','Eastern Standard Time'),
	('America/Indiana/Winamac','Eastern Standard Time'),
	('America/Indianapolis','US Eastern Standard Time'),
	('America/Inuvik','Mountain Standard Time'),
	('America/Iqaluit','Eastern Standard Time'),
	('America/Jamaica','SA Pacific Standard Time'),
	('America/Jujuy','Argentina Standard Time'),
	('America/Juneau','Alaskan Standard Time'),
	('America/Kentucky/Louisville','Eastern Standard Time'),
	('America/Kentucky/Monticello','Eastern Standard Time'),
	('America/Kralendijk','SA Western Standard Time'),
	('America/La_Paz','SA Western Standard Time'),
	('America/Lima','SA Pacific Standard Time'),
	('America/Los_Angeles','Pacific Standard Time'),
	('America/Louisville','Eastern Standard Time'),
	('America/Lower_Princes','SA Western Standard Time'),
	('America/Maceio','SA Eastern Standard Time'),
	('America/Managua','Central America Standard Time'),
	('America/Manaus','SA Western Standard Time'),
	('America/Marigot','SA Western Standard Time'),
	('America/Martinique','SA Western Standard Time'),
	('America/Matamoros','Central Standard Time'),
	('America/Mazatlan','Mountain Standard Time (Mexico)'),
	('America/Mendoza','Argentina Standard Time'),
	('America/Menominee','Central Standard Time'),
	('America/Merida','Central Standard Time (Mexico)'),
	('America/Metlakatla','Pacific Standard Time'),
	('America/Mexico_City','Central Standard Time (Mexico)'),
	('America/Miquelon','Saint Pierre Standard Time'),
	('America/Moncton','Atlantic Standard Time'),
	('America/Monterrey','Central Standard Time (Mexico)'),
	('America/Montevideo','Montevideo Standard Time'),
	('America/Montreal','Eastern Standard Time'),
	('America/Montserrat','SA Western Standard Time'),
	('America/Nassau','Eastern Standard Time'),
	('America/New_York','Eastern Standard Time'),
	('America/Nipigon','Eastern Standard Time'),
	('America/Nome','Alaskan Standard Time'),
	('America/Noronha','UTC-02'),
	('America/North_Dakota/Beulah','Central Standard Time'),
	('America/North_Dakota/Center','Central Standard Time'),
	('America/North_Dakota/New_Salem','Central Standard Time'),
	('America/Ojinaga','Mountain Standard Time'),
	('America/Panama','SA Pacific Standard Time'),
	('America/Pangnirtung','Eastern Standard Time'),
	('America/Paramaribo','SA Eastern Standard Time'),
	('America/Phoenix','US Mountain Standard Time'),
	('America/Port_of_Spain','SA Western Standard Time'),
	('America/Port-au-Prince','Haiti Standard Time'),
	('America/Porto_Velho','SA Western Standard Time'),
	('America/Puerto_Rico','SA Western Standard Time'),
	('America/Punta_Arenas','Magallanes Standard Time'),
	('America/Rainy_River','Central Standard Time'),
	('America/Rankin_Inlet','Central Standard Time'),
	('America/Recife','SA Eastern Standard Time'),
	('America/Regina','Canada Central Standard Time'),
	('America/Resolute','Central Standard Time'),
	('America/Rio_Branco','SA Pacific Standard Time'),
	('America/Santa_Isabel','Pacific Standard Time (Mexico)'),
	('America/Santarem','SA Eastern Standard Time'),
	('America/Santiago','Pacific SA Standard Time'),
	('America/Santo_Domingo','SA Western Standard Time'),
	('America/Sao_Paulo','E. South America Standard Time'),
	('America/Scoresbysund','Azores Standard Time'),
	('America/Sitka','Alaskan Standard Time'),
	('America/St_Barthelemy','SA Western Standard Time'),
	('America/St_Johns','Newfoundland Standard Time'),
	('America/St_Kitts','SA Western Standard Time'),
	('America/St_Lucia','SA Western Standard Time'),
	('America/St_Thomas','SA Western Standard Time'),
	('America/St_Vincent','SA Western Standard Time'),
	('America/Swift_Current','Canada Central Standard Time'),
	('America/Tegucigalpa','Central America Standard Time'),
	('America/Thule','Atlantic Standard Time'),
	('America/Thunder_Bay','Eastern Standard Time'),
	('America/Tijuana','Pacific Standard Time (Mexico)'),
	('America/Toronto','Eastern Standard Time'),
	('America/Tortola','SA Western Standard Time'),
	('America/Vancouver','Pacific Standard Time'),
	('America/Whitehorse','Pacific Standard Time'),
	('America/Winnipeg','Central Standard Time'),
	('America/Yakutat','Alaskan Standard Time'),
	('America/Yellowknife','Mountain Standard Time'),
	('Antarctica/Casey','W. Australia Standard Time'),
	('Antarctica/Davis','SE Asia Standard Time'),
	('Antarctica/DumontDUrville','West Pacific Standard Time'),
	('Antarctica/Macquarie','Central Pacific Standard Time'),
	('Antarctica/Mawson','West Asia Standard Time'),
	('Antarctica/McMurdo','New Zealand Standard Time'),
	('Antarctica/Palmer','Magallanes Standard Time'),
	('Antarctica/Rothera','SA Eastern Standard Time'),
	('Antarctica/Syowa','E. Africa Standard Time'),
	('Antarctica/Vostok','Central Asia Standard Time'),
	('Arctic/Longyearbyen','W. Europe Standard Time'),
	('Asia/Aden','Arab Standard Time'),
	('Asia/Almaty','Central Asia Standard Time'),
	('Asia/Amman','Jordan Standard Time'),
	('Asia/Anadyr','Russia Time Zone 11'),
	('Asia/Aqtau','West Asia Standard Time'),
	('Asia/Aqtobe','West Asia Standard Time'),
	('Asia/Ashgabat','West Asia Standard Time'),
	('Asia/Atyrau','West Asia Standard Time'),
	('Asia/Baghdad','Arabic Standard Time'),
	('Asia/Bahrain','Arab Standard Time'),
	('Asia/Baku','Azerbaijan Standard Time'),
	('Asia/Bangkok','SE Asia Standard Time'),
	('Asia/Barnaul','Altai Standard Time'),
	('Asia/Beirut','Middle East Standard Time'),
	('Asia/Bishkek','Central Asia Standard Time'),
	('Asia/Brunei','Singapore Standard Time'),
	('Asia/Calcutta','India Standard Time'),
	('Asia/Chita','Transbaikal Standard Time'),
	('Asia/Choibalsan','Ulaanbaatar Standard Time'),
	('Asia/Colombo','Sri Lanka Standard Time'),
	('Asia/Damascus','Syria Standard Time'),
	('Asia/Dhaka','Bangladesh Standard Time'),
	('Asia/Dili','Tokyo Standard Time'),
	('Asia/Dubai','Arabian Standard Time'),
	('Asia/Dushanbe','West Asia Standard Time'),
	('Asia/Famagusta','GTB Standard Time'),
	('Asia/Gaza','West Bank Standard Time'),
	('Asia/Hebron','West Bank Standard Time'),
	('Asia/Ho_Chi_Minh','SE Asia Standard Time'),
	('Asia/Hong_Kong','China Standard Time'),
	('Asia/Hovd','W. Mongolia Standard Time'),
	('Asia/Irkutsk','North Asia East Standard Time'),
	('Asia/Jakarta','SE Asia Standard Time'),
	('Asia/Jayapura','Tokyo Standard Time'),
	('Asia/Jerusalem','Israel Standard Time'),
	('Asia/Kabul','Afghanistan Standard Time'),
	('Asia/Kamchatka','Russia Time Zone 11'),
	('Asia/Karachi','Pakistan Standard Time'),
	('Asia/Kathmandu','Nepal Standard Time'),
	('Asia/Katmandu','Nepal Standard Time'),
	('Asia/Khandyga','Yakutsk Standard Time'),
	('Asia/Kolkata','India Standard Time'),
	('Asia/Krasnoyarsk','North Asia Standard Time'),
	('Asia/Kuala_Lumpur','Singapore Standard Time'),
	('Asia/Kuching','Singapore Standard Time'),
	('Asia/Kuwait','Arab Standard Time'),
	('Asia/Macau','China Standard Time'),
	('Asia/Magadan','Magadan Standard Time'),
	('Asia/Makassar','Singapore Standard Time'),
	('Asia/Manila','Singapore Standard Time'),
	('Asia/Muscat','Arabian Standard Time'),
	('Asia/Nicosia','GTB Standard Time'),
	('Asia/Novokuznetsk','North Asia Standard Time'),
	('Asia/Novosibirsk','N. Central Asia Standard Time'),
	('Asia/Omsk','Omsk Standard Time'),
	('Asia/Oral','West Asia Standard Time'),
	('Asia/Phnom_Penh','SE Asia Standard Time'),
	('Asia/Pontianak','SE Asia Standard Time'),
	('Asia/Pyongyang','North Korea Standard Time'),
	('Asia/Qatar','Arab Standard Time'),
	('Asia/Qostanay','Central Asia Standard Time'),
	('Asia/Qyzylorda','Qyzylorda Standard Time'),
	('Asia/Rangoon','Myanmar Standard Time'),
	('Asia/Riyadh','Arab Standard Time'),
	('Asia/Saigon','SE Asia Standard Time'),
	('Asia/Sakhalin','Sakhalin Standard Time'),
	('Asia/Samarkand','West Asia Standard Time'),
	('Asia/Seoul','Korea Standard Time'),
	('Asia/Shanghai','China Standard Time'),
	('Asia/Singapore','Singapore Standard Time'),
	('Asia/Srednekolymsk','Russia Time Zone 10'),
	('Asia/Taipei','Taipei Standard Time'),
	('Asia/Tashkent','West Asia Standard Time'),
	('Asia/Tbilisi','Georgian Standard Time'),
	('Asia/Tehran','Iran Standard Time'),
	('Asia/Thimphu','Bangladesh Standard Time'),
	('Asia/Tokyo','Tokyo Standard Time'),
	('Asia/Tomsk','Tomsk Standard Time'),
	('Asia/Ulaanbaatar','Ulaanbaatar Standard Time'),
	('Asia/Urumqi','China Standard Time'),
	('Asia/Ust-Nera','Vladivostok Standard Time'),
	('Asia/Vientiane','SE Asia Standard Time'),
	('Asia/Vladivostok','Vladivostok Standard Time'),
	('Asia/Yakutsk','Yakutsk Standard Time'),
	('Asia/Yangon','Myanmar Standard Time'),
	('Asia/Yekaterinburg','Ekaterinburg Standard Time'),
	('Asia/Yerevan','Caucasus Standard Time'),
	('Atlantic/Azores','Azores Standard Time'),
	('Atlantic/Bermuda','Atlantic Standard Time'),
	('Atlantic/Canary','GMT Standard Time'),
	('Atlantic/Cape_Verde','Cape Verde Standard Time'),
	('Atlantic/Faeroe','GMT Standard Time'),
	('Atlantic/Faroe','GMT Standard Time'),
	('Atlantic/Madeira','GMT Standard Time'),
	('Atlantic/Reykjavik','Greenwich Standard Time'),
	('Atlantic/South_Georgia','UTC-02'),
	('Atlantic/St_Helena','Greenwich Standard Time'),
	('Atlantic/Stanley','SA Eastern Standard Time'),
	('Australia/Adelaide','Cen. Australia Standard Time'),
	('Australia/Brisbane','E. Australia Standard Time'),
	('Australia/Broken_Hill','Cen. Australia Standard Time'),
	('Australia/Currie','Tasmania Standard Time'),
	('Australia/Darwin','AUS Central Standard Time'),
	('Australia/Eucla','Aus Central W. Standard Time'),
	('Australia/Hobart','Tasmania Standard Time'),
	('Australia/Lindeman','E. Australia Standard Time'),
	('Australia/Lord_Howe','Lord Howe Standard Time'),
	('Australia/Melbourne','AUS Eastern Standard Time'),
	('Australia/Perth','W. Australia Standard Time'),
	('Australia/Sydney','AUS Eastern Standard Time'),
	('CST6CDT','Central Standard Time'),
	('EST5EDT','Eastern Standard Time'),
	('Etc/GMT','UTC'),
	('Etc/GMT+1','Cape Verde Standard Time'),
	('Etc/GMT+10','Hawaiian Standard Time'),
	('Etc/GMT+11','UTC-11'),
	('Etc/GMT+12','Dateline Standard Time'),
	('Etc/GMT+2','UTC-02'),
	('Etc/GMT+3','SA Eastern Standard Time'),
	('Etc/GMT+4','SA Western Standard Time'),
	('Etc/GMT+5','SA Pacific Standard Time'),
	('Etc/GMT+6','Central America Standard Time'),
	('Etc/GMT+7','US Mountain Standard Time'),
	('Etc/GMT+8','UTC-08'),
	('Etc/GMT+9','UTC-09'),
	('Etc/GMT-1','W. Central Africa Standard Time'),
	('Etc/GMT-10','West Pacific Standard Time'),
	('Etc/GMT-11','Central Pacific Standard Time'),
	('Etc/GMT-12','UTC+12'),
	('Etc/GMT-13','UTC+13'),
	('Etc/GMT-14','Line Islands Standard Time'),
	('Etc/GMT-2','South Africa Standard Time'),
	('Etc/GMT-3','E. Africa Standard Time'),
	('Etc/GMT-4','Arabian Standard Time'),
	('Etc/GMT-5','West Asia Standard Time'),
	('Etc/GMT-6','Central Asia Standard Time'),
	('Etc/GMT-7','SE Asia Standard Time'),
	('Etc/GMT-8','Singapore Standard Time'),
	('Etc/GMT-9','Tokyo Standard Time'),
	('Etc/UTC','UTC'),
	('UTC','UTC'),
	('Europe/Amsterdam','W. Europe Standard Time'),
	('Europe/Andorra','W. Europe Standard Time'),
	('Europe/Astrakhan','Astrakhan Standard Time'),
	('Europe/Athens','GTB Standard Time'),
	('Europe/Belgrade','Central Europe Standard Time'),
	('Europe/Berlin','W. Europe Standard Time'),
	('Europe/Bratislava','Central Europe Standard Time'),
	('Europe/Brussels','Romance Standard Time'),
	('Europe/Bucharest','GTB Standard Time'),
	('Europe/Budapest','Central Europe Standard Time'),
	('Europe/Busingen','W. Europe Standard Time'),
	('Europe/Chisinau','E. Europe Standard Time'),
	('Europe/Copenhagen','Romance Standard Time'),
	('Europe/Dublin','GMT Standard Time'),
	('Europe/Gibraltar','W. Europe Standard Time'),
	('Europe/Guernsey','GMT Standard Time'),
	('Europe/Helsinki','FLE Standard Time'),
	('Europe/Isle_of_Man','GMT Standard Time'),
	('Europe/Istanbul','Turkey Standard Time'),
	('Europe/Jersey','GMT Standard Time'),
	('Europe/Kaliningrad','Kaliningrad Standard Time'),
	('Europe/Kiev','FLE Standard Time'),
	('Europe/Kirov','Russian Standard Time'),
	('Europe/Lisbon','GMT Standard Time'),
	('Europe/Ljubljana','Central Europe Standard Time'),
	('Europe/London','GMT Standard Time'),
	('Europe/Luxembourg','W. Europe Standard Time'),
	('Europe/Madrid','Romance Standard Time'),
	('Europe/Malta','W. Europe Standard Time'),
	('Europe/Mariehamn','FLE Standard Time'),
	('Europe/Minsk','Belarus Standard Time'),
	('Europe/Monaco','W. Europe Standard Time'),
	('Europe/Moscow','Russian Standard Time'),
	('Europe/Oslo','W. Europe Standard Time'),
	('Europe/Paris','Romance Standard Time'),
	('Europe/Podgorica','Central Europe Standard Time'),
	('Europe/Prague','Central Europe Standard Time'),
	('Europe/Riga','FLE Standard Time'),
	('Europe/Rome','W. Europe Standard Time'),
	('Europe/Samara','Russia Time Zone 3'),
	('Europe/San_Marino','W. Europe Standard Time'),
	('Europe/Sarajevo','Central European Standard Time'),
	('Europe/Saratov','Saratov Standard Time'),
	('Europe/Simferopol','Russian Standard Time'),
	('Europe/Skopje','Central European Standard Time'),
	('Europe/Sofia','FLE Standard Time'),
	('Europe/Stockholm','W. Europe Standard Time'),
	('Europe/Tallinn','FLE Standard Time'),
	('Europe/Tirane','Central Europe Standard Time'),
	('Europe/Ulyanovsk','Astrakhan Standard Time'),
	('Europe/Uzhgorod','FLE Standard Time'),
	('Europe/Vaduz','W. Europe Standard Time'),
	('Europe/Vatican','W. Europe Standard Time'),
	('Europe/Vienna','W. Europe Standard Time'),
	('Europe/Vilnius','FLE Standard Time'),
	('Europe/Volgograd','Volgograd Standard Time'),
	('Europe/Warsaw','Central European Standard Time'),
	('Europe/Zagreb','Central European Standard Time'),
	('Europe/Zaporozhye','FLE Standard Time'),
	('Europe/Zurich','W. Europe Standard Time'),
	('Indian/Antananarivo','E. Africa Standard Time'),
	('Indian/Chagos','Central Asia Standard Time'),
	('Indian/Christmas','SE Asia Standard Time'),
	('Indian/Cocos','Myanmar Standard Time'),
	('Indian/Comoro','E. Africa Standard Time'),
	('Indian/Kerguelen','West Asia Standard Time'),
	('Indian/Mahe','Mauritius Standard Time'),
	('Indian/Maldives','West Asia Standard Time'),
	('Indian/Mauritius','Mauritius Standard Time'),
	('Indian/Mayotte','E. Africa Standard Time'),
	('Indian/Reunion','Mauritius Standard Time'),
	('MST7MDT','Mountain Standard Time'),
	('Pacific/Apia','Samoa Standard Time'),
	('Pacific/Auckland','New Zealand Standard Time'),
	('Pacific/Bougainville','Bougainville Standard Time'),
	('Pacific/Chatham','Chatham Islands Standard Time'),
	('Pacific/Chuuk','West Pacific Standard Time'),
	('Pacific/Easter','Easter Island Standard Time'),
	('Pacific/Efate','Central Pacific Standard Time'),
	('Pacific/Enderbury','UTC+13'),
	('Pacific/Fakaofo','UTC+13'),
	('Pacific/Fiji','Fiji Standard Time'),
	('Pacific/Funafuti','UTC+12'),
	('Pacific/Galapagos','Central America Standard Time'),
	('Pacific/Gambier','UTC-09'),
	('Pacific/Guadalcanal','Central Pacific Standard Time'),
	('Pacific/Guam','West Pacific Standard Time'),
	('Pacific/Honolulu','Hawaiian Standard Time'),
	('Pacific/Johnston','Hawaiian Standard Time'),
	('Pacific/Kiritimati','Line Islands Standard Time'),
	('Pacific/Kosrae','Central Pacific Standard Time'),
	('Pacific/Kwajalein','UTC+12'),
	('Pacific/Majuro','UTC+12'),
	('Pacific/Marquesas','Marquesas Standard Time'),
	('Pacific/Midway','UTC-11'),
	('Pacific/Nauru','UTC+12'),
	('Pacific/Niue','UTC-11'),
	('Pacific/Norfolk','Norfolk Standard Time'),
	('Pacific/Noumea','Central Pacific Standard Time'),
	('Pacific/Pago_Pago','UTC-11'),
	('Pacific/Palau','Tokyo Standard Time'),
	('Pacific/Pitcairn','UTC-08'),
	('Pacific/Pohnpei','Central Pacific Standard Time'),
	('Pacific/Ponape','Central Pacific Standard Time'),
	('Pacific/Port_Moresby','West Pacific Standard Time'),
	('Pacific/Rarotonga','Hawaiian Standard Time'),
	('Pacific/Saipan','West Pacific Standard Time'),
	('Pacific/Tahiti','Hawaiian Standard Time'),
	('Pacific/Tarawa','UTC+12'),
	('Pacific/Tongatapu','Tonga Standard Time'),
	('Pacific/Truk','West Pacific Standard Time'),
	('Pacific/Wake','UTC+12'),
	('Pacific/Wallis','UTC+12'),
	('PST8PDT','Pacific Standard Time')


	




	/******************************************************************************************** PROCESS:	mood */

	;WITH list AS (
		SELECT * FROM (VALUES
			('Aroused'),
			('Creative'),
			('Energetic'),
			('Euphoric'),
			('Focused'),
			('Giggly'),
			('Happy'),
			('Hungry'),
			('Relaxed'),
			('Sleepy'),
			('Talkative'),
			('Tingly'),
			('Uplifted')
		) t([name])
	)
	MERGE [grow].[strain_mood] t USING list s
	ON LOWER(t.[name])=LOWER(s.[name])
		WHEN MATCHED THEN UPDATE
			SET t.[system]=1
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT ([name], [system]) VALUES (s.[name], 1);
go

