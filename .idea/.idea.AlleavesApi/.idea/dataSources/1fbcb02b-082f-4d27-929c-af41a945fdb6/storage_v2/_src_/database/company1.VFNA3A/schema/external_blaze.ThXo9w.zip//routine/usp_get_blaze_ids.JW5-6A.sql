CREATE PROCEDURE external_blaze.usp_get_blaze_ids
AS
BEGIN
	SELECT id_order_blaze,id_order
	FROM external_blaze.[order]
END
go

