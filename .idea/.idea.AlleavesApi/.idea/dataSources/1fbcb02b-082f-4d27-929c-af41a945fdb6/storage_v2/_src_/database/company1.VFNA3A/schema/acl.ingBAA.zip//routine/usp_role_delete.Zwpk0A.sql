CREATE PROCEDURE [acl].[usp_role_delete]
	@id_role INT,
	@id_user INT
AS
	UPDATE acl.role
	SET deleted=1
		, id_user_updated=@id_user
		, date_updated=getutcdate()
	WHERE id_role=@id_role

	EXEC acl.usp_role_list @id_role, 1
go

