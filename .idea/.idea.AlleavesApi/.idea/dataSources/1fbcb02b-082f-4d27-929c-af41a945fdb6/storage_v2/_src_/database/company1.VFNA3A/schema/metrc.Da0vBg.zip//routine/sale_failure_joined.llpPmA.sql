CREATE PROCEDURE [metrc].[sale_failure_joined]
AS

SELECT e.*,
       vwo.id_order as id_order,
       u_loc.metrc_api_user_key
FROM [metrc].[sale_failure]
AS e
INNER JOIN [order].vw_orders as vwo on vwo.id_order = e.id_order
LEFT JOIN  [base].user_location as u_loc on vwo.id_location = u_loc.id_location and e.created_by = u_loc.id_user
WHERE e.remediated = 0;
go

