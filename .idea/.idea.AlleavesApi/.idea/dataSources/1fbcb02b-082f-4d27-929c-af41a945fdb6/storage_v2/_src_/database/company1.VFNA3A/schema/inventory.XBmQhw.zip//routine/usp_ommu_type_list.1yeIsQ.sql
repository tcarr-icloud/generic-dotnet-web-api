CREATE PROCEDURE [inventory].[usp_ommu_type_list]
	
AS

SELECT o.id_ommu_type 
		,o.[name] as ommu_type
FROM [inventory].[ommu_order_type] o
ORDER BY o.[name]
go

