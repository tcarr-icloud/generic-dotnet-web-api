CREATE PROCEDURE [grow].[usp_strain_save]
	@id_strain BIGINT,
	@id_strain_type INT,
	@mood_list VARCHAR(500) = NULL,
	@name VARCHAR(128),
	@lineage VARCHAR(MAX),
	@percent_thc DECIMAL(6,5) = NULL,
	@percent_cbd DECIMAL(6,5) = NULL,
	@percent_indica DECIMAL(6,5) = NULL,
	@percent_sativa DECIMAL(6,5) = NULL,
	@days_seedling INT = NULL,
	@days_germination INT = NULL,
	@days_vegetative INT = NULL,
	@days_preflower INT = NULL,
	@days_flower INT = NULL,
	@location_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	/* check for duplicate. */
	IF EXISTS (SELECT * FROM grow.strain WHERE name=@name AND deleted=0 AND (@id_strain IS NULL OR id_strain<>@id_strain))
	BEGIN
		DECLARE @msg VARCHAR(255) = 'A strain with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	/* create new strain. */
	IF (@id_strain IS NULL)
	BEGIN
		INSERT INTO grow.strain (name, id_strain_type, lineage, percent_thc, percent_cbd, percent_indica, percent_sativa, days_seedling, days_germination, days_vegetative, days_preflower, days_flower, created_by, updated_by)
		VALUES (@name, @id_strain_type, @lineage, @percent_thc, @percent_cbd, @percent_indica, @percent_sativa, @days_seedling, @days_germination, @days_vegetative, @days_preflower, @days_flower, @id_user, @id_user)

		SET @id_strain = SCOPE_IDENTITY()
	END
	/* update existing strain. */
	ELSE
	BEGIN
		UPDATE grow.strain
		SET name=@name
			, id_strain_type=@id_strain_type
			, lineage=@lineage
			, percent_thc=@percent_thc
			, percent_cbd=@percent_cbd
			, percent_indica=@percent_indica
			, percent_sativa=@percent_sativa
			, days_seedling=@days_seedling
			, days_germination=@days_germination
			, days_vegetative=@days_vegetative
			, days_preflower=@days_preflower
			, days_flower=@days_flower
			, updated_by=@id_user
			, date_updated=getutcdate()
		WHERE id_strain=@id_strain
	END

	/* update location list. */
	MERGE [grow].strain_location t
	USING (
		SELECT @id_strain AS id_strain, *
		FROM OPENJSON(@location_list)
		WITH (
			id_location INT,
			metrc_id INT,
			metrc_name VARCHAR(256)
		)
	) s ON t.id_strain=s.id_strain AND t.id_location=s.id_location
	WHEN MATCHED THEN UPDATE SET t.metrc_id=s.metrc_id, t.metrc_name=ISNULL(s.metrc_name, t.metrc_name)
	WHEN NOT MATCHED BY TARGET THEN INSERT (id_strain, id_location, metrc_id, metrc_name) VALUES (s.id_strain, s.id_location, s.metrc_id, s.metrc_name)
	;

	/* update mood list */
	MERGE [grow].strain_mood_assoc t
	USING (
		SELECT 
			@id_strain as id_strain, 
			id_strain_mood 
		FROM OPENJSON(@mood_list)
		WITH (
			id_strain_mood INT '$.id_strain_mood'
		)
		) as s
		ON t.id_strain = s.id_strain AND t.id_strain_mood = s.id_strain_mood
	WHEN NOT MATCHED BY TARGET THEN INSERT (id_strain, id_strain_mood)
	VALUES (s.id_strain, s.id_strain_mood)
	WHEN NOT MATCHED BY SOURCE THEN DELETE;

	/* return updated strain. */
	EXEC grow.usp_strain_list @id_strain, 1
go

