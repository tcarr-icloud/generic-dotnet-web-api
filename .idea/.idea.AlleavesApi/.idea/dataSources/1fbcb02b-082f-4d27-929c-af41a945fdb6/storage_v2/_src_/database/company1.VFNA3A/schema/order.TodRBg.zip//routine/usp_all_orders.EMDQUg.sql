CREATE PROCEDURE [order].[usp_all_orders]
	 @daterange INT = NULL
	,@id_location INT = NULL
	,@page INT = 1
	,@page_size INT = 100
AS
BEGIN
	DECLARE @offset INT = (@page - 1) * @page_size;
    SELECT
        o.id_order,
        c.name_first,
        c.name_last,
        rs.ride_status,
		o.date_created,
		r.id_ride,
        ISNULL((
            SELECT a.address1, a.address2, city, [state], a.zip, a.delivery_date ,a.lat,a.long
            FROM [order].[address] a
            WHERE a.id_order = o.id_order FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
        ), '{}') AS delivery_address,
		ISNULL((
			SELECT history.id_status_history
				,STATUS.customer_message
				,STATUS.driver_message
				,history.created_at
			FROM [order].ecommerce_ride ride
			JOIN [order].ecommerce_ride_status_history history ON ride.id_ride = history.id_ride
			JOIN [order].ecommerce_ride_status STATUS ON history.id_ride_status = STATUS.id_status
			WHERE ride.id_order = o.id_order
			ORDER BY history.created_at
			FOR JSON PATH
			), '[]') AS status_list,
        ISNULL((
            SELECT u.FirstName
            FROM [base].[user] u
            LEFT JOIN [order].[driver] d ON d.id_user = u.id_user
            WHERE d.id_driver = r.id_driver
        ), NULL) AS driver,
		(select top 1 id_delivery_route from [order].[ride_delivery_route] where id_ride=r.id_ride order by id_ride_delivery_route desc) as id_delivery_route,
	    (select delivery_start_time from [order].[delivery_route]  where id_delivery_route=(select top 1 id_delivery_route from [order].[ride_delivery_route] where id_ride=r.id_ride order by id_ride_delivery_route desc)) as delivery_start_time,
	    (select top 1 position from [order].[ride_delivery_route] where id_ride=r.id_ride order by id_ride_delivery_route desc) as position
    FROM
        [order].[order] o
        LEFT OUTER JOIN [order].[customer] AS c ON c.id_customer = o.id_customer
        LEFT OUTER JOIN [order].ecommerce_ride r ON r.id_order = o.id_order
        LEFT OUTER JOIN (
            SELECT
                er.id_order,
                ers.driver_message AS ride_status
            FROM [order].ecommerce_ride er
                JOIN [order].ecommerce_ride_status_history erh ON erh.id_ride = er.id_ride
                JOIN [order].ecommerce_ride_status ers ON ers.id_status = erh.id_ride_status
                JOIN (
                    SELECT id_ride, MAX(created_at) AS created_at
                    FROM [order].ecommerce_ride_status_history
                    GROUP BY id_ride
                ) erht ON erht.id_ride = erh.id_ride AND erht.created_at = erh.created_at
        ) rs ON rs.id_order = o.id_order
    WHERE
        o.type = 'delivery' and rs.ride_status not in ('Delivered')
		AND (
		@daterange is Null or
          DATEDIFF(day, o.date_created AT TIME ZONE 'UTC', GETDATE() AT TIME ZONE 'UTC') <= ISNULL(@daterange, 20)
		)
	ORDER BY o.id_order DESC
	OFFSET @offset ROWS
    FETCH NEXT @page_size ROWS ONLY;
END
go

