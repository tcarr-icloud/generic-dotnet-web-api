CREATE PROCEDURE [order].[usp_open_order_list] @id_order INT = NULL
	,@id_order_online VARCHAR(256) = NULL
	,@before DATETIME = NULL
	,@after DATETIME = NULL
	,@type VARCHAR(255) = NULL
	,@use_type VARCHAR(64) = NULL
	,@id_location INT = NULL
	,@id_customer INT = NULL
	,@id_status_include VARCHAR(MAX) = NULL
	,@id_item INT = NULL
	,@id_item_return INT = NULL
	,@external_only BIT = NULL
	,@id_inventory_item INT = NULL
	,@id_batch INT = NULL
	,@metrc_package_label VARCHAR(128) = NULL
	,@non_mmic BIT = NULL
AS
--DECLARE @before DATE = NULL
--DECLARE @after DATE = NULL
--DECLARE @type VARCHAR(255) = NULL
--DECLARE @id_location INT = NULL
--DECLARE @id_product INT = NULL
--DECLARE @id_order INT = NULL
--DECLARE @id_customer INT = NULL
--DECLARE @id_status_include VARCHAR(MAX) = NULL -- '[5]'
--DECLARE @id_status_exclude VARCHAR(MAX) = NULL -- '[5]'
IF (
		@id_batch IS NULL
		AND @metrc_package_label IS NOT NULL
		)
BEGIN
	-- This is a problem we should only have one metrc package label per batch but we have dupes
	SET @id_batch = (
			SELECT id_batch
			FROM inventory.batch
			WHERE metrc_package_label = @metrc_package_label
			)
END

SELECT o.id_order
	,o.id_customer
	,o.id_external
	,o.id_order_online
	,o.id_location
	,o.id_status
	,o.id_session
	,c.patient_number
	,s.[name] AS [status]
	,o.[type]
	,o.[use_type]
	,o.auto_apply_discount_exclusions
	,l.[name] AS [location]
	,[order].fn_order_item_json(o.id_order) AS items
	,[order].fn_order_payment_json(o.id_order) AS payments
	,[order].fn_order_discount_json(o.id_order) AS discounts
	,ISNULL((
			SELECT address1
				,address2
				,city
				,[state]
				,zip
				,delivery_date
				,CAST((CASE WHEN (DATEADD(day, 1, CAST(delivery_date as datetime)) AT TIME ZONE tz.tz_windows > GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows) THEN 1 ELSE 0 END) AS BIT) AS future_delivery_date
				,a.id_driver1
				,a.id_driver2
				,a.id_vehicle
			    ,a.lat
			    ,a.long
				,CASE 
					WHEN u1.id_user IS NOT NULL
						THEN u1.FirstName + ' ' + u1.LastName
					ELSE NULL
					END AS driver1
				,d1.license AS driver1_license
				,CASE 
					WHEN u2.id_user IS NOT NULL
						THEN u2.FirstName + ' ' + u2.LastName
					ELSE NULL
					END AS driver2
				,d2.license AS driver2_license
				,v.name AS vehicle
				,v.make
				,v.model
				,v.license AS vehicle_license
			FROM [order].[address] a
			LEFT JOIN [order].driver d1 ON d1.id_driver = a.id_driver1
			LEFT JOIN [order].driver d2 ON d2.id_driver = a.id_driver2
			LEFT JOIN base.[user] u1 ON u1.id_user = d1.id_user
			LEFT JOIN base.[user] u2 ON u2.id_user = d2.id_user
			LEFT JOIN [order].vehicle v ON v.id_vehicle = a.id_vehicle
			WHERE id_order = o.id_order
			FOR JSON PATH
				,WITHOUT_ARRAY_WRAPPER
			), '{}') AS delivery_address
	,r.id_ride
	,ISNULL((
			SELECT history.id_status_history
				,STATUS.customer_message
				,STATUS.driver_message
				,history.created_at
			FROM [order].ecommerce_ride ride
			JOIN [order].ecommerce_ride_status_history history ON ride.id_ride = history.id_ride
			JOIN [order].ecommerce_ride_status STATUS ON history.id_ride_status = STATUS.id_status
			WHERE ride.id_order = o.id_order
			ORDER BY history.created_at
			FOR JSON PATH
			), '[]') AS status_list
	,ISNULL((
			SELECT lo.id_loyalty_order
				,lo.id_offer_reward
				,lo.id_order
				,lo.amount
				,lo.redemption_type
				,lo.loyalty_vender
				,lo.loyalty_name
				,lo.expiry_date
				,lo.discount_type
				,lo.item_value
				,lo.redeemed
			FROM [loyalty].[order] lo
			WHERE lo.id_order = @id_order
			FOR json path
			), '[]') AS loyalties
	,pu.pickup_date
	,CAST((CASE WHEN (DATEADD(day, 1, CAST(pu.pickup_date as datetime)) AT TIME ZONE tz.tz_windows > GETUTCDATE() AT TIME ZONE 'UTC' AT TIME ZONE tz.tz_windows) THEN 1 ELSE 0 END) AS BIT) AS future_pickup_date
	,pu.pickup_time
	,ISNULL(o.subtotal, 0) AS subtotal
	,ISNULL(o.discount, 0) AS discount
	,ISNULL(o.loyalty, 0) AS loyalty
	,o.apply_delivery_fee
	,ISNULL(o.tax, 0) AS tax
	,ISNULL(o.state_tax, 0) AS state_tax
	,ISNULL(o.local_tax, 0) AS local_tax
	,ISNULL(o.excise_tax, 0) AS excise_tax
	,ISNULL(o.sales_tax, 0) AS sales_tax
	,ISNULL(o.state_tax_percentage, 0) AS state_tax_percentage
	,ISNULL(o.local_tax_percentage, 0) AS local_tax_percentage
	,ISNULL(o.excise_tax_percentage, 0) AS excise_tax_percentage
	,ISNULL(o.sales_tax_percentage, 0) AS sales_tax_percentage
	,ISNULL(o.total, 0) AS total
	,ISNULL(o.delivery_fee, 0) AS delivery_fee
	,o.[returns]
	,o.paid_in_full
	,CASE 
		WHEN paid_in_full = 1
			AND o.id_user_cashier IS NOT NULL
			THEN ISNULL(cashier.FirstName, '???') + ' ' + ISNULL(cashier.lastname, '???')
		WHEN paid_in_full = 1
			AND o.id_user_cashier IS NULL
			THEN (
					SELECT ISNULL(FirstName, '???') + ' ' + ISNULL(lastname, '???')
					FROM [base].[user]
					WHERE id_user = (
							SELECT TOP 1 id_user_created
							FROM [order].payment
							WHERE id_order = o.id_order
							)
					)
		ELSE NULL
		END AS cashier
	,o.date_paid
	,CAST(CASE
			WHEN o.complete = 1 THEN 1
			WHEN o.id_status = 4 THEN 1
			ELSE 0
			END AS BIT) AS complete
	,o.cancel
	,o.void
	,o.void_reason
	,o.void_reason_other
	,o.verified
	,o.verified_by
	,o.packed
	,o.packed_by
	,o.scheduled
	,o.scheduled_by
	,o.id_onfleet
	,o.metrc_receipt_id
	,o.biotrack_receipt_id
	,ISNULL(o.ommu_dispensed, 0) AS ommu_dispensed
	,ISNULL(o.caregiver_purchase, 0) AS caregiver_purchase
	,o.id_caregiver
	,o.caregiver_name
	,o.caregiver_card_number
	,o.id_physician
	,o.physician_name
	,o.id_user_working
	,o.date_created
	,o.created_by
	,ISNULL(uc.FirstName, '???') + ' ' + ISNULL(uc.lastname, '???') AS created_by_user
	,o.date_updated
	,DATEDIFF(hour, o.date_updated, GETUTCDATE()) AS hours_since_last_update
	,o.updated_by
	,ISNULL(uu.FirstName, '???') + ' ' + ISNULL(uu.lastname, '???') AS updated_by_user
	,o.non_mmic
FROM [order].[order] o
LEFT OUTER JOIN [order].[pickup] AS pu ON pu.id_order = o.id_order
LEFT OUTER JOIN [order].[status] AS s ON s.id_status = o.id_status
LEFT OUTER JOIN [base].[location] AS l ON l.id_location = o.id_location
LEFT OUTER JOIN [order].[customer] AS c ON c.id_customer = o.id_customer
LEFT OUTER JOIN [base].[user] AS uc ON uc.id_user = o.created_by
LEFT OUTER JOIN [base].[user] AS uu ON uu.id_user = o.updated_by
LEFT OUTER JOIN [base].[user] AS cashier ON cashier.id_user = o.[id_user_cashier]
LEFT OUTER JOIN [order].ecommerce_ride r ON r.id_order = o.id_order
LEFT OUTER JOIN dbo.tz_lookup tz on tz.tz_iana = l.timezone
WHERE (
		@before IS NULL
		OR o.date_created <= @before
		)
	AND (
		@after IS NULL
		OR o.date_created >= @after
		)
	AND (
		@external_only IS NULL
		OR @external_only = 0
		OR o.id_external IS NOT NULL
		)
	AND (
		@type IS NULL
		OR o.[type] = @type
		)
	AND (
		@use_type IS NULL
		OR o.[use_type] = @use_type
		)
	AND (
		@id_location IS NULL
		OR o.id_location = @id_location
		)
	AND (
		@id_order IS NULL
		OR o.id_order = @id_order
		)
	AND (
		@id_order_online IS NULL
		OR o.id_order_online = @id_order_online
		)
	AND (
		@id_customer IS NULL
		OR o.id_customer = @id_customer
		)
	AND (
		@id_status_include IS NULL
		OR o.id_status IN (
			SELECT [value]
			FROM OPENJSON(@id_status_include, '$')
			)
		)
	AND (
		@id_inventory_item IS NULL
		OR o.id_order IN (
			SELECT id_order
			FROM [order].[item]
			WHERE id_inventory_item = @id_inventory_item
			)
		)
	AND (
		@id_batch IS NULL
		OR o.id_order IN (
			SELECT id_order
			FROM [order].[item]
			WHERE id_batch = @id_batch
			)
		)
	AND (
		@id_item IS NULL
		OR (
			@id_item_return IS NULL
			AND o.id_order IN (
				SELECT id_order
				FROM [order].[item]
				WHERE id_item = @id_item
				)
			)
		)
	AND (
		@id_item_return IS NULL
		OR (
			@id_item IS NULL
			AND o.id_order IN (
				SELECT id_order
				FROM [order].[item]
				WHERE id_item_return = @id_item_return
					AND (
						@id_order IS NULL
						OR id_order <> @id_order
						)
				)
			)
		)
	AND (
		o.cancel = 0
		AND o.void = 0
		AND o.paid_in_full = 0
		AND o.ommu_dispensed = 0
		)

OPTION (RECOMPILE)
go

