CREATE PROCEDURE [tax].[usp_upsert_location_tax]
	@id_location INT,
	@tax_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	;WITH tax_list AS (
		SELECT @id_location AS id_location
			, id_tax
		FROM OPENJSON(@tax_list)
		WITH (
			  id_tax INT
		)
	)
	MERGE [tax].[location] AS tl
	USING tax_list AS taxl
	ON taxl.id_location = tl.id_location AND taxl.id_tax = tl.id_tax
	WHEN MATCHED THEN
	UPDATE SET tl.updated_by=@id_user, tl.date_updated=getutcdate(), tl.active=1
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (id_tax, id_location, active, created_by, updated_by) VALUES(taxl.id_tax, taxl.id_location, 1, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND tl.id_location = @id_location THEN
	UPDATE SET tl.active=0, tl.updated_by=@id_user, tl.date_updated=getutcdate()
	;


	--NOT BEING USED ANYWHERE
go

