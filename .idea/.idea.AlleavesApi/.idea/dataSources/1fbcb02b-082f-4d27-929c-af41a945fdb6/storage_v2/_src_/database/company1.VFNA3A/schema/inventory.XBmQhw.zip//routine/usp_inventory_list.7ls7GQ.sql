
CREATE PROCEDURE [inventory].[usp_inventory_list]
	@id_location INT = NULL,
	@id_item INT = NULL,
	@id_batch INT = NULL,
	@id_area INT = NULL,
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS
    SET NOCOUNT ON;

--DECLARE @id_location INT = N'1010',
--	@id_item INT = NULL, --14955,
--	@id_batch INT = NULL, --46265,
--	@id_area INT = NULL, --1046,
--	@start_row INT = 0,
--	@end_row INT = 10,
--	@sort_clause VARCHAR(MAX) = NULL,
--	@filter_clause VARCHAR(max) = NULL	

	DECLARE @select1 NVARCHAR(MAX)
	DECLARE @select2 NVARCHAR(MAX)
	DECLARE @where NVARCHAR(MAX)
	DECLARE @order NVARCHAR(MAX)
	
	SET @select1 = '		
		SELECT * into #vw_area_list FROM inventory.vw_area_list

		CREATE TABLE #inventory_base (id_batch INT,id_area INT,id_location INT,[location] VARCHAR(64),area VARCHAR(64),area_path VARCHAR(max),area_type VARCHAR(64),mobile BIT, available DECIMAL(18,4), priority INT)
		INSERT INTO #inventory_base
		EXEC inventory.usp_get_inventory_base_data @id_batch='+ISNULL(CAST(@id_batch as VARCHAR(20)), 'NULL') +', @id_area='+ISNULL(CAST(@id_area as VARCHAR(20)), 'NULL')+',@id_location = '+ISNULL(CAST(@id_location as VARCHAR(20)), 'NULL')+'	

	;WITH order_agg
AS (
	SELECT oi.id_batch
		,oi.id_area
		,SUM(oi.quantity) AS ordered
	FROM [order].item oi
	INNER JOIN [order].[order] o ON o.id_order = oi.id_order
	INNER JOIN #inventory_base inv ON inv.id_batch = oi.id_batch
		AND inv.id_area = oi.id_area
	WHERE o.void = 0
		AND o.cancel = 0
		AND o.paid_in_full = 0
		AND o.complete = 0
	GROUP BY oi.id_batch
		,oi.id_area
	)
	,transfer_agg
AS (
	SELECT ti.id_batch
		,ti.id_area
		,SUM(ti.quantity) AS transferred
	FROM inventory.transfer t
	JOIN inventory.transfer_item ti ON ti.id_transfer = t.id_transfer
	INNER JOIN #inventory_base inv ON inv.id_batch = ti.id_batch
		AND inv.id_area = ti.id_area
	CROSS APPLY (
		SELECT TOP 1 id_transfer_status
		FROM inventory.transfer_status_history h
		WHERE h.id_transfer = t.id_transfer
		ORDER BY h.date_verified DESC
		) x
	WHERE x.id_transfer_status = 1
	GROUP BY ti.id_batch
		,ti.id_area
	)
	SELECT inv.id_batch
		,inv.id_location
		,inv.[location]
		,inv.id_area
		,inv.area
		,inv.area_path
		,inv.priority
		,inv.area_type
		,inv.mobile
		,ISNULL(inv.available, 0) AS available
		,ISNULL(inv.available, 0) + ISNULL(ord.ordered, 0) + ISNULL(tx.transferred, 0) AS on_hand
		,CAST(CASE 
				WHEN ISNULL(inv.available, 0) + ISNULL(ord.ordered, 0) + ISNULL(tx.transferred, 0) > 0
					THEN 1
				ELSE 0
				END AS BIT) AS has_inventory
		,CAST(CASE 
				WHEN ISNULL(inv.available, 0) > 0
					THEN 1
				ELSE 0
				END AS BIT) AS has_available_inventory
		,CAST(CASE 
				WHEN ISNULL(inv.available, 0) + ISNULL(ord.ordered, 0) + ISNULL(tx.transferred, 0) > 0
					THEN 1
				ELSE 0
				END AS BIT) AS has_owned_batch
	INTO #quantity_list_tmp
	FROM #inventory_base inv
	LEFT OUTER JOIN order_agg ord ON inv.id_batch = ord.id_batch
		AND inv.id_area = ord.id_area
	LEFT OUTER JOIN transfer_agg tx ON inv.id_batch = tx.id_batch
		AND inv.id_area = tx.id_area

	SELECT * INTO #quantity_list FROM (
		SELECT id_batch, id_location, location, id_area, area, area_path, area_type, available, on_hand, has_inventory, has_available_inventory, has_owned_batch, priority 
		FROM #quantity_list_tmp WHERE on_hand <> 0
		
		UNION ALL

		SELECT DISTINCT id_batch, id_location, location, NULL, NULL, NULL, NULL, available, on_hand, 0, 0, 1, priority 
		FROM #quantity_list_tmp WHERE id_batch NOT IN (SELECT id_batch FROM #quantity_list_tmp WHERE on_hand <> 0)
	) b


	SELECT id_test_result
		,id_chemical_profile
		,chemical
		,[value]
	INTO #chemical_profile_list
	FROM (
		SELECT trcp.id_test_result
			,trcp.id_chemical_profile
			,icp.[name] AS chemical
			,trcp.[value]
			,ROW_NUMBER() OVER (
				PARTITION BY trcp.id_test_result
				,trcp.id_chemical_profile ORDER BY trcp.id_test_result
					,trcp.id_chemical_profile
				) AS key_count
		FROM inventory.test_result_chemical_profile trcp
		LEFT JOIN inventory.chemical_profile icp ON icp.id_chemical_profile = trcp.id_chemical_profile
		WHERE id_test_result IN (
				SELECT id_test_result
				FROM #quantity_list
				)
		) cp
	WHERE key_count < 2'

SET @select2 = '
;WITH inventory_list
AS (
	SELECT *
	FROM (
		SELECT b.id_batch
			,t.id_test_result
			,t.coa_s3_key
			,i.id_item
			,i.id_item_group
			,inv.id_location
			,ig.is_adult_use
			,ig.is_medical_use
			,ig.is_cannabis
			,ig.is_plant
			,ig.is_seed
			,ig.threshold_low_quantity
			,ig.threshold_low_quantity_selected
			,b.cost_of_good AS batch_cost_of_good
			,b.id_strain AS id_strain
			,b.biotrack_barcode_id
			,ISNULL(b.biotrack_inventory_type_id, i.biotrack_inventory_type_id) as biotrack_inventory_type_id
			,b.biotrack_scheduled_destroyed
			,b.biotrack_destroyed
			,CAST(ISNULL(ig.is_low_thc, 0) AS BIT) AS is_low_thc
			,CAST(ISNULL(ig.is_medicated, 0) AS BIT) AS is_medicated
			,CAST(ISNULL(ig.is_smoking, 0) AS BIT) AS is_smoking
			,CAST(ISNULL(ig.is_low_thc_and_medical, 0) AS BIT) AS is_low_thc_and_medical
			,ig.is_product
			,c.path AS category
			,ig.id_raw_material
			,rm.name AS raw_material
			,ig.dosage_recommended
			,br.name AS brand
			,vr.name AS vendor
			,vr.metrc_facility_license_number AS vendor_metrc_facility_license_number
			,inv.id_area
			,a.internal_id_area
			,b.id_status
			,RTRIM(CONCAT (
					ig.name
					,'' ''
					,(
						SELECT STRING_AGG(av.name, '' '')
						FROM inventory.item_attribute_value iav
						LEFT JOIN inventory.attribute_value av ON av.id_attribute_value = iav.id_attribute_value
						WHERE iav.id_item = i.id_item
						)
					)) AS item
			,ISNULL(b.name, ''N/A'') AS batch
			,b.vendor_batch_id
			,b.metrc_package_label
			,b.metrc_item_id
			,ig.id_ommu_form
			,ommuf.name AS ommu_form_name
			,CAST(ISNULL(ig.is_ommu_delivery_device, 0) AS BIT) AS is_ommu_delivery_device
			,inv.location
			,inv.area
			,inv.area_path
			,inv.area_type
			,inv.priority
			,CAST(ISNULL(inv.has_owned_batch, 0) as bit) as has_owned_batch
			,ISNULL(inv.on_hand, 0) AS on_hand
			,ISNULL(inv.available, 0) AS available
			,u.quantity_type AS uom_type
			,dr.name AS delivery_route
			,u.name AS uom
			,u.name_short AS uom_short
			,i.weight_useable
			,uu.name AS weight_useable_uom
			,uu.name_short AS weight_useable_uom_short
			,un.name_short AS uom_weight_net_short
			,st.[name] AS [status]
			,b.qc_hold
			,ISNULL(b.cost_of_good, i.cost_of_good) AS cost_of_good
			,i.price_retail_adult_use
			,i.price_retail
			,i.price_retail_medical_use
			,i.price_otd
			,i.price_otd_adult_use
			,i.price_otd_medical_use
			,i.use_otd_price
			,ig.servings
			,CAST(cp.thc AS DECIMAL(7, 3)) AS thc
			,CAST(cp.thc_mg AS DECIMAL(7, 3)) AS thc_mg
			,CAST(cp.cbd AS DECIMAL(7, 3)) AS cbd
			,CAST(cp.cbd_mg AS DECIMAL(7, 3)) AS cbd_mg
			,ISNULL((
				SELECT 
					 chemical AS compound
					,[value] as result
				FROM #chemical_profile_list
				WHERE id_test_result = t.id_test_result
				FOR JSON PATH
			),''[]'') as compounds
					,CAST(ISNULL(inv.has_inventory, 0) as bit) as has_inventory
			,CAST(ISNULL(inv.has_available_inventory, 0) as bit) as has_available_inventory
			,CONVERT(VARCHAR(32), b.date_created, 127) AS date_received
			,CAST(b.date_expire AS VARCHAR(16)) AS date_expire
			,ig.allergens
			,ig.ingredients_list
			,ig.nutritional_information
			,sr.name AS strain
			,b.harvest_batch
			,''api/inventory/batch/methodlabs/'' + b.harvest_batch as methodlabs_coa
			,il.location_threshold_low_quantity_value 
			,il.location_threshold_low_quantity_selected
		FROM inventory.batch b
		INNER JOIN inventory.item i ON i.id_item = b.id_item
		INNER JOIN inventory.item_group ig ON ig.id_item_group = i.id_item_group
		LEFT OUTER JOIN inventory.vw_category_list c ON ig.id_category = c.id_category
		LEFT OUTER JOIN inventory.brand br ON br.id_brand = ig.id_brand
		LEFT OUTER JOIN inventory.vendor vr ON vr.id_vendor = ig.id_vendor
		LEFT OUTER JOIN grow.strain sr ON sr.id_strain = ig.id_strain
		INNER JOIN inventory.[status] st ON st.id_status = b.id_status
		INNER JOIN inventory.uom u ON u.id_uom = ig.id_uom
		LEFT JOIN inventory.delivery_route dr ON dr.id_delivery_route = ig.id_delivery_route		
		LEFT OUTER JOIN inventory.test_result t ON t.id_batch = b.id_batch
		LEFT OUTER JOIN inventory.raw_material rm ON rm.id_raw_material = ig.id_raw_material
		LEFT OUTER JOIN inventory.uom uu ON uu.id_uom = ig.id_uom_weight_useable
		LEFT OUTER JOIN inventory.uom un ON un.id_uom = i.id_uom_weight_net
		LEFT OUTER JOIN ommu.form ommuf ON ommuf.id_form = ig.id_ommu_form
		INNER JOIN #quantity_list inv ON inv.id_batch = b.id_batch
		LEFT JOIN inventory.area a ON a.id_area=inv.id_area
		LEFT OUTER JOIN inventory.item_location il ON il.id_item = b.id_item AND il.id_location = inv.id_location
		LEFT OUTER JOIN (
			SELECT 
				id_test_result,
				[1] AS cbd, 
				[2] AS thc, 
				[60] AS thc_mg, 
				[61] AS cbd_mg
			FROM 
				(SELECT id_test_result, id_chemical_profile, [value] FROM #chemical_profile_list WHERE id_chemical_profile IN (1,2,60,61)) AS SourceTable
			PIVOT
				(MAX([value]) FOR id_chemical_profile IN ([1], [2], [60], [61])) AS PivotTable
		) cp on cp.id_test_result = t.id_test_result
		) inventory'

	SET @where = 'WHERE 1=1'
	if (@id_location IS NOT NULL)
		SET @where = @where + ' AND (id_location = '+CAST(@id_location as VARCHAR(16)) +' or id_location IS NULL)'
	IF (@id_item IS NOT NULL)
		SET @where = @where + ' AND id_item = '+ ISNULL(CAST(@id_item AS VARCHAR(16)), 'id_item')
	IF (@id_batch IS NOT NULL)
		SET @where = @where + ' AND id_batch = '+ ISNULL(CAST(@id_batch AS VARCHAR(16)), 'id_batch')
	IF (@id_area IS NOT NULL)
		SET @where = @where + ' AND id_area = '+ CAST(@id_area AS VARCHAR(16))
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)
	SET @where = @where + ')'
	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'item, batch')

	DECLARE @base_sql NVARCHAR(max) = @select1 + @select2 + ' ' + @where

	DECLARE @sql NVARCHAR(MAX) = '

	'+@base_sql+'

	SELECT 
		 *
		,COUNT(1) OVER() as total_rows
		,SUM(on_hand) OVER () AS on_hand_total
		,SUM(available) OVER () AS available_total
	FROM inventory_list t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	--SELECT @sql
	EXEC sp_executesql @sql
go

