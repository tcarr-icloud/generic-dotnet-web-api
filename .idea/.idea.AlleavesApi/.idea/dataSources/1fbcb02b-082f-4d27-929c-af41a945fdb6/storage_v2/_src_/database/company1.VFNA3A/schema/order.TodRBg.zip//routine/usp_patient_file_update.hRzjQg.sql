CREATE PROCEDURE [order].usp_patient_file_update
        @id_file INT,
        @id_customer INT
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE [order].customer
	SET
	[id_file_patient] = @id_file
	WHERE id_customer =  @id_customer
END
go

