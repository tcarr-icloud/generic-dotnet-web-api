CREATE PROCEDURE [dbo].[update_daily_accounts]
	@category VARCHAR(50),
	@location VARCHAR(50),
	@quantity INT,
	@discount MONEY,
	@prediscount MONEY,
	@postdiscount MONEY,
	@cost MONEY,
	@profit MONEY
AS
	SET NOCOUNT ON;

	IF EXISTS(SELECT * FROM [dbo].[daily_accounts] WHERE Category=@category AND Location=@location)
		UPDATE [dbo].[daily_accounts]
		SET Sales+=1,
			Quantity+=@quantity,
			Discount+=@discount,
			PreDiscount+=@prediscount,
			PostDiscount+=@postdiscount,
			Cost+=@cost,
			Profit+=@profit

		WHERE Category=@category AND Location=@location
	ELSE
		INSERT INTO [dbo].[daily_accounts] (Category, Location, Sales, Quantity, Discount, PreDiscount, PostDiscount, Cost, Profit)
		VALUES (@category, @location, 1, @quantity, @discount, @prediscount, @postdiscount, @cost, @profit)
go

