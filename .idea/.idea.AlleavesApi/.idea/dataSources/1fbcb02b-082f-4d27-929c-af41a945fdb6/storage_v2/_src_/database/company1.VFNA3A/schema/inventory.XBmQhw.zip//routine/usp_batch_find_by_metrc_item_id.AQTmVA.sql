CREATE PROCEDURE [inventory].[usp_batch_find_by_metrc_item_id]
	@metrc_item_id INT
AS
	SELECT i.id_item
			, i.id_item_group
			, b.id_batch
			, i.item
			, b.name AS batch
			, i.metrc_item_id
			, b.metrc_package_label
	FROM inventory.vw_item_list i
	JOIN inventory.batch b ON b.id_item=i.id_item
	WHERE i.metrc_item_id=@metrc_item_id AND b.metrc_package_label IS NOT NULL
go

