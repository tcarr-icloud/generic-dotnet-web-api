CREATE PROCEDURE [order].[usp_order_release]
	@id_order INT,
	@id_user INT
AS
	UPDATE [order].[order] 
	SET id_user_working=null,
		date_updated=getutcdate()
	WHERE id_order=@id_order AND
		  id_user_working=@id_user
go

