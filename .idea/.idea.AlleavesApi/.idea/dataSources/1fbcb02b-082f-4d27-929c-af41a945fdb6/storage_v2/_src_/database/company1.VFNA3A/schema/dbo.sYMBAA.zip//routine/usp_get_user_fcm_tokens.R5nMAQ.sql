create   procedure dbo.usp_get_user_fcm_tokens @id_user_list varchar(max) = '[]'
AS
  SET NOCOUNT ON;

    select isnull(fcm_tokens,'[]') as fcm_tokens from base.[user] where id_user in (SELECT [value] FROM OPENJSON(@id_user_list, '$'))
go

