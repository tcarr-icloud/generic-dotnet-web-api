CREATE PROCEDURE [metrc].[usp_transfer_import_list]
	@id_location INT = NULL,	
	@start_row INT = NULL,
	@end_row INT = NULL,
	@sort_clause VARCHAR(max) = NULL,
	@filter_clause VARCHAR(max) = NULL
AS

	DECLARE @select VARCHAR(MAX)
	DECLARE @where VARCHAR(MAX)
	DECLARE @order VARCHAR(MAX)

	SET @select = 'SELECT * FROM (
		SELECT DISTINCT i.id_transfer_import
				, l.id_location
				, t.id_transfer
				, l.name AS location
				, t.vendor
				, t.manifest_number
				, t.package_count
				, CONCAT(u.FirstName, '' '', u.LastName) AS accepted_by
				, i.date_created AS date_accepted
		FROM metrc.transfer_import i
		JOIN metrc.transfer_item ti ON ti.id_transfer_import=i.id_transfer_import
		JOIN metrc.transfer t ON t.id_transfer=ti.id_transfer
		JOIN base.[user] u ON u.id_user=i.id_user_created
		JOIN base.location l ON l.id_location=t.id_location
	) imports'

	SET @where = 'WHERE id_location = '+ ISNULL(CAST(@id_location AS VARCHAR(16)), 'id_location')
	IF (@filter_clause IS NOT NULL)
		SET @where = @where + CONCAT(' AND ', @filter_clause)

	SET @order = 'ORDER BY ' + ISNULL(@sort_clause, 'date_accepted')
	

	DECLARE @base_sql VARCHAR(max) = @select + ' ' + @where

	DECLARE @sql VARCHAR(MAX) = '
	DECLARE @total INT;
	
	SET @total = (SELECT COUNT(*) FROM ('+@base_sql+') t );
	
	SELECT *, @total AS total_rows FROM ('+@base_sql+') t
	' + @order

	IF (@start_row IS NOT NULL)
		SET @sql = @sql + ' OFFSET '+ CAST(@start_row  as VARCHAR(10)) +' ROWS FETCH NEXT '+ CAST(ISNULL(@end_row, @start_row + 100)  as VARCHAR(10)) +' - '+ CAST(@start_row  as VARCHAR(10)) +' ROWS ONLY'
	SET @sql = @sql + '
	OPTION(RECOMPILE);'
	EXEC (@sql)
go

