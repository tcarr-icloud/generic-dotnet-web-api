CREATE PROCEDURE [dbo].[usp_add_company]
	@name VARCHAR(MAX),
	@reference VARCHAR(MAX),
	@workspace VARCHAR(MAX),
	@is_move_client BIT = 0,
	@db_host VARCHAR(MAX) = NULL,
	@db_user VARCHAR(MAX) = NULL,
	@db_password VARCHAR(MAX) = NULL,
	@db_port VARCHAR(32) = NULL
AS
	INSERT INTO dbo.company (name, reference, workspace, is_move_client, db_host, db_user, db_password, db_port)
	VALUES (@name, @reference, @workspace, @is_move_client, @db_host, @db_user, @db_password, @db_port)
go

