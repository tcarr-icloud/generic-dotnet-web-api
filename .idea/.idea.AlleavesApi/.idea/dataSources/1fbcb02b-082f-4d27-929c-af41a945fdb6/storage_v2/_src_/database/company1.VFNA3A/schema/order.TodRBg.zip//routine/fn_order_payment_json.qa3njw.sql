
-- =============================================
-- Author:		Name
-- Create date: 
-- Description:	
-- =============================================
CREATE FUNCTION [order].[fn_order_payment_json]
(
	-- Add the parameters for the function here
	@id_order INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result VARCHAR(MAX)

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = ISNULL((SELECT * FROM [order].fn_order_payment(@id_order) FOR JSON PATH, INCLUDE_NULL_VALUES),'[]')

	-- Return the result of the function
	RETURN @Result

END
go

