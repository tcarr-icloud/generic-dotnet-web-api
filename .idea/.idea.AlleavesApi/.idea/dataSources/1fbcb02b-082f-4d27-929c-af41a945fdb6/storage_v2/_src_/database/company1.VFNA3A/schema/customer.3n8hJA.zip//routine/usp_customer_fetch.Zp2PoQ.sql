CREATE PROCEDURE [customer].[usp_customer_fetch]
    @id_customer INT = NULL
AS
--SET STATISTICS IO ON;
--SET STATISTICS TIME ON;

--DECLARE @id_customer INT = 79545

SELECT 
      c.id_customer
    , c.weedmaps_id
    , c.dispense_id
    , c.iheartjane_id
    , c.deleted
    , c.is_banned
    , c.ban_reason
    , c.ban_expires
    , c.guid_customer
    , c.name_first
    , c.name_middle
    , c.name_last
    , c.name_preferred
    , c.gender
    , c.phone
    , c.phone2
    , c.email
    , c.PasswordHash as [password]
    , c.address1
    , c.address2
    , c.city
    , c.state
	, bs.abbreviation 
    , c.zip
    , c.zip_four
    , c.id_physician
    , c.id_caregiver
    , c.is_caregiver
    , c.caregiver_license_number
    , c.is_employee
    , c.id_referral_method
    , c.drivers_license
    , c.drivers_license_st
    , c.drivers_license_expires
    , c.passport
    , c.expiration_date
    , c.referral_date
    , r.[name] AS referral_method  
    , c.id_customer_referral
    , rc.name_first AS referral_customer_fname
    , rc.name_last AS referral_customer_lname
    , c.id_physician_referral 
	, c.referral_expiration_date
    , p.name_first AS physician_fname
    , p.name_last AS physician_lname
    , p.license_number AS physician_license
	, p.dea
    , p.npi
    , c.referral_description
    , (cgv.name_first + ' ' + cgv.name_last) AS caregiver_name
    , (p.name_first + ' ' + p.name_last) AS physician_name
    , cgv.caregiver_license_number AS active_caregiver_license_number
    , CAST(c.date_of_birth AS VARCHAR(16)) AS date_of_birth
	, ISNULL(cb.credit_balance, 0) as credit_balance
	, ISNULL(oo.open_orders, 0) as open_orders
    , c.patient_number
    , c.id_file_patient
    , c.id_user_online
    , c.id_customer_biotrack
	, c.springbig_user_code
	, c.springbig_signature_url
    , CASE WHEN q.id_queue IS NULL THEN 0 ELSE 1 END AS in_queue
    , q.time_in
    , q.time_out
    , q.id_queue
    , CAST(CAST(c.date_created AS DATE) AS VARCHAR(16)) AS customer_since
    , ISNULL(
    (
        SELECT i.id_identification
                , i.id_customer
                , i.label
                , i.value
        FROM [order].identification i
        WHERE i.id_customer = c.id_customer
        FOR JSON PATH
    ), '[]') AS id_list
    , ISNULL(
    (
        SELECT ct.id_customer_type_selected
                , ct.id_customer
                , ct.id_customer_type
                , t.[name] AS customer_type
        FROM [order].customer_type_selected ct
                    LEFT JOIN [order].customer_type t ON t.id_customer_type = ct.id_customer_type
        WHERE ct.id_customer = c.id_customer
        FOR JSON PATH
    ),'[]') AS customer_type_list
    , c.patient_id_front
	, c.patient_id_back
	, c.driver_license_front
	, c.driver_license_back
FROM [order].[customer] c
LEFT JOIN [order].queue q ON q.id_customer = c.id_customer AND q.time_out IS NULL
LEFT JOIN [order].referral_method r ON r.id_referral_method = c.id_referral_method
LEFT JOIN [order].physician p ON p.id_physician = c.id_physician
LEFT JOIN [order].customer rc ON rc.id_customer = c.id_customer_referral
LEFT JOIN [order].[customer] cgv ON cgv.id_customer = c.id_caregiver
LEFT JOIN [base].states bs ON bs.name = c.state
LEFT OUTER JOIN (
	SELECT
		id_customer,
		CASE WHEN SUM(amount) IS NULL OR SUM(amount) < 0 THEN 0 ELSE SUM(amount) END as credit_balance
    FROM [order].customer_credit_debit
	GROUP BY id_customer
) as cb on cb.id_customer = c.id_customer
LEFT OUTER JOIN (
	SELECT 
		id_customer,
        COUNT(id_order) as open_orders
    FROM [order].[order] oc
    WHERE 
        (
            id_customer = @id_customer OR 
            id_customer IN (
                SELECT cm.id_merging_customer 
                FROM [order].customer_merge cm 
                WHERE cm.id_customer = @id_customer
            )
        )
        AND void <> 1
        AND (cancel = 0 AND paid_in_full <> 1 OR (cancel = 0 AND complete <> 1 AND id_status NOT IN (
            SELECT id_status
            FROM [order].[status]
            WHERE LOWER([name]) LIKE 'complete%'
        )))
	GROUP BY id_customer
) as oo on oo.id_customer = c.id_customer

WHERE 
        c.id_customer = ISNULL(@id_customer, c.id_customer)
OPTION(RECOMPILE)


--SET STATISTICS IO OFF;
--SET STATISTICS TIME OFF;
go

