CREATE PROCEDURE [order].[usp_physician_list]
	@id_physician INT = NULL,
	@show_deleted BIT = 0
AS
	--DECLARE @id_physician INT = NULL
	SELECT 
		  p.id_physician
		, p.name_first
		, p.name_last
		, p.phone
		, p.email
		, p.address1
		, p.address2
		, p.city
		, p.state
		, p.zip			
		, p.license_number
		, p.dea
		, p.npi
	FROM [order].physician p
	WHERE p.id_physician=ISNULL(@id_physician, p.id_physician) AND p.deleted<=@show_deleted
	ORDER BY 
		  p.name_last
go

