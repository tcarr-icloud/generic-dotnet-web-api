CREATE PROCEDURE [inventory].[usp_attribute_list]
	@id_attribute INT = NULL,
	@include_deleted BIT = 0
AS
	SELECT v.id_attribute
			, v.name AS attribute
			, v.deleted
			, ISNULL((SELECT vv.id_attribute_value
							, vv.id_attribute
							, vv.name AS attribute_value
					  FROM inventory.attribute_value vv
					  WHERE vv.id_attribute=v.id_attribute AND vv.deleted=0
					  FOR JSON PATH
			), '[]') AS attribute_value_list
	FROM inventory.attribute v
	WHERE v.id_attribute=ISNULL(@id_attribute, v.id_attribute) AND
		  v.deleted<=@include_deleted
go

