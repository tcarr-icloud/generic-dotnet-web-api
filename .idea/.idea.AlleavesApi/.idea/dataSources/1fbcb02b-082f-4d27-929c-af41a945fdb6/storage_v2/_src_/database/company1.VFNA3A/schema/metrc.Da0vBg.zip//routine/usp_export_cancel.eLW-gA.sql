CREATE PROCEDURE [metrc].[usp_export_cancel]
	@id_export INT,
	@id_user INT
AS
	/* update export object. */
	UPDATE metrc.export
	SET id_user_updated = @id_user
		, cancelled = 1
		, date_cancelled = GETUTCDATE()
		, date_updated = GETUTCDATE()
	WHERE id_export = @id_export


	DECLARE @event_list VARCHAR(MAX),
			@event_notes VARCHAR(128) = CONCAT('Metrc ExportID: ', @id_export, '; Cancelled')

	/* return inventory to alleaves. */
	SET @event_list = (
			SELECT id_batch, id_area, quantity AS adjustment
			FROM metrc.export_item 
			WHERE id_export=@id_export
			FOR JSON PATH
		)
	EXEC [log].usp_event_create_bulk 'transfer_manifest_remove', @event_notes, @event_list, @id_user


	/* return updated transfer. */
	EXEC metrc.usp_export_fetch @id_export
go

