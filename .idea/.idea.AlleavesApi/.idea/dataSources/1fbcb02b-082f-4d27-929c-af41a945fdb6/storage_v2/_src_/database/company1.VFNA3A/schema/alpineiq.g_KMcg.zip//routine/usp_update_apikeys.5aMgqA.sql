CREATE PROCEDURE [alpineiq].[usp_update_apikeys]
	@keys VARCHAR(max) 
AS
	MERGE [alpineiq].[apikey] as t
	USING (
		SELECT id_location, [key] FROM OPENJSON(@keys)
		WITH(
			id_location int,
			[key] varchar(512)
		)
	) as s on t.id_location = s.id_location
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (id_location, [key])
		VALUES(s.id_location, s.[key])
	WHEN MATCHED THEN UPDATE
		SET [key] = s.[key];
go

