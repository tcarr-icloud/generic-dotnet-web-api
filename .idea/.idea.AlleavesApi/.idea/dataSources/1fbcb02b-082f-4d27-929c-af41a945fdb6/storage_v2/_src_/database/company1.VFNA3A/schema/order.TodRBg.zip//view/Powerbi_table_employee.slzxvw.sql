create    view  [order].Powerbi_table_employee as
(select (select u.FirstName + ' ' + u.LastName from base.[user] u where u.id_user=o.created_by) AS 'employee_name',
        o.created_by as  employee_id,
       (select address from base.location where id_location= o.id_location) as location,
       o.date_created,
       sum(oi.price_post_tax)                                     as "Sales Total",
       count(distinct o.id_order)   as "Number of Tickets",
       (select count(case when [order].returns < 0 then 1 else null end)from [order].[order] where [order].created_by = o.created_by) as total_returns,
       (select count(case [order].void when 1 then 1 else null end)from [order].[order] where [order].created_by = o.created_by) as total_voids,
       COUNT(oi.id_item) / count(distinct o.id_order)         as UPT,
       sum(oi.price_post_tax) / count(distinct o.id_order)      as ATP
from [order].[order] o
INNER JOIN [order].[item] oi on oi.id_order = o.id_order
group by o.created_by,o.date_created,o.id_location)
go

