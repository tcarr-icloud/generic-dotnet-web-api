CREATE PROCEDURE [pos].[usp_login]
	@id_user INT,
	@id_register INT
AS

	INSERT INTO pos.session (id_user_start, id_register)
	VALUES (@id_user, @id_register)
go

