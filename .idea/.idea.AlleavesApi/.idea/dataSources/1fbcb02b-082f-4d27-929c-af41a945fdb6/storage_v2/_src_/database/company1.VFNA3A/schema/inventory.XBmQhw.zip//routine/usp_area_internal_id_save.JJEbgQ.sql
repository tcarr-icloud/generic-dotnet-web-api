CREATE PROCEDURE [inventory].[usp_area_internal_id_save]
	@id_area INT,
	@internal_id_area INT
AS
	/* update area. */
	BEGIN
		UPDATE inventory.area
		SET 
			internal_id_area=@internal_id_area
		WHERE id_area=@id_area
	END
go

