CREATE PROCEDURE [inventory].[usp_ride_status_list]
AS
	SELECT id_ride_status
			, name AS ride_status
			, reference AS ride_status_reference
	FROM inventory.ride_status
go

