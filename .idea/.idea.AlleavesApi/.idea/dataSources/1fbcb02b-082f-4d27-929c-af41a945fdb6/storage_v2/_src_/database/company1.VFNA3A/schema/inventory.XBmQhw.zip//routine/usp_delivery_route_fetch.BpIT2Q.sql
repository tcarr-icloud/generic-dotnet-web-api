CREATE PROCEDURE [inventory].[usp_delivery_route_fetch]
@id_delivery_route INT = NULL
AS
BEGIN
	SELECT
		id_delivery_route,
		biotrack_invtype_id
	FROM inventory.delivery_route
	WHERE id_delivery_route=@id_delivery_route
END
go

