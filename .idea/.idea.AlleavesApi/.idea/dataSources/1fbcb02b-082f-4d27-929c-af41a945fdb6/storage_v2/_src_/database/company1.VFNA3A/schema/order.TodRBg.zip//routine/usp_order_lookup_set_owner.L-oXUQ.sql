CREATE   PROCEDURE [order].[usp_order_lookup_set_owner]
	@id_order_lookup INT,
	@id_user INT,
	@takeover BIT = 0
AS
	DECLARE @claimed INT
	SET @claimed=(SELECT id_user_working FROM [order].order_lookup
					WHERE id_order_lookup=@id_order_lookup)

	if(@claimed IS NOT NULL AND @takeover=0) 
	BEGIN
		SELECT 0 AS rtn
		RETURN
	END
	
	UPDATE [order].[order_lookup] 
	SET id_user_working=@id_user,
		date_updated=getutcdate()
	WHERE id_order_lookup=@id_order_lookup 
	
	EXEC [order].usp_order_lookup_list @id_order_lookup
go

