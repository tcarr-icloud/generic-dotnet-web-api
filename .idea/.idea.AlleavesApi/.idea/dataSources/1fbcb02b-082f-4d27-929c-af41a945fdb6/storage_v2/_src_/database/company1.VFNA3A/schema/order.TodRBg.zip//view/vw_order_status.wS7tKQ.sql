CREATE VIEW [order].[vw_order_status] 

AS

SELECT o.id_order
	,o.metrc_receipt_id
    ,CAST(o.date_created AT TIME ZONE 'UTC' AT TIME ZONE ot.tz_windows as date) as Order_Date
    ,CAST(COALESCE(py.payment_date, o.date_created) AT TIME ZONE 'UTC' AT TIME ZONE rt.tz_windows as date) as Payment_Date
    ,r.id_register as Register_ID
	,c.name_first +  ' ' + c.name_last as customer
    ,c.id_customer ,c.date_created as Customer_Since 
    ,l.[name] as [Location] 
    ,o.void as Void 
    ,o.[type] as Order_Type 
    ,o.paid_in_full as Paid 
    ,st.[name] as [Status] 
    ,i.id_item 
    ,CAST(CASE WHEN i.id_item_return IS NOT NULL THEN 1 ELSE 0 END as bit) as [Return] 
    ,i.is_medicated as Medicated 
	,CASE 
		WHEN st.[name] = 'New' OR st.[name] = 'Processing' OR st.[name] = 'Packed' THEN 'Open'
		WHEN st.[name] = 'Completed' THEN 'Paid' 
	END AS order_status
    ,i.price as Gross 
    ,i.price_post_tax as GrossRevenue 
    ,i.price_post_order_discount as NetRevenue 
    ,o.tax
    ,o.total
    ,strain.[name] as Strain 
    ,icat.[name] as Item_Category 
    ,icat.[name] as Product_Category 
    ,CONCAT(ig.[name], ISNULL(' - ' + av.name, '')) as Item_Name 
    ,CONCAT(ig.[name], ISNULL(' - ' + av.name, '')) as Product_Name 
    ,b.[name] as Batch   
	,o.updated_by
	,lu.FirstName + ' ' + lu.LastName as last_updated_by
FROM [order].[order] o
LEFT OUTER JOIN [order].item i on o.id_order = i.id_order 
LEFT OUTER JOIN [order].[status] st on st.id_status = o.id_status 
LEFT OUTER JOIN inventory.batch as b ON b.id_batch = i.id_batch 
LEFT OUTER JOIN grow.strain as strain on b.id_strain = strain.id_strain 
LEFT OUTER JOIN inventory.area as a ON a.id_area = i.id_area 
LEFT OUTER JOIN inventory.item as it ON it.id_item = b.id_item 
LEFT OUTER JOIN inventory.item_group as ig on ig.id_item_group = it.id_item_group 
LEFT OUTER JOIN inventory.item_attribute_value as iav on iav.id_item = it.id_item 
LEFT OUTER JOIN inventory.attribute_value as av on av.id_attribute_value = iav.id_attribute_value 
LEFT OUTER JOIN inventory.category icat ON icat.id_category = ig.id_category AND icat.deleted = 0 
LEFT OUTER JOIN base.[location] as l ON o.id_location = l.id_location 
LEFT OUTER JOIN [base].[user] as lu on lu.id_user = o.updated_by
LEFT OUTER JOIN [order].customer as c ON o.id_customer = c.id_customer 
LEFT OUTER JOIN dbo.tz_lookup ot on ot.tz_iana = l.timezone
LEFT OUTER JOIN (SELECT id_register 
                    ,id_order 
                    ,id_session 
                    ,MAX(payment_date) as payment_date 
                    ,COUNT(DISTINCT id_order) as Transactions 
                    ,SUM(pvt.Cash) as Cash 
                    ,SUM(pvt.Change) as Change 
                    ,SUM(pvt.Cash) + ISNULL(SUM(pvt.Change),0) as CashIn  
                    ,SUM(pvt.CanPay) as CanPay 
                    ,SUM(pvt.Hypur) as Hypur 
                    ,SUM(pvt.[Loyalty Points]) as LoyaltyPoints 
                    ,SUM(pvt.[Store Credit]) as StoreCredit 
                    ,SUM(pvt.[Transact First]) as TransactFirst 
                    ,SUM(pvt.Tip) as Tip 
                FROM (SELECT p.id_register 
                        ,s.id_session 
                        ,p.id_order 
                        ,p.id_user_created as id_user_cashier 
                        ,p.date_created as payment_date 
                        ,method ,tendered 
                     FROM [order].payment p 
                     LEFT OUTER JOIN pos.[session] s on s.id_register = p.id_register AND p.date_created BETWEEN s.date_start AND ISNULL(s.date_end, GETDATE()) 
                     LEFT OUTER JOIN [order].[order] o on p.id_order = o.id_order 
                     WHERE o.void = 0) as src 
                PIVOT (SUM(tendered) 
                FOR method IN (Cash, Change, Hypur, CanPay, [Store Credit], [Loyalty Points], [Transact First], Tip)) as pvt 
                GROUP BY id_register, id_order, id_session) as py on py.id_order = o.id_order 
LEFT OUTER JOIN pos.register r on r.id_register = py.id_register 
LEFT OUTER JOIN base.[location] rl on rl.id_location = r.id_location
LEFT OUTER JOIN dbo.tz_lookup rt on rt.tz_iana = rl.timezone
WHERE o.void = 0
AND o.cancel = 0
go

