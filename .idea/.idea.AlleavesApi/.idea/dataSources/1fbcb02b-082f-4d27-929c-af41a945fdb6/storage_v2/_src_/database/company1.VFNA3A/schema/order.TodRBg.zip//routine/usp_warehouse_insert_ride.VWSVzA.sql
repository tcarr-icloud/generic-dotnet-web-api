CREATE PROCEDURE [order].[usp_warehouse_insert_ride]
	                    @id_warehouse INT,
	                    @id_ride INT
    AS
    BEGIN

        INSERT INTO [order].ride_warehouse (id_ride, id_warehouse) VALUES (@id_ride, @id_warehouse)
     END
go

