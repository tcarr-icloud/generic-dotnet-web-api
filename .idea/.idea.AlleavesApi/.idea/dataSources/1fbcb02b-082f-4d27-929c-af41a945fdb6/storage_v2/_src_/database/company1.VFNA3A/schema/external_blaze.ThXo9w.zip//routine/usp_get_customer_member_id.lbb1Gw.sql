CREATE PROCEDURE external_blaze.usp_get_customer_member_id
                @id_member VARCHAR(100)
AS
BEGIN
	SELECT id_customer
	FROM external_blaze.customer where id_member=@id_member
END
go

