
CREATE PROCEDURE [order].[usp_manifest_item_create]
	@id_manifest INT,
	@description VARCHAR(128),
	@quantity DECIMAL(18,4),
	@weight VARCHAR(32) = NULL
AS
	SET NOCOUNT ON;

	INSERT INTO [order].manifest_item (id_manifest, description, quantity, weight) VALUES
		(@id_manifest, @description, @quantity, @weight)
go

