
CREATE PROCEDURE [order].[usp_order_list_orig]
	@id_order INT = NULL,
	@id_customer INT = NULL,
	@only_open_orders BIT = 1,
	@limit_recently_closed BIT = 0
AS
--DECLARE	@id_order INT = 1146
--DECLARE	@id_customer INT = NULL
--DECLARE	@only_open_orders BIT = 0

	;WITH	area_path AS (
					SELECT a.*, CAST(a.name AS VARCHAR(MAX)) AS path
					FROM inventory.area a
					WHERE a.id_parent IS NULL
					UNION ALL
					SELECT b.*, CONCAT(p.path, ' > ', b.name) AS path
					FROM inventory.area b
					JOIN area_path p ON p.id_area=b.id_parent
				)

	SELECT o.id_order
			, o.id_order_online
			, l.id_location
			, c.id_customer
			, s.id_status
			, l.[name] as [location]
			, CONCAT(c.name_first, ' ', c.name_last) as name_full
			, c.patient_number
			, c.email
			, c.phone
			, s.[name] as [status]
			, o.paid_in_full
			, o.subtotal
			, o.tax
			, o.total
			, o.discount
			, o.complete
			, o.cancel
			, o.void
			, o.[type]
			, o.verified
			, o.scheduled
			, o.packed
			, o.apply_delivery_fee
			, o.delivery_fee
			, ISNULL((SELECT od.id_order
							, od.id_discount
							, dis.name AS discount
							, dis.code
							, dis.id_adjustment_type
							, dis.id_sale_type
							, a.name AS adjustment_type
							, a.reference AS adjustment_type_reference
							, st.name AS sale_type
							, st.reference AS sale_type_reference
							, dis.use_category_in_list
							, dis.use_product_in_list
							, dis.auto_apply
							, dis.apply_pre_tax
							, dis.apply_post_tax
							, dis.can_be_combined
							, dis.active
							, dis.num_uses
							, CAST(dis.date_valid_start AS VARCHAR(16)) AS date_valid_start
							, CAST(dis.date_valid_end AS VARCHAR(16)) AS date_valid_end
							, ISNULL((
								SELECT fc.id_discount
										, fc.id_category
								FROM discount.filter_category fc
								WHERE fc.id_discount=dis.id_discount
								FOR JSON PATH
							), '[]') AS filter_category_list
							, ISNULL((
								SELECT fp.id_discount
										, fp.id_item
								FROM discount.filter_product fp
								WHERE fp.id_discount=dis.id_discount
								FOR JSON PATH
							), '[]') AS filter_product_list
							, ISNULL(
								CASE WHEN a.reference='bulk' THEN
									(SELECT r.id_rule, r.id_discount, r.range_min, r.range_max, r.id_type, r.value, t.reference AS type_reference
									 FROM discount.rule_bulk r 
									 JOIN discount.type t ON t.id_type=r.id_type
									 WHERE r.id_discount=dis.id_discount
									 ORDER BY r.range_min
									 FOR JSON PATH)
								WHEN a.reference='bxgx' THEN
									(SELECT r.id_rule, r.id_discount, r.qty_bought, r.qty_discounted, r.id_type, r.value, t.reference AS type_reference
									 FROM discount.rule_bxgx r 
									 JOIN discount.type t ON t.id_type=r.id_type
									 WHERE r.id_discount=dis.id_discount
									 FOR JSON PATH)
								ELSE
									(SELECT r.id_rule, r.id_discount, r.id_type, r.value, t.reference AS type_reference
									 FROM discount.rule_basic r 
									 JOIN discount.type t ON t.id_type=r.id_type
									 WHERE r.id_discount=dis.id_discount
									 FOR JSON PATH)
								END
							, '[]') AS rule_list
					  FROM [discount].order_discount od
					  JOIN [discount].discount dis ON dis.id_discount=od.id_discount
					  JOIN discount.adjustment_type a ON a.id_adjustment_type=dis.id_adjustment_type
					  LEFT JOIN [order].sale_type st ON st.id_sale_type=dis.id_sale_type					  
					  WHERE od.id_order=o.id_order
					  FOR JSON PATH, INCLUDE_NULL_VALUES    
			), '[]') AS discount_list
			, ISNULL((SELECT oi.id_item
						, oi.id_order
						, pc.id_category
						, oi.id_batch
						, oi.id_area
						, CAST(CASE WHEN EXISTS (SELECT id_item FROM [order].item soi INNER JOIN [order].[order] so on soi.id_order = so.id_order WHERE soi.id_item_return = oi.id_item AND so.void = 0) THEN 1 ELSE 0 END as BIT) as returned
						, oi.id_item_return
						, oi.is_tax_exempt
						, oi.is_medicated
						, oi.thc
						, oi.thc_mg
						, oi.cbd
						, oi.cbd_mg
						, oi.strain
						, ISNULL(pc.name, 'Uncategorized') AS category
						, i.item
						, b.name AS batch
						, a.path AS area
						, COALESCE(oi.price, i.price_retail) AS price
						, oi.price_override
						, oi.price_override_otd
						, oi.price_override_reason
						, oi.ommu_order_type_name
						, oi.ommu_form_name
						, ISNULL(oi.price_post_item_discount, 0) as price_post_item_discount
						, ISNULL(oi.price_post_order_discount,0) as price_post_order_discount
						, ISNULL(oi.price_post_tax, 0) as price_post_tax
						, ISNULL(oi.discount, 0) as discount
			   FROM [order].[item] oi
			   LEFT JOIN inventory.vw_item_list i ON i.id_item=oi.id_inventory_item
			   LEFT JOIN inventory.category pc ON pc.id_category=i.id_category
			   LEFT JOIN inventory.batch b ON b.id_batch=oi.id_batch
			   LEFT JOIN area_path a ON a.id_area=oi.id_area
			   WHERE oi.id_order=o.id_order
			   FOR JSON PATH, INCLUDE_NULL_VALUES    
			   ), '[]') AS item_list,
			   ISNULL((
			   SELECT id_payment, id_order, method, tendered FROM [order].payment pay WHERE pay.id_order = o.id_order AND deleted = 0 FOR JSON PATH, INCLUDE_NULL_VALUES
			   ), '[]') as payment_list,
			   pk.pickup_date,
			   pk.pickup_time,
			   (
			   SELECT address1, address2, city, [state], zip, delivery_date 
							, a.id_driver1
							, a.id_driver2
							, a.id_vehicle
							, CASE WHEN u1.id_user IS NOT NULL THEN u1.FirstName+' '+u1.LastName ELSE NULL END AS driver1
							, d1.license AS driver1_license
							, CASE WHEN u2.id_user IS NOT NULL THEN u2.FirstName+' '+u2.LastName ELSE NULL END AS driver2
							, d2.license AS driver2_license
							, v.name AS vehicle
							, v.make
							, v.model
							, v.license AS vehicle_license
					FROM [order].[address] a
					LEFT JOIN [order].driver d1 ON d1.id_driver=a.id_driver1
					LEFT JOIN [order].driver d2 ON d2.id_driver=a.id_driver2
					LEFT JOIN base.[user] u1 ON u1.id_user=d1.id_user
					LEFT JOIN base.[user] u2 ON u2.id_user=d2.id_user
					LEFT JOIN [order].vehicle v ON v.id_vehicle=a.id_vehicle
					WHERE id_order = o.id_order 
					FOR JSON PATH) as delivery_address
    FROM [order].[order] o	
	LEFT OUTER JOIN [order].[customer] c on c.id_customer=o.id_customer
	LEFT OUTER JOIN [base].[location] l on l.id_location=o.id_location
	LEFT OUTER JOIN [order].[status] s on s.id_status=o.id_status
	LEFT OUTER JOIN [order].[address] d on d.id_order=o.id_order
	LEFT OUTER JOIN [order].pickup pk on pk.id_order = o.id_order
    WHERE o.id_customer=ISNULL(@id_customer, o.id_customer) AND
		  o.id_order=ISNULL(@id_order, o.id_order) AND 
		  (		  
			(@only_open_orders=1) OR			
			(	
				@only_open_orders=0 AND 
				(
					o.complete=0 OR 
					(o.complete=1 AND o.date_updated>=CASE WHEN @limit_recently_closed=1 THEN DATEADD(day, -4, GETUTCDATE()) ELSE o.date_updated END)
				) AND
				(
					o.void=0 OR 
					(o.void=1 AND o.date_updated>=CASE WHEN @limit_recently_closed=1 THEN DATEADD(day, -4, GETUTCDATE()) ELSE o.date_updated END)
				)
			)
		  )
	ORDER BY o.date_created
go

