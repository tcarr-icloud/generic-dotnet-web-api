


CREATE PROCEDURE [inventory].[usp_area_list]
	@id_location INT = NULL,
	@id_area INT = NULL,
	@show_deleted BIT = 0
AS
	SET NOCOUNT ON;

	SELECT l.id_location
			, a.id_area
			, a.id_parent
			, atp.id_area_type
			, a.id_status
			, l.name AS location
			, a.name AS area
			, a.path AS area_path
			, st.name AS area_status
			, atp.name AS area_type
			, atp.reference AS area_type_reference
			, a.[rows]
			, a.[columns]
			, a.canopy_sqft
			, a.metrc_id
			, a.deleted
			, a.returnable
			, a.internal_id_area
			, a.priority
			, a.mobile
	FROM base.location l
	LEFT JOIN inventory.vw_area_list a ON a.id_location=l.id_location
	LEFT JOIN area_type atp ON atp.id_area_type=a.id_area_type
	LEFT JOIN status st ON st.id_status=a.id_status
	WHERE l.id_location=ISNULL(@id_location, l.id_location) 
			AND a.id_area=ISNULL(@id_area, a.id_area)
			AND a.deleted<=ISNULL(@show_deleted, 0)
	ORDER BY a.priority, l.name, a.path
go

