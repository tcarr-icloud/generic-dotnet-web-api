CREATE PROCEDURE [pos].[usp_closeout_data]
	@id_register INT,
	@id_user INT
AS
	--DECLARE @id_user INT = 2
	--DECLARE @id_register INT = 1000
	--DECLARE @balance_ending decimal(18,2) = 243243


	DECLARE @id_session INT = (SELECT TOP 1 id_session FROM [pos].[session] WHERE id_register = @id_register ORDER BY date_start DESC)
	PRINT @id_session

	SELECT s.id_session
			, s.balance_starting
			, ISNULL((SELECT * FROM (
					SELECT CONCAT(c.name_last, ', ', c.name_first) AS name
							, LOWER(p.method) AS type
							, CONCAT('Order #', p.id_order) AS detail
							, tendered AS amount
							, p.date_created
					FROM [order].payment p
					JOIN pos.session s ON s.id_register=p.id_register AND s.id_session=@id_session
					LEFT JOIN [order].[order] o ON o.id_order=p.id_order
					LEFT JOIN [order].customer c ON c.id_customer=o.id_customer
					WHERE p.date_created BETWEEN s.date_start AND ISNULL(s.date_end, getutcdate()) AND p.method IN ('cash', 'change')
					AND o.void = 0
						UNION ALL
					SELECT null AS name
							, 'withdrawal' AS type
							, null AS detail
							, w.amount * -1 AS amount
							, w.date_created
					FROM pos.withdrawal w
					WHERE w.id_session=@id_session
						UNION ALL
					SELECT null AS name
							, 'balance increase ' AS type
							, null AS detail
							, b.amount AS amount
							, b.date_created
					FROM pos.drawer_balance_increase b
					WHERE b.id_session=@id_session
				) t 
				ORDER BY t.date_created
				FOR JSON PATH
			), '[]') AS transaction_list
	FROM pos.session s
	WHERE s.id_session=@id_session
go

