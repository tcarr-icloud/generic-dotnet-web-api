CREATE PROCEDURE [order].[usp_delivery_route_position_update_single_ride]
					@id_delivery_route INT,
                    @id_ride INT,
                    @is_transfer BIT,
                    @position INT,
					@eta INT,
					@delivery_start_date varchar(50)=NULL
AS 
BEGIN
	if(@delivery_start_date IS NOT NULL)
		BEGIN
			UPDATE [order].delivery_route set delivery_start_date=@delivery_start_date WHERE id_delivery_route=@id_delivery_route
		END
	IF (@is_transfer = 1)
	    BEGIN
	    	UPDATE [order].[ride_transfer_delivery_route]
	      	SET position=@position,eta=@eta
	      	WHERE id_delivery_route=@id_delivery_route
	      	AND id_transfer = @id_ride
	    END
    ELSE
	    BEGIN
	    	UPDATE [order].[ride_delivery_route]
	      	SET position=@position,eta=@eta
	      	WHERE id_delivery_route=@id_delivery_route
	      	AND id_ride = @id_ride
	    END
END
go

