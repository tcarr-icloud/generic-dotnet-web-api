CREATE PROCEDURE [order].[usp_referral_method_create]
	@name VARCHAR(512)

AS
	IF EXISTS (SELECT * FROM [order].referral_method WHERE deleted=0 AND name=@name)
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A referral method with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	INSERT INTO [order].referral_method ([name]) VALUES (@name)

	DECLARE @id_referral_method INT = SCOPE_IDENTITY()

	EXEC [order].usp_referral_method_list @id_referral_method
go

