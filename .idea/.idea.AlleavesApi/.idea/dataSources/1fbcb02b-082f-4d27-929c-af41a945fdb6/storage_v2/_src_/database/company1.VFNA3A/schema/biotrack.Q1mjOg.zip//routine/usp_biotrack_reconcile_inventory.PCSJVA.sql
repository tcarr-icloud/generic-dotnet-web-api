CREATE PROCEDURE [biotrack].[usp_biotrack_reconcile_inventory]
	@item_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	DECLARE @id_item INT = NULL,
			@quantity DECIMAL(18,4),
			@id_batch INT = NULL,
			@batch VARCHAR(512),
			@cost_of_good DECIMAL(18,8),
			@biotrack_barcode_id VARCHAR(256) = NULL,
			@biotrack_inventory_type_id INT = NULL,
			@id_area INT = NULL,
			@variance DECIMAL(18,4) = NULL,
			@internal_id_area INT = NULL,
			@msg VARCHAR(MAX)

	/* loop through items in list. */
	DECLARE c CURSOR FOR (SELECT id_item, quantity, id_batch, batch, cost_of_good, biotrack_barcode_id, biotrack_inventory_type_id, id_area, variance, internal_id_area FROM OPENJSON(@item_list)
							WITH (
								id_item INT,
								quantity DECIMAL(18,4),
								id_batch INT,
								batch VARCHAR(512),
								cost_of_good DECIMAL(18,8),
								biotrack_barcode_id VARCHAR(256),
								biotrack_inventory_type_id INT,
								id_area INT,
								variance DECIMAL(18,4),
								internal_id_area INT
							))
	OPEN c
	FETCH NEXT FROM c INTO @id_item, @quantity, @id_batch, @batch, @cost_of_good, @biotrack_barcode_id, @biotrack_inventory_type_id, @id_area, @variance, @internal_id_area
	WHILE @@FETCH_STATUS = 0 BEGIN

		/* manage batch. */
		IF(@id_batch=-1)
		BEGIN
			IF(@batch IS NOT NULL AND EXISTS(SELECT * FROM inventory.batch WHERE name=@batch))
				SET @id_batch = (SELECT TOP 1 id_batch FROM inventory.batch WHERE name=@batch)
			ELSE
				BEGIN
				/* create new batch id or get default batch id if no batch is required. */
				EXEC @id_batch = inventory.usp_batch_create @id_item, NULL, NULL, NULL, NULL, NULL, NULL, @cost_of_good, @biotrack_barcode_id, @biotrack_inventory_type_id, NULL, NULL, @id_user
		
				/* update batch name if value is passd in. */
				IF(@batch IS NOT NULL)
					UPDATE inventory.batch SET name=@batch WHERE id_batch=@id_batch
			END
			
			/* add item to inventory. */
			SET @id_area = (SELECT TOP 1 id_area FROM inventory.area WHERE internal_id_area=@internal_id_area)
			IF @id_area IS NULL
			BEGIN
				SET @msg = 'For Batch Missing Biotrack Area Not Found, Sync Areas'
				RAISERROR(@msg, 11, 1)
				RETURN
			END
			EXEC [log].usp_event_create 'inventory_add', @id_batch, @id_area, @quantity, null, @id_user
		END
		ELSE IF (@id_batch!=-1)
		BEGIN
			EXEC [log].usp_event_create 'inventory_adjust', @id_batch, @id_area, @variance, null, @id_user, 1

			DECLARE @id_area_destination DECIMAL(18,4)
			SET @id_area_destination = (SELECT TOP 1 id_area FROM inventory.area WHERE internal_id_area=@internal_id_area)

			DECLARE @curr_val DECIMAL(18,4) = (SELECT TOP 1 quantity FROM inventory.inventory WHERE id_batch=@id_batch AND id_area=@id_area)
			DECLARE @quantity_neg DECIMAL(18,4)

			IF @id_area_destination IS NULL
			BEGIN
				SET @msg = 'For Exisiting Batch Biotrack Area Not Found, Sync Areas'
				RAISERROR(@msg, 11, 1)
				RETURN
			END

			IF @curr_val < @quantity
				SET @quantity = @curr_val

			IF @curr_val IS NOT NULL AND @quantity > 0 AND @id_area_destination!=@id_area
			BEGIN
				SET @quantity_neg = -@quantity

				/* move item. */
				EXEC [log].usp_event_create 'inventory_move', @id_batch, @id_area, @quantity_neg, NULL, @id_user, 1
				EXEC [log].usp_event_create 'inventory_move', @id_batch, @id_area_destination, @quantity, NULL, @id_user, 1
			END
		END

	FETCH NEXT FROM c INTO @id_item, @quantity, @id_batch, @batch, @cost_of_good, @biotrack_barcode_id, @biotrack_inventory_type_id, @id_area, @variance, @internal_id_area
	END

	CLOSE c
	DEALLOCATE c
go

