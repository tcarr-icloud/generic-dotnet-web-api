
create 
 procedure [order].ecommerce_ride_status_upsert @id_ride int = null,
       @reference varchar(100), @cancellation_note varchar(100)=null
as
declare
    @id_status int = (select id_status
                      from [order].ecommerce_ride_status
                      where reference = @reference)

insert into [order].ecommerce_ride_status_history (id_ride, id_ride_status,cancellation_note, created_at)
values (@id_ride, @id_status,isnull(@cancellation_note,null), getutcdate());

    exec [order].ecommerce_ride_list @id_ride;
go

