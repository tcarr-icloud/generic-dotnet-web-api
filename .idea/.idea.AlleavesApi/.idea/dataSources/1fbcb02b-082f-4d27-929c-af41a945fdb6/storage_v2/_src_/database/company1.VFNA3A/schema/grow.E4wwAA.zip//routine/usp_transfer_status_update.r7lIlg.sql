CREATE PROCEDURE [grow].[usp_transfer_status_update]
	@id_transfer INT,
	@id_transfer_status INT,
	@id_user INT,
	@return BIT = 1
AS
	INSERT INTO grow.transfer_status_history (id_transfer, id_transfer_status, id_user_verified)
	VALUES (@id_transfer, @id_transfer_status, @id_user)

	DECLARE @reference VARCHAR(128) = (SELECT reference FROM grow.transfer_status WHERE id_transfer_status=@id_transfer_status)

	IF(@reference='shipped' OR @reference='received')
		UPDATE grow.transfer 
		SET received=1 
		WHERE id_transfer=@id_transfer
	ELSE 
		UPDATE grow.transfer 
		SET received=0
		WHERE id_transfer=@id_transfer

	IF(@return=1)
		EXEC grow.usp_transfer_fetch @id_transfer
go

