
CREATE PROCEDURE [dbo].[usp_notifications_list]
    @id_user INT = null
AS
    SELECT *
    FROM base.user_notifications n
    WHERE id_user = ISNULL(@id_user, id_user)
go

