CREATE PROCEDURE [grow].[usp_transfer_status_list]
AS
	SELECT id_transfer_status
			, name AS transfer_status
			, reference AS transfer_status_reference
			, sequence
	FROM grow.transfer_status
go

