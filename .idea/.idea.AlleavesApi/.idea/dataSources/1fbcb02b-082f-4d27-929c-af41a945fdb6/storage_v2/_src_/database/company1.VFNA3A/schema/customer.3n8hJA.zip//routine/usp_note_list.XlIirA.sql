-- =============================================
-- Author:		Jeff Hanes
-- Create date: 2/23/2021
-- Description:	Returns list of customer notes
-- =============================================
CREATE PROCEDURE [customer].[usp_note_list]
	@id_customer INT,
	@id_note INT = NULL
AS
BEGIN
	SET NOCOUNT ON;
	SELECT
		 n.id_note
		,n.id_customer
		,n.[entry]
		,n.is_alert
		,n.deleted
		,n.date_created
		,n.date_updated
		,n.created_by
		,n.updated_by
		,CAST(n.date_created AT TIME ZONE 'UTC' AT TIME ZONE 'US Eastern Standard Time' AS DATE) AS create_date_est
		,CONCAT(c.FirstName, ' ', c.LastName) as created_by_name
		,CONCAT(u.FirstName, ' ', u.LastName) as updated_by_name
	FROM customer.note n
	INNER JOIN base.[user] c on n.created_by = c.id_user
	INNER JOIN base.[user] u on n.updated_by = u.id_user
	WHERE id_customer = @id_customer
	AND (@id_note IS NULL OR n.id_note = @id_note)
	AND n.deleted = 0
	ORDER BY n.date_created
END
go

