

CREATE 
 procedure [order].[usp_get_area_driver_info] @id_area int
AS
    SET NOCOUNT ON;

select u.id_user, u.fcm_tokens
from [inventory].area_driver
         join [order].driver on area_driver.id_driver = driver.id_driver
         join base.[user] u on driver.id_user = u.id_user
where id_area = @id_area
go

