CREATE PROCEDURE [metrc].[usp_tag_set_unavailable]
	@id_location INT,
	@tag VARCHAR(128)
AS
	UPDATE metrc.tag
	SET is_available = 0
		, date_used = ISNULL(date_used, GETUTCDATE())
	WHERE id_location=@id_location AND tag=@tag
go

