CREATE PROCEDURE [ommu].[usp_dispensation_list]
	@id_order int = NULL
AS
	SELECT DISTINCT od.[id_order],
		od.[ommu_dispensation_id],
		od.[ommu_order_id],
		od.[id_caregiver],
		od.[caregiver_name],
		od.[physician_name]
	FROM [ommu].[dispensation] od
	WHERE od.[id_order]=ISNULL(@id_order, od.[id_order])
go

