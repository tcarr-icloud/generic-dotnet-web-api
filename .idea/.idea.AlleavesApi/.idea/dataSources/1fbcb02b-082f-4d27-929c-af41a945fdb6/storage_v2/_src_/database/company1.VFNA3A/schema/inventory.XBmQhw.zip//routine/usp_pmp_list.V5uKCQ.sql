CREATE PROCEDURE [inventory].[usp_pmp_list]
 @id_pmp INT = NULL,
 @id_location INT = NULL,
 @deleted BIT = 0
AS
BEGIN
    IF @id_pmp IS NULL
    BEGIN
        SELECT p.id_pmp
            , p.id_location
            , p.enable_pmp
			, p.username
            , p.password
			, p.iv
			, p.auto_submit_time
            , p.deleted
        FROM [inventory].[pmp] p
        WHERE p.deleted = @deleted AND p.id_location = @id_location
    END
    ELSE
    BEGIN
       SELECT p.id_pmp
            , p.id_location
            , p.enable_pmp
			, p.username
            , p.password
			, p.iv
			, p.auto_submit_time
            , p.deleted
        FROM [inventory].[pmp] p
        WHERE p.id_pmp = @id_pmp
        AND p.deleted = @deleted
    END
END
go

