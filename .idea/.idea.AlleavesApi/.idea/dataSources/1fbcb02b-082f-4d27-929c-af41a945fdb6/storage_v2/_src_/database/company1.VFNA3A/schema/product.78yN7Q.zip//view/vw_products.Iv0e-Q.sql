CREATE VIEW [product].[vw_products]

AS
--push test
SELECT
	 i.id_item
	,i.id_order
	,i.id_inventory_item
	,p.id_category
	,p.item AS product_name
	,p.price_retail AS price
FROM [order].item i
LEFT JOIN inventory.vw_item_list p ON p.id_item = i.id_inventory_item AND p.deleted = 0
WHERE i.id_item_return IS NULL
go

