




CREATE VIEW [pos].[vw_session_z_out] AS
WITH session_cte as 
(
SELECT
	 l.name as [Location]
	,r.id_register
	,r.[name] as Register_Name
	,s.id_session
	,s.Session_Status
	,s.SessionIndex
	,s.Transactions
	,s.[Open]
	,s.[Open] + s.Cash - s.Deposits - s.Payouts as Expected
	,s.[Close] + s.[Close Deposits] as [Close]
	,(s.[Close] + s.[Close Deposits]) - (s.[Open] + s.Cash - s.Deposits - s.Payouts) as [Difference]
	,s.Cash
	,s.[Store Credit]
	,s.CanPay
	,s.Hypur
	,s.[Loyalty Points]
	,s.Deposits + s.[Close Deposits] as Deposits
	,s.Payouts
	,s.Open_Date AT TIME ZONE 'UTC' AT TIME ZONE 'US Eastern Standard Time' as Open_Date
	,CAST(s.Open_Date AT TIME ZONE 'UTC' AT TIME ZONE 'US Eastern Standard Time' as DATE) as [Date]
	,s.Open_Cashier
	,s.Close_Date AT TIME ZONE 'UTC' AT TIME ZONE 'US Eastern Standard Time' as Close_Date
	,s.Close_Cashier
FROM
(
	SELECT	
		 s.id_session
		,s.id_register
		,s.balance_starting as [Open]
		,s.balance_ending as [Close]
		,s.date_start as Open_Date
		,s.date_end	as Close_Date
		,CASE WHEN s.date_end IS NULL THEN 'Open' ELSE 'Closed' END as Session_Status
		,ISNULL(p.Transactions, 0) as Transactions
		,ISNULL(p.Cash,0) + ISNULL(p.Change,0) as Cash
		,ISNULL(p.[Store Credit],0) as [Store Credit]
		,ISNULL(p.CanPay,0) as CanPay
		,ISNULL(p.Hypur,0) as Hypur
		,ISNULL(p.[Loyalty Points],0) as [Loyalty Points]
		,ISNULL(w.Deposit,0) as Deposits
		,ISNULL(w.[Close Deposit],0) as [Close Deposits]
		,ISNULL(w.Payout, 0) as Payouts
		,CONCAT(op.FirstName, ' ', op.LastName) as Open_Cashier
		,CONCAT(cl.FirstName, ' ', cl.LastName) as Close_Cashier
		,ROW_NUMBER() OVER(PARTITION BY s.id_register ORDER BY s.date_start DESC) as SessionIndex
	FROM [pos].[session] s
	LEFT OUTER JOIN (
		SELECT 
			id_session, 
			COUNT(id_order) as Transactions,
			SUM(Cash) as Cash,
			SUM(Change) as Change,
			SUM(Hypur) as Hypur,
			SUM(CanPay) as CanPay,
			SUM([Store Credit]) as [Store Credit],
			SUM([Loyalty Points]) as [Loyalty Points]
		FROM
		(SELECT 
			 o.id_session
			,method
			,tendered
			,o.id_order
		FROM [order].payment p
		INNER JOIN [order].[order] o on p.id_order = o.id_order
		WHERE deleted = 0
		AND o.void = 0) as src
		PIVOT (
			SUM(tendered)
			FOR method IN (Cash, Change, Hypur, CanPay, [Store Credit], [Loyalty Points])
		) as pvt
		GROUP BY id_session
	) as p on p.id_session = s.id_session
	LEFT OUTER JOIN (
	SELECT * FROM 
	(
	SELECT id_session, CASE WHEN closing_deposit = 1 THEN 'Close Deposit' ELSE reason END as reason, amount as amount FROM pos.withdrawal
	) as src
	PIVOT (
		SUM(amount)
		FOR reason IN ([Close Deposit],[Deposit], [Payout])
	) as pvt
	) as w ON w.id_session = s.id_session
	LEFT OUTER JOIN [base].[user] op on op.id_user = s.id_user_start
	LEFT OUTER JOIN [base].[user] cl on cl.id_user = s.id_user_end
	WHERE s.id_session IS NOT NULL
) as s
LEFT OUTER JOIN [pos].[register] r on r.id_register = s.id_register
LEFT OUTER JOIN [base].[location] l on l.id_location = r.id_location
)
SELECT (SELECT Session_Status FROM session_cte WHERE id_register = c.id_register and SessionIndex = 1) as Register_Status, * FROM session_cte c
--GO

