
CREATE   PROCEDURE [dbo].[usp_unlock_user] @id_user int

AS
    SET NOCOUNT ON;

update [base].[user]
set
    AccessFailedCount = 0,
    LockoutEnabled =  0,
    LockoutEndDateUtc = null
WHERE [user].id_user = @id_user;
go

