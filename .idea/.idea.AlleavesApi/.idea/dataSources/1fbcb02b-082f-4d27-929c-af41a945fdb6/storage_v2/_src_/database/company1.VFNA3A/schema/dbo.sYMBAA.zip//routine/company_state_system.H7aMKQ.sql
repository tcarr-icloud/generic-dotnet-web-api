CREATE PROCEDURE [dbo].[company_state_system]
AS
	SET NOCOUNT ON;

SELECT * FROM [dbo].[state_system]
go

