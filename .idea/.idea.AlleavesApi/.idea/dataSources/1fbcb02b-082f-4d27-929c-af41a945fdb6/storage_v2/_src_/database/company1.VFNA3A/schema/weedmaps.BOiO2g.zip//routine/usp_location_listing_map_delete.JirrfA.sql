CREATE PROCEDURE [weedmaps].[usp_location_listing_map_delete]
  @id_listing INT
AS
BEGIN
  DELETE FROM weedmaps.location_listing_map
  WHERE id = @id_listing;
END
go

