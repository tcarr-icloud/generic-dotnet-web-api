CREATE PROCEDURE [pos].[usp_cashout_list]
	@id_session INT
AS
	SELECT *
	FROM [pos].[session]
	WHERE id_session = @id_session
go

