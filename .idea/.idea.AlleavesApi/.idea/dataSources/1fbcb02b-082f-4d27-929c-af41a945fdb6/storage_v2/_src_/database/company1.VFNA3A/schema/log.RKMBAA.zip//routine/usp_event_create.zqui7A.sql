CREATE PROCEDURE [log].[usp_event_create]
	@type_reference VARCHAR(128),
	@id_batch INT,
	@id_area INT,
	@adjustment DECIMAL(18,4),
	@notes VARCHAR(MAX) = NULL,
	@id_user INT,
	@prevent_negative BIT = 0
AS
	/* get type id from supplied reference. */
	DECLARE @id_type INT = (SELECT id_type FROM [log].[type] WHERE reference=@type_reference)
	DECLARE @msg VARCHAR(MAX)

	/* throw error if log event type is not found. */
	IF (@id_type IS NULL)
	BEGIN
		SET @msg = CONCAT('Not a valid log event type reference: "', ISNULL(@type_reference, 'NULL'), '"')
		RAISERROR(@msg, 11, 1)
		RETURN
	END


	/* open batch if it is currently closed. */
	-- TODO: revisit once metrc stuff has been looked into
	--IF @adjustment > 0 AND ((SELECT id_status FROM inventory.batch WHERE id_batch=@id_batch) <> 1)
	--BEGIN
	--	UPDATE inventory.batch SET id_status=1 WHERE id_batch=@id_batch
	--END


	/* get current value. */
	DECLARE @curr_val DECIMAL(18,4) = (SELECT TOP 1 quantity FROM inventory.inventory WHERE id_batch=@id_batch AND id_area=@id_area)

	IF @prevent_negative = 1 AND @curr_val + @adjustment < 0 AND @curr_val + @adjustment < @curr_val
	BEGIN
		IF @curr_val > 0
			SET @adjustment = -@curr_val
		ELSE
			RETURN
	END

	/* change inventory value based on adjustment. */
	IF (@curr_val IS NULL)
		INSERT INTO inventory.inventory (id_batch, id_area, quantity, id_user_created, id_user_updated)
		VALUES (@id_batch, @id_area, @adjustment, @id_user, @id_user)
	ELSE
		UPDATE inventory.inventory
		SET quantity = @curr_val + @adjustment
			, id_user_updated = @id_user
			, date_updated = GETUTCDATE()
		WHERE id_batch=@id_batch AND id_area=@id_area

	/* get current uom, item name, and category name. */
	DECLARE @id_uom INT,
			@item VARCHAR(256), 
			@category VARCHAR(256)
			
	SELECT @id_uom = ig.id_uom
			, @category = ISNULL(c.path, 'Uncategorized')
			, @item = RTRIM(CONCAT(ig.name, ' ', (
					SELECT STRING_AGG(av.name, ' ')
					FROM inventory.item_attribute_value iav
					LEFT JOIN inventory.attribute_value av ON av.id_attribute_value=iav.id_attribute_value
					WHERE iav.id_item=i.id_item)
				)) 
	FROM inventory.batch b
	JOIN inventory.item i ON i.id_item=b.id_item
	JOIN inventory.item_group ig ON ig.id_item_group=i.id_item_group
	LEFT JOIN inventory.vw_category_list c ON c.id_category=ig.id_category
	WHERE b.id_batch=@id_batch
	

	/* insert log event. */
	INSERT INTO [log].[event] (id_type, id_batch, id_area, item, category, original_quantity, adjustment, id_uom, notes, id_user_created)
	VALUES (@id_type, @id_batch, @id_area, @item, @category, ISNULL(@curr_val , 0), @adjustment, @id_uom, @notes, @id_user)
go

