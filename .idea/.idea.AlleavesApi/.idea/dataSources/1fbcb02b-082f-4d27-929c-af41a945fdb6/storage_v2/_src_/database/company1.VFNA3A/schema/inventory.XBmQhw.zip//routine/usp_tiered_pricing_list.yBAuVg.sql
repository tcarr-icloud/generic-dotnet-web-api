CREATE PROCEDURE [inventory].[usp_tiered_pricing_list]
 @id_tiered_pricing INT = NULL,
 @deleted BIT = 0
AS
BEGIN
    IF @id_tiered_pricing IS NULL
    BEGIN
        SELECT t.id_tiered_pricing
            , t.[name]
			, u.name as uom
			,u.name_short
			, u.id_uom
            , t.tier
			, t.enable_combined_tiers
            , t.enable_cumulative_weights
            , t.show_price_total
            , t.deleted
        FROM [inventory].[tiered_pricing] t
		LEFT JOIN inventory.uom u ON u.id_uom = t.id_uom
        WHERE t.deleted = @deleted
    END
    ELSE
    BEGIN
        SELECT t.id_tiered_pricing
            , t.[name]
			, u.name as uom
			,u.name_short
			, u.id_uom
            , t.tier
			, t.enable_combined_tiers
            , t.enable_cumulative_weights
            , t.show_price_total
            , t.deleted
        FROM [inventory].[tiered_pricing] t
		LEFT JOIN inventory.uom u ON u.id_uom = t.id_uom
        WHERE t.id_tiered_pricing = @id_tiered_pricing 
        AND t.deleted = @deleted
    END
END
go

