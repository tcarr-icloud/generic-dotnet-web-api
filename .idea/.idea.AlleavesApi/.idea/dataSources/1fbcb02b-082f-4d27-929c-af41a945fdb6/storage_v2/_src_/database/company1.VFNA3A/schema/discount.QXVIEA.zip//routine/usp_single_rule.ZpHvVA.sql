CREATE      PROCEDURE [discount].[usp_single_rule] @id_rule int
AS
SELECT [rules].[id],
       [rules].[enabled],
       [rules].[exclusive],
       [rules].[title],
       [rules].[priority],
       [rules].[filters],
       COALESCE([rules].[bundledFilters], [rules].filters) as bundledFilters,
       [rules].[conditions],
       [rules].[product_adjustments],
       [rules].[cart_adjustments],
       [rules].[buy_x_get_x_adjustments],
       [rules].[buy_x_get_y_adjustments],
       [rules].[bulk_adjustments],
       [rules].[set_adjustments],
       [rules].[other_discounts],
       [rules].[dateFrom],
       [rules].[dateTo],
       [rules].[usageLimit],
       [rules].[additional],
       [rules].[max_discount_sum],
       [rules].[advance_discount_message],
       [rules].[createdAt],
       [rules].[updatedAt],
       [rules].[deletedAt],
       [rules].[discount_type],
       [rules].[discount_options],
       [rules].[promotion_code],
       rules.exclude_sales_items,
       rules.auto_apply,
       rules.apply_pre_tax,
       rules.apply_post_tax,
       [discountTypeDetails].[columnName] AS [discountTypeDetails.columnName]
FROM [discount].[rules] AS [rules]
         LEFT OUTER JOIN [discount].[discount_types] AS [discountTypeDetails]
                         ON [rules].[discount_type] = [discountTypeDetails].[id] AND
                            ([discountTypeDetails].[deletedAt] IS NULL)
WHERE ([rules].[deletedAt] IS NULL AND [rules].[id] = @id_rule)
go

