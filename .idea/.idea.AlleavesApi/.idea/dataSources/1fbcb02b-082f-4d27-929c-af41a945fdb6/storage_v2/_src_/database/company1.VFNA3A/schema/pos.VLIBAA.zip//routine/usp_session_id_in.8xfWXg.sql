CREATE PROCEDURE pos.usp_session_id_in
                @id_session_string VARCHAR(MAX) = ''
AS
BEGIN
EXEC ('SELECT id_session,id_register,id_user_start,balance_starting,date_start,balance_ending,date_end FROM pos.session' +
    ' WHERE id_session IN ( '+ @id_session_string+')')
END
go

