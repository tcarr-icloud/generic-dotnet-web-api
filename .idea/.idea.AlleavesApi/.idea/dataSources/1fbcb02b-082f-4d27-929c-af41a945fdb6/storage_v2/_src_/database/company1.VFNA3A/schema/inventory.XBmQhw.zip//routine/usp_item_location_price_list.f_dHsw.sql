CREATE PROCEDURE [inventory].[usp_item_location_price_list]
	@id_inventory_item INT = NULL,
	@id_location INT = NULL,
	@is_adult_use BIT = 0,
	@is_medical_use BIT = 0
AS
	SET NOCOUNT ON;

	SELECT ilp.id_inventory_item
			, ilp.id_location
			, ilp.[use_type]
			, ilp.[is_adult_use]
			, ilp.[is_medical_use]
			, ilp.[location_price_of_good]
			, ilp.[location_retail_price]
			, ilp.[location_sale_price]
			, ilp.[location_flat_excise_tax]
			, l.name AS location
			, l.city
			, bs.name AS full_state_name
	FROM inventory.item_location_price ilp
	LEFT JOIN [base].[location] l ON ilp.id_location = l.id_location
	LEFT JOIN [base].[states] bs ON l.[state] = bs.[name]
	WHERE 
			(@id_location IS NULL OR ilp.id_location=@id_location) AND
			(@id_inventory_item IS NULL OR ilp.id_inventory_item=@id_inventory_item) AND
			(ilp.is_adult_use=@is_adult_use AND ilp.is_medical_use=@is_medical_use)
go

