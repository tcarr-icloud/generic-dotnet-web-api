CREATE PROCEDURE [grow].[usp_plant_move_grid]
	@id_plant INT,
	@row INT = NULL,
	@column INT = NULL,
	@id_user INT
AS
	DECLARE @id_area INT,
			@notes VARCHAR(512)

	/* get plant's current area. */
	SELECT @id_area = p.id_area
	FROM grow.plant p
	JOIN inventory.vw_area_list a ON a.id_area=p.id_area
	WHERE p.id_plant=@id_plant


	/* update plant. */
	UPDATE grow.plant 
	SET [row]=@row
		, [column]=@column
		, id_user_updated=@id_user
		, date_updated=GETUTCDATE()
	WHERE id_plant=@id_plant

	/* add event. */
	EXEC grow.usp_event_create 'move', @id_plant, @id_area, @row, @column, @notes, @id_user
go

