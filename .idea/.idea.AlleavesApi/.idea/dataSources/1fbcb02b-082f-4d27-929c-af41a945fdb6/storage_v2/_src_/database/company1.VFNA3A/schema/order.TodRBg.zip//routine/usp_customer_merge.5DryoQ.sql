CREATE PROCEDURE [order].[usp_customer_merge] 
	 @id_customer int
    ,@id_merging_customer int
    ,@id_user int
    ,@deleted_merge bit
AS
BEGIN
    SET NOCOUNT ON;
    IF @deleted_merge = 1
    BEGIN
        -- Update existing records in customer_merge where id_merging_customer matches id_customer
        UPDATE [order].customer_merge
        SET deleted_merge = 1, -- Set to true as per the new parameter
            date_updated = GETUTCDATE(), -- Update the date_updated to the current UTC date
            updated_by = @id_user -- Update the updated_by to the current user ID
        WHERE id_merging_customer = @id_merging_customer;
    END
    ELSE
    IF NOT EXISTS 
    (
        SELECT 1 FROM [order].customer_merge 
        WHERE id_customer = @id_customer AND 
              id_merging_customer = @id_merging_customer AND 
              deleted_merge = 0
    )
    BEGIN
        INSERT INTO [order].customer_merge(
            id_customer, 
            id_merging_customer, 
            deleted_merge, 
            date_created, 
            date_updated, 
            created_by, 
            updated_by
        )
        VALUES(
            @id_customer, 
            @id_merging_customer, 
            0, 
            GETUTCDATE(), 
            GETUTCDATE(),  
            @id_user, 
            @id_user
        );
    END

    UPDATE [order].customer
    SET deleted = 1
    WHERE id_customer = @id_merging_customer

    IF EXISTS 
    (
        SELECT 1 FROM [order].[queue]
        WHERE id_customer = @id_merging_customer AND time_out IS NULL
    )
	IF @id_customer IS NOT NULL
    BEGIN
        UPDATE [order].[queue]
        SET id_customer = @id_customer
        WHERE id_customer = @id_merging_customer 
        AND time_out IS NULL
        AND NOT EXISTS (
            SELECT 1 FROM [order].[queue]
            WHERE id_customer = @id_customer
            AND time_out IS NULL 
        )
    END
END
go

