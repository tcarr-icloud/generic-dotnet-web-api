CREATE PROCEDURE [dbo].[daily_category_account]
AS
	SET NOCOUNT ON;

SELECT t.[name] AS category, t.loc_name AS store_location, SUM(t.num) AS sold, SUM(t.revenue) AS pre_discount, SUM(t.post_discount) AS post_discount, SUM(t.discount) AS discount 
FROM (
	SELECT orders.*, products.id_item_group, products.id_category, products.[name] 
	FROM (
		SELECT g.*, (g.disc_rat * g.revenue) AS post_discount, ((1 - g.disc_rat) * g.revenue) AS discount 
		FROM (
			SELECT t1.id_order, t1.id_item, t1.revenue, t1.num, t2.order_date, t2.[name] AS loc_name, t2.id_location, t2.complete, t2.disc_rat 
			FROM (SELECT [id_order], id_item, SUM([price]) AS revenue, COUNT(*) AS num 
				FROM [order].[item]
				GROUP BY [id_order], id_item
			) t1
			INNER JOIN (
				SELECT [order].[order].[id_order], [order].date_created as [order_date], [order].[order].id_location, [base].[location].[name], [order].[order].complete, ([order].[order].total / [order].[order].subtotal) AS disc_rat 
				FROM [order].[order]
				LEFT JOIN [base].[location] ON [order].[order].id_location = [base].[location].id_location
			) t2 ON t1.id_order = t2.id_order
		) g
	) orders
	LEFT JOIN (
		SELECT prod.id_category, prod.id_item, prod.id_item_group, prod.category AS name
		FROM inventory.vw_item_list prod
	) products ON orders.id_item = products.id_item
) t
GROUP BY t.id_category, t.id_location, t.[name], t.loc_name
go

