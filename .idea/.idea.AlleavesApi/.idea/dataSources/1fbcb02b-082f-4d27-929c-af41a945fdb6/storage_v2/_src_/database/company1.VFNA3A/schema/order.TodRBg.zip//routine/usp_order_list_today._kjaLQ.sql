CREATE PROCEDURE [order].[usp_order_list_today] @id_order INT = NULL
	,@id_order_online VARCHAR(256) = NULL
	,@per_page INT = 100
	,@page INT = 1
	,@before DATETIME = NULL
	,@after DATETIME = NULL
	,@type VARCHAR(255) = NULL
	,@use_type VARCHAR(64) = NULL
	,@id_location INT = NULL
	,@id_customer INT = NULL
	,@id_status_include VARCHAR(MAX) = NULL
	,@id_item INT = NULL
	,@id_item_return INT = NULL
	,@external_only BIT = NULL
	,@id_inventory_item INT = NULL
	,@id_batch INT = NULL
	,@complete BIT = NULL
	,@void BIT = NULL
	,@cancel BIT = NULL
	,@paid_in_full BIT = NULL
	,@metrc_package_label VARCHAR(128) = NULL
	,@date_created DATETIME = NULL
AS

DECLARE @merge_id_customer INT = NULL

IF (@id_order IS NOT NULL)
BEGIN
	SET @page = 1
	SET @per_page = 1
	DECLARE @order_id_customer INT = (SELECT id_customer FROM [order].[order] WHERE id_order = @id_order)
	;WITH top_customer as 
	(
		SELECT id_customer, 1 as [lvl] FROM [order].customer_merge WHERE id_merging_customer = @order_id_customer AND deleted_merge = 0
		UNION ALL
		SELECT c.id_customer, p.lvl + 1 FROM [order].customer_merge c
		INNER JOIN [top_customer] p on p.id_customer = c.id_merging_customer
		WHERE c.deleted_merge = 0
	)
	SELECT TOP 1 @merge_id_customer=id_customer FROM top_customer ORDER BY lvl DESC
END

IF (
		@id_batch IS NULL
		AND @metrc_package_label IS NOT NULL
		)
BEGIN
	-- This is a problem we should only have one metrc package label per batch but we have dupes
	SET @id_batch = (
			SELECT id_batch
			FROM inventory.batch
			WHERE metrc_package_label = @metrc_package_label
			)
END

SELECT o.id_order
	,c.id_customer
	,o.id_external
	,o.id_order_online
	,o.id_location
	,o.id_status
	,o.id_session
	,c.patient_number
    ,c.name_first
    ,c.name_last
	,s.[name] AS [status]
	,o.[type]
	,o.[source]
	,o.[use_type]
	,o.auto_apply_discount_exclusions
	,l.[name] AS [location]
	,[order].fn_order_payment_json(o.id_order) AS payments
	,[order].fn_order_discount_json(o.id_order) AS discounts
	,ISNULL((
			SELECT address1
				,address2
				,city
				,[state]
				,a.zip
				,a.zip_four
				,a.note
				,delivery_date
				,a.id_driver1
				,a.id_driver2
				,a.id_vehicle
			    ,a.lat
			    ,a.long
				,CASE
					WHEN u1.id_user IS NOT NULL
						THEN u1.FirstName + ' ' + u1.LastName
					ELSE NULL
					END AS driver1
				,d1.license AS driver1_license
				,CASE
					WHEN u2.id_user IS NOT NULL
						THEN u2.FirstName + ' ' + u2.LastName
					ELSE NULL
					END AS driver2
				,d2.license AS driver2_license
				,v.name AS vehicle
				,v.make
				,v.model
				,v.license AS vehicle_license
			FROM [order].[address] a
			LEFT JOIN [order].driver d1 ON d1.id_driver = a.id_driver1
			LEFT JOIN [order].driver d2 ON d2.id_driver = a.id_driver2
			LEFT JOIN base.[user] u1 ON u1.id_user = d1.id_user
			LEFT JOIN base.[user] u2 ON u2.id_user = d2.id_user
			LEFT JOIN [order].vehicle v ON v.id_vehicle = a.id_vehicle
			WHERE id_order = o.id_order
			FOR JSON PATH
				,WITHOUT_ARRAY_WRAPPER
				,INCLUDE_NULL_VALUES 
			), '{}') AS delivery_address
	,r.id_ride
	,ISNULL((select FirstName from [base].[user] u LEFT JOIN [order].[driver] d on d.id_user=u.id_user where d.id_driver=r.id_driver),null) as driver
	,ISNULL((
			SELECT history.id_status_history
				,STATUS.customer_message
				,STATUS.driver_message
				,history.created_at
			FROM [order].ecommerce_ride ride
			JOIN [order].ecommerce_ride_status_history history ON ride.id_ride = history.id_ride
			JOIN [order].ecommerce_ride_status STATUS ON history.id_ride_status = STATUS.id_status
			WHERE ride.id_order = o.id_order
			ORDER BY history.created_at
			FOR JSON PATH
			), '[]') AS status_list
	,ISNULL((
			SELECT lo.id_loyalty_order
				,lo.id_offer_reward
				,lo.id_order
				,lo.amount
				,lo.redemption_type
				,lo.loyalty_vender
				,lo.loyalty_name
				,lo.redemption_url
				,lo.[expiry_date]
				,lo.discount_type
				,lo.item_value
				,lo.redeemed
			FROM [loyalty].[order] lo
			WHERE lo.id_order = @id_order
			FOR json path
			), '[]') AS loyalties
	,pu.pickup_date
	,pu.pickup_time
	,ISNULL(o.subtotal, 0) AS subtotal
	,ISNULL(o.discount, 0) AS discount
	,ISNULL(o.round_amount, 0) AS round_amount
	,ISNULL(o.loyalty, 0) AS loyalty
	,o.apply_delivery_fee
	,ISNULL(o.tax, 0) AS tax
	,ISNULL(o.state_tax, 0) AS state_tax
	,ISNULL(o.local_tax, 0) AS local_tax
	,ISNULL(o.excise_tax, 0) AS excise_tax
	,ISNULL(o.sales_tax, 0) AS sales_tax
	,ISNULL(o.state_tax_percentage, 0) AS state_tax_percentage
	,ISNULL(o.local_tax_percentage, 0) AS local_tax_percentage
	,ISNULL(o.excise_tax_percentage, 0) AS excise_tax_percentage
	,ISNULL(o.sales_tax_percentage, 0) AS sales_tax_percentage
	,ISNULL(o.total, 0) AS total
	,ISNULL(o.delivery_fee, 0) AS delivery_fee
	,o.[returns]
	,o.paid_in_full
	,CASE 
		WHEN paid_in_full = 1
			AND o.id_user_cashier IS NOT NULL
			THEN ISNULL(cashier.FirstName, '???') + ' ' + ISNULL(cashier.LastName, '???')
		WHEN paid_in_full = 1
			AND o.id_user_cashier IS NULL
			THEN (
					SELECT ISNULL(FirstName, '???') + ' ' + ISNULL(LastName, '???')
					FROM [base].[user]
					WHERE id_user = (
							SELECT TOP 1 id_user_created
							FROM [order].payment
							WHERE id_order = o.id_order
							)
					)
		ELSE NULL
		END AS cashier
	,o.date_paid
	,CAST(CASE
			WHEN o.complete = 1 THEN 1
			WHEN o.id_status = 4 THEN 1
			ELSE 0
			END AS BIT) AS complete
	,o.cancel
	,o.void
	,o.void_reason
	,o.void_reason_other
	,o.verified
	,o.verified_by
	,o.packed
	,o.packed_by
	,o.scheduled
	,o.scheduled_by
	,o.id_onfleet
	,o.metrc_receipt_id
	,ISNULL(o.ommu_dispensed, 0) AS ommu_dispensed
	,ISNULL(o.caregiver_purchase, 0) AS caregiver_purchase
	,o.id_caregiver
	,o.caregiver_name
	,o.caregiver_card_number
	,o.id_physician
	,o.physician_name
	,o.id_user_working
    ,o.discount_stack_order
	,o.date_created
	,o.created_by
	,ISNULL(uc.FirstName, '???') + ' ' + ISNULL(uc.lastname, '???') AS created_by_user
	,o.date_updated
	,o.updated_by
	,ISNULL(uu.FirstName, '???') + ' ' + ISNULL(uu.lastname, '???') AS updated_by_user
	,rs.ride_status
	,(select top 1 id_delivery_route from [order].[ride_delivery_route] where id_ride=r.id_ride order by id_ride_delivery_route desc) as id_delivery_route
	,(select delivery_start_time from [order].[delivery_route]  where id_delivery_route=(select top 1 id_delivery_route from [order].[ride_delivery_route] where id_ride=r.id_ride order by id_ride_delivery_route desc)) as delivery_start_time
	,(select top 1 position from [order].[ride_delivery_route] where id_ride=r.id_ride order by id_ride_delivery_route desc) as position
FROM [order].[order] o
LEFT OUTER JOIN [order].[pickup] AS pu ON pu.id_order = o.id_order
LEFT OUTER JOIN [order].[status] AS s ON s.id_status = o.id_status
LEFT OUTER JOIN [base].[location] AS l ON l.id_location = o.id_location
LEFT OUTER JOIN [order].[customer] AS c ON c.id_customer = COALESCE(@merge_id_customer, o.id_customer)
LEFT OUTER JOIN [base].[user] AS uc ON uc.id_user = o.created_by
LEFT OUTER JOIN [base].[user] AS uu ON uu.id_user = o.updated_by
LEFT OUTER JOIN [base].[user] AS cashier ON cashier.id_user = o.[id_user_cashier]
LEFT OUTER JOIN [order].ecommerce_ride r ON r.id_order = o.id_order
LEFT outer JOIN ( SELECT er.id_order, ers.driver_message AS ride_status FROM [order].ecommerce_ride er
			JOIN [order].ecommerce_ride_status_history erh ON erh.id_ride=er.id_ride
			JOIN [order].ecommerce_ride_status ers ON ers.id_status=erh.id_ride_status
			JOIN ( SELECT id_ride, MAX(created_at) AS created_at FROM [order].ecommerce_ride_status_history 
				GROUP BY id_ride) erht ON erht.id_ride=erh.id_ride AND erht.created_at=erh.created_at ) rs ON rs.id_order=o.id_order
WHERE (
		@before IS NULL
		OR o.date_created <= @before
		)
	AND (
		@after IS NULL
		OR o.date_created >= @after
		)
	AND (
		@external_only IS NULL
		OR @external_only = 0
		OR o.id_external IS NOT NULL
		)
	AND (
		@type IS NULL
		OR o.[type] = @type
		)
	AND (
		@use_type IS NULL
		OR o.[use_type] = @use_type
		)
	AND (
		@id_location IS NULL
		OR o.id_location = @id_location
		)
		AND (
		@date_created IS NULL
		OR CONVERT(VARCHAR(12), CAST(CAST(o.date_created AS DATETIME2(0)) AT TIME ZONE 'UTC' as DATETIME)) = (select CONVERT(VARCHAR(12), CAST(CAST(@date_created AS DATETIME2(0)) AT TIME ZONE 'UTC' as DATETIME)))
		)
	AND (
		@id_order IS NULL
		OR o.id_order = @id_order
		)
	AND (
		@id_order_online IS NULL
		OR o.id_order_online = @id_order_online
		)
	AND (
		@id_customer IS NULL
		OR o.id_customer = @id_customer
		)
	AND (
		@void IS NULL
		OR o.void = @void
		)
	AND (
		@cancel IS NULL
		OR o.cancel = @cancel
		)
	AND (
		@paid_in_full IS NULL
		OR o.paid_in_full = @paid_in_full
		)
	AND (
		@complete IS NULL
		OR o.complete = @complete
		)
	AND (
		@id_status_include IS NULL
		OR o.id_status IN (
			SELECT [value]
			FROM OPENJSON(@id_status_include, '$')
			)
		)
	AND (
		@id_inventory_item IS NULL
		OR o.id_order IN (
			SELECT id_order
			FROM [order].[item]
			WHERE id_inventory_item = @id_inventory_item
			)
		)
	AND (
		@id_batch IS NULL
		OR o.id_order IN (
			SELECT id_order
			FROM [order].[item]
			WHERE id_batch = @id_batch
			)
		)
	AND (
		@id_item IS NULL
		OR (
			@id_item_return IS NULL
			AND o.id_order IN (
				SELECT id_order
				FROM [order].[item]
				WHERE id_item = @id_item
				)
			)
		)

	AND (
		@id_item_return IS NULL
		OR (
			@id_item IS NULL
			AND o.id_order IN (
				SELECT id_order
				FROM [order].[item]
				WHERE id_item_return = @id_item_return
					AND (
						@id_order IS NULL
						OR id_order <> @id_order
						)
				)
			)
		)
	AND r.id_ride is not NUll
ORDER BY o.id_order DESC OFFSET(@page - 1) * @per_page ROWS

FETCH NEXT @per_page ROWS ONLY
OPTION (RECOMPILE)
go

