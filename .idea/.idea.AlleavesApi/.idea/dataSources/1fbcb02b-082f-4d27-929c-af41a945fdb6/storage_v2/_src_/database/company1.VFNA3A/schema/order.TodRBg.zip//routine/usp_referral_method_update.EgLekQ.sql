CREATE PROCEDURE [order].[usp_referral_method_update]
	@id_referral_method INT,
	@name VARCHAR(512),
	@deleted BIT = 0

AS
	IF EXISTS (SELECT * FROM [order].referral_method WHERE deleted=0 AND @deleted<>1 AND name=@name AND id_referral_method<>@id_referral_method)
	BEGIN
		DECLARE @msg VARCHAR(MAX) = 'A referral method with this name already exists. Cannot create duplicate.'
		RAISERROR(@msg, 11, 1)
		RETURN
	END

	UPDATE [order].referral_method
	SET 
		[name]=@name
	  , deleted = @deleted
	WHERE id_referral_method = @id_referral_method
	EXEC [order].usp_referral_method_list @id_referral_method, 1
go

