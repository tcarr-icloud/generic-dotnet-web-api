CREATE PROCEDURE [process].[usp_process_update_attribute]
	@id_process INT,
	@attribute_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	WITH attribute_list AS (
		SELECT @id_process AS id_process
				, id_process_attribute
				, id_form_attribute
				, value
		FROM OPENJSON(@attribute_list)
		WITH (
			id_process_attribute INT '$.id_process_attribute',
			id_form_attribute INT '$.id_form_attribute',
			value VARCHAR(128) '$.value'
		)
		WHERE value IS NOT NULL
	)

	MERGE process.process_attribute t
	USING attribute_list s
	ON t.id_process_attribute=s.id_process_attribute
	WHEN MATCHED THEN 
		UPDATE SET t.value=s.value, t.updated_by=@id_user, t.date_updated=getutcdate()
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_process, id_form_attribute, value, created_by, updated_by) VALUES (s.id_process, s.id_form_attribute, s.value, @id_user, @id_user)
	WHEN NOT MATCHED BY SOURCE AND t.id_process=@id_process THEN DELETE
	;

	EXEC process.usp_process_list @id_process
go

