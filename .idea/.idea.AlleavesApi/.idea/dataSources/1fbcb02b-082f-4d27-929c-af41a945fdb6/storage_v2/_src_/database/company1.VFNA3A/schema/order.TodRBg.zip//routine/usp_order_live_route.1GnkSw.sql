CREATE PROCEDURE [order].[usp_order_live_route]
    @id_location INT = NULL,
    @delivery_date DATE = NULL,
    @id_driver INT = NULL,
	@id_user int =null
AS
	BEGIN
	IF(@id_location IS NULL)
	BEGIN
		SET @id_location=(select id_location from [order].driver where id_user=@id_user)
	END
    SELECT
        dr.id_delivery_route,
        dr.id_driver,
        driver_user.FirstName + ' ' + driver_user.LastName AS driver_name,
        d.lat,
        d.long,
        d.id_user AS id_user_alleaves,
		delivery_start_time,
		delivery_start_date,
		delivery_end_eta,
        ISNULL((
            SELECT rdr.id_ride,
                   rdr.eta,
                   er.id_order,
                   er.delivery_date AS date,
                   rdr.position,
				   a.lat,a.long,er.delivered_time,
				   a.address1,a.address2,a.city,a.[state],a.zip,d.id_user,
                   (
                       SELECT TOP 1 ers.driver_message
                       FROM [order].ecommerce_ride_status_history history
                       JOIN [order].ecommerce_ride_status ers ON ers.id_status = history.id_ride_status
                       WHERE rdr.id_ride = history.id_ride
                       ORDER BY history.created_at DESC
                   ) AS last_ride_status,
				   (
                       SELECT TOP 1 history.cancellation_note
                       FROM [order].ecommerce_ride_status_history history
                       WHERE rdr.id_ride = history.id_ride
                       ORDER BY history.created_at DESC
                   ) AS cancellation_note
            FROM [order].[ride_delivery_route] rdr
            INNER JOIN [order].ecommerce_ride er ON rdr.id_ride = er.id_ride
			INNER JOIN [order].[address] a ON a.id_order = er.id_order
			left join [order].[driver] d on d.id_driver=er.id_driver
            WHERE rdr.id_delivery_route = dr.id_delivery_route 
            FOR JSON PATH
        ), '[]') AS ride_list,
        ISNULL((
            SELECT dt.id_transfer,
                   dt.eta,
                   t.date_created AS date,				   
                   dt.position,d.id_user,
                   (
                       SELECT TOP 1 s.name
                       FROM [inventory].transfer_status_history history
                       JOIN [inventory].transfer_status s ON s.id_transfer_status = history.id_transfer_status
                       WHERE dt.id_transfer = history.id_transfer
                       ORDER BY id_transfer_status_history DESC
                   ) AS last_transfer_status,
				   ISNULL((
						SELECT  l.name,address,city,state,postal_code from [base].location l where l.id_location=t.id_location_source
						FOR JSON PATH
					), '[]') AS source_address,
					ISNULL((
					SELECT  l.name,address,city,state,postal_code from [base].location l where l.id_location=t.id_location_destination
					FOR JSON PATH
				), '[]') AS destination_address
				   
            FROM [order].[ride_transfer_delivery_route] dt
            INNER JOIN [inventory].[transfer] t ON dt.id_transfer = t.id_transfer
			left join [order].[driver] d on d.id_driver=t.id_driver1
            WHERE dt.id_delivery_route = dr.id_delivery_route 
            FOR JSON PATH
        ), '[]') AS transfer_list
    FROM [order].[delivery_route] dr
    JOIN [order].driver d ON d.id_driver = dr.id_driver
    LEFT JOIN base.[user] driver_user ON d.id_user = driver_user.id_user
    WHERE (@id_driver IS NULL OR dr.id_driver = @id_driver) 
END
go

