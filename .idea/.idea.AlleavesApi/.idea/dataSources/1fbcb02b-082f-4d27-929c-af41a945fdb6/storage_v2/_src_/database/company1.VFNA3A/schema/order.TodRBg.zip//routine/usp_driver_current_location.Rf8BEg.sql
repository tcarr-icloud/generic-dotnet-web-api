
CREATE PROCEDURE [order].[usp_driver_current_location]
	 @id_driver_list varchar(200) = NULL
	,@id_location int = null
AS
    select id_driver,lat,long from [order].[driver] where id_driver in (SELECT * FROM STRING_SPLIT(@id_driver_list,',')) and id_location=@id_location
go

