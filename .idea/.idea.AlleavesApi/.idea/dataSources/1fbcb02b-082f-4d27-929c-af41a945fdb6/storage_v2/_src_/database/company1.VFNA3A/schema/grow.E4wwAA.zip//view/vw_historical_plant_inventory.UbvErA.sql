CREATE VIEW [grow].[vw_historical_plant_inventory]

AS

SELECT  
     MIN(pp.date_started) as [birthdate]
    ,l.[name] as [location] 
	,p.[name] as inventory_id
	,s.[name] as strain
	,ph.[name] as phase
	,a.[name] as room
	,CASE WHEN p.is_mother = 'true' THEN 'Yes' ELSE 'No' END as mother
	,COUNT(p.[name]) as total_plant_count
	,CASE WHEN ph.[name] = 'harvested' THEN COUNT(p.[name]) ELSE '' END as total_harvested
	,CASE WHEN ph.[name] = 'flowering' THEN COUNT(p.[name]) ELSE '' END as total_flowering
	,CASE WHEN ph.[name] = 'seedling' THEN COUNT(p.[name]) ELSE '' END as total_seedling
	,CASE WHEN ph.[name] = 'vegetative' THEN COUNT(p.[name]) ELSE '' END as total_vegetative
FROM [inventory].[batch] b
JOIN [grow].[batch_plant] bp on bp.id_batch = b.id_batch
JOIN [grow].[plant] p on p.id_plant = bp.id_plant
JOIN [grow].[plant_phase] pp on pp.id_plant = p.id_plant 
JOIN [grow].[phase] ph on ph.id_phase = pp.id_phase
JOIN [inventory].[area] a on a.id_area = p.id_area
JOIN [grow].[strain] s on s.id_strain = p.id_strain
JOIN [base].[location] l on l.id_location = a.id_location
GROUP BY l.[name], p.[name], s.[name], ph.[name], a.[name], p.is_mother
go

