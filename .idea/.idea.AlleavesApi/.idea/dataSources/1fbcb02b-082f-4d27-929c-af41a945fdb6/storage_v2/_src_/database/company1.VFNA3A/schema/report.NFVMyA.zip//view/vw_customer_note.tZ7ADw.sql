

-------------------------------------------------------------------------------------
---Customer Note Events--------------------------------------------------------------

CREATE VIEW [report].[vw_customer_note]
	AS 

SELECT 
	cn.[id_note]
	,cn.[created_by] as 'id_created_by'
	,buc.[FirstName] + ' ' + buc.[LastName] as 'created_by'
	,cn.[updated_by] as 'id_updated_by'
	,buu.[FirstName] + ' ' + buu.[LastName] as 'updated_by'
    ,cn.[id_customer]
	,oc.[name_first] + ' ' + oc.[name_last] as 'customer'
    ,cn.[entry]
    ,cn.[is_alert]
    ,cn.[deleted]
	,cn.[date_created] as 'UTC_created_datetime'
	,cn.[date_updated] as 'UTC_updated_datetime'

FROM [customer].[note] cn
	LEFT OUTER JOIN [base].[user] buu on cn.[updated_by] = buu.[id_user]
	LEFT OUTER JOIN [base].[user] buc on cn.[created_by] = buc.[id_user]
	LEFT OUTER JOIN [order].[customer] oc on cn.[id_customer] = oc.[id_customer]
go

