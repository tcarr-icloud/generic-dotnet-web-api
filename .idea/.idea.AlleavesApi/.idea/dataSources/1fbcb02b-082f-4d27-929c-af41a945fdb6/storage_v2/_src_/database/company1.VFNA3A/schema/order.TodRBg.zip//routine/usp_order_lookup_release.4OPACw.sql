CREATE   PROCEDURE [order].[usp_order_lookup_release]
	@id_order_lookup INT,
	@id_user INT
AS
	UPDATE [order].[order_lookup] 
	SET id_user_working=null,
		date_updated=getutcdate()
	WHERE id_order_lookup=@id_order_lookup AND
		  id_user_working=@id_user


	EXEC [order].usp_order_lookup_list @id_order_lookup
go

