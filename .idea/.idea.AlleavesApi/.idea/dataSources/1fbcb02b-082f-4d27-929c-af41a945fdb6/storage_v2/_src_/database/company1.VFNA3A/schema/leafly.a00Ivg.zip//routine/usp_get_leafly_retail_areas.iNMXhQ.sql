CREATE PROCEDURE [leafly].[usp_get_leafly_retail_areas]
	@id_location INT
AS
	SELECT mra.id_location,
		mra.id_area,
		ia.[name] as area,
		mra.active
	FROM [leafly].[menu_retail_area] mra
	LEFT JOIN [inventory].[area] ia ON ia.id_area = mra.id_area
	WHERE mra.id_location = @id_location AND ia.deleted = 0 AND mra.active = 1
go

