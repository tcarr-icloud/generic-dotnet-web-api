CREATE PROCEDURE [order].[usp_get_order_timestamp]
	@id_order INT
AS
	SELECT ts AS timestamp
	FROM [order].[order]
	WHERE id_order = @id_order
go

