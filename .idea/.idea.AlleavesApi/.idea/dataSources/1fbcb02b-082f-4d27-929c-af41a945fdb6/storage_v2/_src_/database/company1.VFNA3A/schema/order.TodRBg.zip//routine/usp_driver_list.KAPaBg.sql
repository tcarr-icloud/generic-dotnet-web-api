CREATE PROCEDURE [order].[usp_driver_list]
	@id_driver INT = NULL,
	@include_all_users BIT = 1,
	@id_location INT = NULL
AS
	SELECT u.id_user AS id_user_alleaves
			, d.id_driver
			, l.id_location
			, u.FirstName AS name_first
			, u.LastName AS name_last
	     	, u.Email as email
	        , u.PhoneNumber as phone_number
	        , u.UserName as user_name
			, d.license
	     	, d.lat
	        , d.long
	        , d.journey_started
			, l.name AS location
			, u.internal_employee_id
			, u.employee_id
			, u.id_user
	FROM base.[user] u 
	LEFT JOIN [order].driver d ON d.id_user=u.id_user
	LEFT JOIN base.location l ON l.id_location=d.id_location
	WHERE 
		(
			(@id_driver IS NOT NULL AND d.id_driver=@id_driver) OR
			(
				@id_driver IS NULL AND 
				1=(CASE WHEN @include_all_users=0 AND d.license IS NULL THEN 0 ELSE 1 END) AND 
				u.id_user<>-1
			)
		) AND
		u.deleted = 0 AND
		(@id_location IS NULL OR l.id_location = @id_location)
	ORDER BY d.id_driver
go

