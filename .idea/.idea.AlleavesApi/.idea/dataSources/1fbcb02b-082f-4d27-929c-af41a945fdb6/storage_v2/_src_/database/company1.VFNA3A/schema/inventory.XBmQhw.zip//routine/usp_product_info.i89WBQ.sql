CREATE PROCEDURE [inventory].[usp_product_info] AS 
SELECT
	 i.id_item
	,i.barcode
	,i.sku
	,i.price_retail
	,i.deleted
	,ig.id_item_group
	,CONCAT(ig.[name], ISNULL(' - ' + av.[name], '')) as item
	,ig.dosage_recommended 
	,c.[name] as category
	,u.[name] as uom
	,b.[name] as brand
	,bt.id_batch
	,bt.date_production as batch_production
	,bt.date_expire as batch_expire
	,bt.[name] as batch_barcode
	,bt.metrc_package_label
	,bt.vendor_batch_id
	,i.metrc_category
	,um.[name] as metrc_uom
FROM inventory.item i
LEFT OUTER JOIN inventory.item_group ig on i.id_item_group = ig.id_item_group
LEFT OUTER JOIN inventory.item_group_attribute iga on ig.id_item_group = iga.id_item_group
LEFT OUTER JOIN inventory.item_attribute_value iav on i.id_item = iav.id_item
LEFT OUTER JOIN inventory.attribute_value av on av.id_attribute_value = iav.id_attribute_value
LEFT OUTER JOIN inventory.category c on ig.id_category = c.id_category
LEFT OUTER JOIN inventory.uom u on u.id_uom = ig.id_uom
LEFT OUTER JOIN inventory.brand b on b.id_brand = ig.id_brand
LEFT OUTER JOIN inventory.batch bt on bt.id_item = i.id_item
LEFT OUTER JOIN inventory.uom um on um.id_uom = bt.id_uom_metrc
WHERE ig.is_product = 1
go

