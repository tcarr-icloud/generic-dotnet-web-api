CREATE PROCEDURE [metrc].[usp_summary]
    @id_export INT
AS
    SELECT 
        e.source_address,
        e.source_city,
        e.source_state,
        e.source_postal_code,
        e.destination_address,
        e.destination_city,
        e.destination_postal_code,
        e.notes,
        e.date_created,
        e.date_completed,
        e.id_export,
        s.name AS status_name,
        b.name AS batch_name,
        i.id_batch,
        i.quantity,
        ISNULL(b.cost_of_good, it.cost_of_good) AS cost_of_good,
        ISNULL(il.price_wholesale, it.price_wholesale) AS price_wholesale,
        ig.name AS item_name,
        ba.name AS source_location_name,
        ISNULL(bs.name, v.name) as destination_location_name
    from metrc.export e
    JOIN metrc.export_item i ON e.id_export=i.id_export
    JOIN base.location ba ON ba.id_location=e.id_location_source
    LEFT JOIN base.location bs ON bs.id_location=e.id_location_destination
    LEFT JOIN inventory.vendor va ON va.id_vendor=e.id_location_destination
    JOIN inventory.batch b ON b.id_batch=i.id_batch
    JOIN inventory.item it ON it.id_item=b.id_item
    JOIN inventory.status s ON s.id_status=b.id_status
    JOIN inventory.item_group ig ON ig.id_item_group=it.id_item_group
    LEFT JOIN inventory.vendor v ON v.id_vendor=e.id_vendor_destination
    LEFT JOIN inventory.item_location il ON il.id_location=bs.id_location AND il.id_item = it.id_item
    WHERE e.id_export=@id_export
go

