CREATE PROCEDURE [grow].[usp_nutrient_add]
	@id_batch INT,
	@id_area INT,
	@quantity DECIMAL(18,4),
	@plant_list VARCHAR(MAX) = '[]',
	@id_user INT
AS
	DECLARE @id_nutrient INT

	/* create plant list. */
	SELECT * INTO #plant_list
	FROM (
		SELECT p.id_plant
				, p.id_area
				, p.[row]
				, p.[column]
		FROM OPENJSON(@plant_list)
		WITH (
			id_plant INT
		) l
		JOIN grow.plant p ON p.id_plant=l.id_plant
	) t

	/* create nutrient action. */
	INSERT INTO grow.nutrient (id_batch, quantity, id_user_created)
	VALUES (@id_batch, @quantity, @id_user)

	SET @id_nutrient = SCOPE_IDENTITY()

	/* add plants to nutrient action. */
	INSERT INTO grow.nutrient_plant (id_nutrient, id_plant)
	SELECT @id_nutrient AS id_nutrient
			, id_plant
	FROM #plant_list

	/* add log event. */
	DECLARE @notes VARCHAR(255) = CONCAT('NutrientID: ', CAST(@id_nutrient AS VARCHAR(16)))

	DECLARE @adjustment DECIMAL(18,4) = -@quantity
	EXEC [log].usp_event_create 'nutrient_apply', @id_batch, @id_area, @adjustment, @notes, @id_user

	DECLARE @list_create VARCHAR(MAX) = (SELECT id_plant, id_area, [row], [column], @notes AS notes FROM #plant_list FOR JSON PATH)
	EXEC grow.usp_event_create_bulk 'nutrient', NULL, NULL, NULL, NULL, @list_create, @id_user


	/* return nutrient. */
	SELECT n.id_nutrient
			, g.id_item_group
			, i.id_item
			, g.name AS item
			, n.quantity
			, u.name AS uom
			, g.nutrient_type
			, g.nutrient_application_device
			, v.name AS vendor
			, ISNULL((
				SELECT ig.name
						, ig.percentage
				FROM inventory.item_group_nutrient_ingredient ig
				WHERE ig.id_item_group=g.id_item_group
				FOR JSON PATH
			), '[]') AS nutrient_ingredient_list
			, ISNULL((
				SELECT p.id_plant
						, p.name AS plant
						, p.metrc_label
						, p.metrc_batch
						, p.metrc_id
				FROM grow.plant p
				JOIN grow.nutrient_plant np ON np.id_plant=p.id_plant
				WHERE np.id_nutrient=n.id_nutrient
				FOR JSON PATH
			), '[]') AS plant_list
	FROM grow.nutrient n
	JOIN inventory.batch b ON b.id_batch=n.id_batch
	JOIN inventory.item i ON i.id_item=b.id_item
	JOIN inventory.item_group g ON g.id_item_group=i.id_item_group
	JOIN inventory.uom u ON u.id_uom=g.id_uom
	LEFT JOIN inventory.vendor v ON v.id_vendor=g.id_vendor
	WHERE n.id_nutrient=@id_nutrient
go

