CREATE PROCEDURE [base].[usp_user_delete]
    @id_user_modified_by INT, 
    @id_user INT
AS
BEGIN
    UPDATE base.[user]
    SET deleted = 1 
    WHERE id_user = @id_user

    EXEC [base].usp_user_insert_history @id_user, 'DELETE'

    EXEC base.usp_user_list @id_user, 1
END
go

