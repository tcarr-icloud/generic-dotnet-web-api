CREATE PROCEDURE [order].[usp_order_item_list]
	@id_order INT = NULL
AS
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET ANSI_WARNINGS OFF;

DECLARE @_id_order INT = @id_order

SELECT _oi.id_item_return
	,COUNT(_o.id_order) AS [returns]
INTO #return_orders_cte
FROM [order].[order] AS _o
INNER JOIN [order].item _oi ON _o.id_order = _oi.id_order
WHERE _oi.id_item_return IN (
		SELECT id_item
		FROM [order].item
		WHERE id_order = @_id_order
		)
	AND _o.void = 0
	AND _o.cancel = 0
	AND _o.id_status IN (
		SELECT id_status
		FROM [order].[status]
		WHERE [name] <> 'Cancelled'
		)
GROUP BY _oi.id_item_return
HAVING COUNT(_o.id_order) > 0

SELECT d.id_item
	,d.id_item_discount
	,d.id_discount
	,d.id_rule
	,d.amount
	,d.line_item_discount
	,COALESCE(dis.code, r.title) AS title
	,CASE 
		WHEN dt.columnName = 'cart_adjustments'
			THEN JSON_VALUE(r.cart_adjustments, '$.label')
		WHEN dt.columnName = 'product_adjustments'
			THEN JSON_VALUE(r.product_adjustments, '$.label')
		WHEN dt.columnName = 'bulk_adjustments'
			THEN JSON_VALUE(r.bulk_adjustments, '$.label')
		WHEN dt.columnName = 'set_adjustments'
			THEN JSON_VALUE(r.set_adjustments, '$.label')
		WHEN dt.columnName = 'buy_x_get_y_adjustments'
			THEN JSON_VALUE(r.buy_x_get_y_adjustments, '$.label')
		WHEN dt.columnName = 'buy_x_get_x_adjustments'
			THEN JSON_VALUE(r.buy_x_get_x_adjustments, '$.label')
		END AS [label]
INTO #discount_cte
FROM [order].item_discount d
LEFT OUTER JOIN discount.discount dis ON d.id_discount = dis.id_discount
LEFT OUTER JOIN discount.rules r ON r.id = d.id_rule
LEFT OUTER JOIN discount.discount_types dt ON dt.id = r.discount_type
WHERE EXISTS (
		SELECT 1
		FROM [order].item _doi
		INNER JOIN [order].[order] _do ON _do.id_order = _doi.id_order
		WHERE _doi.id_item = d.id_item
			AND _do.id_order = @_id_order
		)

SELECT doi.id_item
	,(
		SELECT id_item_discount
			,id_discount
			,id_rule
			,amount
			,title
			,[label]
			,line_item_discount
		FROM #discount_cte
		WHERE id_item = doi.id_item
		FOR JSON PATH
			,INCLUDE_NULL_VALUES
		) AS discounts
INTO #discount_json_cte
FROM [order].[order] do
INNER JOIN [order].item doi ON doi.id_order = do.id_order
WHERE do.id_order = @_id_order

SELECT oi.id_item
	,oi.id_inventory_item
	,ISNULL(oi.id_inventory_item_category, (
			SELECT TOP 1 id_category
			FROM inventory.category
			WHERE LOWER([name]) = 'uncategorized'
			)) AS id_inventory_item_category
	,dr2.id_delivery_route AS id_delivery_route2
	,dr2.[name] AS delivery_route2
	,i.item_group
	,i.item
	,i.category_path as inventory_category_path
	,u.name AS uom
	,u.name_short AS uom_short
	,i.weight_useable_uom
	,i.weight_useable_uom_short
	,oi.id_batch
	,oi.id_area
	,a.[name] AS area
	,b.[name] AS batch
	,b.manufactured_by
	,b.metrc_package_label
	,b.[name] AS batch_split
	,b.biotrack_barcode_id
	,b.biotrack_inventory_type_id
	,it.vt_product_number
	,it.vt_product_name
	,it.vt_product_type
	,it.vt_business_name
	,oi.id_item_return
	,oi.discount
	,oi.discount_overrides
	,oi.taxable_discount
	,oi.sku
	,ISNULL(oi.loyalty, 0) AS loyalty
	,oi.quantity
	,oi.rounded_quantity
	,oi.price
	,ISNULL(iil.cost_of_good, i.cost_of_good) AS cost_of_good
	,oi.price_override
	,oi.price_override_otd
	,oi.price_override_reason
	,oi.price_post_item_discount
	,oi.price_post_item_loyalty
	,oi.price_post_order_discount
	,oi.price_post_order_loyalty
	,oi.price_post_round
	,oi.price_post_all_adjustments
	,oi.price_post_tax
	,oi.item_state_excise_tax_percentage
	,oi.item_local_excise_tax_percentage
	,oi.item_state_sales_tax_percentage
	,oi.item_local_sales_tax_percentage
	,oi.item_state_category_tax_percentage
	,oi.item_local_category_tax_percentage
	,oi.is_tax_exempt
	,i.is_cannabis
	,ISNULL(i.is_adult_use, 0) AS is_adult_use
	,ISNULL(i.is_medical_use, 0) AS is_medical_use
	,oi.taxes
	,oi.id_tax_category
	,st.id_strain
	,st.[name] as strain
	,oi.inventory_category
	,oi.inventory_brand
	,oi.use_scale
	,CAST(CASE 
			WHEN returned_orders.[returns] > 0
				THEN 1
			ELSE 0
			END AS BIT) AS returned
	,ISNULL(discount.discounts, '[]') AS discounts
	,ISNULL((
			SELECT li.id_loyalty_item
				,li.id_offer_reward
				,li.id_order_item
				,li.amount
				,li.redemption_type
				,li.loyalty_vender
				,li.loyalty_name
				,li.expiry_date
				,li.discount_type
				,li.redeemed
				,li.item_value
			FROM [loyalty].[item] li
			WHERE li.id_order_item = oi.id_item
			FOR json path
			), '[]') AS loyalties
	,oi.thc
	,oi.cbd
	,oi.thc_mg
	,oi.cbd_mg
	,oi.item_thc
	,oi.item_cbd
	,oi.item_thc_mg
	,oi.item_cbd_mg
	,bt.total_thc as biotrack_thc
	,bt.total_cbd as biotrack_cbd
	,bt.thca as biotrack_thca
	,bt.cbda as biotrack_cbda
	,i.id_brand
	,oi.inventory_brand as brand
	,i.id_vendor
	,oi.inventory_vendor
	,i.weight_useable
	,i.id_uom_weight_useable
	,it.weight_net
	,it.id_uom_weight_net
	,it.gross_weight_useable
	,it.id_uom_gross_weight_useable
	,oi.inventory_uom_type
	,i.id_delivery_route
	,dr.[name] AS delivery_route
	,drp.name AS delivery_route_parent
	,ISNULL(i.is_low_thc, 0) AS is_low_thc
	,ISNULL(i.is_medicated, 0) AS is_medicated
	,ISNULL(i.is_smoking, 0) AS is_smoking
	,ISNULL(i.is_low_thc_and_medical, 0) AS is_low_thc_and_medical
	,i.id_ommu_form
	,ISNULL(i.is_ommu_delivery_device, 0) AS is_ommu_delivery_device
	,CASE 
		WHEN i.id_ommu_form IS NULL
			OR oi.ommu_form_name IS NOT NULL
			THEN oi.ommu_form_name
		ELSE i.ommu_form_name
		END AS ommu_form_name
	,oi.ommu_order_type_name
	,CAST(ISNULL(ig.is_ommu_delivery_device, 0) AS BIT) AS is_ommu_delivery_device
	,i.item_barcode
	,b.date_expire
	,cinv.on_hand
	,cinv.available
FROM [order].[item] oi
LEFT OUTER JOIN inventory.vw_item_list i ON oi.id_inventory_item = i.id_item
LEFT OUTER JOIN inventory.item it ON oi.id_inventory_item = it.id_item
LEFT OUTER JOIN inventory.item_group ig ON ig.id_item_group = it.id_item_group
LEFT OUTER JOIN grow.strain st on st.id_strain = ig.id_strain
LEFT OUTER JOIN inventory.uom u ON u.id_uom = i.id_uom
LEFT OUTER JOIN inventory.area a ON a.id_area = oi.id_area
LEFT OUTER JOIN inventory.batch b ON b.id_batch = oi.id_batch
LEFT OUTER JOIN biotrack.biotrack_test_result bt ON bt.id_batch = oi.id_batch
LEFT OUTER JOIN inventory.delivery_route dr ON dr.id_delivery_route = i.id_delivery_route
LEFT OUTER JOIN inventory.category c ON c.id_category = oi.id_inventory_item_category
LEFT OUTER JOIN inventory.delivery_route dr2 ON dr2.id_delivery_route = c.id_delivery_route
LEFT OUTER JOIN inventory.delivery_route drp ON drp.id_delivery_route = dr.id_parent
LEFT OUTER JOIN [inventory].[item_location] iil ON iil.id_item = oi.id_inventory_item
	AND iil.id_location = a.id_location
LEFT OUTER JOIN #return_orders_cte AS returned_orders ON returned_orders.id_item_return = oi.id_item
LEFT OUTER JOIN #discount_json_cte discount ON discount.id_item = oi.id_item
/* required for vermont integration. */
LEFT OUTER JOIN (
	SELECT id_batch, id_location, SUM(on_hand) AS on_hand, sum(available) AS available
	FROM inventory.vw_current_inventory inv
	GROUP BY id_batch, id_location
) cinv ON cinv.id_batch=b.id_batch AND cinv.id_location=a.id_location
WHERE oi.id_order = @_id_order
go

