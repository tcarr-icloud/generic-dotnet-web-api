CREATE PROCEDURE [grow].[usp_strain_delete]
	@id_strain INT,
	@id_user INT
AS
	UPDATE grow.strain
	SET deleted = 1
		, updated_by = @id_user
		, date_updated = getutcdate()
	WHERE id_strain = @id_strain
go

