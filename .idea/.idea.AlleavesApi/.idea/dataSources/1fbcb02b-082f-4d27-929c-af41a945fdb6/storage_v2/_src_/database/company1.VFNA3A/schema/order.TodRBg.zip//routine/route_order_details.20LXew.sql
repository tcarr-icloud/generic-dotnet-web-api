CREATE PROCEDURE [order].[route_order_details]
@id_route int = null

AS 
SELECT o.id_order,c.name_first,c.name_last,a.address1 AS address,a.address2 ,a.city ,a.state,a.zip,a.zip_four,a.lat,a.long,er.delivery_date,er.delivered_time,rdr.eta,dr.delivery_start_date FROM [order].[order] o 
INNER JOIN [order].ecommerce_ride er ON er.id_order = o.id_order 
INNER JOIN [order].address a ON a.id_order = o.id_order 
INNER JOIN [order].customer c ON o.id_customer = c.id_customer 
INNER JOIN [order].ride_delivery_route rdr ON rdr.id_ride = er.id_ride  
INNER JOIN [order].delivery_route dr ON dr.id_delivery_route = rdr.id_delivery_route
WHERE dr.id_delivery_route = ISNULL(@id_route,null)
go

