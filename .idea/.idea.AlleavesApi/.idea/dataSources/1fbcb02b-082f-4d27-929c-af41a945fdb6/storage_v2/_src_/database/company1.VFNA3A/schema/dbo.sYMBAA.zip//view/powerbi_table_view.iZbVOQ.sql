CREATE    VIEW dbo.powerbi_table_view
AS
SELECT [order].vw_order_items.product_category AS category,
       [order].vw_order_items.product,
       COUNT([order].vw_order_items.product) AS Quantity,
       avg([order].vw_order_items.price) as [standard price],
       SUM([order].vw_order_items.price_post_tax) AS [Sales Total],
       COUNT(DISTINCT [order].vw_order_items.id_order) AS [Number of Tickets],
             [order].vw_order_items.order_date_utc, vo.location
FROM   [order].vw_order_items INNER JOIN
             [order].payment AS p ON [order].vw_order_items.id_order = p.id_order INNER JOIN
             [order].vw_orders AS vo ON [order].vw_order_items.id_order = vo.id_order
GROUP BY [order].vw_order_items.product, [order].vw_order_items.product_category, [order].vw_order_items.order_date_utc, vo.location
go

