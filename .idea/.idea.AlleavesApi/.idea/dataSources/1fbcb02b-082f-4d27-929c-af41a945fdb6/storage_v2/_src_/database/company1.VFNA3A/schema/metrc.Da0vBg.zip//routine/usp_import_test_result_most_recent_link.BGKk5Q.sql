CREATE PROCEDURE [metrc].[usp_import_test_result_most_recent_link]
	@metrc_test_result VARCHAR(512),
	@metrc_state VARCHAR(256)
AS
	SELECT TOP 1 id_chemical_profile
	FROM inventory.test_result_chemical_profile
	WHERE metrc_state = @metrc_state AND metrc_test_result = @metrc_test_result
	ORDER BY date_created DESC
go

