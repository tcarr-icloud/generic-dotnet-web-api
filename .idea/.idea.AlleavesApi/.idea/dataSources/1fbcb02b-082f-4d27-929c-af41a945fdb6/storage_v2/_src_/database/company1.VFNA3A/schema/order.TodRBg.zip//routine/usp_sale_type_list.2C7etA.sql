CREATE PROCEDURE [order].[usp_sale_type_list]

AS
	SELECT id_sale_type
			, name AS sale_type
			, reference AS sale_type_reference
	FROM [order].sale_type
go

