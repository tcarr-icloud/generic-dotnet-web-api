CREATE PROCEDURE [metrc].[usp_crawl_import]
	@id_location INT,
	@manifest_list VARCHAR(MAX) = '[]',
	@package_list VARCHAR(MAX) = '[]'
AS
	/* upsert manifests. */
	MERGE metrc.crawler_manifest t
	USING (SELECT * FROM OPENJSON(@manifest_list)
		WITH (
			manifest_number VARCHAR(128),
			shipper VARCHAR(256),
			shipper_facility VARCHAR(64),
			package_count INT,
			date_received DATETIME
		)
	) as s
	ON t.manifest_number=s.manifest_number AND t.id_location=@id_location
	WHEN MATCHED THEN UPDATE
		SET t.shipper=s.shipper
			, t.shipper_facility=s.shipper_facility
			, t.package_count=s.package_count
			, t.date_received=s.date_received
			, t.date_updated=GETUTCDATE()
	WHEN NOT MATCHED BY TARGET THEN 
		INSERT (id_location, manifest_number, shipper, shipper_facility, package_count, date_received)
		VALUES (@id_location, s.manifest_number, s.shipper, s.shipper_facility, s.package_count, s.date_received)
	;

	/* upsert packages. */
	MERGE metrc.crawler_package t
	USING (SELECT * FROM OPENJSON(@package_list)
		WITH (
			package VARCHAR(128),
			is_open BIT,
			manifest_number VARCHAR(128),
			transfer_quantity DECIMAL(18,4),
			transfer_cost DECIMAL(18,4)
		)
	) as s
	ON t.package=s.package AND t.id_location=@id_location --AND (t.manifest_number = s.manifest_number OR (t.manifest_number IS NULL AND s.manifest_number IS NULL) OR (t.manifest_number IS NULL AND s.manifest_number IS NOT NULL AND t.imported=0))
	WHEN MATCHED THEN UPDATE
		SET t.manifest_number=ISNULL(s.manifest_number, t.manifest_number)
			, t.is_open=ISNULL(s.is_open, t.is_open)
			, t.transfer_quantity=ISNULL(s.transfer_quantity, t.transfer_quantity)
			, t.transfer_cost=ISNULL(s.transfer_cost, t.transfer_cost)
			, t.date_updated=GETUTCDATE()
			-- clear out automatic system user import if package is part of a manifest
			, t.imported = (CASE WHEN t.id_user_imported=-1 AND ISNULL(s.manifest_number, t.manifest_number) IS NOT NULL THEN 0 ELSE t.imported END)
			, t.date_imported = (CASE WHEN t.id_user_imported=-1 AND ISNULL(s.manifest_number, t.manifest_number) IS NOT NULL THEN NULL ELSE t.date_imported END)
			, t.id_user_imported = (CASE WHEN t.id_user_imported=-1 AND ISNULL(s.manifest_number, t.manifest_number) IS NOT NULL THEN NULL ELSE t.id_user_imported END)
	WHEN NOT MATCHED BY TARGET AND s.is_open=1 THEN
		INSERT (id_location, package, manifest_number, transfer_quantity, transfer_cost)
		VALUES (@id_location, s.package, s.manifest_number, s.transfer_quantity, s.transfer_cost)
	;

	/* mark packages created at facility as imported if quantity exists. */
	UPDATE p
	SET p.imported=1
		, p.date_imported=inv.date_created
		, p.id_user_imported = -1
	FROM metrc.crawler_package p
	JOIN inventory.batch b ON b.metrc_package_label=p.package
	JOIN inventory.inventory inv ON inv.id_batch=b.id_batch AND inv.quantity > 0
	WHERE p.imported=0 AND p.manifest_number IS NULL
go

