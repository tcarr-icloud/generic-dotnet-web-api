CREATE PROCEDURE [alpineiq].[usp_get_apikeys]
	@id_location INT 
AS
	SELECT 
		l.id_location, 
		l.[name] as [location],
		a.[key]
	FROM [base].[location] as l
	LEFT OUTER JOIN alpineiq.apikey as a on a.id_location = l.id_location
	WHERE (@id_location IS NULL OR l.id_location = @id_location)
	AND l.active = 1;
go

