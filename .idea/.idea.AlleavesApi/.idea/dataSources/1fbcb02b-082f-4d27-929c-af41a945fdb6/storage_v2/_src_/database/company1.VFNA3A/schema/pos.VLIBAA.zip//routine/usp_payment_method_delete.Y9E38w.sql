CREATE PROCEDURE [pos].[usp_payment_method_delete]
	@id_payment_method INT
AS
	DELETE FROM [pos].[payment_methods] WHERE id_payment_method = @id_payment_method
go

