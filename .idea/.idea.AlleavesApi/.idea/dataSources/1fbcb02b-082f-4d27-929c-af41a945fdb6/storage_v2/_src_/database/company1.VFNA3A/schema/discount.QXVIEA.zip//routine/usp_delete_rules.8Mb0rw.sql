CREATE PROCEDURE [discount].[usp_delete_rules]
	@id_rule_list VARCHAR(max),
	@id_user INT
AS

UPDATE [discount].[rules]
SET 
	[deletedAt]=getutcdate(),
	[id_user_updated] = @id_user
WHERE ([id] in (SELECT [value] FROM OPENJSON(@id_rule_list, '$')))
go

