CREATE PROCEDURE [order].[usp_sale_limit_delete]
	@id_sale_limit INT,
	@id_user INT
AS
	UPDATE [order].sale_limit
	SET deleted=1
		, id_user_updated=@id_user
		, date_updated=GETUTCDATE()
	WHERE id_sale_limit=@id_sale_limit

	EXEC [order].usp_sale_limit_list @id_sale_limit, NULL, 1
go

