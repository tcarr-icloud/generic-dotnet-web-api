-- =============================================
-- Author:		Jeff
-- Create date: 2/23/2021
-- Description:	
-- =============================================
CREATE PROCEDURE [customer].[usp_note_create] 
	@id_customer int,
	@entry varchar(max),
	@is_alert bit,
	@id_user int
AS
BEGIN
	SET NOCOUNT ON;
	--DECLARE @id_customer INT = 19858
	--DECLARE @entry varchar(max) = 'test' 
	--DECLARE @is_alert bit = 0
	--DECLARE @id_user int = 2

	INSERT INTO customer.note (id_customer, [entry], is_alert, created_by, updated_by)
	values(@id_customer, @entry, @is_alert, @id_user, @id_user)
	
	DECLARE @id_note INT = scope_identity()
	
	EXEC customer.usp_note_list @id_customer, @id_note
END
go

