CREATE PROCEDURE [ommu].[usp_form_list]
	
AS

SELECT o.id_form 
		,o.[name] as ommu_form
FROM [ommu].[form] o
ORDER BY o.[name]
go

