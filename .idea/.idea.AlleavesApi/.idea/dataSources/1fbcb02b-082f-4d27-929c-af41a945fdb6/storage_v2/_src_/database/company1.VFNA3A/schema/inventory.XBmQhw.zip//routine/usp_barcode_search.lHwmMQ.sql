CREATE PROCEDURE [inventory].[usp_barcode_search] (
	@barcode VARCHAR(max),
	@id_location INT
) as 
	DECLARE @id_item INT, @id_batch INT, @id_area INT

	/* Find the item */

	/* By SKU */
	--PRINT 'Finding By SKU'
	SELECT TOP 1 @id_item=i.id_item 
	FROM inventory.item i 
	LEFT OUTER JOIN inventory.item_group ig on i.id_item_group = ig.id_item_group
	WHERE i.sku = @barcode

	/* By Item Barcode */
	IF(@id_item IS NULL)
	BEGIN 
		--PRINT 'Finding By Item Barcode'
		SELECT TOP 1 @id_item=i.id_item FROM inventory.item i 
		LEFT OUTER JOIN inventory.item_group ig on i.id_item_group = ig.id_item_group
		WHERE i.barcode = @barcode
		AND i.deleted = 0
		AND ig.deleted = 0
	END

	/* By Batch Barcode */
	IF(@id_item IS NULL)
	BEGIN 
		--PRINT 'Finding By Batch'
		SELECT TOP 1 @id_item=i.id_item, @id_batch=b.id_batch
		FROM inventory.item i 
		LEFT OUTER JOIN inventory.item_group ig on i.id_item_group = ig.id_item_group
		LEFT OUTER JOIN inventory.batch b on i.id_item = b.id_item
		LEFT OUTER JOIN inventory.inventory as inv on inv.id_batch = b.id_batch
		LEFT OUTER JOIN inventory.area as a on a.id_area = inv.id_area
		LEFT OUTER JOIN inventory.area_type as aty on aty.id_area_type = a.id_area_type
		LEFT OUTER JOIN [base].[location] l on a.id_location = l.id_location
		WHERE b.[name] = @barcode
		AND i.deleted = 0
		AND ig.deleted = 0
		AND inv.quantity > 0
		AND aty.[name] = 'retail'
		AND l.id_location = @id_location
	END

	/* By Vender Batch Barcode */
	IF(@id_item IS NULL)
	BEGIN 
		--PRINT 'Finding By Vendor Batch'
		SELECT TOP 1 @id_item=i.id_item, @id_batch=b.id_batch
		FROM inventory.item i 
		LEFT OUTER JOIN inventory.item_group ig on i.id_item_group = ig.id_item_group
		LEFT OUTER JOIN inventory.batch b on i.id_item = b.id_item
		LEFT OUTER JOIN inventory.inventory as inv on inv.id_batch = b.id_batch
		LEFT OUTER JOIN inventory.area as a on a.id_area = inv.id_area
		LEFT OUTER JOIN inventory.area_type as aty on aty.id_area_type = a.id_area_type
		LEFT OUTER JOIN [base].[location] l on a.id_location = l.id_location
	 WHERE b.vendor_batch_id = @barcode
        AND i.deleted = 0
        AND ig.deleted = 0
        AND inv.quantity > 0
        AND aty.[name] = 'retail'
        AND l.id_location = @id_location
END

	/* By Metrc Package Label */
	IF(@id_item IS NULL)
	BEGIN 
		--PRINT 'Finding By Metrc Package Label'
		SELECT TOP 1 @id_item=i.id_item, @id_batch = b.id_batch
		FROM inventory.item i 
		LEFT OUTER JOIN inventory.item_group ig on i.id_item_group = ig.id_item_group
		LEFT OUTER JOIN inventory.batch b on i.id_item = b.id_item
		LEFT OUTER JOIN inventory.inventory as inv on inv.id_batch = b.id_batch
		WHERE b.metrc_package_label = @barcode
		AND i.deleted = 0
		AND ig.deleted = 0
		AND inv.quantity > 0
	END

	IF(@id_item IS NULL)
	BEGIN
		--PRINT 'Not Found'
		return;
	END
	ELSE
	BEGIN
		/* Find Area */
		SELECT TOP 1 
			  @id_area=a.id_area
			 ,@id_batch=ISNULL(@id_batch, b.id_batch)
		FROM inventory.inventory inv
		LEFT OUTER JOIN inventory.batch b on inv.id_batch = b.id_batch
		LEFT OUTER JOIN inventory.area a on inv.id_area = a.id_area		
		LEFT OUTER JOIN inventory.area_type aty on aty.id_area_type = a.id_area_type
		WHERE b.id_item = @id_item
		AND (@id_batch IS NULL OR b.id_batch = @id_batch)
		AND aty.[reference] = 'retail'
		AND @id_location = a.id_location
		AND inv.quantity > 0

		EXEC inventory.usp_inventory_list @id_item=@id_item,@id_batch=@id_batch,@id_area=@id_area
	END
go

